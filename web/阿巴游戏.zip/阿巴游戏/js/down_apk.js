var apk = document.getElementById('down-apk');
    apk.onclick = function(){
        window.location.href='app/app.apk';
    };
    

