the trex runner game abstracted from chrome offline err page.

![chrome offline game cast](img/chrome_offline_game.gif)