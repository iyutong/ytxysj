

var testFunction = {
	
	test1:function(){
		//....
	},
	test2:function(){
		//....
	}
}



