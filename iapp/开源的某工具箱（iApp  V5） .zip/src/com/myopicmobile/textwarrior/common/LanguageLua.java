/*
 * Copyright (c) 2013 Tah Wei Hoon.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Apache License Version 2.0,
 * with full text available at http://www.apache.org/licenses/LICENSE-2.0.html
 *
 * This software is provided "as is". Use at your own risk.
 */
package com.myopicmobile.textwarrior.common;

/**
 * Singleton class containing the symbols and operators of the Javascript language
 */

public class LanguageLua extends Language {
	private static Language _theOne = null;
	private final static String keywordTarget ="addv()|aslist()|bfm()|bfms()|bfv()|bfvs()|bfvss()|bfs()|bly()|blp()|btoo()|cls()|clssm()|call()|cast()|dslist()|dha()|dhs()|dht()|dhr()|dhset()|dhas()|dhast()|dh()|dh()|dhon()|dhb()|else()|else f()|end()|ends()|endutw()|f()|for()|fd()|fe()|fs()|fr()|fc()|fw()|fl()|ft()|fdir()|fuz()|fuzs()|fo()|fj()|fi()|ftz()|gvs()|gslist()|gslistl()|gslistsz()|gslistis()|gslistiof()|gslistlof()|git()|hs()|hd()|hw()|hws()|huf()|hdfl()|hdfla()|hdd()|hdda()|hddg()|hdds()|hdduigo()|hsas()|has()|java()|javax()|javanew()|javacb()|javags()|javass()|json()|lan()|loadso()|loadjar()|nsz()|nvw()|nuibs()|ngde()|otob()|res()|s()|ss()|sss()|syso()|s2()|sn()|sr()|sj()|sl()|siof()|slof()|ssg()|slg()|strim()|slower()|supper()|stop()|sran()|sssz()|sgszl()|stobm()|sutf8to()|sbp()|sdeg()|sxb()|shb()|sslist()|sit()|sjxx()|simsi()|simei()|swh()|se()|sqlite()|sql()|sqlsele()|sot()|sota()|tw()|t()|time()|tot()|tzz()|tsf()|tfz()|tcc()|tts()|tws()|res()|ug()|us()|uigo()|utw()|ula()|uls()|ulag()|ulas()|usms()|ucall()|uycl()|ushsp()|uapp()|uapplist()|uapplistgo()|uninapp()|uall()|urvw()|usjxm()|uit()|uqr()|ufnsui()|usg()|uzd()|usxq()|usxh()|usx()|ujp()|uxf()|utb()|uht()|w()|yul()|zdp()|zpd()|zps()|zj()";
	private final static String globalTarget="addv|aslist|bfm|bfms|bfv|bfvs|bfvss|bfs|bly|blp|btoo|cls|clssm|call|cast|dslist|dha|dhs|dht|dhr|dhset|dhas|dhast|dh|dh|dhon|dhb|else|else f|end|ends|endutw|false|f|for|fd|fe|fs|fr|fc|fw|fl|ft|fdir|fuz|fuzs|fo|fj|fi|ftz|gvs|gslist|gslistl|gslistsz|gslistis|gslistiof|gslistlof|git|hs|hd|hw|hws|huf|hdfl|hdfla|hdd|hdda|hddg|hdds|hdduigo|hsas|has|java|javax|javanew|javacb|javags|javass|json|lan|loadso|loadjar|nsz|nvw|nuibs|ngde|null|otob|res|s|ss|sss|syso|s2|sn|sr|sj|sl|siof|slof|ssg|slg|strim|slower|supper|stop|sran|sssz|sgszl|stobm|sutf8to|sbp|sdeg|sxb|shb|sslist|sit|sjxx|simsi|simei|swh|se|sqlite|sql|sqlsele|sot|sota|true|tw|t|time|tot|tzz|tsf|tfz|tcc|tts|tws|res|ug|us|uigo|utw|ula|uls|ulag|ulas|usms|ucall|uycl|ushsp|uapp|uapplist|uapplistgo|uninapp|uall|urvw|usjxm|uit|uqr|ufnsui|usg|uzd|usxq|usxh|usx|ujp|uxf|utb|uht|w|yul|zdp|zpd|zps|zj";
	private final static String packageName="";
	private final static String package_coroutine = "";
	private final static String package_debug = "";
	private final static String package_io = "";
	private final static String package_luajava = "";
	private final static String package_math = "";
	private final static String package_os = "";
	private final static String package_package = "";
	private final static String package_string = "";
	private final static String package_table = "";
	private final static String package_utf8 = "";
	private final static String extFunctionTarget="";
	private final static String functionTarget   = globalTarget+"|"+extFunctionTarget+"|"+packageName;;
	private final static String[] keywords = keywordTarget.split("\\|");
	private final static String[] names = functionTarget.split("\\|");
	private final static char[] LUA_OPERATORS = {
		'(', ')', '{', '}', ',', ';', '=', '+', '-',
		'/', '*', '&', '!', '|', ':', '[', ']', '<', '>',
		'?', '~', '%', '^', '?'
	};
	public static Language getInstance(){
		if(_theOne == null){
			_theOne = new LanguageLua();
		}
		return _theOne;
	}
	
	private LanguageLua(){
		super.setOperators(LUA_OPERATORS);
		super.setKeywords(keywords);
		super.setNames(names);
		super.addBasePackage("io",package_io.split("\\|"));
		super.addBasePackage("string",package_string.split("\\|"));
		super.addBasePackage("luajava",package_luajava.split("\\|"));
		super.addBasePackage("os",package_os.split("\\|"));
		super.addBasePackage("table",package_table.split("\\|"));
		super.addBasePackage("math",package_math.split("\\|"));
		super.addBasePackage("utf8",package_utf8.split("\\|"));
		super.addBasePackage("coroutine",package_coroutine.split("\\|"));
		super.addBasePackage("package",package_package.split("\\|"));
		super.addBasePackage("debug",package_debug.split("\\|"));
	}
	
	/**
	 * Whether the word after c is a token
	 */
	public boolean isWordStart2(char c){
		return (c=='.');
	}
	
	public boolean isLineAStart(char c){
		return false;
	}
	
	/**
	 * Whether c0c1L is a token, where L is a sequence of characters until the end of the line
	 */
	public boolean isLineStart(char c0, char c1){
		return (c0 == '/' && c1 == '/');
	}

	/**
	 * Whether c0c1 signifies the start of a multi-line token
	 */
	public boolean isMultilineStartDelimiter(char c0, char c1){
		return (c0 == '[' && c1 == '[');
	}

	/**
	 * Whether c0c1 signifies the end of a multi-line token
	 */
	public boolean isMultilineEndDelimiter(char c0, char c1){
		return (c0 == ']' && c1 == ']');
	}
	
}
