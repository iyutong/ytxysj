package com.toolbox.miao;

import android.app.Application;
import android.content.Context;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class miaoApplication extends Application {
  @Override
  public void onCreate() {
    super.onCreate();
    RxToast.setContext(this);
    crash.getInstance().init(this);
  }
  
  @Override
  protected void attachBaseContext(Context base) {
    super.attachBaseContext(base);
  }

}