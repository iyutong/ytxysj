package com.toolbox.miao;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class crash implements Thread.UncaughtExceptionHandler {


    private static crash mUnCatchHandler = new crash();
    private Context mContext;
    private Thread.UncaughtExceptionHandler mDefaultHandler;
    public static crash getInstance() {
        return mUnCatchHandler;
    }
    public void init(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(this);
        mContext = context.getApplicationContext();
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }
    @Override
    public void uncaughtException(Thread t, Throwable e) {
      if (!savecl(e)&&mDefaultHandler!=null){
          mDefaultHandler.uncaughtException(t,e);
      } else {
          android.os.Process.killProcess(android.os.Process.myPid());
      }
    }
    private boolean savecl(Throwable ex){
        if (ex==null){
            return false;
        }
        try {
            saveSD(ex);
        } catch (Exception e) {
        }
        return true;
    }
    private void saveSD(Throwable throwable) throws Exception {
        PackageManager pm = mContext.getPackageManager();
        PackageInfo inFo = pm.getPackageInfo(mContext.getPackageName(), PackageManager.GET_ACTIVITIES);
        String versionName = inFo.versionName;
        int versionCode = inFo.versionCode;
        int version_code = Build.VERSION.SDK_INT;
        String release = Build.VERSION.RELEASE;
        String mobile = Build.MODEL;
        String mobileName = Build.MANUFACTURER;
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        String path = mContext.getExternalFilesDir("").getAbsolutePath();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy_MM_DD_HH_mm_ss");
        String time = simpleDateFormat.format(new Date());
        File f = new File(path, "crash");
        f.mkdirs();
        File file = new File(f.getAbsolutePath(), "crash_" + time + ".txt");
        if (!file.exists()) {
            file.createNewFile();
        }
        String data ="\nAndroid版本号：" + release +"\nMobile型号：" + mobile + "\nMobileName：" + mobileName + "\nSDK版本：" + version_code +"\n版本名称：" + versionName + "\n版本号：" + versionCode + "\n\n异常信息：" + throwable.getMessage()+"\n\n异常详情："+sw.toString();
        byte[] buffer = data.trim().getBytes();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(buffer, 0, buffer.length);
        fileOutputStream.flush();
        fileOutputStream.close();
    }
}

