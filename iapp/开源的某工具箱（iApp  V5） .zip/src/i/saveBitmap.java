package i;

import java.lang.*;
import com.toolbox.miao.R;
import android.graphics.Bitmap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class saveBitmap {
  public void saveBitmap(String bitName, Bitmap mBitmap) {
    File f = new File("/sdcard/miao工具箱/我画的画/" + bitName + ".png");
    try {
      f.createNewFile();
    } catch (IOException e) {
    }
    FileOutputStream fOut = null;
    try {
      fOut = new FileOutputStream(f);
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
    try {
      fOut.flush();
    } catch (IOException e) {
      e.printStackTrace();
    }
    try {
      fOut.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  
}