package com.i9707174eeab0cd4f;

import android.app.Application;
import com.qt.box.tool;

public class App extends Application{
	
	@Override
	public void onCreate() {
		super.onCreate();
         
         tool.init(this);
            
	}
}