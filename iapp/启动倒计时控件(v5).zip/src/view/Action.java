package cn.lemon.view;

/**
 * Created by linlongxin on 2016/8/29.
 */

public interface Action {
    void onAction();
}
