package com.link.sb;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.content.Context;
import android.text.method.LinkMovementMethod;
import android.text.Spannable;
import android.text.style.URLSpan;
import android.text.SpannableStringBuilder;
import android.text.style.UnderlineSpan;
import android.text.TextPaint;
import android.text.Spanned;
import android.content.Intent;
import android.text.style.ClickableSpan;
import android.view.View;
public class Lanjie extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
    }
    
    
    public static void interceptHyperLink(TextView tv,Context ei) {  
      
      removeHyperLinkUnderline(tv);
      
        tv.setMovementMethod(LinkMovementMethod.getInstance());  
        CharSequence text = tv.getText();  
        if (text instanceof Spannable) {  
            int end = text.length();  
            Spannable spannable = (Spannable) tv.getText();  
            URLSpan[] urlSpans = spannable.getSpans(0, end, URLSpan.class);  
            if (urlSpans.length == 0) {  
                return;  
            }  

            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(text);  
            // 循环遍历并拦截 所有http://开头的链接  
            for (URLSpan uri : urlSpans) {  
                String url = uri.getURL();  
                if (url.indexOf("http://") == 0||url.indexOf("https://") == 0) {  
                    CustomUrlSpan customUrlSpan = new CustomUrlSpan(ei,url);  
                    spannableStringBuilder.setSpan(customUrlSpan, spannable.getSpanStart(uri),  
                                                   spannable.getSpanEnd(uri), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);  
                }  
            }  
            tv.setText(spannableStringBuilder);  
        }  
    }  

    public static class NoUnderlineSpan extends UnderlineSpan {  

        @Override  
        public void updateDrawState(TextPaint ds) {  
            ds.setUnderlineText(false);  
        }  
    }  

    //移除下划线
    public static void removeHyperLinkUnderline(TextView tv) {  
        CharSequence text = tv.getText();  
        if(text instanceof Spannable){  
            Spannable spannable = (Spannable) tv.getText();  
            spannable.setSpan(new NoUnderlineSpan(),0,text.length(), Spanned.SPAN_MARK_MARK);  
        }  
	}  
 

}


//QQ 1823565614 七桐