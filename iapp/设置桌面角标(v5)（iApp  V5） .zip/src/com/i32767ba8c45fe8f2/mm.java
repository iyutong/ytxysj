package com.i32767ba8c45fe8f2;

import java.lang.*;
import com.i32767ba8c45fe8f2.R;

public class mm {
  
  public static String getModel() {
        return android.os.Build.MANUFACTURER + "|" // 手机厂商
                + android.os.Build.MODEL; // 型号;
    }
  
}