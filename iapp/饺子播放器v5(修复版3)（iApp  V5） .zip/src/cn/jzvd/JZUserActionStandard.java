package cn.jzvd;

/**
 * Created by Nathen
 * On 2016/04/26 20:53
 */
public interface JZUserActionStandard extends JZUserAction {

    int ON_CLICK_START_THUMB = 101;
    int ON_CLICK_BLANK = 102;

}
