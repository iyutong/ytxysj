package com.xs.duanxin;

import java.lang.*;
import com.xs.duanxin.R;

import android.support.v7.widget.RecyclerView;
import android.widget.Adapter;
import android.view.ViewGroup;
import android.view.View;
import android.view.LayoutInflater;
import android.content.Context;
import java.util.List;
import android.widget.TextView;

public class spq extends RecyclerView.Adapter<spq.vh> {

	private Context mcontext;

	private List<String> 手机号;

	private List<String> 内容;

	public spq(Context context,List<String> a,List<String>b){
		this.mcontext=context;
		this.手机号=a;
		this.内容=b;
	}
	
	@Override
	public spq.vh onCreateViewHolder(ViewGroup p1, int p2) {
		View view = LayoutInflater.from(mcontext).inflate(R.layout.list, p1, false);
		return new vh(view);
	}

	@Override
	public void onBindViewHolder(spq.vh p1, int p2) {
		p1.t1.setText(手机号.get(p2));
		p1.t2.setText(内容.get(p2));
	}

	@Override
	public int getItemCount() {
		return 手机号.size();
	}

    class vh extends RecyclerView.ViewHolder{
		private TextView t1,t2;
		public vh(View view){
			super(view);
			t1=(TextView)view.findViewById(R.id.wb1);
			t2=(TextView)view.findViewById(R.id.wb2);
		}
	}
    
    
}