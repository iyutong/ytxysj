package com.xs.duanxin;

import java.lang.*;
import com.xs.duanxin.R;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class duanxin {
  private String name;
  private List<String> 手机号 = new ArrayList();
  private List<String> 姓名 = new ArrayList();
  private List<String> 内容 = new ArrayList();
  private Uri SMS_INBOX = Uri.parse("content://sms/");
  private Context context;
  
  //构造器
  public duanxin(Context mcontext, List<String> a, List<String> b, List<String> c) {
    this.context = mcontext;
    this.手机号 = a;
    this.姓名 = b;
    this.内容 = c;
  }
  
  public void getSmsFromPhone() {
    ContentResolver cr = context.getContentResolver();
    String[] projection = new String[] {"_id", "address", "person","body", "date", "type" };
    Cursor cur = cr.query(SMS_INBOX, projection, null, null, "date desc");
    if (null == cur) {
      Log.i("ooc", "************cur == null");
      return;
    }
    while (cur.moveToNext()) {
      String number = cur.getString(cur.getColumnIndex("address"));//手机号
      String name = cur.getString(cur.getColumnIndex("person"));//联系人姓名列表
      String body = cur.getString(cur.getColumnIndex("body"));//短信内容
      //至此就获得了短信的相关的内容, 以下是把短信加入map中，构建listview,非必要。
      手机号.add(number);
      姓名.add(name);
      内容.add(body);
    }
  }
  
  public String getnumber(){
    return 手机号.toString();
  }
  
  public String getname(){
    return 姓名.toString();
  }
  
  public String getboby(){
    return 内容.toString();
  }
  
  
}