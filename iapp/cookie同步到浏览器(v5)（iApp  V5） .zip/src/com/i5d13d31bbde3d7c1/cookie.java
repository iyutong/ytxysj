package com.i5d13d31bbde3d7c1;

import java.lang.*;
import com.i5d13d31bbde3d7c1.R;
import android.app.*;
import android.os.*;
import android.webkit.*;
import java.util.*;
import android.util.*;
import android.widget.*;

public class cookie {

  
public WebView view;
public String url = "http://0.0.0.0:8088";





public static boolean set(String url,String data)
{
  CookieManager c = CookieManager.getInstance();
  if(c==null) return false;
  c.setAcceptCookie(true);
  c.setCookie(url, data);
  return true;
}

public static String get(String url)
{
  CookieManager c = CookieManager.getInstance();
  c.setAcceptCookie(true);
  return c.getCookie(url);
}
  
}








