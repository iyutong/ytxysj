package ls.interfaces;

/**LabelView TextView OnclickListsner Interface
 * Created by Brioal on 2016/9/7.
 */
public interface OnLabelSelectedListener {
    void selected(int position, String content);
}
