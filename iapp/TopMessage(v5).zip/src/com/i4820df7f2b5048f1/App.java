package com.i4820df7f2b5048f1;

import android.app.Application;
 
import com.wizchen.topmessage.util.TopActivityManager;
public class App extends Application {
 
    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(TopActivityManager.getInstance());
    }
}