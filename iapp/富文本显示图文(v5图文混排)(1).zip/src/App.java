package com.if6df557277a57d94;

import android.app.Application;

/**
 * Created by wanglei on 2016/11/02.
 */

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        com.fwb.UILKit.init(getApplicationContext());        //初始化UIL
    }

}
