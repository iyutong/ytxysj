package com.ida84fc554cb;

import java.lang.*;
import com.ida84fc554cb.R;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class txcz {
public static void saveBitmapFile(android.graphics.Bitmap bitmap,String ml){

        java.io.File temp = new java.io.File("/sdcard/"+ml+"/");//要保存文件先创建文件夹   
        if (!temp.exists()) {
            temp.mkdir();
        }
        ////重复保存时，覆盖原同名图片
        int min=123456789;
        int max=999999999;
        Random random = new Random();
        int num = random.nextInt(max) % (max - min + 1) + min;
        
        java.io.File file=new java.io.File("/sdcard/"+ml+"/"+num+".jpg");//将要保存图片的路径和图片名称
        //    File file =  new File("/sdcard/1delete/1.png");/////延时较长
        try {
            java.io.BufferedOutputStream bos= new java.io.BufferedOutputStream(new java.io.FileOutputStream(file));
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, bos);
            bos.flush();
            bos.close();

        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }

}