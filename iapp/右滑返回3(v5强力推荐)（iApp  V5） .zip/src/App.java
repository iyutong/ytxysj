package com.i4dbe716158c75557;

import android.app.Application;

import com.slideback.helper.manager.ActivityLifeManager;

public class App extends i.app.applicationMain {
    @Override
    public void onCreate() {
        super.onCreate();
        ActivityLifeManager.registerListener(this);
    }
}


//需要把 apk/AndroidManifest.xml 里的 i.app.applicationMain 改成.App
//把项目的 sdk/classes.jar这个文件复制到你的项目
//QQ 1823565614 七桐
//github开源地址 https://github.com/hhoy/SlideBackHelper.git