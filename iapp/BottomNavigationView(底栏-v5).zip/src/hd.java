package com.qt;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.Bitmap;
import android.content.res.ColorStateList;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.LinearLayout;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.annotation.SuppressLint;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.util.Log;
import java.lang.reflect.Field;

public class hd {

public static BottomNavigationView set(android.content.Context activity,BottomNavigationView mBt,ViewPager Vp,String one,String two,String three,String four,Bitmap o,Bitmap t,Bitmap h,Bitmap f)
{
  final ViewPager mVp=Vp;
  Menu menu=mBt.getMenu();
  menu.add(0,0,1,one);
  menu.add(0,1,1,two);
  menu.add(0,2,2,three);
  menu.add(0,3,3,four);
  
  disableShiftMode(mBt);
  
  MenuItem item = menu.findItem(0);
  item.setIcon(new BitmapDrawable(o));
  item=menu.findItem(1);
 
  item.setIcon(new BitmapDrawable(t));
  item=menu.findItem(2);
  item.setIcon(new BitmapDrawable(h));
  item=menu.findItem(3);
  item.setIcon(new BitmapDrawable(f));

  BottomNavigationView.OnNavigationItemSelectedListener mC=new BottomNavigationView.OnNavigationItemSelectedListener()
  {
        public boolean onNavigationItemSelected(MenuItem item)
        {
            switch (item.getItemId())
            {
                case 0:
                    mVp.setCurrentItem(0);
                    return true;
                case 1:
                    mVp.setCurrentItem(1);
                    return true;
                case 2:
                    mVp.setCurrentItem(2);
                    return true;
                case 3:
                    mVp.setCurrentItem(3);
                    return true;
            }
            return false;
        }
    };
  
  mBt.setOnNavigationItemSelectedListener(mC);

  return mBt;
}


    @SuppressLint("RestrictedApi")
    public static void disableShiftMode(BottomNavigationView view) {
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) view.getChildAt(0);
        try {
            Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
            shiftingMode.setAccessible(true);
            shiftingMode.setBoolean(menuView, false);
            shiftingMode.setAccessible(false);
            for (int i =0; i < menuView.getChildCount(); i++) {
                BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
                item.setShiftingMode(false);
                item.setChecked(item.getItemData().isChecked());
            }
        } catch (NoSuchFieldException e) {
            Log.e("BNVEffect", "Unable to get shift mode field", e);
        } catch (IllegalAccessException e) {
            Log.e("BNVEffect", "Unable to change value of shift mode", e);
        }
    }
    
}