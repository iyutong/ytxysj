package com.i037b024b35f1d70e;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.widget.Toast;
import java.security.MessageDigest;
import android.content.Context;
import android.content.pm.Signature;

public class packagesign {
    public boolean getSignature(Context context,int p1) {
		boolean same = false;
        PackageManager pm = context.getPackageManager();
		PackageInfo pi;
		StringBuilder sb = new StringBuilder();

		try {
			pi = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
			Signature[] signatures = pi.signatures;
			for (Signature signature : signatures) {
				sb.append(signature.toString());
			}
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
        if(sb.toString().hashCode()!=p1){
          same = true;
        }else{
          same = false;
        }
		return same;
	}
 
    public int getSignInfo(Context context) {
		boolean same = false;
        PackageManager pm = context.getPackageManager();
		PackageInfo pi;
		StringBuilder sb = new StringBuilder();

		try {
			pi = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
			Signature[] signatures = pi.signatures;
			for (Signature signature : signatures) {
				sb.append(signature.toString());
			}
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		return sb.toString().hashCode();
	}
}