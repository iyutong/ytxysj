package com.i0e89ffefe0d15f56;



import android.app.Application;

import ts.ts;

//github地址 https://github.com/ytam/CustomToast.git
//QQ 1823565614

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ts.init(this);
    }
}
