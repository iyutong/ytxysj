package ts;

import java.lang.*;
import com.i0e89ffefe0d15f56.R;
import android.content.Context;
import io.github.ytam.customtoast.CustomToast;
import android.widget.Toast;
public class ts {
         
      private static Context context;
      
      
              public static void init(Context context) {
        ts.context = context.getApplicationContext();
    }
    
    
    public static void ts(String nr){
      
      CustomToast.success(context,nr,Toast.LENGTH_SHORT);
      
    }
    
    public static void cts(String nr){
      CustomToast.error(context,nr,Toast.LENGTH_LONG);
    }
    
      public static void xx(String nr){
      
        CustomToast.info(context,nr,Toast.LENGTH_LONG);
        }
        
      public static void jts(String nr){
        CustomToast.warning(context,nr,Toast.LENGTH_LONG);
    }
    



}
//github地址 https://github.com/ytam/CustomToast.git
//QQ 1823565614