package com.i0e89ffefe0d15f56;

import java.lang.*;
import com.i0e89ffefe0d15f56.R;

import ts.ts;

public class tw {

  //提示
  public static void ts(String nr){
     ts.ts(nr);
  }
  //错误提示
   public static void cts(String nr){
     ts.cts(nr);
  }
  //信息提示
   public static void xx(String nr){
     ts.xx(nr);
  }
  //异常提示
   public static void jts(String nr){
     ts.jts(nr);
  }
}

//github地址 https://github.com/ytam/CustomToast.git
//QQ 1823565614