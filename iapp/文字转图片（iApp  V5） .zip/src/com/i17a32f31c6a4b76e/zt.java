package com.i17a32f31c6a4b76e;

import java.lang.*;
import com.i17a32f31c6a4b76e.R;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.graphics.drawable.BitmapDrawable;

public class zt {
public zt() {
}
public static BitmapDrawable textAsBitmap(String text, float textSize) {

		TextPaint textPaint = new TextPaint();
		textPaint.setColor(Color.BLACK);
		textPaint.setAntiAlias(true);
		textPaint.setTextSize(textSize);
        //textPaint.setARGB(0x31, 0x31, 0x31, 0);
		StaticLayout layout = new StaticLayout(text, textPaint, 1000,
											   Layout.Alignment.ALIGN_NORMAL, 1.3f, 0.0f, true);
		Bitmap bitmap = Bitmap.createBitmap(layout.getWidth() + 20,
											layout.getHeight() + 20, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		canvas.translate(10, 10);
		canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);//绘制透明色
		layout.draw(canvas);
		return new BitmapDrawable(bitmap);
	}
}








