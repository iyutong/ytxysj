package com.dlna;
import android.app. *;
import android.widget. *;
import android.os. *;
import android.view. *;
import android.view.View. *;
import android.webkit. *;
import android.graphics. *;
import android.graphics.drawable. *;
import android.content. *;
import android.content.res. *;
import java.util. *;
import java.io. *;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.zx.zpush.DeviceDisplay;
import com.zx.zpush.MyUpnpService;
import java.util.Collection;
import org.teleal.cling.android.AndroidUpnpService;
import org.teleal.cling.controlpoint.ActionCallback;
import org.teleal.cling.controlpoint.ControlPoint;
import org.teleal.cling.model.ServiceReference;
import org.teleal.cling.model.action.ActionInvocation;
import org.teleal.cling.model.message.UpnpResponse;
import org.teleal.cling.model.meta.Device;
import org.teleal.cling.model.meta.LocalDevice;
import org.teleal.cling.model.meta.RemoteDevice;
import org.teleal.cling.model.meta.Service;
import org.teleal.cling.model.types.ServiceId;
import org.teleal.cling.model.types.UDAServiceId;
import org.teleal.cling.registry.DefaultRegistryListener;
import org.teleal.cling.registry.Registry;
import org.teleal.cling.registry.RegistryListener;
import org.teleal.cling.support.avtransport.callback.Pause;
import org.teleal.cling.support.avtransport.callback.Play;
import org.teleal.cling.support.avtransport.callback.Seek;
import org.teleal.cling.support.avtransport.callback.SetAVTransportURI;
import org.teleal.cling.support.avtransport.callback.Stop;
import org.teleal.cling.support.connectionmanager.callback.GetProtocolInfo;
import org.teleal.cling.support.connectionmanager.callback.PrepareForConnection;
import org.teleal.cling.support.model.ConnectionInfo;
import org.teleal.cling.support.model.ProtocolInfo;
import org.teleal.cling.support.model.ProtocolInfos;


import com.i29973aea2d5b1852.R;




public class dlna extends Activity {
  
  private Dialog listdialog;
  private ListView devicelist;
  private ArrayAdapter<DeviceDisplay> listAdapter;
  private AndroidUpnpService upnpService;
  private RegistryListener registryListener;
  private ServiceConnection serviceConnection;
  private String s = "AVTransport";
  private String s1 = "ConnectionManager";
  String url = "http://gcqq450f71eywn6bv7u.exp.bcevod.com/mda-hbqagik5sfq1jsai/mda-hbqagik5sfq1jsai.mp4";
  private int deviceIndex = 0;
  
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
   // setContentView(R.layout.main);
    
    初始化();
    搜索设备();
    置投屏幕内容("http://gcqq450f71eywn6bv7u.exp.bcevod.com/mda-hbqagik5sfq1jsai/mda-hbqagik5sfq1jsai.mp4");
  }
  
  
  
  public void  初始化() {
    
    
    registryListener = new BrowseRegistryListener();
    serviceConnection = new ServiceConnection(){
      
      public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        upnpService = (AndroidUpnpService)iBinder;
        for (Device device :upnpService.getRegistry().getDevices()) {
          ((BrowseRegistryListener)registryListener).deviceAdded(device);
        }
        upnpService.getRegistry().addListener(registryListener);
        upnpService.getControlPoint().search();
      }
      
      public void onServiceDisconnected(ComponentName componentName) {
        upnpService = null;
      }
    };
    
  }
  public void 搜索设备(){
    
    showDialog();
    
  }
  public void  暂停播放() {
    
    DeviceDisplay deviceDisplay = (DeviceDisplay)listAdapter.getItem(deviceIndex);
    Device device = deviceDisplay.getDevice();
    executePause(device);
    
  }
  public void  继续播放() {
    
    DeviceDisplay deviceDisplay = (DeviceDisplay)listAdapter.getItem(deviceIndex);
    Device device = deviceDisplay.getDevice();
    executePlay(device);
    
  }
  public void  停止播放() {
    
    DeviceDisplay deviceDisplay = (DeviceDisplay)listAdapter.getItem(deviceIndex);
    Device device = deviceDisplay.getDevice();
    executeStop(device);
    
  }
  
  public void showDialog() {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle((CharSequence)"可选择设备……");
    LayoutInflater layoutInflater = LayoutInflater.from(this);
    View view = layoutInflater.inflate(R.layout.listview, null);
    bindService(new Intent(this, MyUpnpService.class), serviceConnection, 1);
    devicelist = (ListView)view.findViewById(R.id.devicelist);
    listAdapter = new ArrayAdapter(this, 17367043);
    devicelist.setAdapter(listAdapter);
    builder.setView(view);
    builder.setNegativeButton((CharSequence)"取消", new DialogInterface.OnClickListener(){
      
      public void onClick(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
      }
    });
    listdialog = builder.create();
    listdialog.show();
    devicelist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
      
      public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
        deviceIndex = n;
        DeviceDisplay deviceDisplay = (DeviceDisplay)listAdapter.getItem(n);
        Device device = deviceDisplay.getDevice();
        Uri.parse((String)url);
        GetInfo(device);
        executeAVTransportURI(device, url);
        executePlay(device);
        listdialog.dismiss();
      }
    });
  }
  
  
  public void  置投屏幕内容(String 播放地址) {
    
    url = 播放地址;
    
  }
  
  public void onDestroy() {
    if (upnpService != null) {
      upnpService.getRegistry().removeListener(registryListener);
    }
    if (serviceConnection != null) {
      unbindService(serviceConnection);
    }
  }
  
  
  public void executeAVTransportURI(Device device, String string) {
    UDAServiceId uDAServiceId = new UDAServiceId(s);
    Service service = device.findService((ServiceId)uDAServiceId);
    SetAVTransportURI setAVTransportURI = new SetAVTransportURI(service, string){
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.e((String)"SetAVTransportURI", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)setAVTransportURI);
  }
  
  
  public void executePlay(Device device) {
    UDAServiceId uDAServiceId = new UDAServiceId(s);
    Service service = device.findService((ServiceId)uDAServiceId);
    Play play = new Play(service){
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.e((String)"Play", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)play);
  }
  
  
  public void executePause(Device device) {
    UDAServiceId uDAServiceId = new UDAServiceId(s);
    Service service = device.findService((ServiceId)uDAServiceId);
    Pause pause = new Pause(service){
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.e((String)"Play", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)pause);
  }
  
  
  public void executeStop(Device device) {
    UDAServiceId uDAServiceId = new UDAServiceId(s);
    Service service = device.findService((ServiceId)uDAServiceId);
    Stop stop = new Stop(service){
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.e((String)"Play", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)stop);
  }
  
  
  public void executeSeek(Device device, String string) {
    UDAServiceId uDAServiceId = new UDAServiceId(s);
    Service service = device.findService((ServiceId)uDAServiceId);
    Seek seek = new Seek(service, string){
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.e((String)"Play", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)seek);
  }
  
  
  
  public void GetInfo(Device device) {
    UDAServiceId uDAServiceId = new UDAServiceId(s1);
    Service service = device.findService((ServiceId)uDAServiceId);
    GetProtocolInfo getProtocolInfo = new GetProtocolInfo(service){
      
      public void received(ActionInvocation actionInvocation, ProtocolInfos protocolInfos, ProtocolInfos protocolInfos2) {
        Log.v((String)"sinkProtocolInfos", (String)protocolInfos.toString());
        Log.v((String)"sourceProtocolInfos", (String)protocolInfos2.toString());
      }
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.v((String)"GetProtocolInfo", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)getProtocolInfo);
  }
  
  
  
  public void PrepareConn(Device device) {
    UDAServiceId uDAServiceId = new UDAServiceId(s1);
    Service service = device.findService((ServiceId)uDAServiceId);
    PrepareForConnection prepareForConnection = new PrepareForConnection(service, null, null, - 1, null){
      
      public void received(ActionInvocation actionInvocation, int n, int n2, int n3) {
        Log.v((String)"avTransportID", (String)Integer.toString(n3));
      }
      
      public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String string) {
        Log.v((String)"PrepareForConnection", (String)"failed^^^^^^^");
      }
    };
    upnpService.getControlPoint().execute((ActionCallback)prepareForConnection);
  }
  
  
  class BrowseRegistryListener
  extends DefaultRegistryListener {
    BrowseRegistryListener() {
    }
    
    public void remoteDeviceDiscoveryStarted(Registry registry, RemoteDevice remoteDevice) {
      deviceAdded((Device)remoteDevice);
    }
    
    public void remoteDeviceDiscoveryFailed(Registry registry, RemoteDevice remoteDevice, Exception exception) {
      deviceRemoved((Device)remoteDevice);
    }
    
    public void remoteDeviceAdded(Registry registry, RemoteDevice remoteDevice) {
      deviceAdded((Device)remoteDevice);
    }
    
    public void remoteDeviceRemoved(Registry registry, RemoteDevice remoteDevice) {
      deviceRemoved((Device)remoteDevice);
    }
    
    public void localDeviceAdded(Registry registry, LocalDevice localDevice) {
      deviceAdded((Device)localDevice);
    }
    
    public void localDeviceRemoved(Registry registry, LocalDevice localDevice) {
      deviceRemoved((Device)localDevice);
    }
    
    public void deviceAdded(final Device device) {
      runOnUiThread(new Runnable(){
        
        @Override
        public void run() {
          DeviceDisplay deviceDisplay = new DeviceDisplay(device);
          int n = listAdapter.getPosition(deviceDisplay);
          if (n >= 0) {
            listAdapter.remove(deviceDisplay);
            listAdapter.insert(deviceDisplay, n);
          } else {
            listAdapter.add(deviceDisplay);
          }
          listAdapter.notifyDataSetChanged();
        }
      });
    }
    
    public void deviceRemoved(final Device device) {
      runOnUiThread(new Runnable(){
        
        @Override
        public void run() {
          listAdapter.remove(new DeviceDisplay(device));
        }
      });
    }
    
  }
  
  
  
  
}