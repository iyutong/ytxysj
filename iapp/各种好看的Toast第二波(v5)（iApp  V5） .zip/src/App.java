package com.qq1823565614.toast;

import android.app.Application;

import ts.ts;

/**
 * 创建人: 雷富
 * 创建时间: 2018/1/31 17:01
 * 描述:
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ts.init(this);
    }
}
