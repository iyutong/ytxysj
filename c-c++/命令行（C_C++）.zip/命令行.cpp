#include<stdio.h>
#include<stdlib.h>
//#include<windows.h>
#include<conio.h>

int main()
{
char a[99]={0};
int i,w=0;
//system("d:&& DIR");
while(1)
{
printf("请输入命令>>");


for(int i=0;;i++)
{

scanf("%c",&a[i]);
if(a[i]=='\n')
{
w = i;
a[w]='\0';

    break;
}

}
printf("\n");
system(a);
printf("\n<<%s>>命令\n",a);


for(int i=0;i<w;i++)
{
a[i]='\0';
}






}
return 0;

}