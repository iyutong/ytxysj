#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include "Snake.h"

#define SIZE 20
float SPEED = 0.8;
// 是否达到难度上线
int speed_flag = 0;
int speed_flag1 = 0;

// 空白，墙，蛇身,蛇头
enum
{ Null, Wall, Snake, SnakeHead, Food };
// 移动方向
enum
{ Top, Bottom, Left, Right };
// 绘制界面
void DrawMap(int map[SIZE][SIZE]);

// 更新地图
void ReMap(int map[SIZE][SIZE], S_Head * head, int food[2]);

// 随机产生食物
void creatFood(int map[SIZE][SIZE], S_Head * head, int food[2]);

// 游戏控制
void GameControl(S_Head * head);

// 时间控制
void wait(float time);

// 游戏玩法介绍
void Gameinit();

// 增加难度
void GameCheck(S_Head* head);

int main()
{
	Gameinit();
	int food[2] = { 0 };
	int map[SIZE][SIZE] = { 0 };
	S_Head *head = Snake_init();
	// 产生食物
	creatFood(map, head, food);
	while (1)
	{
		clrscr();				// 清屏
		memset(map, 0, sizeof(map));
		// 刷新地图
		ReMap(map, head, food);
		// 绘制地图
		DrawMap(map);
		wait(SPEED);
		GameControl(head);
		// 蛇移动
		Snake_move(head);
		// 判断是否吃到食物
		if (Snake_eat(head, food[0], food[1]))
		{
			Snake_add(head);
			creatFood(map, head, food);
			GameCheck(head);
		}
		// 判断撞墙
		if (Snake_die(head, SIZE))
		{
			clrscr();			// 清屏
			printf("你撞墙了啊!\n");
			break;
		}
		// 判断是否撞到自己
		if (Snake_self(head))
		{
			clrscr();
			printf("你不小心撞到自己了!\n");
			break;
		}
	}
	return 0;
}

// 绘制界面
void DrawMap(int map[SIZE][SIZE])
{
	setbuf(stdout,NULL);
	for (int i = 0; i < SIZE; ++i)
	{
		printf("\t  ");
		for (int j = 0; j < SIZE; ++j)
		{
			if (map[i][j] == Wall)
			{
				printf("■");
			}
			else if (map[i][j] == Null)
			{
				printf("□");
			}
			else if (map[i][j] == Snake)
			{
				printf("●");
			}
			else if (map[i][j] == SnakeHead)
			{
				printf("◆");
			}
			else if (map[i][j] == Food)
			{
				printf("⊙");
			}

		}
		printf("\n");
	}
}

// 更新地图
void ReMap(int map[SIZE][SIZE], S_Head * head, int food[2])
{
	S_Body *cbody;
	for (int i = 0; i < SIZE; ++i)
	{
		for (int j = 0; j < SIZE; ++j)
		{
			for (int k = 0; k < head->max; ++k)
			{
				cbody = searchBody(head, k);
				if (i == cbody->y && j == cbody->x)
				{
					map[i][j] = Snake;
				}
				else if (i == head->y && j == head->x)
				{
					map[i][j] = SnakeHead;
				}
				else if (i == 0 || i == SIZE - 1 || j == 0 || j == SIZE - 1)
				{
					map[i][j] = Wall;
				}
				else if (i == food[1] && j == food[0])
				{
					map[i][j] = Food;
				}
				else if (map[i][j] == Snake)
				{
					map[i][j] = Snake;
				}
				else if (map[i][j] == Food)
				{
					map[i][j] = Food;
				}
				else
				{
					map[i][j] = Null;
				}
			}
		}
	}
}

// 随机产生食物
void creatFood(int map[SIZE][SIZE], S_Head * head, int food[2])
{
	srand(time(NULL));
	S_Body *body = NULL;
	int flag = 0;
	while (1)
	{
		food[0] = (rand() % (SIZE - 2)) + 1;
		food[1] = (rand() % (SIZE - 2)) + 1;
		for (int i = 0; i < head->max; ++i)
		{
			body = searchBody(head, i);
			if (food[0] == body->x && food[1] == body->y)
			{
				flag = 1;
				break;
			}
		}
		if (!flag)
		{
			map[food[1]][food[0]] = Food;
			break;
		}
	}
	return;
}

// 游戏控制
void GameControl(S_Head * head)
{
	if (_kbhit())
	{
		fflush(stdin);		
		switch(getch())
		{
			case 50:  // 向上
			    changeSnake(head,Top);
		        break;
		    case 56:  // 向下
		        changeSnake(head,Bottom);
		        break;
		    case 52:  //向左
		        changeSnake(head,Left);
		        break;
		    case 54:  //向右
		        changeSnake(head,Right);
		        break;
		    default:
		        break;
		}
	}
}

// 时间控制
void wait(float time)
{
	clock_t delay = time * CLOCKS_PER_SEC;
	clock_t start = clock();
	while (clock() - start < delay)
	{
		;
	}
}

// 游戏玩法介绍
void Gameinit()
{
	printf("    ***********C语言贪吃蛇**********\n");
	printf("    ** 1--本游戏由爱编程的猴子开发\n");
	printf("    ** 2--游戏玩法介绍:\n");
	printf("    **      按2:向上\n");
	printf("    **      按8:向下\n");
	printf("    **      按4:向左\n");
	printf("    **      按6:向右\n");
	printf("    ******************************\n");
	getchar();
}

// 增加难度
void GameCheck(S_Head* head)
{
	if (speed_flag == 0 )
	{
    	if (head->max >= 10 && head->max < 20)
    	{
    		if (speed_flag1 == 0)
    		{
    		    SPEED -= 0.15;
    		    speed_flag1 = 1;
    		}		 
    	}
    	else if (head->max >= 20)
    	{
	    	SPEED -= 0.25;
	    	speed_flag = 1;
    	}
	}
}