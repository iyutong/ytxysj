#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "Snake.h"

enum
{ Top, Bottom, Left, Right };

/*
struct Snake_Head
{
	int max;					// 蛇身最大数量
	int x;						// x坐标
	int y;						// y坐标
	S_Body *pnext;				// 后继蛇身
	int direction;				// 当前移动方向
};

struct Snake_Body
{
	int x;						// x坐标
	int y;						// y坐标
	S_Body *pnext;
	int direction;				// 当前移动方向
};
*/

// 创建蛇身
S_Body *newBody()
{
	S_Body *body = (S_Body*) malloc(sizeof(S_Body));
	if (body == NULL)
	{
		perror("创建失败!\n");
		exit(1);
	}
	body->x = 0;
	body->y = 0;
	body->direction = Right;
	body->pnext = NULL;
	return body;
}

// 创建蛇
S_Head *Snake_init()
{
	S_Head *head = (S_Head *) malloc(sizeof(S_Head));
	if (head == 0)
	{
		perror("创建失败!\n");
		exit(0);
	}
	head->max = 0;
	head->x = 10;
	head->y = 10;
	head->direction = Right;
	head->pnext = NULL;
	S_Body *cbody = head->pnext;
	// 创建3个蛇身
	for (int i = 0; i < 3; ++i)
	{
		S_Body *body = newBody();
		if (head->pnext == NULL)
		{
			head->pnext = body;
			cbody = head->pnext;
			body->x = (head->x) - 1;
			body->y = (head->y);
			body->direction = head->direction;
			body->pnext = NULL;
			(head->max)++;
		}
		else
		{
			cbody->pnext = body;
			body->x = (cbody->x) - 1;
			body->y = cbody->y;
			body->direction = cbody->direction;
			body->pnext = NULL;
			(head->max)++;
			cbody = cbody->pnext;
		}
	}
	cbody = NULL;
	return head;
}

// 判断蛇是否吃到食物(蛇头，食物坐标)
BOOL Snake_eat(S_Head * head, int x, int y)
{
	if (head->x == x && head->y == y)
	{
		return true;
	}
	return false;
}

// 判断蛇是否撞到自己
BOOL Snake_self(S_Head * head)
{
	S_Body *body = head->pnext;
	while (body != NULL)
	{
		if (head->x == body->x && head->y == body->y)
		{
			return true;		// 撞到了自己
		}
		body = body->pnext;
	}
	body = NULL;
	return false;				// 没有撞到
}

// 判断蛇是否撞墙(蛇头，边界)
BOOL Snake_die(S_Head * head, int size)
{
	if (head->x == 0 || head->x == size - 1 || head->y == 0 || head->y == size - 1)
	{
		return true;
	}
	return false;
}


// 蛇吃到食物后长度加一
BOOL Snake_add(S_Head * head)
{
	if (head->max < MAXLENGTH)
	{
		S_Body *body = head->pnext;
		while (body->pnext != NULL)
		{
			body = body->pnext;
		}
		// 最后一个节点
		S_Body *newbody = newBody();		
		switch (body->direction)
		{
		case Top:
			newbody->x = body->x;
			newbody->y = (body->y) + 1;
			newbody->direction = body->direction;
			body->pnext = newbody;
			if (newbody->x == body->x && newbody->y == body->y)
			{
				newbody->y = (body->y)+1;
			}
			(head->max)++;
			break;
		case Bottom:
			newbody->x = body->x;
			newbody->y = (body->y) - 1;
			newbody->direction = body->direction;
			body->pnext = newbody;
			if (newbody->x == body->x && newbody->y == body->y)
			{
				newbody->y = (body->y)+1;
			}
			(head->max)++;
			break;
		case Left:
			newbody->x = (body->x) + 1;
			newbody->y = body->y;
			newbody->direction = body->direction;
			body->pnext = newbody;
			if (newbody->x == body->x && newbody->y == body->y)
			{
				newbody->x = (body->x)-1;
			}
			(head->max)++;
			break;
		case Right:
			newbody->x = (body->x) - 1;
			newbody->y = body->y;
			newbody->direction = body->direction;
			body->pnext = newbody;
			if (newbody->x == body->x && newbody->y == body->y)
			{
				newbody->x = (body->y)+1;
			}
			(head->max)++;
			break;
		default:
			break;
		}		
		body = NULL;
		return true;
	}
	return false;
}

// 查找蛇身(蛇头，下标)
S_Body* searchBody(S_Head* head,int id)
{
	if (id < 0 || id >= head->max)
	{
		return NULL;
	}
	S_Body* sbody = NULL;
	for (int i = 0;i <= id;++i)
	{
		if (i == 0)
		{
			sbody = head->pnext;
		}
		else
		{
			sbody = sbody->pnext;
		}
	}
	return sbody;
}

// 通过按键控制蛇方向
void changeSnake(S_Head* head,int dir)
{
	switch (dir)
	{
		case Top:
		    if (head->direction == Bottom)
		    {		  
		    	break;
		    }
		    head->direction = Top;
		    break;
		case Bottom:
		    if (head->direction == Top)
		    {		  
		    	break;
		    }
		    head->direction = Bottom;
		    break;
		case Left:
		    if (head->direction == Right)
		    {		  
		    	break;
		    }
		    head->direction = Left;
		    break;
		case Right:
		    if (head->direction == Left)
		    {		  
		    	break;
		    }
		    head->direction = Right;
		    break;
		default:
		    break;
	}
}

// 蛇运动
void Snake_move(S_Head* head)
{
	S_Body* body = NULL;
	S_Body* hbody = NULL;
	int ix = head->x;
	int iy = head->y;
	switch (head->direction)
	{
		case Top:
		    head->y--;
		    break;
		case Bottom:
		    head->y++;
		    break;
		case Left:
		    head->x--;
		    break;
		case Right:
		    head->x++;
		    break;
		default:
		    break;
	}
	for (int i = (head->max)-1;i >= 0;--i)
	{
		if (i == 0)
		{
			body = head->pnext;
			body->x = ix;
			body->y = iy;
		}
		else
		{
	    	hbody = searchBody(head,i);
	    	body = searchBody(head,i-1);
	    	hbody->x = body->x;
	    	hbody->y = body->y;
		}	
	}
}