/*
** 蛇结构
*/

#ifndef _SNACK_H_
#define _SNACK_H_
#define BOOL int
#define true 1;
#define false 0;
// 最大长度
#define MAXLENGTH 15

//typedef struct Snake_Head S_Head;  //蛇头
//typedef struct Snake_Body S_Body;  //蛇身
typedef struct Snake_Body
{
	int x;						// x坐标
	int y;						// y坐标
	struct Snake_Body* pnext;
	int direction;				// 当前移动方向
}S_Body;

typedef struct Snake_Head
{
	int max;					// 蛇身最大数量
	int x;						// x坐标
	int y;						// y坐标
	S_Body *pnext;				// 后继蛇身
	int direction;				// 当前移动方向
}S_Head;


// 创建蛇
S_Head* Snake_init();

// 创建蛇身
S_Body* newBody();

// 判断蛇是否吃到食物(蛇头，食物坐标)
BOOL Snake_eat(S_Head* head,int x,int y);

// 判断蛇是否撞到自己
BOOL Snake_self(S_Head* head);

// 判断蛇是否撞墙(蛇头，边界)
BOOL Snake_die(S_Head* head,int size);

// 蛇吃到食物后长度加一
BOOL Snake_add(S_Head* head);

// 查找蛇身(蛇头，下标<从0开始>)
S_Body* searchBody(S_Head* head,int id);

// 通过按键控制蛇方向
void changeSnake(S_Head* head,int dir);

// 蛇运动
void Snake_move(S_Head* head);

#endif