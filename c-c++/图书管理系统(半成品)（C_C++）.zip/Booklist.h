#ifndef BOOKLIST_H
#define BOOKLIST_H 1
typedef struct BOOKINFO
{
	char name[20];//书籍名称
	char postdata[20];//出版日期
	int price;//价格
	int num;//库存
	
}Book;

typedef struct BOOKLISTNODE
{
	int count;//书籍种类数量
	struct BOOKINFO book;//书籍
	struct BOOKLISTNODE *pnext;//后继节点
}BookList;

/* 创建书籍 */
Book* newBook();

/* 创建链表 */
BookList* newBookList();  

/* 添加书籍到表头 */
void insertBookToHead(BookList *phead,Book *newbook);

/*  添加数据到表尾  */
void AddDataToLast(BookList *phead,Book *newbook);

/* 删除指定节点 */
void delBookByName(BookList *phead,char *bookname);

/* 查找书籍 */
int searchBookByName(BookList *phead,char *bookname);

/* 书籍排序 */
void sortBook(BookList *phead);

/* 打印书籍 */
void printBook(BookList *booknode);

/* 打印链表 */
void printBookList(BookList *phead);

/*  文件操作--存储数据  */
void SaveDataToFile(const char *filename,BookList *phead);

/*  文件操作--读取数据  */
void ReadDataFromFile(const char *filename,BookList *phead);
#endif
