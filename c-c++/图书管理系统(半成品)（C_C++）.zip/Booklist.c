#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "Booklist.h"

/* 创建书籍 */
Book* newBook()
{
	Book *book=(Book*)malloc(sizeof(Book));
	if(book==0)
	{
		printf("内存不足!\n");
	}
	book->price=0;
	book->num=0;
	return book;
}

/* 创建链表 */
BookList* newBookList()
{
	BookList *phead=(BookList*)malloc(sizeof(BookList));
	if(phead==0)
	{
		printf("内存不足!\n");
		exit(0);
	}
	phead->count=0;
	phead->pnext=NULL;
	return phead;
}

/* 添加书籍到表头 */
void insertBookToHead(BookList *phead,Book *newbook)
{
	BookList *pnew=newBookList();
	pnew->book=*newbook;
	if(phead->pnext==NULL) //如果为空链表
	{
		phead->pnext=pnew;
	}
	else
	{
		pnew->pnext=phead->pnext;
		phead->pnext=pnew;
	}
	printf("添加成功!\n");
}

/*  添加数据到表尾  */
void AddDataToLast(BookList *phead,Book *newbook)
{
	BookList *newbooklist=newBookList();
	newbooklist->book=*newbook;
	BookList *pnode=phead->pnext;
	if(pnode==NULL) //没有元素
	{
		phead->pnext=newbooklist;
		return;
	}
	while(pnode->pnext!=NULL)
	{
		pnode=pnode->pnext;
	}
	pnode->pnext=newbooklist;
}

/* 删除指定节点 */
void delBookByName(BookList *phead,char *bookname)
{
	BookList *delnode,*leftnode;
	leftnode=phead;
	delnode=phead->pnext;
	while(delnode!=NULL && strcmp(delnode->book.name,bookname))
	{
		leftnode=leftnode->pnext;
		delnode=delnode->pnext;
	}
	if(delnode!=NULL)
	{
		leftnode->pnext=delnode->pnext;
		delnode->pnext=NULL;
		free(delnode);
		delnode=NULL;
		printf("删除成功!\n");
	}
	else
	{
		printf("删除失败,未找到相关书籍!\n");
	}
	
}

/* 查找书籍 */
int searchBookByName(BookList *phead,char *bookname)
{
	BookList *posnode=phead->pnext;
	const char *str;
	while(posnode!=NULL)
	{
		str=posnode->book.name;
		if(!strcmp(str,bookname))
		{
			printBook(posnode);
			return 1;
		}
		posnode=posnode->pnext;
	}
	printf("未找到相关书籍!\n");
	posnode=NULL;
	return 0;
}

/* 书籍排序 */
void sortBook(BookList *phead)
{
	
}

/* 打印书籍 */
void printBook(BookList *booknode)
{
	printf("\t书名\t出版日期\t价格\t库存\n");
	printf("\t%s\t  %s\t\t %d \t %d  \n",booknode->book.name,booknode->book.postdata,booknode->book.price,booknode->book.num);
}

/* 打印链表 */
void printBookList(BookList *phead)
{
	BookList *pnode=phead->pnext;
	if(pnode==NULL)
	{
		printf("书架空荡荡的~\n");
	}else{
		printf("\t书名\t出版日期\t价格\t库存\n");
		while(pnode!=NULL)
		{
	        printf("\t%4s\t%4s\t%4d\t%4d\n",pnode->book.name,pnode->book.postdata,pnode->book.price,pnode->book.num);
			pnode=pnode->pnext;
		}
	}
	pnode=NULL;
}

/*  文件操作--存储数据  */
void SaveDataToFile(const char *filename,BookList *phead)
{
	FILE *fp=fopen(filename,"w");
	if(fp==NULL)
	{
		printf("打开或创建文件失败!\n");
		fclose(fp);
		return;
	}
	BookList *pnode=phead->pnext;
	while(pnode!=NULL)
	{
		if(pnode->pnext==NULL) //最后一个元素，写入时不换行
		{
			fprintf(fp,"%s\t%s\t%d\t%d",pnode->book.name,pnode->book.postdata,pnode->book.price,pnode->book.num);
			break;
		}
		fprintf(fp,"%s\t%s\t%d\t%d\n",pnode->book.name,pnode->book.postdata,pnode->book.price,pnode->book.num);
		pnode=pnode->pnext;
	}
	fclose(fp);
	return;
}

/*  文件操作--读取数据  */
void ReadDataFromFile(const char *filename,BookList *phead)
{
	FILE *fp=fopen(filename,"r");
	if(fp==NULL)  //文件不存在
	{
		fp=fopen(filename,"w+");
		if(fp==NULL) //文件操作有问题
		{
			printf("读取数据失败!\n");
			return;
		}
	}
	while(!feof(fp))
	{
		Book *newbook=newBook();
		fscanf(fp,"%s%s%d%d",(char*)newbook->name,(char*)&newbook->postdata,&newbook->price,&newbook->num);
        AddDataToLast(phead,newbook);
	}
	fclose(fp);
}