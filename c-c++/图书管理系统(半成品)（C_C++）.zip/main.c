#include <stdio.h>
#include<conio.h>
#include <stdlib.h>
#include "Booklist.h"
//#include "User.h"
const char *filename="/storage/emulated/0/图书管理.txt";  //文件名

/*  等待用户操作  */
int pause()
{
	printf("按任意数字继续.. ");
	//getchar();
	int a = 0;
	scanf("%d",&a);
	a++;
	return 1;
}

/*  界面布局 */
void show()
{
	printf("  ****************************\n");
	printf("  *-------- 图书管理系统 --------\n");
	printf("  ① 图书登记--添加新的图书\n");
	printf("  ② 图书查看--查看当前书架图书\n");
	printf("  ③ 图书查找--查看指定书籍\n");
	printf("  ④ 图书删除--将指定书籍从书籍移除\n");
	printf("  ⑤ 图书借阅--借阅图书,但需要登记\n");
	printf("  ⑥ 图书归还--归还从书架借阅的书\n");
	printf("  ⑦ 退出系统--安全退出并记录数据\n");
	printf("****************************\n");
}

int main()
{
	int comment=0; //指令下标
	char strs[20];
	char *pstr=strs;//用于各种字符串输入
	//int wait=0; //安卓没有pause，用跳过输入实现
	int needaddbooknum=1; //需要添加书籍数量
	BookList *phead=newBookList();
	Book *newbook=newBook();  //临时变量
	ReadDataFromFile(filename,phead);//读取文件数据
	while(1)
	{
		//clrscr(); //刷新一下界面
		show();
		comment = 0;
		printf("请输入(1-7)的指令:");
		scanf("%d",&comment);
		switch(comment)
		{
			case 1:  //图书登记
			    clrscr();
				printf("***当前位置>>图书管理系统>>图书登记\n");
				printf("●请输入需要添加的书籍数量(默认为1):");
				scanf("%d",&needaddbooknum);
				if(needaddbooknum <= 0)
				{
					printf("输入数量错误!\n");
					pause();
					break;
				}
				else
				{
					for(int i=0;i<needaddbooknum;i++)
					{
						printf("请输入书籍相关信息(书名,出版日期,价格,库存:");
						scanf("%s%s%d%d",(char*)newbook->name,(char*)&newbook->postdata,&newbook->price,&newbook->num);
						insertBookToHead(phead,newbook);
					}
					SaveDataToFile(filename,phead);
					pause();
				}
			    break;
			case 2:  //图书查看
			    clrscr();
				printf("***当前位置>>图书管理系统>>图书查看\n");
			    printBookList(phead);
				pause();
			    break;
			case 3:  //图书查找
			    clrscr();
				printf("***当前位置>>图书管理系统>>图书查找\n");
				printf("●请输入待查找的书名:");
				scanf("%s",(char*)pstr);
				searchBookByName(phead,pstr);
				pause();
			    break;
			case 4:  //图书删除
			    clrscr();
				printf("***当前位置>>图书管理系统>>图书删除\n");
				printf("●请输入需要删除的书名:");
				scanf("%s",(char*)pstr);
				delBookByName(phead,pstr);
				SaveDataToFile(filename,phead);
				pause();
			    break;
			case 5:  //图书借阅
			    printf("正在开发中...\n");
				pause();
			    break;
			case 6:  //图书归还
			    printf("正在开发中...\n");
				pause();
			    break;
			case 7:  //退出系统
			    SaveDataToFile(filename,phead);
				pause();
				printf("退出成功!\n");
				exit(0);
			    break;
		    default:
			    break;
		}
		clrscr();
	}
	return 0;
}