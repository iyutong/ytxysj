#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
	// 棋盘宽度
const int map_width = 17;
// 棋盘高度 
const int map_height = 17;
int g_conserX = map_width / 2;	// 光标X坐标 
int g_conserY = map_height / 2;	// 光标Y坐标
int player = 1;					// 默认黑棋先下 黑为1,白为2
int game_map[map_width][map_height];
int ai_scores[map_width][map_height] = { 0 };
int result[2] = { 0, 0 };


// 开始游戏
void PlayGame();

// 初始化游戏
void InitGame();

// 绘制棋盘
void Print_Map();

// 下棋
int CheckDown();

// 判断游戏是否结束,传入棋手和下棋的坐标
int Game_Check(int player, int x, int y);

// 光标改变
void Conser_Change();

/* 游戏说明 */
void GamePrint();

/* AI计算 */
void Ai();

int main()
{
	InitGame();
	GamePrint();
	getch();
	while (1)
	{
		PlayGame();
	}
	return 0;
}

// 开始游戏
void PlayGame()
{
	Print_Map();
	Conser_Change();
	return;
}

// 初始化游戏
void InitGame()
{
	memset(game_map, 0, sizeof(game_map));	// 初始化棋盘数组为0
	memset(ai_scores, 0, sizeof(ai_scores));
	g_conserX = map_width / 2;	// 光标X坐标 
	g_conserY = map_height / 2;	// 光标Y坐标 
	return;
}

/* 游戏说明 */
void GamePrint()
{
	printf("\t********五子棋********\n");
	printf("\t游戏说明 : \n");
	printf("\t光标向上移动 : 2\n");
	printf("\t光标向下移动 : 8\n");
	printf("\t光标向左移动 : 4\n");
	printf("\t光标向右移动 : 6\n");
	printf("\t下棋 : 5  ");
}

// 绘制棋盘
void Print_Map()
{
	clrscr();
	printf("\n\n");
	// 双重for循环
	for (int i = 0; i < map_width; i++)
	{
		printf("\t    ");
		for (int j = 0; j < map_height; j++)
		{
			if (i == 0 && j == 0 && game_map[i][j] == 0 && i != g_conserY && j != g_conserX)	// 左上角
			{
				printf("┌");
			}
			else if (i == 0 && j == map_width - 1 && game_map[i][j] == 0 && i != g_conserY && j != g_conserX)	// 右上角
			{
				printf("┐");
			}
			else if (i == map_height - 1 && j == 0 && game_map[i][j] == 0 && i != g_conserY && j != g_conserX)	// 左下角
			{
				printf("└");
			}
			else if (i == map_height - 1 && j == map_width - 1 && game_map[i][j] == 0 && i != g_conserY && j != g_conserX)	// 右下角
			{
				printf("┘");
			}
			else if (i == 0 && j != g_conserX && game_map[i][j] == 0)	// 上边界
			{
				printf("┬");
			}
			else if (i == map_height - 1 && j != g_conserX && game_map[i][j] == 0)	// 下边界
			{
				printf("┴");
			}
			else if (j == 0 && i != g_conserY && game_map[i][j] == 0)	// 左边界
			{
				printf("├");
			}
			else if (j == map_width - 1 && i != g_conserY && game_map[i][j] == 0)	// 右边界
			{
				printf("┤");
			}
			else if (i == g_conserY && j == g_conserX && game_map[i][j] == 0)
			{
				printf("╋");
			}
			else if (game_map[i][j] == 2)
			{
				printf("●");
			}
			else if (game_map[i][j] == 1)
			{
				printf("○");
			}
			else if (i != g_conserY || j != g_conserX && game_map[i][j] == 0)	// 中间
			{
				printf("┼");
			}
		}
		printf("\n");
	}
	if (player == 1)
	{
		printf(" 当前棋手 : 黑棋  ");
	}
	else
	{
		printf(" 当前棋手 : 白旗  ");
	}
	printf("  x : %d,y : %d ", g_conserX, g_conserY);
	printf("\n %d", ai_scores[g_conserY][g_conserX]);
	return;
}

// 光标改变
void Conser_Change()
{
	switch (getch())
	{
	case 50:					// 向上
		g_conserY--;
		if (g_conserY < 0)
		{
			g_conserY = map_height - 1;
		}
		while (1)
		{
			if (game_map[g_conserY][g_conserX] == 0)
			{
				break;
			}
			else
			{
				g_conserY--;
				if (g_conserY < 0)
				{
					g_conserY = map_height - 1;
				}
			}
		}
		break;
	case 56:					// 向下
		g_conserY++;
		if (g_conserY >= map_height)
		{
			g_conserY = 0;
		}
		while (1)
		{
			if (game_map[g_conserY][g_conserX] == 0)
			{
				break;
			}
			else
			{
				g_conserY++;
				if (g_conserY >= map_height)
				{
					g_conserY = 0;
				}
			}
		}
		break;
	case 52:					// 向左
		g_conserX--;
		if (g_conserX < 0)
		{
			g_conserX = map_width - 1;
		}
		while (1)
		{
			if (game_map[g_conserY][g_conserX] == 0)
			{
				break;
			}
			else
			{
				g_conserX--;
				if (g_conserX < 0)
				{
					g_conserX = map_width - 1;
				}
			}
		}
		break;
	case 54:					// 向右
		g_conserX++;
		if (g_conserX > map_width - 1)
		{
			g_conserX = 0;
		}
		while (1)
		{
			if (game_map[g_conserY][g_conserX] == 0)
			{
				break;
			}
			else
			{
				g_conserX++;
				if (g_conserX > map_width - 1)
				{
					g_conserX = 0;
				}
			}
		}
		break;
	case 53:					// 下棋
		if (CheckDown() && player == 1)
		{
			if (Game_Check(player, g_conserX, g_conserY) == 1)
			{
				Print_Map();
				sleep(1);
				clrscr();		// 清屏
				printf("\n\n\t*****黑棋胜利!*****\n");
				printf("\t按tab键重新开始,其他键退出...");
				switch (getch())
				{
				case 32:
					InitGame();
					break;
				default:
					exit(0);
					break;
				}
			}
			player = 3 - player;			
		}
		//player = 3 - player;
		Ai();
		g_conserX = result[1];
		g_conserY = result[0];
		if (CheckDown() && player == 2)
		{
			if (Game_Check(player, g_conserX, g_conserY) == 2)
			{
				Print_Map();
				sleep(1);
				clrscr();		// 清屏
				printf("\n\n\t*****白棋胜利!*****\n");
				printf("\t按tab键重新开始,其他键退出...");
				switch (getch())
				{
				case 32:
					InitGame();
					break;
				default:
					exit(0);
					break;
				}
			}
			player = 3 - player;
			break;
		}
		else
		{
			
		}
		//player = 3 - player;
		break;
	default:
		break;
	}
}

// 下棋
int CheckDown()
{
	if (player == 1 && game_map[g_conserY][g_conserX] == 0)	// 黑棋且没有被下
	{
		game_map[g_conserY][g_conserX] = 1;
		return 1;
	}
	else if (player == 2 && game_map[g_conserY][g_conserX] == 0)	// 白旗且未被下
	{
		game_map[g_conserY][g_conserX] = 2;
		return 1;
	}
	return 0;
}

// 判断游戏是否结束,传入棋手和下棋的坐标
int Game_Check(int player, int x, int y)
{
	int total = 0;				// 存储相同棋子个数
	for (int i = x; i < x + 5; i++)	// 横向向右
	{
		if (game_map[y][i] == player)	// 如果是玩家1
		{
			total++;
			if (total >= 5)
			{
				total = 0;
				return player;
			}
		}
		else if (game_map[y][i] != player || i >= map_width - 1)	// 到达棋盘边界或不满足
		{
			for (int j = x; j > x - 5; j--)	// 向左搜索
			{
				if (game_map[y][j] == player)
				{
					total++;
				}
				else if (game_map[y][j] != player || j <= 0)	// 到达棋盘边界或者不满足
				{
					break;
				}
			}
			break;
		}
	}
	if (total >= 6)
	{
		total = 0;
		return player;
	}
	total = 0;					// 横向不满足，棋子置为0
	for (int i = y; i < y + 5; i++)	// 纵向向下
	{
		if (game_map[i][x] == player)	// 如果是玩家1
		{
			total++;
			if (total >= 5)
			{
				total = 0;
				return player;
			}
		}
		else if (game_map[i][x] != player || i >= map_width - 1)
		{
			for (int j = y; j > y - 5; j--)	// 向上搜索
			{
				if (game_map[j][x] == player)
				{
					total++;
				}
				else if (game_map[j][x] != player || j <= 0)
				{
					break;
				}
			}
			break;
		}
	}
	if (total >= 6)
	{
		total = 0;
		return player;
	}
	total = 0;
	/* 斜向下到斜向上 */
	for (int i = 0; i < 5; i++)
	{
		if (game_map[y - i][x + i] == player)
		{
			total++;
			if (total >= 5)
			{
				total = 0;
				return player;
			}
		}
		else if (game_map[y - i][x + i] != player || (y - i) >= 0 || (x + i) >= map_width)
		{
			for (int j = 0; j < 5; j++)
			{
				if (game_map[y + j][x - j] == player)
				{
					total++;
				}
				else if (game_map[y + j][x - j] != player || (y + j) >= map_height || (x - j) <= 0)
				{
					break;
				}
			}
			break;
		}

	}
	if (total >= 6)
	{
		total = 0;
		return player;
	}
	total = 0;
	/* 左上到右下 */
	for (int i = 0; i < 5; i++)
	{
		if (game_map[y + i][x + i] == player)
		{
			total++;
			if (total >= 5)
			{
				total = 0;
				return player;
			}
		}
		else if (game_map[y + i][x + i] != player || (x + i) >= map_width || (y + i) >= map_height)
		{
			for (int j = 0; j < 5; j++)
			{
				if (game_map[y - j][x - j] == player)
				{
					total++;
				}
				else if (game_map[y - j][x - j] != player || (y - j) <= 0 || (x - j) <= 0)
				{
					break;
				}
			}
			break;
		}
	}
	if (total >= 6)
	{
		total = 0;
		return player;
	}
	total = 0;
	return total;
}

/* ---------- 普通AI算法 ---------- */
void Ai()
{
	memset(ai_scores ,0,sizeof (ai_scores));
	int player_num = 0;			// 玩家棋子个数
	int ai_num = 0;				// Ai棋子个数
	int other_num = 0;			// 计算分数
	// 遍历每个点
	for (int y = 0; y < map_height; y++)
	{
		for (int x = 0; x < map_width; x++)
		{
			/* ---------- */
			// 如果这个点未被下,判断该点8个方向黑白棋
			if (game_map[y][x] == 0 && x > 0 && y > 0)
			{
				for (int j = -1; j <= 1; j++)
				{
					for (int i = -1; i <= 1; i++)
					{
						// 重置
						player_num = 0;
						other_num = 0;
						ai_num = 0;
						// 如果不是原点
						if (i != 0 || j != 0)
						{
							// 判断黑棋(玩家)棋子
							for (int m = 1; m < 5; m++)
							{
								if (game_map[y + (m * j)][x + (m * i)] == 1 && (y + (m * j)) >= 0
									&& (y + (m * j)) < map_height && (x + (m * i)) >= 0
									&& (x + (m * i)) < map_width)
								{
									player_num++;
								}
								else if (game_map[y + (m * j)][x + (m * i)] == 0
										 && (y + (m * j)) >= 0
										 && (y + (m * j)) < map_height
										 && (x + (m * i)) >= 0 && (x + (m * i)) < map_width)
								{
									other_num++;
									break;
								}
								else
								{
									break;
								}
							}
							other_num = 0;
							for (int m = 1; m < 5; m++)
							{
								if (game_map[y - (m * j)][x + (m * i)] == 1 && (y - (m * j)) >= 0
									&& (y - (m * j)) < map_height && (x - (m * i)) >= 0
									&& (x - (m * i)) < map_width)
								{
									player_num++;
								}
								else if (game_map[y - (m * j)][x + (m * i)] == 0
										 && (y - (m * j)) >= 0
										 && (y - (m * j)) < map_height
										 && (x - (m * i)) >= 0 && (x - (m * i)) < map_width)
								{
									other_num++;
									break;
								}
								else
								{
									break;
								}
							}
							if (player_num == 1)	// 杀二 
							{
								ai_scores[y][x] += 20;
							}
							else if (player_num == 2)	// 杀三
							{
								if (other_num == 1)
								{
									ai_scores[y][x] += 60;
								}
								else if (other_num == 2)
								{
									ai_scores[y][x] += 120;
								}
							}
							else if (player_num == 3)	// 杀四
							{
								if (other_num == 1)
								{
									ai_scores[y][x] += 240;
								}
								else if (other_num == 2)
								{
									ai_scores[y][x] += 480;
								}
							}
							else if (player_num == 4)	// 杀五
							{
								ai_scores[y][x] += 15000;
							}
							other_num = 0;
							// 对ai棋子判断
                            for (int m = 1; m < 5; m++)
							{
								if (game_map[y + (m * j)][x + (m * i)] == 2 && (y + (m * j)) >= 0
									&& (y + (m * j)) < map_height && (x + (m * i)) >= 0
									&& (x + (m * i)) < map_width)
								{
									ai_num++;
								}
								else if (game_map[y + (m * j)][x + (m * i)] == 0
										 && (y + (m * j)) >= 0
										 && (y + (m * j)) < map_height
										 && (x + (m * i)) >= 0 && (x + (m * i)) < map_width)
								{
									other_num++;
									break;
								}
								else
								{
									break;
								}
							}
							other_num = 0;
							for (int m = 1; m < 5; m++)
							{
								if (game_map[y - (m * j)][x + (m * i)] == 2 && (y - (m * j)) >= 0
									&& (y - (m * j)) < map_height && (x - (m * i)) >= 0
									&& (x - (m * i)) < map_width)
								{
									ai_num++;
								}
								else if (game_map[y - (m * j)][x + (m * i)] == 0
										 && (y - (m * j)) >= 0
										 && (y - (m * j)) < map_height
										 && (x - (m * i)) >= 0 && (x - (m * i)) < map_width)
								{
									other_num++;
									break;
								}
								else
								{
									break;
								}
							}
							if (ai_num == 1)	// 活二 
							{
								ai_scores[y][x] += 15;
							}
							else if (ai_num == 2)	// 活三
							{
								if (other_num == 1)
								{
									ai_scores[y][x] += 30;
								}
								else if (other_num == 2)
								{
									ai_scores[y][x] += 60;
								}
							}
							else if (ai_num == 3)	// 活四
							{
								if (other_num == 1)
								{
									ai_scores[y][x] += 120;
								}
								else if (other_num == 2)
								{
									ai_scores[y][x] += 240;     
								}
							}
							else if (ai_num == 4)	// 活五
							{
								ai_scores[y][x] += 20000;
							}
							other_num = 0;
						}
					}
				}
			}
			/* ---------- */
		}
	}
	// 取出最大值
	int max = 0;
	for (int y = 0; y < map_height; y++)
	{
		for (int x = 0; x < map_width; x++)
		{
			if (ai_scores[y][x] > max)
			{
				max = ai_scores[y][x];
				result[0] = y;
				result[1] = x;
			}
		}
	}
}
/* ---------- AI结束 ---------- */