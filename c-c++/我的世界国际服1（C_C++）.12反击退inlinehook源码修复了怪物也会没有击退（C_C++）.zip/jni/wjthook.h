#include <stdio.h>
#include <jni.h>
#include <stddef.h>
#include "include/inlineHook.h"
#include <android/log.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

#include <stddef.h>
#include <dlfcn.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>


unsigned long wjtweb = NULL;

int (*old_wjtweb)(void) = NULL;


int new_wjtwebwjtweb(void)
{


  return 0;
}


int hookCalcwjtweb()
{

    if (registerInlineHook((uint32_t) wjtweb, (uint32_t) new_wjtwebwjtweb, (uint32_t **) &old_wjtweb) != ELE7EN_OK) {
        return -1;
    }
    if (inlineHook((uint32_t) wjtweb) != ELE7EN_OK) {
        return -1;
    }

    return 0;
}

int unHookhookCalcwjtweb()
{

    if (inlineUnHook((uint32_t) wjtweb) != ELE7EN_OK) {
        return -1;
    }
    return 0;
}
