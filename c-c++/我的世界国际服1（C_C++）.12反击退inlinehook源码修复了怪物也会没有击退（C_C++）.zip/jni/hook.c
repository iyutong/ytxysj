#include <stdio.h>
#include <jni.h>
#include <stddef.h>
#include "include/inlineHook.h"
#include <android/log.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

#include <wjthook.h>
#include <dlfcn.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>

#define LOG_TAG "xyz"

#define LOGD(fmt,args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG,fmt, ##args)

pthread_t pthread;

int getPID() {
    int id = -1, pid = -1;
    DIR *dir = 0;
    FILE *file = 0;
    char filename[32] = {0};
    char cmdline[256] = {0};
    struct dirent *entry = 0;



    dir = opendir("/proc");
    if (dir == NULL) {
        return -1;
    }

    while ((entry = readdir(dir)) != NULL) {
        id = atoi(entry->d_name);
        if (id > 0) {
            sprintf(filename, "/proc/%d/cmdline", id);
            file = fopen(filename, "r");

            if (file) {
                fgets(cmdline, sizeof(cmdline), file);
                fclose(file);

                if (strcmp("com.mojang.minecraftpe", cmdline) == 0) {
                    pid = id;
                    break;
                }
            }
        }
    }
    closedir(dir);
    return pid;
    /*���ؽ���id*/
}

static unsigned long find_database_of(char* soName)
{
  char filename[32];
  char cmdline[256];
  sprintf(filename, "/proc/%d/maps", getPID());

  FILE *fp = fopen(filename, "r");
  unsigned long revalue = 0;
  if (fp)
  {
    while(fgets(cmdline, 256, fp))
    {
      if(strstr(cmdline, soName) && strstr(cmdline, "r-xp"))
      {

        char *str = strstr(cmdline,"-");
        if(str)
        {
          *str='\0';
          char num[32];
          sprintf(num, "0x%s", cmdline);
          revalue = strtoul( num, NULL, 0 );

          return revalue;
        }
      }
      memset(cmdline,0,256);
    }
    fclose(fp);
  }
  return 0L;
}








void hack(){
unsigned long base = find_database_of("libminecraftpe.so");
while(true){
if(base <0L){
base = find_database_of("libminecraftpe.so");
}
if(base==0L){
base = find_database_of("libminecraftpe.so");
}
if(base > 0L){
break;
}
}
if (base > 0L) {
     LOGD("base = %x ",base);

    	


	    	
	    	wjtweb = base + 0x12B0258;
		
        
   		 	hookCalcwjtweb();
    		
			
        
 }
pthread_exit(NULL);
      
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*vm, void* reserved){

    pthread_create(&pthread, NULL, hack, NULL);
    return JNI_VERSION_1_6;
}


