#include <stdio.h>
#include "Game/LinkList.h"
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include "Game/game.h"

/*
** 作者 : 爱编程的猴子
** 功能 : 简单文字游戏
** 时间 : 2020.6.18
*/

const char *filename="/storage/emulated/0/文字游戏.txt";
void show(const char* str)
{
	printf("%s",str);
}
int main(void)
{
	srand(time(NULL));
	User* user = init_User();
	Dcat* dcat=init_Dcat();
	Emy*emy = init_Emy();
	Head* mbag = GetBagHeadFromUser(user);
	Head* MapEmy = newLinkListHead();
	//int map_randindex;//随机地图下标
	int againstcount = 0;//战斗时怪物下标
	int chiosemapindex = 0;//地图下标
	int needNowthing_index = 0;//需要佩戴装备的下标
	int needBuy_index=-1;//需要购买装备的下标
	User_addThing(user,Bag_getThing(user,0));
	int contral = 0;
	/* 读取数据 */
	//GetDataFromFile(filename,user);
	while(true)
	{
		againstcount = 0;
		User_Show(user);
		System_ShowContral();
		printf("请输入:");
		scanf("%d",&contral);
		switch(contral)
		{
		case 1://显示背包
			Bag_show(user);
			break;
		case 2://战斗
			//Head *MapEmy = newLinkListHead();
			clrscr();
			printf("正在进入...\n");
			sleep(1);
			printf("当前可探索区域:\n");
			printf("1.破废城区\t2.暗黑熔岩\t3.黑暗盛林\n4.虚空之眼\t5.远古战场\t6.无尽深渊\n");
			printf("请选择地图:");
			scanf("%d",&chiosemapindex);
			MapEmy = GetEmyFromMap(emy,chiosemapindex);
			Bag_show(user);
			printf("请选择需要佩戴的装备:");
			scanf("%d",&needNowthing_index);
			if(needNowthing_index>0&&needNowthing_index<=LinkList_getSize(mbag))
			{
				printf("正在穿戴...\n");
				sleep(1);
				User_addThing(user,(Thing*)Bag_getThing(user,needNowthing_index-1));
				printf("穿戴完成");
			}
			else{
				printf("穿戴失败!\n");
				
			}
			printf("正在进入...\n");
			sleep(1);
			Spc*mspc;
			while(true)
			{
				if(againstcount>=LinkList_getSize(MapEmy))
				{
					printf("挑战成功,获得小额奖励,正在返回...\n");
					User_Recover(user);
					LinkList_delAll(MapEmy);
					User_clearNowThing(user);
					SaveDataToFile(filename,user);
					show("返回成功!\n");
					break;
				}
				mspc = LinkList_getData(MapEmy,againstcount);
				if(Against(user,mspc))
				{
					againstcount++;
					sleep(1);
					continue;
				}
				User_Recover(user);
				User_clearNowThing(user);
				LinkList_delAll(MapEmy);
				show("欢迎回来!\n");
				break;
			}
			break;
		case 3://进入商城
		    clrscr();
		    show("正在进入...");
			show("进入成功!\n");
			sleep(1);
			Shop_Show(dcat);
			printf("请输入需要购买的装备序号:");
			scanf("%d",&needBuy_index);
			User_BuyThing(user,dcat,needBuy_index);
		    break;
		case 6:
		    SaveDataToFile(filename,user);
			show("正在退出..");
			sleep(1);
			show("退出成功!");
			exit(0);
			break;
		default:
			show("请输入正确指令!\n");
			sleep(1.5);
			clrscr();
			break;
		}
	}
	return 0;
}