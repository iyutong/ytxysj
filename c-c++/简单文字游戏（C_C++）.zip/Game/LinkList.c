#include "LinkList.h"
#include <stdio.h>
#include <stdlib.h>

/*
** 作者 : 爱编程的猴子
** 功能 : 简单链表封装--用于存储数据
** 时间 : 2020.6.19
*/

struct LinkListHead
{
	int length;
    struct LinkListNode *plink;
};

struct LinkListNode
{
	const void *data;
	struct LinkListNode *pfront;
	struct LinkListNode *pnext;
};


Head* newLinkListHead()
{
	Head *phead;
	phead=(Head*)malloc(sizeof(Head));
	if(phead==0)
	{
		printf("内存不足！\n");
		exit(0);
	}
	phead->length=0;
	phead->plink=NULL;
	return phead;
}

Node* newLinkListNode()
{
	Node *pnode;
	pnode=(Node*)malloc(sizeof(Node));
	if(pnode==0)
	{
		printf("内存不足!\n");
		exit(0);
	}
	pnode->pnext=NULL;
	pnode->pfront=NULL;
	return pnode;
}

bool LinkList_isEmpty(Head *phead)
{
	if(phead->plink==NULL || LinkList_getSize(phead)==0)
	{
		return true;
	}
	return false;
}

bool LinkList_addData(Head *phead,const void *data)
{
	int Length=LinkList_getSize(phead);
	if(LinkList_addAt(phead,data,Length))
	{
		return true;
	}
	return false;
}

bool LinkList_addAt(Head *phead,const void *data,int n)
{
	Node *pnew=newLinkListNode();
	pnew->data=data;
	if(LinkList_isEmpty(phead)==1)
	{
		 phead->plink=pnew;
		 phead->length+=1;
		 // printf("添加成功\n");
		 return true;
	}else
	{
	    Node *pro=LinkList_getNode(phead,n-1);
	    if(pro==NULL)
	    {
		    printf("添加失败\n");
		    free(pnew);
		    return false;
	     }
	    Node *next=pro->pnext;
	    pro->pnext=pnew;
	    pnew->pfront=pro;
	    pnew->pnext=next;
	    if(next!=NULL)
	    {
		    next->pfront=pnew;
	    }
	    phead->length++;
	    // printf("添加成功\n");
    }
	return true;
}

Node* LinkList_getNode(Head* phead,int n)
{
	Node *pnode=phead->plink;
	if(n>(LinkList_getSize(phead)-1))
	{
		printf("获取失败,请检查下标\n");
		return NULL;
	}else
	{
	    for(int i=0;i<n;i++)
	    {
		    pnode=pnode->pnext;
	    }
		return pnode;
	}
	return pnode;
}

int LinkList_getSize(Head *phead)
{
	return (int)phead->length;
}

void *LinkList_getData(Head *phead,int n)
{
	Node *pnode=LinkList_getNode(phead,n);
	if(pnode==NULL)
	{
		return NULL;
	}
	return (void*)(pnode->data);
}

bool LinkList_delAt(Head *phead,int n)
{
	if(n<0 || n>=LinkList_getSize(phead))
	{
		printf("请输入合适下标!\n");
		return false;
	}
	Node *pnode=LinkList_getNode(phead,n);
	Node *front=pnode->pfront;
	Node *next=pnode->pnext;
	if(front!=NULL)//不是第一个
	{
		pnode->pfront=NULL;
		if(next!=NULL)
		{
			pnode->pnext=NULL;
			next->pfront=front;
			front->pnext=next;
		}else//为最后一个
		{
			front->pnext=NULL;
		}
	}else//为第一个
	{
		if(next!=NULL)//元素不止一个
		{
			next->pfront=NULL;
			pnode->pnext=NULL;
			phead->plink=next;
		}else//有且只有一个
		{
			phead->plink=NULL;
		}
	}
	free(pnode);
	phead->length--;
	return true;
}

bool LinkList_pop(Head *phead)
{
	if(LinkList_delAt(phead,LinkList_getSize(phead)-1))
	{
		return true;
	}
	return false;
}

void LinkList_sort(Head *phead,int type)
{
	Node *node,*sort;
	const void *t;
	switch(type)
	{
		case 5:
		     for(int i=0;i<LinkList_getSize(phead);i++)
			 {
				 node=LinkList_getNode(phead,i);
				 for(int j=i;j<LinkList_getSize(phead);j++)
				 {
					 sort=LinkList_getNode(phead,j);
					 if((sort->data)<(node->data))
					 {
						 t=sort->data;
						 sort->data=node->data;
						 node->data=t;
					 }
				 }
			 }
		     break;
	    case 10:
		     for(int i=0;i<LinkList_getSize(phead);i++)
			 {
				 node=LinkList_getNode(phead,i);
				 for(int j=i;j<LinkList_getSize(phead);j++)
				 {
					 sort=LinkList_getNode(phead,j);
					 if((sort->data)>(node->data))
					 {
						 t=node->data;
						 node->data=sort->data;
						 sort->data=t;
					 }
				 }
			 }
		     break;
	}
}

bool LinkList_delAll(Head *phead)
{
	for(int i=LinkList_getSize(phead)-1;i>=0;i--)
	{
		LinkList_delAt(phead,i);
	}
	return true;
}
