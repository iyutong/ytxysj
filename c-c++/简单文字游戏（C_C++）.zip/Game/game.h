#include "LinkList.h"
 typedef struct USER User;
 typedef struct BAG Bag;
 typedef struct EMY Emy;
 typedef struct DCAT Dcat;
 typedef struct THING Thing;
 typedef struct SPC Spc;
 
 /*
** 作者 : 爱编程的猴子
** 功能 : ..
** 时间 : 2020.6.19
*/
 
 //创建用户
 User* newUser();
 //创建背包
 Bag* newBag();
 //创建敌人集合
 Emy* newEmy();
 //创建装备集合
 Dcat* newDcat();
 //创建装备
 Thing* newThing();
 //创建怪兽
 Spc* newSpc();
 //初始化用户属性
 User* init_User();
 //初始化背包
 Bag* init_Bag();
 //初始化装备集合
 Dcat* init_Dcat();
 //初始化敌人集合
 Emy* init_Emy();
 //获取装备
 Thing* GetThing(int count);
 //获取怪兽
 Spc* GetSpc(int count);
 //添加物品进入背包
 bool Bag_add(User *user,Thing *thing);
 //显示背包物品
 bool Bag_show(User *user);
 //更新背包属性
 bool Bag_change(Bag *bag);
 //判断是否已满
 bool Bag_iscanAdd(Bag *bag);
 //从背包中获取装备
 Thing *Bag_getThing(User *user,int count);
 //删除物品
 bool Bag_delThing(User *user,int count);
 //携带装备
 bool User_addThing(User *user,Thing *thing);
 //恢复
 bool User_Recover(User *user);
 //判断是否可以升级
 bool User_CheckUp(User *user);
 //更改昵称
 bool User_ChangeName(User *user,char *name);
 //更改密码
 bool User_ChangePass(User *user,char *pass);
 //购买判断
 bool User_BuyChick(User *user,Thing *thing);
 //购买商品
 bool User_BuyThing(User *user,Dcat *dcat,int n);
 //选择怪物
 Spc *ChioseSpcByMap(Emy *emy,int n);
 //打架
 bool Against(User *user,Spc *spc);
 //显示用户信息
 bool User_Show(User *user);
 //打印商城商品
 bool Shop_Show(Dcat *dcat);
 //打印指令
 bool System_ShowContral();
 //卸载装备
 bool User_clearNowThing(User *user);
 //获取背包
 Head* GetBagHeadFromUser(User *user);
 //根据地图创建敌人队列
 Head* GetEmyFromMap(Emy *emy,int n);
 //保存数据
 bool SaveDataToFile(const char *filename,User *user);
 //读取数据
 bool GetDataFromFile(const char *filename,User *user);
 