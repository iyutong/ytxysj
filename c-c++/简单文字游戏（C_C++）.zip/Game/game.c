#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include "game.h"
#include <conio.h>
#include "LinkList.h"

/*
** 作者 : 爱编程的猴子
** 功能 : 垃圾游戏逻辑和数据
** 时间 : 2020.6.19
*/

extern const char *filename;
struct USER
{
	char*name;
	char*account;
	char*pass;
	int hp;
	int att;
	int resist;
	int MaxHp;
	int leval;
	int MaxExp;
	int NowExp;
	long int money;
	Bag*bag;
	Thing*nowThing;
};

struct BAG
{
	Head*phead;
	int MaxCount;
	int NowCount;
	int OtherCount;
	int leval;
};

struct EMY
{
	Head*phead;
};

struct DCAT
{
	Head*phead;
};

struct THING
{
	int att;
	int resist;
	int bg;
	char*In;
	int ReHp;
	char*name;
	int cost;
};

struct SPC
{
	char*name;
	char*In;
	int att;
	int resist;
	int maxhp;
	int hp;
	int bg;
	int cost;
	int exp;
	int leval;
};

User*newUser()
{
	User*user = (User*)malloc(sizeof(User));
	if(user==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	user->bag = NULL;
	user->nowThing = NULL;
	return user;
}

Bag*newBag()
{
	Bag*bag = (Bag*)malloc(sizeof(Bag));
	if(bag==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	return bag;
}

Emy*newEmy()
{
	Emy*emy = (Emy*)malloc(sizeof(Emy));
	if(emy==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	return emy;
}

Dcat*newDcat()
{
	Dcat*dcat = (Dcat*)malloc(sizeof(Dcat));
	if(dcat==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	return dcat;
}

Thing*newThing()
{
	Thing*thing = (Thing*)malloc(sizeof(Thing));
	if(thing==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	return thing;
}

Spc*newSpc()
{
	Spc*spc = (Spc*)malloc(sizeof(Spc));
	if(spc==0)
	{
		printf("无法分配内存空间!\n");
		return NULL;
	}
	return spc;
}

User*init_User()
{
	User*user = newUser();
	user->name = "毒云";
	user->account = "123456";
	user->pass = "123456";
	user->att = 15;
	user->resist = 5;
	user->leval = 1;
	user->MaxExp = 200;
	user->NowExp = 0;
	user->money = 20;
	user->bag = init_Bag();
	user->MaxHp = 100;
	user->hp = user->MaxHp;
	return user;
}

Bag*init_Bag()
{
	Dcat*dcat = init_Dcat();
	Bag*bag = newBag();
	bag->phead = newLinkListHead();
	bag->MaxCount = 10;
	bag->leval = 1;
	bag->NowCount = 0;
	if(LinkList_addData(bag->phead,(Thing*)LinkList_getData(dcat->phead,0)))
	{
		bag->NowCount++;
		Bag_change(bag);
		return bag;
	}
	Bag_change(bag);
	return bag;
}

Dcat*init_Dcat()
{
	Dcat*dcat = newDcat();
	dcat->phead = newLinkListHead();
	for(int i = 0;i<5;i++)
	{
		LinkList_addData(dcat->phead,(Thing*)GetThing(i));
	}
	return dcat;
}

Emy*init_Emy()
{
	Emy*emy = newEmy();
	emy->phead = newLinkListHead();
	for(int i = 0;i<5;i++)
	{
		LinkList_addData(emy->phead,(Spc*)GetSpc(i));
	}
	return emy;
}

Thing*GetThing(int count)
{
	Thing*thing = newThing();
	switch(count)
	{
	case 0:
		thing->name = "初级打野刀";
		thing->att = 5;
		thing->resist = 0;
		thing->bg = 0;
		thing->ReHp = 0;
		thing->cost = 25;
		thing->In = "外出时带一把刀不香吗";
		break;
	case 1:
		thing->name = "闪电战刀";
		thing->att = 20;
		thing->resist = 25;
		thing->bg = 15;
		thing->ReHp = 5;
		thing->cost = 100;
		thing->In = "凝聚闪电的力量，可以打出暴击";
		break;
	case 2:
		thing->name = "看起来还行的刀";
		thing->att = 30;
		thing->resist = 40;
		thing->bg = 0;
		thing->ReHp = 20;
		thing->cost = 500;
		thing->In = "相传是远古遗留下来的";
		break;
	case 3:
		thing->name = "远古利刃";
		thing->att = 50;
		thing->resist = 10;
		thing->bg = 40;
		thing->ReHp = -20;
		thing->cost = 3000;
		thing->In = "残存邪念，以牺牲自我为代价换取高额暴击";
		break;
	case 4:
		thing->name = "深渊主宰";
		thing->att = 100;
		thing->resist = 80;
		thing->bg = 10;
		thing->ReHp = 10;
		thing->cost = 7000;
		thing->In = "屠过龙，杀过魔";
		break;
	default:
		thing->name = "一元小刀";
		thing->att = 1;
		thing->resist = 1;
		thing->bg = 0;
		thing->ReHp = 0;
		thing->cost = 50000;
		thing->In = "当你住够强大时，小刀亦能斩天灭地";
		break;
	}
	return thing;
}

Spc*GetSpc(int count)
{
	Spc*spc = newSpc();
	switch(count)
	{
	case 0:
		spc->name = "失落的小人";
		spc->att = 8;
		spc->bg = 0;
		spc->resist = 2;
		spc->maxhp=100;
		spc->hp = spc->maxhp;
		spc->cost = 2;
		spc->exp = 5;
		spc->leval = 1;
		spc->In = "与部队走丢的小人,经常出没于林间";
		break;
	case 1:
		spc->name = "精英战士";
		spc->att = 25;
		spc->bg = 5;
		spc->resist = 5;
		spc->maxhp=250;
		spc->hp = spc->maxhp;
		spc->cost = 5;
		spc->exp = 10;
		spc->leval = 2;
		spc->In = "有着锋利的刀和精湛的技术!";
		break;
	case 2:
		spc->name = "狂暴飞龙";
		spc->att = 105;
		spc->bg = 20;
		spc->resist = 50;
		spc->maxhp=550;
		spc->hp = spc->maxhp;
		spc->cost = 15;
		spc->exp = 28;
		spc->leval = 5;
		spc->In = "异常狂暴，一般别惹";
		break;
	case 3:
		spc->name = "无尽守卫";
		spc->att = 150;
		spc->bg = 50;
		spc->resist = 150;
		spc->maxhp=2000;
		spc->hp = spc->maxhp;
		spc->cost = 50;
		spc->exp = 205;
		spc->leval = 8;
		spc->In = "别小瞧它，血可厚了";
		break;
	case 4:
		spc->name = "深渊主宰";
		spc->att = 700;
		spc->bg = 60;
		spc->resist = 400;
		spc->maxhp=1500;
		spc->hp = spc->maxhp;
		spc->cost = 200;
		spc->exp = 550;
		spc->leval = 50;
		spc->In = "龙族的一次进化，千万小心";
		break;
	default:
		spc->name = "万界魔王";
		spc->att = 5000;
		spc->bg = 90;
		spc->resist = 1500;
		spc->maxhp=50000;
		spc->hp = spc->maxhp;
		spc->cost = 100000;
		spc->exp = 5000;
		spc->leval = 100;
		spc->In = "与部队走丢的小人,经常出没于林间";
		break;
	}
	return spc;
}

bool Bag_change(Bag*bag)
{
	bag->OtherCount = (bag->MaxCount)-(bag->NowCount);
	return true;
}

bool Bag_add(User*user,Thing*thing)
{
	Bag*bag = (Bag*)user->bag;
	if(Bag_iscanAdd(bag))
	{
		return LinkList_addData(bag->phead,(Thing*)thing);
	}
	printf("背包已满!无法添加\n");
	return false;
}

bool Bag_iscanAdd(Bag*bag)
{
	if(bag->OtherCount>0)
	{
		return true;
	}
	return false;
}

bool User_Recover(User*user)
{
	user->hp = user->MaxHp;
	return true;
}

bool User_addThing(User*user,Thing*thing)
{
	if(user->nowThing!=NULL)
	{
		printf("当前已佩戴装备!\n");
		return false;
	}
	user->nowThing = thing;
	return true;
}

bool Bag_show(User*user)
{
	printf("背包当前物品:\n");
	for(int i = 0;i<LinkList_getSize(user->bag->phead);i++)
	{
		Thing*t = LinkList_getData(user->bag->phead,i);
		printf("%d.%s\t",i+1,t->name);
		if(i%2==0&&i!=0)
		{
			printf("\n");
		}
	}
	return true;
}

Thing*Bag_getThing(User*user,int count)
{
	return(Thing*)LinkList_getData(user->bag->phead,count);
}

bool User_BuyThing(User*user,Dcat*dcat,int n)
{
	if(n>=1 && n<=LinkList_getSize(dcat->phead))//如果下标满足
	{
		if(User_BuyChick(user,LinkList_getData(dcat->phead,n-1)))//如果钱足够
		{
			if(Bag_iscanAdd(user->bag))//如果背包未满
			{
				Bag_add(user,LinkList_getData(dcat->phead,n-1));
				printf("恭喜你，购买成功\n");
				return true;
			}else{
				printf("很抱歉，您的背包已满!\n");
				return false;
			}
		}
		else
		{
			printf("钱不够,购买失败了!\n");
			return false;
		}
	}
	printf("购买出错!\n");
	return false;
}

bool User_Show(User*user)
{
	printf("\n");
	for(int i = 0;i<60;i++)
	{
		printf("*");
	}
	printf("\n  昵称:%s\t等级:%d\t金币:%ld\n",
		user->name,user->leval,user->money);
	printf("  攻击:%d\t血量:%d\t经验:%d/%d\n",
		user->att,user->MaxHp,user->NowExp,user->MaxExp);
	return true;
}

Spc*ChioseSpcByMap(Emy*emy,int n)
{
	int index = 0;
	Spc*spc;
	switch(n)
	{
	case 1:
		index = rand()%2;
		spc = (Spc*)LinkList_getData(emy->phead,index);
		break;
	case 2:
		index = rand()%2+1;
		spc = (Spc*)LinkList_getData(emy->phead,index);
		break;
	case 3:
		index = rand()%2+2;
		spc = (Spc*)LinkList_getData(emy->phead,index);
		break;
	case 4:
		index = rand()%2+3;
		spc = (Spc*)LinkList_getData(emy->phead,index);
		break;
	case 5:
		index = rand()%5;
		spc = (Spc*)LinkList_getData(emy->phead,index);
		break;
	default:
		index = rand()%5;
		spc = (Spc*)LinkList_getData(emy->phead,index);
	}
	return spc;
}

bool Against(User*user,Spc*spc)
{
	int isbg = 0;
	int mcount = 0;//轮数
	int mrand = 0;//随机数
	int gw_att = 0;//怪物攻击
	int user_att = 0;//人物攻击
	while(user->hp>0&&spc->hp>0)
	{
		//默认怪物先攻击
		mrand = rand()%100+1;
		if(mrand<=spc->bg)//产生暴击
		{
			isbg = 1;
		}else{
			isbg = 0;
			
		}
		gw_att = spc->att*(1+isbg);
		user->hp = (user->hp)-(gw_att-(user->resist));//玩家损血
		if(user->hp<=0)
		{
			mcount++;
			break;
		}
		mrand = rand()%100+1;
		if(mrand<=user->nowThing->bg)
		{
			isbg = 1;
		}else{
			isbg = 0;
			
		}
		user_att = user->att+user->nowThing->att;
		user_att = user_att*(1+isbg);
		spc->hp = spc->hp-(user_att-spc->resist);//怪物损血
		if(spc->hp<=0)
		{
			mcount++;
			break;
		}
		mcount++;
	}
	if((user->hp)>(spc->hp))//玩家取胜
	{
		user->NowExp+=spc->exp;//增加经验
		user->money+=spc->cost;
		User_CheckUp(user);
		printf("经过%d轮艰苦战斗,你击败了%s,获得%d点经验!\n",mcount+1,spc->name,spc->exp);
		spc->hp=spc->maxhp;
		return true;
	}
	user->NowExp+=spc->leval+mcount;
	user->money-=user->leval;
	User_CheckUp(user);
	printf("在与%d级%s的战斗中你不幸身亡,一共战斗了%d轮,即将传送回安全地带!\n",spc->leval,spc->name,mcount);
	spc->hp=spc->maxhp;
	return false;
}

bool User_CheckUp(User*user)
{
	int addleval = 0;
	int moreExp = 0;
	if(user->NowExp>user->MaxExp)//升级
	{
		addleval = user->NowExp/user->MaxExp;
		moreExp = user->NowExp%user->MaxExp;
		user->leval+=addleval;
		user->att+=addleval*5;
		user->NowExp = moreExp;
		user->MaxHp+=100*addleval;
		User_Recover(user);
		printf("恭喜你成功升级,当前等级:%d\n",user->leval);
		return true;
	}
	return false;
}

bool User_ChangeName(User*user,char*newname)
{
	if(newname==NULL)
	{
		return false;
	}
	user->name = newname;
	return true;
}

bool User_ChangePass(User*user,char*newpass)
{
	if(newpass==NULL)
	{
		return false;
	}
	user->name = newpass;
	return true;
}

bool User_BuyChick(User*user,Thing*thing)
{
	return(user->money>=thing->cost);
}

bool Shop_Show(Dcat*dcat)
{
	printf("当前已上架商品:\n");
	for(int i = 0;i<LinkList_getSize(dcat->phead);i++)
	{
		Thing*t = LinkList_getData(dcat->phead,i);
		printf("%d.%s\t",i+1,t->name);
		if(i%2==0&&i!=0)
		{
			printf("\n");
		}
	}
	return true;
}

bool System_ShowContral()
{
	printf("当前可用操作:\n");
	printf("1.查看背包物品\t2.野外探索\n3.进入商场\t4.查看排行榜\n5.充值金币\t6.退出游戏\n");
	return true;
}

bool User_clearNowThing(User*user)
{
	user->nowThing = NULL;
	return true;
}

Head*GetBagHeadFromUser(User*user)
{
	return(Head*)user->bag->phead;
}

Head*GetEmyFromMap(Emy*emy,int n)
{
	Head*MapEmy = newLinkListHead();
	switch(n)
	{
	case 1:
		for(int i = 0;i<10;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,1));
		}
		break;
	case 2:
		for(int i = 0;i<15;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,2));
		}
		break;
	case 3:
		for(int i = 0;i<20;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,3));
		}
		break;
	case 4:
		for(int i = 0;i<25;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,4));
		}
		break;
	case 5:
		for(int i = 0;i<30;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,5));
		}
		break;
	default:
		n = rand()%5+1;
		for(int i = 0;i<50;i++)
		{
			LinkList_addData(MapEmy,(Spc*)ChioseSpcByMap(emy,n));
		}
		break;
	}
	return MapEmy;
}

bool SaveDataToFile(const char *filename,User *user)
{
	FILE *fp=fopen(filename,"w");
	if(fp==NULL)
	{
		printf("无法打开文件,数据保存失败!\n");
		return false;
	}
	fprintf(fp,"%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%ld\t",user->name,user->hp,user->att,user->resist,user->MaxHp,user->leval,user->MaxExp,user->NowExp,user->money);
	fclose(fp);
	return true;
}

bool GetDataFromFile(const char *filename,User *user)
{
	FILE *fp=fopen(filename,"r");
	if(fp==NULL)
	{
		fp=fopen(filename,"w+");
		fclose(fp);
		return false;
	}
	fscanf(fp,"%s%d%d%d%d%d%d%d%ld",(char*)user->name,&user->hp,&user->att,&user->resist,&user->MaxHp,&user->leval,&user->MaxExp,&user->NowExp,&user->money);
	fclose(fp);
	return true;
}