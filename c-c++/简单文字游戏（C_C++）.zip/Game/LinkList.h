
#define DOWN 10
#define UP 5
#include <stdbool.h>

/*
** 作者 : 爱编程的猴子
** 功能 : 简单链表封装--用于存储数据
** 时间 : 2020.6.19
*/

/*#define Bool int
#define true 1
#define false 0
#define bool Bool*/

// 申明节点类型
typedef struct LinkListHead Head;

typedef struct LinkListNode Node;

//创建新链表
Head* newLinkListHead();

//创建节点
Node* newLinkListNode();

//判断为空
bool LinkList_isEmpty(Head *phead);

//添加数据到尾部
bool LinkList_addData(Head *phead,const void *data);

//添加数据到指定位置
bool LinkList_addAt(Head *phead,const void *data,int n);

//获取指定位置数据
Node *LinkList_getNode(Head *phead,int n);

//获取个数
int LinkList_getSize(Head *phead);

//获取数据
void *LinkList_getData(Head *phead,int n);

//删除数据
bool LinkList_delAt(Head *phead,int n);

//弹出最后一个元素
bool LinkList_pop(Head *phead);

//排序__参数有"UP"和"DOWN"，对应升序和降序
void LinkList_sort(Head *phead,int type);

//清除所有
bool LinkList_delAll(Head *phead);