package com.xiaoheng.sjsz;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import java.util.*;
import android.graphics.*;
import org.apache.http.client.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button button=(Button)findViewById(R.id.mainButton);
		final View lt=findViewById(R.id.mainLinearLayout);
		final TextView textview=(TextView)findViewById(R.id.mainTextView);
		final TextView textview1=(TextView)findViewById(R.id.mainTextView1);
		final TextView textview2=(TextView)findViewById(R.id.mainTextView2);
		button.setOnClickListener(new OnClickListener(){
			
				@Override
				public void onClick(View p1)
				{
					Random a=new Random();
					
					//红色
					int red=a.nextInt(256);
					textview.setText("红："+red);
					textview.setTextColor(Color.rgb(red, 0, 0));
					
					//绿色
					int green=a.nextInt(256);
					textview1.setText("绿："+green);
					textview1.setTextColor(Color.rgb(0 , green, 0));
					
					//蓝色
					int blue=a.nextInt(256);
					textview2.setText("蓝："+blue);
					textview2.setTextColor(Color.rgb(0,0,blue));
					
					//线性布局背景颜色
					lt.setBackgroundColor(Color.rgb(red,green,blue));
				}
		});
		
    }
}
/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/