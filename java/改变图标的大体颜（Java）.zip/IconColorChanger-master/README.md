[![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-IconColorChanger-brightgreen.svg?style=flat)](http://android-arsenal.com/details/1/1976)

<a href='https://ko-fi.com/A302HW7' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi4.png?v=f' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a> 

# IconColorChanger
IconColorChanger is a custom implementation in which icons with white colors can be transformed in to different colors using hex color codes. It is very useful to maintain icons in the drawable without using multiple resources.

![z](https://cloud.githubusercontent.com/assets/11768239/8147576/501152aa-128f-11e5-88ba-c192db79a2b4.jpg)

For tutorials. please visit my blog http://takeoffandroid.com/uncategorized/changing-color-of-drawable-icon-programmatically/
