package com.hotbitmapgg.moequest.model.taomodel;

import java.util.ArrayList;

public class Contentlist
{

    public int totalFavorNum;

    public String realName;

    public String totalFanNum;

    public String link;

    public String weight;

    public String avatarUrl;

    public String type;

    public String userId;

    public String city;

    public String height;

    public ArrayList<String> imgList;

    public String cardUrl;
}
