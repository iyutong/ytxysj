package com.hotbitmapgg.moequest.model.taomodel;

import com.google.gson.annotations.SerializedName;


public class ShowapiResBody
{

    @SerializedName("ret_code")
    public String retCode;

    public Pagebean pagebean;
}
