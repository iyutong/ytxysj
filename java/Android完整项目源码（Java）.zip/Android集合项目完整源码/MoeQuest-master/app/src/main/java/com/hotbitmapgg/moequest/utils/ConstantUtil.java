package com.hotbitmapgg.moequest.utils;

/**
 * 常量配置工具类
 *
 * @HotBitmapGG
 */
public class ConstantUtil
{

    //易源接口AppId
    public static final String APP_ID = "15314";

    //易源接口AppSign
    public static final String APP_SIGN = "d424376f51f1467da1b8c75debebf148";

    //本地存储dir目录
    public static final String FILE_DIR = "moe_quest";

    //腾讯buglyID
    public static final String BUGLY_ID = "900037370";

    //性感妹子
    public static final String XINGGAN_MEIZI = "xinggan";

    //日本妹子
    public static final String JAPAN_MEIZI = "japan";

    //台湾妹子
    public static final String TAIWAN_MEIZI = "taiwan";

    //清纯妹子
    public static final String QINGCHUN_MEIZI = "mm";

    //自拍妹子
    public static final String ZIPAI_MEIZI = "share";

    //推荐
    public static final String TUIJIAN_MEIZI ="best";

    //热门
    public static final String HOT_MEIZI = "hot";

    //每日更新
    public static final String UPDATE_MEIZI = "all";
}
