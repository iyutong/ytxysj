package com.hotbitmapgg.moequest.model.taomodel;

import java.util.ArrayList;

public class Pagebean
{

    public ArrayList<Contentlist> contentlist;

    public String maxResult;

    public String currentPage;

    public String allNum;

    public String allPages;
}
