package feinimei.voln520;



import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class Shezhi extends Activity implements OnCheckedChangeListener{
	CheckBox yy,yx;
	SharedPreferences sp;
 @Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	requestWindowFeature(1);
	getWindow().setFlags(1024, 1024);

	setContentView(R.layout.shezhi);
	sp=getSharedPreferences("game",MODE_PRIVATE);
  
  
	yx=(CheckBox)findViewById(R.id.yx);
	boolean yxSave=sp.getBoolean("yx", true);
	yx.setChecked(yxSave);
	yy=(CheckBox)findViewById(R.id.yy);
	boolean yySave=sp.getBoolean("yy", true);
	yy.setChecked(yySave);
	
   yy.setOnCheckedChangeListener(this);
	yx.setOnCheckedChangeListener(this);
}
@Override
public void onCheckedChanged(CompoundButton button, boolean isChecked) {
	// TODO Auto-generated method stub
	switch(button.getId())
	{
	case R.id.yy:
		sp.edit().putBoolean("yy",isChecked).commit();
		break;
	case R.id.yx:
		sp.edit().putBoolean("yx",isChecked).commit();
		break;
	
	
	
	}
	
	
	
}
}
