package feinimei.voln520;


import android.annotation.SuppressLint;
import android.content.*;
import android.graphics.*;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;



import android.view.*;


import java.util.*;







@SuppressLint("ViewConstructor")
public class MySurfaceView extends SurfaceView
implements SurfaceHolder.Callback,Runnable
{ GameActivity ga;
	
	static int sw,sh;
	SurfaceHolder sfh;
	Paint paint;
	Canvas canvas;
	boolean flag;	
	final static int STATE_MENU=0;
	final static int STATE_GAMING=1;
	final static int STATE_OVER=2;
	final static int STATE_SILE=3;
	final static int STATE_PAUSE=4;
	static int state;
Context context;
Vector<Zhangai> vcZhangai;
int createZhangaiTime=30;
int count=0;
Random random;
Bitmap bmpGuaiwu[]=new Bitmap[3];
int createGuaiwuTime=100;
Vector<Guaiwu> vcGuaiwu;
Vector<Daoju> vcDaoju;
Vector<Zidan> vcZidan;
int createDaojuTime=80;
	
	
Bitmap bmpTree,bmpGrass,bmpLog,bmpPlayer,bmpHead,bmpHandle,bmpOver,bmpStar,bmpPutao,bmpCoin,bmpHua,bmpPause;	
Hua hua;
Bg bg;
Player player;
static boolean yxSave,yySave;
static SharedPreferences sp;
	MySurfaceView(Context context,GameActivity ga)
	{super(context);
		sfh=getHolder();
		sfh.addCallback(this);
		paint =new Paint();
this.context=context;
this.ga=ga;

state=STATE_MENU;
	  sp=context.getSharedPreferences("game", Context.MODE_PRIVATE);
		yxSave=sp.getBoolean("yx", true);
		yySave=sp.getBoolean("yy", true);
		
	if(yxSave)
	{soundP=new SoundPool(4, AudioManager.STREAM_MUSIC,100);
	
	sFlap=soundP.load(context, R.raw.flap, 1);
	
	sTing=soundP.load(context, R.raw.ting, 1);
	
	for (int i = 1; i <=3; i++) {
		sJump[i-1]=soundP.load(context,context.getResources().getIdentifier("jump"+i, "raw", context.getPackageName()), 1);
	}}
	if(yySave)
	{mp=MediaPlayer.create(context,R.raw.pappu);
	mp.setLooping(true);}
	}	
MediaPlayer mp;
static SoundPool soundP;
int sFlap,sTing;
int sJump[]=new int[3];
	public void initGame()
{sw=getWidth();
sh=getHeight();

bmpHua=BitmapFactory.decodeResource(getResources(), R.drawable.hua);
bmpPlayer=BitmapFactory.decodeResource(getResources(), R.drawable.play);
bmpTree=BitmapFactory.decodeResource(getResources(),R.drawable.tree);	
bmpGrass=BitmapFactory.decodeResource(getResources(),R.drawable.grass);	
bmpLog=BitmapFactory.decodeResource(getResources(), R.drawable.log);
bmpGuaiwu[0]=BitmapFactory.decodeResource(getResources(),R.drawable.angry_pakia);
bmpGuaiwu[1]=BitmapFactory.decodeResource(getResources(),R.drawable.sad_pakia);
bmpGuaiwu[2]=BitmapFactory.decodeResource(getResources(),R.drawable.happy_pakia);
  bmpOver=BitmapFactory.decodeResource(getResources(),R.drawable.over);
  bmpStar=BitmapFactory.decodeResource(getResources(),R.drawable.star);
  bmpPutao=BitmapFactory.decodeResource(getResources(),R.drawable.berries);
  bmpCoin=BitmapFactory.decodeResource(getResources(),R.drawable.coins_old);

player=new Player(bmpPlayer,bmpLog.getWidth(),bmpLog.getHeight(),ga);
bg=new Bg(bmpTree,bmpGrass,bmpLog);	
 random=new Random();
 vcZhangai=new Vector<Zhangai>();
 bmpPause=BitmapFactory.decodeResource(getResources(),R.drawable.gamepause);
    bmpHead=BitmapFactory.decodeResource(getResources(),R.drawable.head);
  bmpHandle=BitmapFactory.decodeResource(getResources(),R.drawable.handle);
vcGuaiwu=new Vector<Guaiwu>();

  vcDaoju=new Vector<Daoju>();
  vcZidan=new Vector<Zidan>();
  
  hua=new Hua(bmpHua,0,sh-bmpHua.getHeight());

	
	
	
	
	
}
	public void surfaceCreated(SurfaceHolder p1)
	{
		// TODO: Implement this method
		if(state==STATE_MENU)
		{initGame();}
	
	
		
		if(yySave)
		{mp.start();}

	flag=true;
		new Thread(this).start();
	}
    public boolean onTouchEvent(MotionEvent event)
{
	switch(state)
	{case STATE_PAUSE:
		if(event.getAction()==0)
    	{state=STATE_GAMING;
    	player.isUP=true;
    	
    	}
		break;
    case STATE_MENU:
    	if(event.getAction()==0)
    	{state=STATE_GAMING;}
	break;
	case STATE_GAMING:
		player.onTouch(event);
	break;
	case STATE_OVER:
	break;
	case STATE_SILE:
		break;
		}
		
	return true;}
	public void logic()
	{hua.logic();
		switch(state)
		{case STATE_PAUSE:
			break;
			case STATE_MENU:
				player.logic();
           break;
			case STATE_GAMING:
			player.logic();
			if(player.isUP&&yxSave)
			{if(count%5==0)
				{soundP.play(sFlap, 1, 1, 0, 0, 1);}}
				bg.logic();
	for(int i=0;i<vcZhangai.size();i++)
	{Zhangai za=vcZhangai.elementAt(i);
	 if(za.isDead)
	 {vcZhangai.removeElementAt(i);}
else
	 {za.logic();}
	 }
	for (int i = 0; i < vcGuaiwu.size(); i++) {
	Guaiwu gw=vcGuaiwu.elementAt(i);
		if(gw.isDead)
		{vcGuaiwu.removeElementAt(i);}
		else
		{gw.logic();
		if(yxSave&&!gw.isPlay)
		{if(gw.x<sw-gw.bmp.getWidth()&&gw.y<sh-gw.bmp.getHeight())
		{soundP.play(sJump[gw.type], 1, 1, 0, 0, 1);
		gw.isPlay=true;}
		}
		
		}
		}
	for(int i=0;i<vcDaoju.size();i++)
{Daoju dj=vcDaoju.elementAt(i);
	if(dj.isDead)
	{vcDaoju.removeElementAt(i);}
	else
	{dj.logic();}
	}	
		
for(int i=0;i<vcZidan.size();i++)
{Zidan zd=vcZidan.elementAt(i);
		if(zd.isDead)
		{vcZidan.removeElementAt(i);}
		else
		{zd.logic();}
		}	
count++;
if(count%createZhangaiTime==0)
{int zaIndex=random.nextInt(3)+1;
  int zaX=sw+random.nextInt(Player.frameW*2);
int zy=0;
switch(zaIndex)
{case 1:
	zy=sh-random.nextInt(bmpHandle.getHeight());
break;
case 2:
	zy=0-random.nextInt(bmpHandle.getHeight());
 break;
case 3:
	zy=0-random.nextInt(bmpHandle.getHeight()-(sh-bmpHandle.getHeight()-Player.frameH*3));
 break;
	  }
vcZhangai.addElement(new Zhangai(bmpHead,bmpHandle,zaX,zy,zaIndex));
 }
if(count%createGuaiwuTime==0)
{int who=random.nextInt(3);
int gx=sw/2+random.nextInt(sw+sw/2);

vcGuaiwu.addElement(new Guaiwu(bmpGuaiwu[who], gx,who));

}
	if(count%createDaojuTime==0)
	{int daojuType=random.nextInt(3)+1;
	
	switch(daojuType)
	 {case 1:
	 boolean flag1;
	 int daoju1X,daoju1Y;
	 do{flag1=false;
		 daoju1X=sw+random.nextInt(Player.frameW*2);
		 daoju1Y=random.nextInt(sh-bmpPutao.getHeight());
	   for(int i=0;i<vcZhangai.size();i++)
	   {if(vcZhangai.elementAt(i).isHint(daoju1X,daoju1Y,bmpPutao.getWidth(),bmpPutao.getHeight()))
		 {  flag1=true;
		 }

	   }
	   
	}while(flag1);
	vcDaoju.addElement(new Daoju(bmpPutao,daoju1X,daoju1Y,daojuType));
	 break;
	 case 2:
	 boolean flag2;
	 int daoju2X,daoju2Y;
	 do{flag2=false;
		  daoju2X=sw+random.nextInt(Player.frameW*2);
		 daoju2Y=random.nextInt(sh-bmpStar.getHeight());
		for(int i=0;i<vcZhangai.size();i++)
		{if(vcZhangai.elementAt(i).isHint(daoju2X,daoju2Y,bmpStar.getWidth(),bmpStar.getHeight()))
		{  flag2=true;
		}
		  
		}
		
		}
		while(flag2);
		vcDaoju.addElement(new Daoju(bmpStar,daoju2X,daoju2Y,daojuType));
	 
	 break;
	 case 3:
	 boolean flag3;
	 int daoju3X,daoju3Y;
	 do{flag3=false;
		  daoju3X=sw+random.nextInt(Player.frameW*2);
		 daoju3Y=random.nextInt(sh-bmpCoin.getHeight());
	   for(int i=0;i<vcZhangai.size();i++)
	   {if(vcZhangai.elementAt(i).isHint(daoju3X,daoju3Y,bmpCoin.getWidth()/4,bmpCoin.getHeight()))
		 {  flag3=true;
		 }

	   }
	   
		
		
		}while(flag3);
		vcDaoju.addElement(new Daoju(bmpCoin,daoju3X,daoju3Y,daojuType));
	 break;
	    }
	  
	  
	}
			if(!player.isWudi){
			  for(int i=0;i<vcGuaiwu.size();i++)
			  {if(vcGuaiwu.elementAt(i).isHint(player))
				{state=STATE_SILE;} }
			for(int i=0;i<vcZhangai.size();i++)
			{
			  if(vcZhangai.elementAt(i).isHint(player))
			  {state=STATE_SILE;}
			}}
			for(int i=0;i<vcDaoju.size();i++)
			{Daoju dj=vcDaoju.elementAt(i);
			  if(dj.isHint(player))
			  {vcDaoju.elementAt(i).isDead=true;
			  if(yxSave)
			  {soundP.play(sTing, 1, 1, 0, 0, 1);}
			  
				switch(dj.getType())
			  {case 1:
			  for(int j=0;j<4;j++)
			  {vcZidan.addElement(new Zidan(bmpPlayer,player.x+Player.frameW,player.y+Player.frameH/2-random.nextInt(Player.frameH)));}
			
			break;
			  case 2:
			  player.isWudi=true;
			  player.count=0;
			  break;
			  case 3:
			  player.score=player.score+(4-dj.index)*50;
			  break;
				  } }

			}
	for(int i=0;i<vcZidan.size();i++)
	{for(int j=0;j<vcGuaiwu.size();j++)
	{if(vcZidan.elementAt(i).isHint(vcGuaiwu.elementAt(j)))
	{vcGuaiwu.elementAt(j).isDead=true;}
	  }
	for(int k=0;k<vcZhangai.size();k++)
	{if(vcZidan.elementAt(i).isHint(vcZhangai.elementAt(k)))
	{vcZhangai.elementAt(k).isDead=true;}
	  }
	  }
	break;
			case STATE_OVER:
				break;
			case STATE_SILE:
			player.logic();
			for (int i = 0; i < vcGuaiwu.size(); i++) {
				Guaiwu gw=vcGuaiwu.elementAt(i);
					if(gw.isDead)
					{vcGuaiwu.removeElementAt(i);}
					else
					{gw.logic();}
					}
				break;
		}
		
	}

	public void myDraw()
	{
		switch(state)
		{case STATE_PAUSE:
			bg.drawTree(canvas);
			bg.drawGrass(canvas);
			player.draw(canvas);
			
			for(int i=0;i<vcZhangai.size();i++)
			{vcZhangai.elementAt(i).draw(canvas);
							}

			for(int i=0;i<vcGuaiwu.size();i++)
			{vcGuaiwu.elementAt(i).draw(canvas);
			}
			for(int i=0;i<vcDaoju.size();i++)
			{vcDaoju.elementAt(i).draw(canvas);}
			for(int i=0;i<vcZidan.size();i++)
			{vcZidan.elementAt(i).draw(canvas);}
						player.drawScore(canvas);	
			
			canvas.drawBitmap(bmpPause,(sw-bmpPause.getWidth())/2,(sh-bmpPause.getHeight())/2,paint);
			break;
			case STATE_MENU:
bg.drawTree(canvas);
bg.drawLog(canvas);
bg.drawGrass(canvas);
player.draw(canvas);
			player.drawScore(canvas);
			
	break;
			case STATE_GAMING:
				bg.drawTree(canvas);
				bg.drawGrass(canvas);
				player.draw(canvas);
			
for(int i=0;i<vcZhangai.size();i++)
{vcZhangai.elementAt(i).draw(canvas);
				}

for(int i=0;i<vcGuaiwu.size();i++)
{vcGuaiwu.elementAt(i).draw(canvas);
}
for(int i=0;i<vcDaoju.size();i++)
{vcDaoju.elementAt(i).draw(canvas);}
for(int i=0;i<vcZidan.size();i++)
{vcZidan.elementAt(i).draw(canvas);}
			player.drawScore(canvas);
						break;
			case STATE_OVER:
			bg.drawTree(canvas);
			bg.drawGrass(canvas);
			
			for(int i=0;i<vcZhangai.size();i++)
			{vcZhangai.elementAt(i).draw(canvas);
			}	
			canvas.drawBitmap(bmpOver,(sw-bmpOver.getWidth())/2,(sh-bmpOver.getHeight())/2,paint);
			player.drawScore(canvas);
			player.drawScore(canvas);
				break;
			case STATE_SILE:
			
			bg.drawTree(canvas);
			bg.drawGrass(canvas);
			for(int i=0;i<vcGuaiwu.size();i++)
			{vcGuaiwu.elementAt(i).draw(canvas);
			}
			player.draw(canvas);
			
			for(int i=0;i<vcZhangai.size();i++)
			{vcZhangai.elementAt(i).draw(canvas);
			}

			for(int i=0;i<vcGuaiwu.size();i++)
			{vcGuaiwu.elementAt(i).draw(canvas);
			}
			
			player.drawScore(canvas);
				break;
		}
		hua.draw(canvas);
	}	

	public void surfaceChanged(SurfaceHolder p1, int p2, int p3, int p4)
	{
		// TODO: Implement this method
	}

	public void surfaceDestroyed(SurfaceHolder p1)
	{
		// TODO: Implement this method
		flag=false;
		if(state==STATE_GAMING)
		{state=STATE_PAUSE;}

			
	
		if(yySave)
		{mp.pause();}
	}

	public void run()
	{while(flag)
		{long start=System.currentTimeMillis();
			
			try{canvas=sfh.lockCanvas();
				if(canvas!=null)
				{myDraw();}

			}
			catch(Exception e){}
			finally{
				if(canvas!=null)
				{sfh.unlockCanvasAndPost(canvas);}
			}	
		  logic();
		long end=System.currentTimeMillis();	
			if(end-start<50)
			{try
				{
					Thread.sleep(50 - (end - start));
				}
				catch (InterruptedException e)
				{}
			}
		}	}
	
}
