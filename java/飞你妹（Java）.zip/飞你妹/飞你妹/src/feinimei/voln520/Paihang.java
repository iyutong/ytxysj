package feinimei.voln520;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;


public class Paihang extends ListActivity {
static int n;
@Override
protected void onCreate(Bundle savedInstanceState) {
   
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	requestWindowFeature(1);
	getWindow().setFlags(1024,1024);
	
	Intent  intent=getIntent();
	 n=Integer.parseInt(intent.getStringExtra("n"));
setContentView(R.layout.paihang);
	
	String name[]=new String[10];
	int score[]=new int[10];
	SharedPreferences sp;
	sp=getSharedPreferences("game", MODE_PRIVATE);
	String str="";
	for (int i = 0; i <name.length; i++) {
		str=str+"尘土"+"\t"+(10-i)*10+"\n";
	}
	str=sp.getString("paihang", str);
	sp.edit().putString("paihang", str);
	 String arr[]= str.split("\n"); 
    for (int i = 0; i < arr.length; i++) {
    	String temp[]=arr[i].split("\t");
    	name[i]=temp[0];
    	score[i]=Integer.parseInt(temp[1]);
 }
    
	List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
	Map<String, Object> map;
	for (int i = 0; i < arr.length; i++) {
		map=new HashMap<String, Object>();
		
		map.put("name", name[i]);
		map.put("score", score[i]+"");
		list.add(map);
	}
MySimpleAdapter sa=new MySimpleAdapter(this, list, R.layout.item, 
			new String[]{"name","score"}, new int[]{R.id.name,R.id.score});

	setListAdapter(sa);



}


	
}
