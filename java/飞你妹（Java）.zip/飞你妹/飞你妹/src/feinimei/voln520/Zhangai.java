package feinimei.voln520;
import android.graphics.*;

public class Zhangai
{

int speed;
boolean isDead=false;
Paint paint;

Bitmap bmp[]=new Bitmap[2];
int x[]=new int[2];
int y[]=new int[2];
int type;
public Zhangai(Bitmap head,Bitmap handle,int x,int y,int type)
{paint=new Paint();

this.type=type;
speed=Player.frameW/4;
switch(type)
{  case 1:
	bmp[0]=head;
	bmp[1]=handle;
this.x[1]=x;
this.x[0]=this.x[1]-(bmp[0].getWidth()-bmp[1].getWidth())/2;
this.y[1]=y;
this.y[0]=this.y[1]-bmp[0].getHeight();
break;
  case 2:
bmp[0]=head;
 bmp[1]=handle;
	this.x[1]=x;
	this.x[0]=this.x[1]-(bmp[0].getWidth()-bmp[1].getWidth())/2;
	this.y[1]=y;
	this.y[0]=this.y[1]+bmp[1].getHeight();
   break;
  case 3:
	bmp[0]=handle;
	bmp[1]=handle;
	this.x[1]=(this.x[0]=x);
  this.y[0]=y;
  this.y[1]=this.y[0]+bmp[0].getHeight()+Player.frameH*3;
	break;

}


  
  }
public void logic()
{
  x[0]-=speed;
x[1]-=speed;
if(x[0]<-bmp[0].getWidth()-Player.frameW)
{isDead=true;}
  }

public void draw(Canvas canvas)
{
  switch(type)
  {  case 1:
	  canvas.save();
	  canvas.scale(-1,1,x[0]+bmp[0].getWidth()/2,y[0]+bmp[0].getHeight()/2);
	  canvas.drawBitmap(bmp[0],x[0],y[0],paint);
	  canvas.restore();  canvas.drawBitmap(bmp[1],x[1],y[1],paint);
	  	break;
	case 2:
	canvas.save();
	canvas.scale(-1,-1,x[0]+bmp[0].getWidth()/2,y[0]+bmp[0].getHeight()/2);
	  canvas.drawBitmap(bmp[0],x[0],y[0],paint);
	canvas.restore();
	  canvas.save();
	  canvas.scale(1,-1,x[1]+bmp[1].getWidth()/2,y[1]+bmp[1].getHeight()/2);
	    canvas.drawBitmap(bmp[1],x[1],y[1],paint);
	canvas.restore();
	
	break;
	case 3:
	  canvas.drawBitmap(bmp[0],x[0],y[0],paint);
	  canvas.save();
	  canvas.scale(1,-1,x[1]+bmp[1].getWidth()/2,y[1]+bmp[1].getHeight()/2);
	  canvas.drawBitmap(bmp[1],x[1],y[1],paint);
	  canvas.restore();
	
	break;
  }

}

public boolean isHint(Player player)
  {for(int i=0;i<2;i++)
  {if(player.x<x[i]-Player.frameW)
  {}
else if(player.x>x[i]+bmp[i].getWidth())
  {}
else if(player.y<y[i]-Player.frameH)	
{}	
else if(player.y>y[i]+bmp[i].getHeight())
  {}
else
  {return true;}
  }
	
	return false;
  }
  
  public boolean isHint(int x,int y,int w,int h)
  {
	for(int i=0;i<2;i++)
	{if(x<this.x[i]-w)
	  {}
	  else if(x>this.x[i]+bmp[i].getWidth())
	  {}
	  else if(y<this.y[i]-h)	
	  {}	
	  else if(y>this.y[i]+bmp[i].getHeight())
	  {}
	  else
	  {return true;}
	}
	
	
	return false;}

  
  
  }
