package feinimei.voln520;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;
import cn.domob.android.ads.DomobAdEventListener;
import cn.domob.android.ads.DomobAdManager.ErrorCode;
import cn.domob.android.ads.DomobAdView;
import cn.domob.android.ads.DomobInterstitialAd;
import cn.domob.android.ads.DomobInterstitialAdListener;
import cn.domob.android.ads.DomobUpdater;



public class MainActivity extends Activity implements OnClickListener{
	RelativeLayout dmlayout;
	DomobAdView dmview;
	Button kaishi,shezhi,paihang;
	DomobInterstitialAd domob=null;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	requestWindowFeature(1);
	getWindow().setFlags(1024, 1024);
	
	setContentView(R.layout.main);

	 DomobUpdater.checkUpdate(this, "56OJzXhouNOsqXcH40");
     dmview=new DomobAdView(this, "56OJzXhouNOsqXcH40", "16TLm2DvAp0OiNU--3wGGvXi",DomobAdView.INLINE_SIZE_320X50);
     dmlayout=(RelativeLayout)findViewById(R.id.dmlayout);
     dmview.setAdEventListener(new DomobAdEventListener() {
			
@Override
public void onDomobAdReturned(DomobAdView adView) {
	Log.i("DomobSDKDemo", "onDomobAdReturned");				
}

@Override
public void onDomobAdOverlayPresented(DomobAdView adView) {
	Log.i("DomobSDKDemo", "overlayPresented");
}

@Override
public void onDomobAdOverlayDismissed(DomobAdView adView) {
	Log.i("DomobSDKDemo", "Overrided be dismissed");				
}

@Override
public void onDomobAdClicked(DomobAdView arg0) {
	Log.i("DomobSDKDemo", "onDomobAdClicked");				
}

@Override
public void onDomobAdFailed(DomobAdView arg0, ErrorCode arg1) {
	Log.i("DomobSDKDemo", "onDomobAdFailed");				
}

@Override
public void onDomobLeaveApplication(DomobAdView arg0) {
	Log.i("DomobSDKDemo", "onDomobLeaveApplication");				
}

@Override
public Context onDomobAdRequiresCurrentContext() {
	return MainActivity.this;
}
});
     dmlayout.addView(dmview);
     domob=new DomobInterstitialAd(this, "56OJzXhouNOsqXcH40", 
    			"16TLm2DvAp0OiNU-N95-bcjk", DomobInterstitialAd.INTERSITIAL_SIZE_300X250);
    	domob.setInterstitialAdListener(new DomobInterstitialAdListener() {
    		@Override
    		public void onInterstitialAdReady() {
    			Log.i("DomobSDKDemo", "onAdReady");
    			//domob.showInterstitialAd(MainActivity.this);
    		}

    		@Override
    		public void onLandingPageOpen() {
    			Log.i("DomobSDKDemo", "onLandingPageOpen");
    		}

    		@Override
    		public void onLandingPageClose() {
    			Log.i("DomobSDKDemo", "onLandingPageClose");
    		}

    		@Override
    		public void onInterstitialAdPresent() {
    			Log.i("DomobSDKDemo", "onInterstitialAdPresent");
    		}

    		@Override
    		public void onInterstitialAdDismiss() {
    			// Request new ad when the previous interstitial ad was closed.
    			domob.loadInterstitialAd();
    			Log.i("DomobSDKDemo", "onInterstitialAdDismiss");
    		}

    		@Override
    		public void onInterstitialAdFailed(ErrorCode arg0) {
    			Log.i("DomobSDKDemo", "onInterstitialAdFailed");				
    		}

    		@Override
    		public void onInterstitialAdLeaveApplication() {
    			Log.i("DomobSDKDemo", "onInterstitialAdLeaveApplication");
    			
    		}

    		@Override
    		public void onInterstitialAdClicked(DomobInterstitialAd arg0) {
    			Log.i("DomobSDKDemo", "onInterstitialAdClicked");
    		}
    	});
    	domob.loadInterstitialAd();
    
     
     
     
     

	kaishi=(Button)findViewById(R.id.kaishi);
	shezhi=(Button)findViewById(R.id.shezhi);
	paihang=(Button)findViewById(R.id.paihang);
	kaishi.setOnClickListener(this);
	shezhi.setOnClickListener(this);
	paihang.setOnClickListener(this);
	
	
}
public boolean onCreateOptionsMenu(Menu menu)
{menu.add(0, 1, 1, "关于").setIcon(R.drawable.about);
menu.add(0,2,2,"退出").setIcon(R.drawable.exit);
	return true;}

public boolean onOptionsItemSelected(MenuItem item)
{        switch (item.getItemId()) 
	{        case 1:            
		new AlertDialog.Builder(this).setIcon(R.drawable.ic_launcher)
		.setTitle("疯狂的小鸟v1.1")
		.setMessage("作者:尘土\nQQ:469039528\nEmail:voln520@live.com").setPositiveButton("确定", null).show();
	return true;    
		case 2:    
	finish();
	System.exit(0);
			return true;   
		      }       
return false;     } 

long currentBackPressedTime=0;
public void onBackPressed() {
	
	if (System.currentTimeMillis() - currentBackPressedTime > 2000) {
		currentBackPressedTime = System.currentTimeMillis();
	Toast.makeText(this, "再按一次返回退出", Toast.LENGTH_SHORT).show();
	} else {
		
		finish();
		System.exit(0);
	}
}

@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	Intent intent=new Intent();
	switch(v.getId())
	{case R.id.kaishi:
		intent.setClass(this, GameActivity.class);
		break;
	case R.id.shezhi:
		intent.setClass(this, Shezhi.class);
		break;
	case R.id.paihang:
		intent.putExtra("n", "-1");
		intent.setClass(this, Paihang.class);
		break;
}
	startActivity(intent);
	
	
}
@Override
protected void onResume() {
	// TODO Auto-generated method stub
	super.onResume();
	if(domob.isInterstitialAdReady())
	{domob.showInterstitialAd(this);}
	else
	{domob.loadInterstitialAd();}
}

}
