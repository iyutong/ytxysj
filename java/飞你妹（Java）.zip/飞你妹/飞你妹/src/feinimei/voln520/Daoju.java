package feinimei.voln520;
import java.util.Random;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Daoju
{int type;
Bitmap bmp;
Paint paint;
int x,y;
int frameW,frameH;
boolean isDead=false;
int index=0;
int speed;
Random random;
public Daoju(Bitmap bmp,int x,int y,int type)
{this.x=x;
this.y=y;
this.bmp=bmp;
paint=new Paint();
random=new Random();
speed=Player.frameW/4;
frameH=bmp.getHeight();
this.type=type;
switch(type)
{case 1:
	frameW=bmp.getWidth();
break;
case 2:
	frameW=bmp.getWidth();
break;
case 3:
	index=random.nextInt(4);
	frameW=bmp.getWidth()/4;
break;
}


}

public void logic()
{x-=speed;
if(x<-2*frameW)
{isDead=true;}
	

}

public void draw(Canvas canvas)
{switch(type)
	{
case 1:
	canvas.drawBitmap(bmp, x, y, paint);
	break;
case 2:
	canvas.drawBitmap(bmp, x, y, paint);
break;
case 3:
	canvas.save();
	canvas.clipRect(x, y, x+frameW, y+frameH);
	canvas.drawBitmap(bmp, x-index*frameW, y, paint);
	canvas.restore();
	break;

	}
	

}

public int getType()
{return type;}

	public 	boolean isHint(Player player)
	{if(player.x<x-Player.frameW)
	{return false;}
	 else if(player.x>x+frameW)
	 {return false;}
	else if(player.y<y-Player.frameH)
	{return false;}
	 else if(player.y>y+frameH)
	 {return false;}
	  
	 return true; 
	}
	
	
	


}
