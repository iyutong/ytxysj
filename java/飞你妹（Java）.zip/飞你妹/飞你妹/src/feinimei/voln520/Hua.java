package feinimei.voln520;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Hua {
	Bitmap bmp;
	Paint paint;
	int x1,y1,x2,y2;
	int speed;
	Hua(Bitmap bmp,int x1,int y1)
	{this.bmp=bmp;
	this.x1=(x2=x1);
	this.y1=y1;
		y2=y1-bmp.getHeight()+Player.frameW*2;	
		paint=new Paint();
		speed=Player.frameW/12;
	}

	public void logic()
	{y1+=speed;
	y2+=speed;	
		if(y1>MySurfaceView.sh)
		{y1=y2-bmp.getHeight()+Player.frameW*2;
		x1=0;}
		if(y2>MySurfaceView.sh)
		{y2=y1-bmp.getHeight()+Player.frameW*2;
		x2=0;}
		if(y1>-bmp.getHeight()&&y1<MySurfaceView.sh)
		{x1-=speed;}
		if(y2>-bmp.getHeight()&&y2<MySurfaceView.sh)
		{x2-=speed;}
		
		
	}
	
	public void draw(Canvas canvas)
	{canvas.drawBitmap(bmp, x1, y1, paint);
		canvas.drawBitmap(bmp, x2, y2, paint);
		
	}
	
	
}
