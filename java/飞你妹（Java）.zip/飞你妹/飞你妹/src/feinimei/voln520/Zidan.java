package feinimei.voln520;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.*;

public class Zidan {
Bitmap bmp;
Paint paint;
boolean isDead=false;
int x,y;
	int speed;
	int index=0;
	int frameW,frameH;
	Random random=new Random();
	public Zidan(Bitmap bmp,int x,int y)
{this.bmp=bmp;
frameW=bmp.getWidth();
frameH=bmp.getHeight()/8;
this.x=x;
this.y=y;
speed=Player.frameW/6;
paint=new Paint();
}
	public void logic()
	{index++;
	if(index>=8)
	{index=0;}
	y+=frameH/2-random.nextInt(frameH);
		x+=speed;
	if(x>MySurfaceView.sw)
	{isDead=true;}
		}
	
	public void draw(Canvas canvas)
	{canvas.save();
	canvas.clipRect(x, y, x+frameW, y+frameH);
	canvas.drawBitmap(bmp, x, y-index*frameH, paint);
		canvas.restore();	
		}
	public boolean isHint(Guaiwu gw)
	{int gwW=gw.bmp.getWidth();
	int gwH=gw.bmp.getHeight();
	if(gw.x<x-gwW)
	{return false;}
	else if(gw.x>x+frameW)
	{return false;}
	else if(gw.y<y-gwH)
	{return false;}
	else if(gw.y>y+frameH)
	{return false;}
	return true;}
	
	public boolean isHint(Zhangai za)
	{for(int i=0;i<2;i++)
	{if(za.x[i]<x-za.bmp[i].getWidth())
	{}
	else if(za.x[i]>x+frameW)
	{}
	 else if(za.y[i]<y-za.bmp[i].getHeight())
	 {}
	  else if(za.y[i]>y+frameH)
	  {}
	  else
	  {return true;}
	}
	 
	 
	 return false;}
	
}
