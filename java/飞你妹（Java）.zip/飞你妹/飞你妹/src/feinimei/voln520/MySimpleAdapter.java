package feinimei.voln520;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MySimpleAdapter extends BaseAdapter{
private  LayoutInflater mInflater;
private List<Map<String,Object>> list;	
private int layoutID;
private String flag[];
	private int itemIds[];
	public MySimpleAdapter(Context context,List<Map<String,Object>> list,int layoutId,String flag[],int itemIds[])
	{this.mInflater=LayoutInflater.from(context);
	this.list=list;
	this.layoutID=layoutId;
	this.flag=flag;
		this.itemIds=itemIds;
		
		
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		convertView=mInflater.inflate(layoutID, null);
		for (int i = 0; i < flag.length; i++) {
			if(convertView.findViewById(itemIds[i]) instanceof TextView)
			{TextView tv=(TextView)convertView.findViewById(itemIds[i]);
			tv.setText((String)list.get(position).get(flag[i]));}
}
if(Paihang.n!=-1&&position==Paihang.n)
{convertView.setBackgroundColor(0xff0080FF);}
		
		return convertView;
	}

}
