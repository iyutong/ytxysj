package feinimei.voln520;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.Path.Direction;
import android.os.Handler;
import android.os.Message;
import android.text.InputFilter;
import android.view.MotionEvent;
import android.widget.EditText;

public class Player {
	int win,lost;
	GameActivity ga;
Bitmap bmp;
int playHP=1;
int x,y;
Paint paint,wdPaint;
boolean isUP=true;
int index=0;
static int frameW,frameH;
int speed;
int angle;
int score;
boolean isWudi=false;
int count=0;
int wudiTime=100;
String nameOld[]=new String[10];
int scoreOld[]=new int[10];
	public Player(Bitmap bmp,int logW,int logH,GameActivity ga)
{this.bmp=bmp;
if(MySurfaceView.yxSave)
{win=MySurfaceView.soundP.load(ga, R.raw.win, 1);
lost=MySurfaceView.soundP.load(ga, R.raw.lost, 1);}

this.ga=ga;
frameW=bmp.getWidth();
frameH=bmp.getHeight()/8;
score=0;
paint=new Paint();
wdPaint=new Paint();
wdPaint.setAlpha(70);
Typeface typeface = Typeface.createFromAsset(ga.getAssets(),"fonts/ziti.TTF");
paint.setTypeface(typeface);
paint.setAntiAlias(true);
paint.setColor(0xffffffff);
paint.setTextSize(frameH/1.5f);
paint.setStyle(Style.STROKE);
speed=frameW/6;
x=(logW-frameW)/2+frameW;
y=MySurfaceView.sh-logH-frameH;	
}
	
public void onTouch(MotionEvent event)
{if(event.getAction()==MotionEvent.ACTION_DOWN)
{isUP=true;}
else if(event.getAction()==MotionEvent.ACTION_UP)
{isUP=false;}
}
public void logic()
{switch (MySurfaceView.state) {
case MySurfaceView.STATE_MENU:
	index++;
	if(index>=8)
	{index=0;}
	angle=0;
  break;
case MySurfaceView.STATE_GAMING:
	score++;
	if(isUP)
	{index++;
	if(index>=8)
	{index=0;}
	y-=speed;
	angle=-20;
	}
	else
	{index=0;
     y+=speed;
     angle=20;
}

	
if(isWudi)
{count++;
if(count%wudiTime==0)
{isWudi=false;
count=0;}
	}	
	

	break;
case MySurfaceView.STATE_SILE:
	y+=speed;
	angle+=10;
	speed+=Player.frameW/30;
break;

}

if(y<0-frameH||y>MySurfaceView.sh)
{paihang();
	MySurfaceView.state=MySurfaceView.STATE_OVER;
}	

}




	public void draw(Canvas canvas)
	{canvas.save();
	Path path=new Path();
	path.addCircle(x+frameW/2, y+frameH/2, frameW/2, Direction.CCW);
		canvas.clipPath(path);
		canvas.rotate(angle, x+frameW/2, y+frameH/2);
	if(isWudi)
	{	canvas.drawBitmap(bmp, x, y-index*frameH, wdPaint);

	}
	else
	  {	canvas.drawBitmap(bmp, x, y-index*frameH, paint);}

	canvas.restore();
	if(isWudi)
	{canvas.drawRect((MySurfaceView.sw-wudiTime*frameW/15)/2,
			(MySurfaceView.sh-frameH/2)/2,
			(MySurfaceView.sw-wudiTime*frameW/15)/2+wudiTime*frameW/15,
			(MySurfaceView.sh-frameH/2)/2+frameH/2, paint);
	canvas.drawRect((MySurfaceView.sw-wudiTime*frameW/15)/2,
			(MySurfaceView.sh-frameH/2)/2,
			(MySurfaceView.sw-wudiTime*frameW/15)/2+count*frameW/15,
			(MySurfaceView.sh-frameH/2)/2+frameH/2, wdPaint);}
	
	}
	public void drawScore(Canvas canvas)
	{canvas.drawText("Score:"+score, 0, frameH/1.5f, paint);
	}

public void setHP(int hp)
{playHP=hp;}

public int getHP()
{return playHP;}	
String str;
int m,n;
public void paihang()
{
str="";
for (m = 0; m <nameOld.length; m++) {
	str=str+"尘土"+"\t"+(10-m)*10+"\n";
}
str=MySurfaceView.sp.getString("paihang", str);
String arr[]= str.split("\n"); 
for (m = 0; m< arr.length; m++) {
	String temp[]=arr[m].split("\t");
	nameOld[m]=temp[0];
	scoreOld[m]=Integer.parseInt(temp[1]);
}
boolean isBig=false;
for ( n = 0; n < arr.length;n++) {
	if (score>scoreOld[n]) {
		isBig=true;
		break;
	}
}

if(isBig)
{if(MySurfaceView.yxSave)
{MySurfaceView.soundP.play(win, 1, 1, 0, 0, 1);}
Message msg=handler.obtainMessage();
handler.sendMessage(msg);
}
else{
	if(MySurfaceView.yxSave)
	{MySurfaceView.soundP.play(lost, 1, 1, 0, 0, 1);}
}

}
EditText inputServer;
@SuppressLint("HandlerLeak")
Handler handler=new Handler(){
	public void handleMessage(android.os.Message msg) 
	{inputServer = new EditText(ga);
		 inputServer.setFocusable(true);
		 inputServer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
		 new AlertDialog.Builder(ga).setIcon(R.drawable.ic_launcher).setTitle("请输入高姓大名：")
		 .setView(inputServer)
		 .setPositiveButton("确定", new android.content.DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(android.content.DialogInterface dialog, int which) { 
					
	String inputName = inputServer.getText().toString().trim();
	

		               for (int m =nameOld.length-1; m >n; m--) {
						nameOld[m]=nameOld[m-1];
						scoreOld[m]	=scoreOld[m-1];	
					}
		              
		            nameOld[n]=inputName;
		            scoreOld[n]=score;
		            
		            str="";
		            
		            for (int m = 0; m <nameOld.length; m++) {
		            	str=str+nameOld[m]+"\t"+scoreOld[m]+"\n";
					}
		       
		      MySurfaceView.sp.edit().putString("paihang", str).commit();  
		    
		      Intent intent=new Intent();
		      intent.putExtra("n", n+"");
		      intent.setClass(ga, Paihang.class);
		      ga.startActivity(intent);
		      
	}
			}
		). show();
		 
	};
	
};
	}
