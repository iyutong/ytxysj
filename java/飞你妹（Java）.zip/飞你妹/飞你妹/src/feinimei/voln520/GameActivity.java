package feinimei.voln520;


import android.app.Activity;
import android.media.AudioManager;
import android.os.Bundle;



public class GameActivity extends Activity
{ 
GameActivity ga;
    /** Called when the activity is first created. */
    @Override
  
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
requestWindowFeature(1);
getWindow().setFlags(1024,1024);
setVolumeControlStream(AudioManager.STREAM_MUSIC); 
ga=this;




setContentView(new MySurfaceView(this, ga));




	}
    
   
    	
  

public void onBackPressed()
{if(MySurfaceView.state==MySurfaceView.STATE_GAMING)
{MySurfaceView.state=MySurfaceView.STATE_PAUSE;
}
else
{finish();}
}

    
}
