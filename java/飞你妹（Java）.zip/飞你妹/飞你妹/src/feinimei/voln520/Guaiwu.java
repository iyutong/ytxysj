package feinimei.voln520;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Guaiwu {
Bitmap bmp;
int speed;
int x;int y;
Paint paint;
boolean isDead=false;
boolean isPlay=false;
int type;
public Guaiwu(Bitmap bmp,int x,int type)
{speed=Player.frameW/3;
this.x=x;
this.type=type;
paint=new Paint();
this.bmp=bmp;
}
	
	public void logic()
	{x-=speed;
y=(int) (0.00106f*Math.pow(x, 2)-0.25294f*x+143.3032f);
	if(x<0)
	{isDead=true;}
	
	}
	
	public void draw(Canvas canvas)
	{canvas.drawBitmap(bmp, x, y, paint);
          
	}
	
	
	public boolean isHint(Player player)
	{if(player.x<x-Player.frameW)
	{return false;}
	else if(player.x>x+bmp.getWidth())
	 {return false;}
	else  if(player.y<y-Player.frameH)
	  {return false;}
	else  if(player.y>y+bmp.getHeight())
	  {return false;}
	  return true;
	  }
	
}
