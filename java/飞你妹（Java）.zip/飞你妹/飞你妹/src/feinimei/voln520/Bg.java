package feinimei.voln520;


import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

public class Bg
{Paint paint;
Bitmap bgBmp,grassBmp,groundBmp;
int bgx1,bgx2;
int bgy;
int groundx1,groundx2;
int groundy;
int treeSpeed;
int grassSpeed;
Bitmap bmpLog;
int logW,logH;
Bg(Bitmap bgBmp,Bitmap groundBmp,Bitmap bmpLog)
{this.bgBmp=bgBmp;
bgx1=0;
bgx2=bgx1+bgBmp.getWidth();
bgy=MySurfaceView.sh-bgBmp.getHeight();
this.groundBmp=groundBmp;
groundx1=0;
groundx2=groundx1+groundBmp.getWidth();
groundy=MySurfaceView.sh-groundBmp.getHeight();
this.bmpLog=bmpLog;
paint=new Paint();
logW=bmpLog.getWidth();
logH=bmpLog.getHeight();
treeSpeed=Player.frameW/12;
grassSpeed=Player.frameW/4;
}


public void logic()
{

bgx1-=treeSpeed;
bgx2-=treeSpeed;
groundx1-=grassSpeed;
groundx2-=grassSpeed;
if(bgx1<-bgBmp.getWidth())
{bgx1=bgx2+bgBmp.getWidth();
}
if(bgx2<-bgBmp.getWidth())
{bgx2=bgx1+bgBmp.getWidth();
}
 if(groundx1<-groundBmp.getWidth())
 {groundx1=groundx2+groundBmp.getWidth();
  }
  if(groundx2<-groundBmp.getWidth())
  {groundx2=groundx1+groundBmp.getWidth();
  }
  
}

public void drawTree(Canvas canvas)
{canvas.drawBitmap(bgBmp,bgx1,bgy,paint);
canvas.drawBitmap(bgBmp,bgx2,bgy,paint);
}
public void drawGrass(Canvas canvas)
{
canvas.drawBitmap(groundBmp,groundx1,groundy,paint);
canvas.drawBitmap(groundBmp,groundx2,groundy,paint);
}

public void drawLog(Canvas canvas)
{canvas.drawBitmap(bmpLog, Player.frameW, MySurfaceView.sh-logH, paint);

}


}
