/** Automatically generated file. DO NOT MODIFY */
package feinimei.voln520;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}