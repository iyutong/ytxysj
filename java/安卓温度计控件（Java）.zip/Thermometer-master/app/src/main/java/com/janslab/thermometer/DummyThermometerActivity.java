package com.janslab.thermometer;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Kofi Gyan on 1/29/2016.
 */
public class DummyThermometerActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy_thermometer);

    }

}
