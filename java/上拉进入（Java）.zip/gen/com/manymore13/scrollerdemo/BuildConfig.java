/** Automatically generated file. DO NOT MODIFY */
package com.manymore13.scrollerdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}