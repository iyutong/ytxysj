package com.duihuakuang.qq1;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.widget.*;
import android.view.*;
import android.view.View.*;
import android.telephony.*;
import java.nio.file.*;
import java.security.*;
import android.util.*;
import java.util.*;
import java.net.*;
import java.lang.reflect.*;

public class MainActivity extends Activity 
{
	public static Context thzz;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		thzz = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		String serial1 = getProperty("ro.serialno","");
		Toast.makeText(this,(serial1),5000).show();
    }

	public static void 普通对话框(Context con){
		AlertDialog.Builder dia = new AlertDialog.Builder(con,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
		dia.setTitle("");
		dia.setCancelable(false);
		dia.setMessage("请加群");
		dia.setNegativeButton("取消",null);
		dia.setPositiveButton("加群",null);
		final AlertDialog dia2 = dia.show();
		dia2.show();
		dia2.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					加QQ(thzz,"abc");
					dia2.dismiss();
				}
			});
		dia2.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					dia2.dismiss();
				}
			});
	}


	public static boolean 加QQ(Context context, String str) {
        Intent intent = new Intent();
        intent.setData(Uri.parse(new StringBuffer().append("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Fk%3D").append(str).toString()));
        try {
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

	public static void 验证(Context context){

		final EditText pass=new EditText(context);
        pass.setText(getIMEI(thzz));
		if (pass.getText().toString().isEmpty())
		{
			pass.setText("未获取设备信息");
		}
		pass.setKeyListener(null);
		pass.setTextIsSelectable(true);
		AlertDialog.Builder builder=new AlertDialog.Builder(context,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
		builder.setTitle("请加群授权");
		builder.setView(pass);
		builder.setPositiveButton("验证",null);
		builder.setCancelable(false);
		final AlertDialog dialog=builder.show();
		dialog.show();

		dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					try {int i = pass.getText().toString().length();
						if(i < 8)
						{
							Thread.sleep((long) 125);
							android.os.Process.killProcess(android.os.Process.myPid());
							return;
						}else if(pass.getText().toString().equals("123456789"))
						{
							dialog.dismiss();
						}
						else {
							Toast.makeText(thzz,("设备未授权，请加群授权"),5000).show();
						}

					}catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}
	public static final String getIMEI(Context context) {
        try {
            //实例化TelephonyManager对象
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            //获取IMEI号
            String imei = telephonyManager.getDeviceId();
            //在次做个验证，也不是什么时候都能获取到的啊
            if (imei == null) {
			}
            return imei;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
	}

	public static String getProperty(String key, String defaultValue) {
        String value = defaultValue;
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            Method get = c.getMethod("get", String.class, String.class);
            value = (String)(get.invoke(c, key, defaultValue));
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return value;
        }
    }
	}
