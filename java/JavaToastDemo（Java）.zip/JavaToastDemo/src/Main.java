import java.lang.reflect.*;
import java.util.*;

public class Main
{
	
	public static void main(String[] args)
	{
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {}
		try
		{
		    
		 Class<?> Looper=Class.forName("android.os.Looper");
			Looper.getMethod("prepare").invoke(null);
			Class<?> mToastClass =Class.forName("android.widget.Toast");
			Object mToast = mToastClass.getMethod("makeText",
			                                      Class.forName("android.content.Context"),
												  java.lang.CharSequence.class,int.class).
												  invoke(null,getContext(),"内容",3000);
			mToastClass.getMethod("show").invoke(mToast);
			Looper.getMethod("loop").invoke(null);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Object getContext(){
		Object con =null;
		synchronized (Main.class) {
			try {
			
					Class activityThreadClass = Class.forName("android.app.ActivityThread");
					Object activityThread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
					Field activitiesField = activityThreadClass.getDeclaredField("mActivities");
					activitiesField.setAccessible(true);
					Map activities = (Map) activitiesField.get(activityThread);
					for (Object activityRecord : activities.values()) {
						Class activityRecordClass = activityRecord.getClass();
						Field pausedField = activityRecordClass.getDeclaredField("paused");
						pausedField.setAccessible(true);
						Field activityField = activityRecordClass.getDeclaredField("activity");
						activityField.setAccessible(true);
				  con =  activityField.get(activityRecord);
					}			
			} catch (Exception e) {
				e.printStackTrace();
			}
	     }
	 return con;
    }  
}
