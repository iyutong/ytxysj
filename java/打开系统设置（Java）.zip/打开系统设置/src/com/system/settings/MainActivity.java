package com.system.settings;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;

public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
}
	public void Button0(View view)
	{
		Intent intent = new Intent(android.provider.Settings. ACTION_SETTINGS);
		MainActivity.this.startActivity(intent);
	}
	public void Button1(View view)
	{
		Intent intent = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);
		MainActivity.this.startActivity(intent);
	}
	public void Button2(View view)
	{
		Intent intent = new Intent(android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS);
		MainActivity.this.startActivity(intent);
	}
	public void Button3(View view)
	{
		Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_SETTINGS);
		MainActivity.this.startActivity(intent);
    }
}
/*
ACTION_SETTINGS	系统设置

ACTION_APN_SETTINGS APN设置

ACTION_LOCATION_SOURCE_SETTINGS 位置和访问信息

ACTION_WIRELESS_SETTINGS 网络设置

ACTION_AIRPLANE_MODE_SETTINGS 无线和网络热点设置

ACTION_SECURITY_SETTINGS 位置和安全设置

ACTION_WIFI_SETTINGS 无线网WIFI设置

ACTION_WIFI_IP_SETTINGS 无线网IP设置

ACTION_BLUETOOTH_SETTINGS 蓝牙设置

ACTION_DATE_SETTINGS 时间和日期设置

ACTION_SOUND_SETTINGS 声音设置

ACTION_DISPLAY_SETTINGS 显示设置——字体大小等

ACTION_LOCALE_SETTINGS 语言设置

ACTION_INPUT_METHOD_SETTINGS 输入法设置

ACTION_USER_DICTIONARY_SETTINGS 用户词典

ACTION_APPLICATION_SETTINGS 应用程序设置

ACTION_APPLICATION_DEVELOPMENT_SETTINGS 应用程序设置=》开发设置

ACTION_QUICK_LAUNCH_SETTINGS 快速启动设置

ACTION_MANAGE_APPLICATIONS_SETTINGS 已下载（安装）软件列表

ACTION_SYNC_SETTINGS 应用程序数据同步设置

ACTION_NETWORK_OPERATOR_SETTINGS 可用网络搜索

ACTION_DATA_ROAMING_SETTINGS 移动网络设置

ACTION_INTERNAL_STORAGE_SETTINGS 手机存储设置

ACTION_MEMORY_CARD_SETTINGS 默认存储设置
*/
