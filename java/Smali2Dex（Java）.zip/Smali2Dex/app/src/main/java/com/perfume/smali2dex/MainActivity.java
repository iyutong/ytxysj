package com.perfume.smali2dex;

import android.app.*;
import android.os.*;
import java.io.*;
import java.util.*;
import org.antlr.runtime.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.writer.builder.*;
import org.jf.dexlib2.writer.io.*;
import org.jf.smali.*;
import android.widget.*;
import org.zeroturnaround.zip.*;

public class MainActivity extends Activity 
{
	private DexBuilder dex;
	private ProgressDialog prodialog,p;
	private List<File> smali=new ArrayList();
	private String Out;
	private String In;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		prodialog = new ProgressDialog(this);
		dex = new DexBuilder(Opcodes.getDefault());
		Out=ReadTxtFile("sdcard/tencent/apktool/2.txt");
		In=ReadTxtFile("sdcard/tencent/apktool/1.txt");
		final File input = new File(In+"/smali/");
		run(input);
		prodialog.setMax(smali.size());
		prodialog.setProgress(0);
		prodialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		prodialog.setCancelable(false);
		prodialog.setTitle("Smali2Dex");
		prodialog.setMessage("Smali.....");
		prodialog.show();
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					try
					{
						for (int i=0;i < smali.size();i++)
						{
							prodialog.setProgress(i);
							Smali.assembleSmaliFile(smali.get(i), dex, new SmaliOptions());
						}
						prodialog.dismiss();
						runOnUiThread(new Runnable(){

								@Override
								public void run()
								{
									p=new ProgressDialog(MainActivity.this);
									p.setTitle("Out Apk.....");
									p.setCancelable(false);
									p.show();
								}
							});
						FileDataStore Test2=new FileDataStore(new File("sdcard/Smali.dex"));
						dex.writeTo(Test2);
						ZipUtil.pack(new File(In),new File(Out));
						ZipUtil.removeEntries(new File(Out),new String[]{"unkonwn/","smali/","original/"});
						ZipUtil.removeEntry(new File(Out),"apktool.yml");
						ZipUtil.removeEntry(new File(Out),"LogCat.txt");
						ZipUtil.addEntry(new File(Out),"classes.dex",new File("sdcard/Smali.dex"));
						p.dismiss();
						new File("sdcard/Smali.dex").delete();
						System.exit(0);
					}
					catch (final Exception e)
					{
						runOnUiThread(new Runnable(){

								@Override
								public void run()
								{
									Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), 5000).show();
								}
							});
					}
				}
			}).start();

    }

	private void run(File Path) 
	{
		for (File a:Path.listFiles())
		{
			if (a.isDirectory())
			{
				run(a.getAbsoluteFile());
			}
			else
			{
				smali.add(a.getAbsoluteFile());
			}
		}
	}
	public String ReadTxtFile(String strFilePath)
    {
        String path = strFilePath;
        String content = ""; //文件内容字符串
		//打开文件
		File file = new File(path);
		try
		{
			InputStream instream = new FileInputStream(file); 
			if (instream != null) 
			{
				InputStreamReader inputreader = new InputStreamReader(instream);
				BufferedReader buffreader = new BufferedReader(inputreader);
				String line;
				//分行读取
				while ((line = buffreader.readLine()) != null)
				{
					content += line;
				}                
				instream.close();
			}
		}
		catch (java.io.FileNotFoundException e) 
		{
		} 
		catch (IOException e) 
		{
		}
		return content;
    }
}
