package com.laugh.HighlightCode;
import android.app.*;
import android.os.*;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.widget.ScrollView;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
public class MainActivity extends Activity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}
