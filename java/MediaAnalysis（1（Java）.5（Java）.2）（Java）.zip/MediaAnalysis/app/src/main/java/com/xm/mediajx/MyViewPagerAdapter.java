package com.xm.mediajx;
import android.support.v4.view.*;
import android.view.*;
import java.util.*;

public class MyViewPagerAdapter extends PagerAdapter
{
	ArrayList<View> v=new ArrayList<View>();
	public MyViewPagerAdapter(ArrayList<View> v){
		this.v=v;
	}
	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return v.size();
	}

	@Override
	public boolean isViewFromObject(View p1, Object p2)
	{
		// TODO: Implement this method
		return p1==p2;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object)
	{
		// TODO: Implement this method
		container.removeView(v.get(position));
		}

	@Override
	public Object instantiateItem(ViewGroup container, int position)
	{
		// TODO: Implement this method
		container.addView(v.get(position));
		return v.get(position);
	}
	
}
