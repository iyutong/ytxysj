package com.xm.mediajx;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.support.v4.view.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;
import junit.runner.*;
import org.json.*;
import java.lang.annotation.*;
import android.webkit.*;


public class MainActivity extends Activity 
{
	private View Music_View;
	private View Video_View;
	private final String VERSION="1.5.2";
	private ListView music_list_1,music_list_2,music_list_3;
	private boolean isExit=false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
	    setContentView(R.layout.main);
		into();
		SeachMusic("9420");
    }



	public void into()
	{
		//检查更新
		Update();
		//初始化ActionBar
		final ImageButton seach=(ImageButton) findViewById(R.id.mainImageButton1);
		final ImageButton memu=(ImageButton) findViewById(R.id.mainImageButton2);
		seach.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					AlertDialog.Builder aler=new AlertDialog.Builder(MainActivity.this);
					aler.setTitle("搜索：");
					final View view=LayoutInflater.from(MainActivity.this).inflate(R.layout.seach, null);
					aler.setView(view);
					aler.setPositiveButton("音乐", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								EditText ed=(EditText)view.findViewById(R.id.seachEditText1);
								String text=ed.getText().toString();
								if (!text.equals(""))
								{
									SeachMusic(text);
								}
								else
								{
									Toast.makeText(getApplicationContext(), "请输入搜索的内容", Toast.LENGTH_SHORT).show();
								}
							}
						});
					AlertDialog alert=aler.show();
					alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xffe91e63);
					alert.setCanceledOnTouchOutside(false);
					try
					{
						Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
						mAlert.setAccessible(true);
						Object mAlertController = mAlert.get(alert);
						Field mTitle = mAlertController.getClass().getDeclaredField("mTitleView");
						mTitle.setAccessible(true);
						TextView mTitleView = (TextView) mTitle.get(mAlertController);
						mTitleView.setTextColor(0xffe91e63);
					}
					catch (Exception e)
					{
						e.printStackTrace();
					} 
				}
			});

		memu.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					PopupMenu popmume=new PopupMenu(MainActivity.this, memu);
					popmume.getMenuInflater().inflate(R.menu.menu, popmume.getMenu());
					popmume.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){

							@Override
							public boolean onMenuItemClick(MenuItem p1)
							{
								// TODO: Implement this method
								switch (p1.getItemId())
								{
									case R.id.about:
										startActivity(new Intent(MainActivity.this, About.class));
										break;
									case R.id.exit:
										System.exit(0);
										break;
								}
								return false;
							}
						});
					popmume.show();
				}
			});

		//初始化ViewPager
		final ViewPager vp_home=(ViewPager) findViewById(R.id.mainViewPager1);
		TextView item_music=(TextView) findViewById(R.id.mainTextView1);
		TextView item_video=(TextView) findViewById(R.id.mainTextView2);
		final LinearLayout seekbar=(LinearLayout) findViewById(R.id.mainLinearLayout1);
		vp_home.setOnPageChangeListener(new ViewPager.OnPageChangeListener(){

				@Override
				public void onPageScrolled(int p1, float p2, int p3)
				{
					// TODO: Implement this method
					float f=getWindow().getDecorView().getWidth() / 2 * (p1 + p2);
					seekbar.setX(f);
				}

				@Override
				public void onPageSelected(int p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onPageScrollStateChanged(int p1)
				{
					// TODO: Implement this method
				}
			});
		ArrayList<View> view=new ArrayList<View>();
	    Music_View = LayoutInflater.from(this).inflate(R.layout.music, null);
		Video_View = LayoutInflater.from(this).inflate(R.layout.video, null);	
		view.add(Music_View);
		view.add(Video_View);
		MyViewPagerAdapter adapter=new MyViewPagerAdapter(view);
		vp_home.setAdapter(adapter);
		item_music.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					vp_home.setCurrentItem(0);
				}
			});
		item_video.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					vp_home.setCurrentItem(1);
				}
			});
        //初始化音乐
		music_list_1 = (ListView) Music_View.findViewById(R.id.musicListView1);
		music_list_2 = (ListView) Music_View.findViewById(R.id.musicListView2);
		music_list_3 = (ListView) Music_View.findViewById(R.id.musicListView3);
		final TextView music_list_tv_1=(TextView) Music_View.findViewById(R.id.musicTextView1);
		final TextView music_list_tv_2=(TextView) Music_View.findViewById(R.id.musicTextView2);
		final TextView music_list_tv_3=(TextView) Music_View.findViewById(R.id.musicTextView3);
		SeekBar skb=(SeekBar) Music_View.findViewById(R.id.musicSeekBar1);
		final ImageView img_play_pause=(ImageView) Music_View.findViewById(R.id.musicImageView1);
		skb.setMax(0);
		img_play_pause.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					if (Client.getPlayState())
					{
						Client.setPlayPause();
						img_play_pause.setImageResource(R.drawable.ic_play_circle);
					}
					else if (Client.getPlayState() == false)
					{
						Client.setPlayStart();
						img_play_pause.setImageResource(R.drawable.ic_pause_circle_outline);
					}
				}
			});
		music_list_tv_1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					music_list_1.setVisibility(View.VISIBLE);
					music_list_2.setVisibility(View.GONE);
					music_list_3.setVisibility(View.GONE);
					music_list_tv_1.setTextColor(0xffe91e63);
					music_list_tv_2.setTextColor(0xff9e9e9e);
					music_list_tv_3.setTextColor(0xff9e9e9e);
				}
			});

		music_list_tv_2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					music_list_1.setVisibility(View.GONE);
					music_list_2.setVisibility(View.VISIBLE);
					music_list_3.setVisibility(View.GONE);
					music_list_tv_1.setTextColor(0xff9e9e9e);
					music_list_tv_2.setTextColor(0xffe91e63);
					music_list_tv_3.setTextColor(0xff9e9e9e);
				}
			});

		music_list_tv_3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					music_list_1.setVisibility(View.GONE);
					music_list_2.setVisibility(View.GONE);
					music_list_3.setVisibility(View.VISIBLE);
					music_list_tv_1.setTextColor(0xff9e9e9e);
					music_list_tv_2.setTextColor(0xff9e9e9e);
					music_list_tv_3.setTextColor(0xffe91e63);
				}
			});


		//视频初始化
		final TextView video_web_tv_1=(TextView) Video_View.findViewById(R.id.videoTextView1);
		final TextView video_web_tv_2=(TextView) Video_View.findViewById(R.id.videoTextView2);
		final TextView video_web_tv_3=(TextView) Video_View.findViewById(R.id.videoTextView3);
		final TextView video_web_tv_page=(TextView) Video_View.findViewById(R.id.videoTextView4);
		Button video_bar_btn_1=(Button) Video_View.findViewById(R.id.videoButton1);
		Button video_bar_btn_2=(Button) Video_View.findViewById(R.id.videoButton2);
		Button video_bar_btn_3=(Button) Video_View.findViewById(R.id.videoButton3);
		final WebView video_web_1=(WebView) Video_View.findViewById(R.id.videoWebView1);
		final WebView video_web_2=(WebView) Video_View.findViewById(R.id.videoWebView2);
		final WebView video_web_3=(WebView) Video_View.findViewById(R.id.videoWebView3);
		video_web_1.loadUrl("https://www.youku.com/");
		video_web_2.loadUrl("http://m.v.qq.com/");
		video_web_3.loadUrl("http://m.iqiyi.com/");
		video_web_tv_1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					video_web_tv_page.setText("0");
					video_web_1.setVisibility(View.VISIBLE);
					video_web_2.setVisibility(View.GONE);
					video_web_3.setVisibility(View.GONE);
					video_web_tv_1.setTextColor(0xffe91e63);
					video_web_tv_2.setTextColor(0xff9e9e9e);
					video_web_tv_3.setTextColor(0xff9e9e9e);
				}
			});
			
		video_web_tv_2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					video_web_tv_page.setText("1");
					video_web_1.setVisibility(View.GONE);
					video_web_2.setVisibility(View.VISIBLE);
					video_web_3.setVisibility(View.GONE);
					video_web_tv_1.setTextColor(0xff9e9e9e);
					video_web_tv_2.setTextColor(0xffe91e63);
					video_web_tv_3.setTextColor(0xff9e9e9e);
				}
			});
			
		video_web_tv_3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					video_web_tv_page.setText("2");
					video_web_1.setVisibility(View.GONE);
					video_web_2.setVisibility(View.GONE);
					video_web_3.setVisibility(View.VISIBLE);
					video_web_tv_1.setTextColor(0xff9e9e9e);
					video_web_tv_2.setTextColor(0xff9e9e9e);
					video_web_tv_3.setTextColor(0xffe91e63);
				}
			});
			
			
		video_web_1.setWebViewClient(new WebViewClient() {
				@Override 
				public void onPageFinished(WebView view,String url) { 
					//加载完成
				} 
				@Override 
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					//设置在本浏览器打开新网页
					view.loadUrl(url);
					return true;
				}
			});
		
			
		video_web_2.setWebViewClient(new WebViewClient() {
				@Override 
				public void onPageFinished(WebView view,String url) { 
					//加载完成
				} 
				@Override 
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					//设置在本浏览器打开新网页
					view.loadUrl(url);
					return true;
				}
			});
		
			
		video_web_3.setWebViewClient(new WebViewClient() {
				@Override 
				public void onPageFinished(WebView view,String url) { 
					//加载完成
				} 
				@Override 
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					//设置在本浏览器打开新网页
					view.loadUrl(url);
					return true;
				}
			});
		
		video_bar_btn_1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String s=video_web_tv_page.getText().toString();
					if(s.equals("0")){
						video_web_1.goBack();
					}else if(s.equals("1")){
						video_web_2.goBack();
					}else if(s.equals("2")){
						video_web_3.goBack();
					}
				}
			});
			
			
		video_bar_btn_2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String s=video_web_tv_page.getText().toString();
					if(s.equals("0")){
						video_web_1.reload();
					}else if(s.equals("1")){
						video_web_2.reload();
					}else if(s.equals("2")){
						video_web_3.reload();
					}
				}
			});
		
			
		video_bar_btn_3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String s=video_web_tv_page.getText().toString();
					if(s.equals("0")){
						video_web_1.loadUrl("http://y.mt2t.com/lines?url="+video_web_1.getUrl());
					}else if(s.equals("1")){
						video_web_2.loadUrl("http://y.mt2t.com/lines?url="+video_web_2.getUrl());
					}else if(s.equals("2")){
						video_web_3.loadUrl("http://y.mt2t.com/lines?url="+video_web_3.getUrl());
					}
				}
			});
	}


	public void SeachMusic(String name)
	{
		if (name.replace(" ", "").length() != 0)
		{
			if (Client.GetNetWorkState(this))
			{
				try
				{
					name = URLEncoder.encode(name, "utf-8");
					Toast.makeText(this, "搜索中...", Toast.LENGTH_SHORT).show();
					new KGMusicAsync(this, Music_View).execute(name);
					new QQMusicAsync(this, Music_View).execute(name);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				Toast.makeText(MainActivity.this, "请检查网络是否连接！", Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(this, "请不要留空", 0).show();
		}
	}
	public void Update()
	{
		new Thread(new Runnable(){
				Handler han=new Handler(){
					@Override
					public void handleMessage(Message msg)
					{
						HashMap map=(HashMap) msg.obj;
						String respone=(String) map.get("respone");
						String content=(String) map.get("content");
						if (respone == "alert")
						{
							AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
							alert.setTitle("更新：");
							alert.setMessage("发现新版本是否更新？");				
							alert.setPositiveButton("去酷安更新", new DialogInterface.OnClickListener(){

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										// TODO: Implement this method
										Intent intent=new Intent();

									}
								});
							AlertDialog aler=alert.show();
							aler.setCanceledOnTouchOutside(false);
							Field mAlert=AlertDialog.class.getDeclaredField("mAlert");
							mAlert.setAccessible(true);
							Object mAlertView=mAlert.get(aler);
							Field mTitleView=mAlertView.getClass().getDeclaredField("mTitleView");
							mTitleView.setAccessible(true);
							TextView mTitle=(TextView) mTitleView.get(mAlertView);
							mTitle.setTextColor(0xffe91e63);
							Field mMessageView=mAlertView.getClass().getDeclaredField("mMessageView");
							mMessageView.setAccessible(true);
							TextView mMessage=(TextView) mMessageView.get(mAlertView);
							mMessage.setTextColor(0xffe91e63);
							Field mPositiveButtonView=mAlertView.getClass().getDeclaredField("mButtonPositive");
							mPositiveButtonView.setAccessible(true);
							Button mPositiveButton=(Button) mPositiveButtonView.get(mAlertView);
							mPositiveButton.setTextColor(0xffe91e63);
						}

						else if (respone == "toast")
						{
							Toast.makeText(MainActivity.this, content, 0).show();
						}
						super.handleMessage(msg);
					}
				};
				@Override
				public void run()
				{
					// TODO: Implement this method
					try
					{
						HashMap<Object,Object> hash=new HashMap<>();
						if (Client.GetNetWorkState(MainActivity.this))
						{
							HttpURLConnection httpURLConnection =(HttpURLConnection) new URL("http://52xmi.top/MediaAnalysis/backstage.txt").openConnection();
							httpURLConnection.setConnectTimeout(6000);
							httpURLConnection.setRequestMethod("GET");
							String result=Client.PrintStream(httpURLConnection);
							JSONObject json=new JSONObject(result);
							String softwareversion=json.getString("SoftWareVersion");
							String fileadress=json.getString("FileAdress");
							int version=Integer.parseInt(VERSION.replace(".", ""));
							int newversion=Integer.parseInt(softwareversion.replace(".", ""));
							if (newversion > version)
							{
								hash = new HashMap<>();
								hash.put("respone", "alert");
								hash.put("content", fileadress);
								han.obtainMessage(22, hash).sendToTarget();
							}
							else
							{
								hash = new HashMap<>();
								hash.put("respone", "toast");
								hash.put("content", "暂无最新版本！");
								han.obtainMessage(22, hash).sendToTarget();
							}
						}
						else
						{
							hash = new HashMap<>();
							hash.put("respone", "toast");
							hash.put("content", "请检查网络是否连接！");
							han.obtainMessage(22, hash).sendToTarget();
						}
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			}).start();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		// TODO: Implement this method
		Handler han=new Handler(){
			@Override
			public void handleMessage(Message msg)
			{
				isExit = false;
				super.handleMessage(msg);
			}
		};
		if (keyCode == 4)
		{
			if (isExit)
			{
				System.exit(0);
			}
			else
			{
				isExit = true;
				Toast.makeText(this, "再按一次退出程序", 0).show();
				han.sendEmptyMessageDelayed(0, 2000);
			}
		}
		return false;
	}


}
	

