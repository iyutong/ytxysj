package com.xm.mediajx;

import abc.abc.abc.*;
import abc.abc.abc.nm.bn.*;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class About extends Activity
{

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		//初始化赞助广告
		AdManager.getInstance(About.this).init("b0e937cb60bdd001", "fe97874b0fbfe4a5", false);
		LinearLayout shareapplication= (LinearLayout) findViewById(R.id.aboutLinearLayout1);
		LinearLayout support=(LinearLayout) findViewById(R.id.aboutLinearLayout2);
		LinearLayout contactauthor=(LinearLayout) findViewById(R.id.aboutLinearLayout3);
		LinearLayout addqqgroup=(LinearLayout) findViewById(R.id.aboutLinearLayout4);
		ImageButton back=(ImageButton) findViewById(R.id.aboutImageButton1);	
		LinearLayout remarks=(LinearLayout) findViewById(R.id.aboutLinearLayout5);
		shareapplication.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Intent intent=new Intent();
					intent.setAction(Intent.ACTION_SEND);
					intent.putExtra(Intent.EXTRA_TEXT, "Hi,我在用@音乐视频解析器：https://www.coolapk.com/apk/com.xm.mediajx 一款可以免费下载付费音乐和播放收费视频的软件你也来试试看吧！");
					intent.setType("text/plain");
					About.this.startActivity(Intent.createChooser(intent, "分享软件"));
				}
			});

		support.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					//获取广告条
					View bannerView = BannerManager.getInstance(About.this).getBannerView(About.this, new BannerViewListener(){

							@Override
							public void onRequestSuccess()
							{
								// TODO: Implement this method
								System.out.println("请求成功！");
							}

							@Override
							public void onSwitchBanner()
							{
								// TODO: Implement this method
								
							}

							@Override
							public void onRequestFailed()
							{
								// TODO: Implement this method
								System.out.println("请求失败！");
							}
						});
					View view=LayoutInflater.from(About.this).inflate(R.layout.support, null);
				    LinearLayout lay=(LinearLayout) view.findViewById(R.id.supportLinearLayout1);
					lay.addView(bannerView);
					AlertDialog.Builder alert=new AlertDialog.Builder(About.this)
						.setTitle("捐赠支持：")
						.setView(view)
						.setPositiveButton("不捐赠", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
							}
						});
					AlertDialog alerts=alert.show();
				}
			});

		contactauthor.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
				    String url="mqqwpa://im/chat?chat_type=wpa&uin=3510088586";
					startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
				}
			});

		addqqgroup.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
				    String url="mqqapi://card/show_pslcard?src_type=internal&version=1&uin=241449466&card_type=group&source=qrcode";
					startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
				}
			});

		back.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					About.this.finish();
				}
			});
			
		remarks.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					AlertDialog.Builder aler=new AlertDialog.Builder(About.this);
						aler.setNegativeButton("b站链接", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								ClipboardManager x=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
							    x.setText("http://space.bilibili.com/88716390?share_medium=android&share_source=copy_link&bbid=265CD17E-432F-4719-80CD-990865F4A2901995infoc&ts=1518267020861");
								Toast.makeText(About.this,"已复制链接",0).show();
							}
						})
						.setPositiveButton("博客链接", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								ClipboardManager x=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
								x.setText("http://xmiblog.top");
								Toast.makeText(About.this,"已复制链接",0).show();
							}
						})
						.show();
				}
			});

	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		BannerManager.getInstance(About.this).onDestroy();
		super.onDestroy();
	}

}
