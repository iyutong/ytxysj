package com.xm.mediajx;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.math.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class KGMusicAsync extends AsyncTask<String,String,String>
{
	Context context;
	View view;
	ArrayList<String> list_name=new ArrayList<String>();
	ArrayList<String> list_url=new ArrayList<String>();
	ArrayList<String> list_author=new ArrayList<String>();
	ArrayList<String> list_size=new ArrayList<String>();
	public KGMusicAsync(Context context,View view){
		this.context=context;
		this.view=view;
	}

	@Override
	protected void onPreExecute()
	{
		// TODO: Implement this method
		super.onPreExecute();

	}

	@Override
	protected String doInBackground(String[] p1)
	{
		// TODO: Implement this method
		try
		{
			HttpURLConnection conn=(HttpURLConnection) new URL("http://songsearch.kugou.com/song_search_v2?callback=none&keyword="+p1[0]+"&page=1&pagesize=30&userid=-1&clientver=&platform=WebFilter&tag=em&filter=2&iscorrection=1&privilege_filter=0&_=1516435193648").openConnection();
			conn.setConnectTimeout(6000);
			conn.setRequestMethod("GET");
			conn.connect();
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			InputStream inputStream=conn.getInputStream();
			byte[] byt=new byte[1024];
			int len=0;
			while ((len = inputStream.read(byt)) != -1)
			{
				byteArrayOutputStream.write(byt, 0, len);
			}
			byteArrayOutputStream.close();
			inputStream.close();
			return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(String result)
	{
		// TODO: Implement this method
		super.onPostExecute(result);
		System.out.println(context);
		
		try
		{
			result=result.substring(result.indexOf("error_code\":0,\"data\":")+21,result.lastIndexOf("}"));
			System.out.println(result);
			JSONObject jsono=new JSONObject(result);
			JSONArray lists=jsono.getJSONArray("lists");
			for(int i=0;i<lists.length();i++){
				JSONObject listt=new JSONObject(lists.getString(i));
				String name=listt.getString("FileName");
				name=name.replace("/","").replace("<em>","");
				String size=Double.parseDouble(listt.getString("FileSize"))/1024/1024+"";
				BigDecimal b= new BigDecimal(size); 
				size=b.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue()+"MB";
				String author=listt.getString("SingerName");
				String hash=listt.getString("FileHash");
				//if(hash.length()!=32)
				//hash=listt.getString("SQHash");
				if(hash.length()!=32)
			    hash=listt.getString("FileHash");
				String id=listt.getString("AlbumID");
				System.out.println(name);
				list_name.add(name);
				list_url.add("http://www.kugou.com/song/#hash="+hash+"&id="+id);
				list_author.add(author);
				list_size.add(size);
			}
			ListView list=(ListView) view.findViewById(R.id.musicListView1);
			list.setAdapter(new MyListAdapter(context,view,list_name,list_url,list_author,list_size));
			System.out.println("执行了吗");
		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
	}
	
}
