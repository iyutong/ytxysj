package com.xm.mediajx;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.*;
import android.media.*;
public class MyListAdapter extends BaseAdapter
{
	Context context;
	View views;
	ArrayList<String> List_Url=new ArrayList<String>();
	ArrayList<String> List_Name=new ArrayList<String>();
	ArrayList<String> List_Author=new ArrayList<String>();
	ArrayList<String> List_Size=new ArrayList<String>();
	public MyListAdapter(Context context,View view, ArrayList<String> List_Name, ArrayList<String> List_Url,ArrayList<String> List_Author,ArrayList<String> List_Size)
	{
		System.out.println("执行了");
		this.views=view;
		this.context = context;
		this.List_Url = List_Url;
		this.List_Name = List_Name;
		this.List_Author=List_Author;
		this.List_Size=List_Size;
	}


	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return List_Name.size();
	}

	@Override
	public Object getItem(int p1)
	{
		// TODO: Implement this method
		return List_Name.get(p1);
	}

	@Override
	public long getItemId(int p1)
	{
		// TODO: Implement this method
		return p1;
	}

	@Override
	public View getView(int p1, View p2, ViewGroup p3)
	{ 
		View view=null;
		Holder holder=null;
		if (p2 == null)
		{
			view = LayoutInflater.from(context).inflate(R.layout.listitem, null);
			holder = new Holder();
			holder.Url = (TextView) view.findViewById(R.id.listitemTextView2);
			holder.Name = (TextView) view.findViewById(R.id.listitemTextView1);
			holder.Author=(TextView) view.findViewById(R.id.listitemTextView3);
			holder.Size=(TextView) view.findViewById(R.id.listitemTextView4);
			holder.Play = (ImageButton) view.findViewById(R.id.listitemImageButton1);
			holder.Download = (ImageButton) view.findViewById(R.id.listitemImageButton2);
			holder.Share = (ImageButton) view.findViewById(R.id.listitemImageButton3);
			view.setTag(holder);
		}
		else
		{
			view = p2;
			holder = (Holder) view.getTag();
		}
		holder.Url.setText(List_Url.get(p1));
		holder.Name.setText(List_Name.get(p1));
		holder.Author.setText(List_Author.get(p1));
		holder.Size.setText(List_Size.get(p1));
		final String sharesn=List_Name.get(p1);
		final String shares=List_Url.get(p1);
		final String share= sharesn + "：分享来自@音乐视频解析器 " + List_Url.get(p1);
		holder.Play.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					final ProgressDialog pr=ProgressDialog.show(context,null,"解析中...");
				    TextView tv=(TextView) views.findViewById(R.id.musicTextView6);
					tv.setText("正在播放："+sharesn);
					if(Client.GetNetWorkState(context)){
					new Thread(new Runnable(){
							Handler hand=new Handler(){
								@Override
								public void handleMessage(Message msg){
									Client.setDataSource(msg.obj.toString(),views);
									pr.dismiss();
									super.handleMessage(msg);
								}
							};
							@Override
							public void run()
							{
								// TODO: Implement this method
								if(shares.indexOf("kugou")!=-1){
									String m=Client.KGMusic(shares);
									hand.obtainMessage(22,m).sendToTarget();
								}else if(shares.indexOf("y.qq.")!=-1){
									hand.obtainMessage(22,Client.QQMusic(shares)).sendToTarget();
								}
							}
						}).start();}
						else{
							Toast.makeText(context,"请检查网络是否连接！",Toast.LENGTH_SHORT).show();
							pr.dismiss();
						}
				}
			});

		holder.Download.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					
					final ProgressDialog pr=ProgressDialog.show(context,null,"解析中...");
			        if(Client.GetNetWorkState(context)){
					new Thread(new Runnable(){
							Handler hand=new Handler(){
								@Override
								public void handleMessage(Message msg){
									Intent intent_d= new Intent();        
									intent_d.setAction("android.intent.action.VIEW");    
									Uri content_url = Uri.parse(msg.obj.toString());   
									intent_d.setData(content_url);  
									context.startActivity(intent_d);
									pr.dismiss();
									super.handleMessage(msg);
								}
							};
							@Override
							public void run()
							{
								// TODO: Implement this method
								if(shares.indexOf("kugou")!=-1){
								String m=Client.KGMusic(shares);
								hand.obtainMessage(22,m).sendToTarget();
								}else if(shares.indexOf("y.qq.")!=-1){
							    hand.obtainMessage(22,Client.QQMusic(shares)).sendToTarget();
								}
							}
						}).start();}
						else{
							Toast.makeText(context,"请检查网络是否连接！",Toast.LENGTH_SHORT).show();
							pr.dismiss();
						}
				}
			});

		holder.Share.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					AlertDialog.Builder aler=new AlertDialog.Builder(context)
					.setTitle("解析提示：")
					.setMessage("请选择分享模式")
						.setPositiveButton("直链分享", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
							    final ProgressDialog pr=ProgressDialog.show(context,null,"解析中...");
								if(Client.GetNetWorkState(context)){
								new Thread(new Runnable(){
									Handler hand=new Handler(){
										@Override
										public void handleMessage(Message msg){
											Intent sendIntent = new Intent();
											sendIntent.setAction(Intent.ACTION_SEND);
											sendIntent.putExtra(Intent.EXTRA_TEXT,sharesn+"：分享来自@音乐视频解析器 "+msg.obj.toString());
											sendIntent.setType("text/plain");
											context.startActivity(Intent.createChooser(sendIntent, "Share With"));  
											pr.dismiss();
											super.handleMessage(msg);
										}
									};
										@Override
										public void run()
										{
											// TODO: Implement this method
											if(shares.indexOf("kugou")!=-1){
											String m=Client.KGMusic(shares);
											hand.obtainMessage(22,m).sendToTarget();
											}else if(shares.indexOf("y.qq.")!=-1){
											hand.obtainMessage(22,Client.QQMusic(shares)).sendToTarget();
											}
										}
									}).start();}
									else{
										Toast.makeText(context,"请检查网络是否连接！",Toast.LENGTH_SHORT).show();
										pr.dismiss();
									}
							}
						})
						.setNegativeButton("直接分享", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								Intent sendIntent = new Intent();
								sendIntent.setAction(Intent.ACTION_SEND);
								sendIntent.putExtra(Intent.EXTRA_TEXT, share);
								sendIntent.setType("text/plain");
								context.startActivity(Intent.createChooser(sendIntent, "Share With"));  
							}
						});
					 AlertDialog alert=aler.show();
					
					
				}
			});
		return view;
	}
	class Holder
	{
		TextView Url,Name,Author,Size;
		ImageButton Play,Download,Share;
	}
	
	
}
