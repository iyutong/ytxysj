package com.xm.mediajx;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.math.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class QQMusicAsync extends AsyncTask<String,String,String>
{
	Context context;
	View view;
	ArrayList<String> list_name=new ArrayList<String>();
	ArrayList<String> list_url=new ArrayList<String>();
	ArrayList<String> list_author=new ArrayList<String>();
	ArrayList<String> list_size=new ArrayList<String>();
	private String hash,id;
	public QQMusicAsync(Context context,View view){
		this.context=context;
		this.view=view;
	}

	@Override
	protected void onPreExecute()
	{
		// TODO: Implement this method
		super.onPreExecute();

	}

	@Override
	protected String doInBackground(String[] p1)
	{
		// TODO: Implement this method
		try
		{
			HttpURLConnection conn=(HttpURLConnection) new URL("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?ct=24&qqmusic_ver=1298&new_json=1&remoteplace=txt.yqq.center&searchid=48195095085784994&t=0&aggr=1&cr=1&catZhida=1&lossless=0&flag_qc=0&p=1&n=20&w="+p1[0]+"&g_tk=5381&jsonpCallback=MusicJsonCallback18665371754858695&loginUin=0&hostUin=0&format=jsonp&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0").openConnection();
			conn.setConnectTimeout(6000);
			conn.setRequestMethod("GET");
			conn.connect();
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			InputStream inputStream=conn.getInputStream();
			byte[] byt=new byte[1024];
			int len=0;
			while ((len = inputStream.read(byt)) != -1)
			{
				byteArrayOutputStream.write(byt, 0, len);
			}
			byteArrayOutputStream.close();
			inputStream.close();
			return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected void onPostExecute(String result)
	{
		// TODO: Implement this method
		super.onPostExecute(result);
		System.out.println(context);
		try
		{
			result=result.substring(result.indexOf("(")+1,result.lastIndexOf(")"));
			System.out.println(result);
			JSONObject jsono=new JSONObject(result);
			JSONArray lists=jsono.getJSONObject("data").getJSONObject("song").getJSONArray("list");
			for(int i=0;i<lists.length();i++){
				JSONObject listt=new JSONObject(lists.getString(i));
				String name=listt.getString("title");
				String singer=new JSONObject(listt.getJSONArray("singer").getString(0)).getString("name");
				String id=listt.getJSONObject("file").getString("media_mid");
				String size=Double.parseDouble(listt.getJSONObject("file").getString("size_128"))/1024/1024+"";
				BigDecimal b= new BigDecimal(size); 
				size=b.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue()+"MB";
				list_name.add(singer+" - "+name);
				list_author.add(singer);
				list_url.add("https://y.qq.com/n/yqq/song/"+id+".html");
				list_size.add(size);
			}
			ListView list=(ListView) view.findViewById(R.id.musicListView3);
			list.setAdapter(new MyListAdapter(context,view,list_name,list_url,list_author,list_size));
			System.out.println("执行了吗");
		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
	}



	

}
