package com.xm.mediajx;

import android.content.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class Client
{
	static MediaPlayer mediaPlayer=new MediaPlayer();
	public static String KGMusic(String link) {
		try {
			String hash=link.substring(link.indexOf("hash=")+5,link.lastIndexOf("&"));
			String id=link.substring(link.indexOf("id=")+3);
			System.out.println(hash+"   "+id);
			HttpURLConnection connection=(HttpURLConnection) new URL("http://www.kugou.com/yy/index.php?r=play/getdata&hash="+ hash+"& album_ id="+ id+"&_="+ System. currentTimeMillis()).openConnection();
			connection.setConnectTimeout(6000);
			connection.setRequestMethod("GET");
			connection.addRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 5.1.1; 2014813 Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 Mobile Safari/537.36");
			String result=PrintStream(connection);
			String absolute=result.substring(result.indexOf("\"play_url\":\"")+12,result.lastIndexOf("\",\"authors\":"));
			absolute=absolute.replaceAll("/", "");
			absolute=absolute.replace("\\","/");
			return absolute;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "解析出错了";
	}
	
	
	public static String QQMusic(String link){
		String mid=GetStringMaddle(link,"song/",".html",true);
		System.out.println(mid);
		long uid=10*10*10*10*10*10*10*10*10*10;
		float guid=(Math.round(2147483647*Math.random())*System.currentTimeMillis()%uid);
		System.out.println(guid);
		try{
		HttpURLConnection connection=(HttpURLConnection) new URL("https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?g_tk=5381&jsonpCallback=MusicJsonCallback6264595942381119&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&cid=205361747&callback=MusicJsonCallback6264595942381119&uin=0&songmid="+mid+"&filename=C400"+mid+".m4a&guid="+guid).openConnection();
		connection.setConnectTimeout(6000);
		connection.setRequestMethod("GET");
		connection.addRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 5.1.1; 2014813 Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 Mobile Safari/537.36");
		String result=PrintStream(connection);
		System.out.println(result);
		String vkey=new JSONObject(new JSONObject(GetStringMaddle(result,"(",")",true)).getJSONObject("data").getJSONArray("items").getString(0)).getString("vkey");
		return "http://dl.stream.qqmusic.qq.com/C400"+mid+".m4a?vkey="+vkey+"&guid="+guid+"&uin=0&fromtag=66";
		}catch(Exception e){
			e.printStackTrace();
		}
		return "解析出错了";
	}
	
	public static void setDataSource(String url,View view){
		final ImageView ibtn=(ImageView) view.findViewById(R.id.musicImageView1);
		final SeekBar skb=(SeekBar) view.findViewById(R.id.musicSeekBar1);
		final TextView tv_1=(TextView) view.findViewById(R.id.musicTextView4);
		final TextView tv_2=(TextView) view.findViewById(R.id.musicTextView5);
		final TimerTask timerTask=new TimerTask(){
			Handler han=new Handler(){
				@Override
				public void handleMessage(Message msg){
					tv_2.setText(FormatMusicTime(mediaPlayer.getCurrentPosition()));
					skb.setProgress(mediaPlayer.getCurrentPosition());
					super.handleMessage(msg);
				}
			};
			public void run(){
				han.obtainMessage(22).sendToTarget();
			}
		};
		final Timer timer=new Timer(true);
		try
		{
			mediaPlayer.reset();
			mediaPlayer.setDataSource(url);
			mediaPlayer.prepare();
			mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mediaPlayer) {
						//播放音乐
						mediaPlayer.start();
						ibtn.setImageResource(R.drawable.ic_pause_circle_outline);
						skb.setMax(mediaPlayer.getDuration());
						tv_1.setText(FormatMusicTime(mediaPlayer.getDuration()));
						timer.schedule(timerTask,0,500);
					}
				});
			mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){

					@Override
					public void onCompletion(MediaPlayer p1)
					{
						// TODO: Implement this method
						ibtn.setImageResource(R.drawable.ic_play_circle);
						timer.cancel();
						skb.setMax(0);
					}
				});
		   skb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {
						//判断是用户改变的滑块后的值有无变化
						if(fromUser==true){
							//滑块改变后设置音乐的播放进度
							mediaPlayer.seekTo(progress);
						}
					}
					@Override
					public void onStartTrackingTouch(SeekBar seekBar) {
					}
					@Override
					public void onStopTrackingTouch(SeekBar seekBar) {
					}
				});

		}
		catch (IllegalArgumentException e)
		{}
		catch (IOException e)
		{}
		catch (IllegalStateException e)
		{}
		catch (SecurityException e)
		{}
	}
	
	public static void setPlayPause(){
		mediaPlayer.pause();
	}
	
	public static void setPlayStart(){
		mediaPlayer.start();
	}
	
	public static boolean getPlayState(){
		return mediaPlayer.isPlaying();
	}
	
	public static String FormatMusicTime(int time){
		int m = time/1000/60;
		int s = time/1000%60;
		if (m<10){
			if (s<10){
				return "0" + m +":" + "0" + s ;
			}else
				return "0" + m +":" + s ;
		}else {
			if (s<10){
				return m +":" + "0" + s ;
			}else
				return m +":" + s ;
		}
	}
	
	
	public static boolean GetSdkVwesion(int v){
		return Build.VERSION.SDK_INT>=v?true:false;
	}
	
	public static  boolean GetNetWorkState(Context context){
		ConnectivityManager cm=(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo[] nwi=cm.getAllNetworkInfo();
		if (cm != null)
		{
			if(nwi!=null&&nwi.length>0){
				for(int i=0;i<nwi.length;i++){
					if(nwi[i].getState()==NetworkInfo.State.CONNECTED)
						return true;
				}
			}
		}
		return false;
	}
	
	
	public static String GetStringMaddle(String s,String l,String r,boolean i){
		if(i){
		return s.substring(s.indexOf(l)+l.length(),s.lastIndexOf(r));
		}
		else{
			return s.substring(s.indexOf(l)+l.length(),s.indexOf(r));
		}
	}
	
	public static String PrintStream(HttpURLConnection conn) {
		try {
			conn.connect();
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			InputStream inputStream=conn.getInputStream();
			byte[] byt=new byte[1024];
			int len=0;
			while((len=inputStream.read(byt))!=-1) {
				byteArrayOutputStream.write(byt,0,len);
			}
			byteArrayOutputStream.close();
			inputStream.close();
			return new String(byteArrayOutputStream.toByteArray(),"UTF-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
