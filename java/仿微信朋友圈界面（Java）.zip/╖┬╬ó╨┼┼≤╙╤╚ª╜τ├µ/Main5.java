package com.example.testproject;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.enums.PopupPosition;

public class Main5 extends AppCompatActivity implements YusScrollView.ScrollViewListener {
    private YusScrollView yusScrollView;
    private RelativeLayout relativeLayout;
    private RelativeLayout relativeLayout1;
    private ImageView imageView1,imageView2,imageView3;
    private TextView textView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main10);

        yusScrollView=findViewById(R.id.sv);
        relativeLayout=findViewById(R.id.iv);
        relativeLayout1=findViewById(R.id.header);
        imageView1=findViewById(R.id.t1);
        imageView2=findViewById(R.id.t3);
        textView=findViewById(R.id.t2);
        imageView3=findViewById(R.id.s2);

        yusScrollView.setScrollViewListener(this);


        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new XPopup.Builder(v.getContext())
                        .offsetX(10)
                        .offsetY(-80)
                        .popupPosition(PopupPosition.Left)
                        .hasShadowBg(false)
                        .atView(v)
                        .asCustom(new AttachPopup(v.getContext()))
                        .show();
            }
        });

    }

    @Override
    public void onScrollChanged(YusScrollView scrollView, int x, int y, int oldx, int oldy) {
        int tvHeight=textView.getHeight();
        int ivHeight=relativeLayout.getHeight();
        if(y<=0){
            relativeLayout1.setBackgroundColor(Color.TRANSPARENT);
            textView.setVisibility(View.INVISIBLE);
            imageView1.setVisibility(View.INVISIBLE);
            imageView2.setVisibility(View.INVISIBLE);

        }else if(y<ivHeight){
            float scale = (float) y / (float) ivHeight;
            float alpha = 255 * scale;

//            llHeader.setBackgroundColor(Color.argb((int) alpha, 144, 151, 166));
//            tvHeader.setVisibility(View.INVISIBLE);
            //先设置一个背景，然后在让背景乘以透明度
            relativeLayout1.setBackgroundColor(getResources().getColor(R.color.jjjj));
            relativeLayout1.getBackground().setAlpha((int)alpha);
            textView.setVisibility(View.INVISIBLE);
            imageView1.setVisibility(View.INVISIBLE);
            imageView2.setVisibility(View.INVISIBLE);


        }
        else if(y>=ivHeight){
            relativeLayout1.setBackgroundColor(getResources().getColor(R.color.jjjj));
            textView.setVisibility(View.VISIBLE);
            imageView1.setVisibility(View.VISIBLE);
            imageView2.setVisibility(View.VISIBLE);
        }
    }
}
