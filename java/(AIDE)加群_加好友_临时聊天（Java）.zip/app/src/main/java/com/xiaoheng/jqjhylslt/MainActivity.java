package com.xiaoheng.jqjhylslt;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		int a=0;
		while(a<6)
		{
		Toast Imagetoast=new Toast(MainActivity.this);
		Imagetoast.setGravity(Gravity.BOTTOM,0,0);
		LinearLayout layout=new LinearLayout(MainActivity.this);
		layout.setOrientation(0);
		/*ImageView image=new ImageView(MainActivity.this);
		image.setImageResource(R.drawable.heng);
		layout.addView(image);*/
		TextView toastmassage=new TextView(MainActivity.this);
		toastmassage.setText("小亨QQ：1919196455");
		toastmassage.setTextSize(28);
		toastmassage.setTextColor(Color.GREEN);
		layout.addView(toastmassage);
		Imagetoast.setDuration(Toast.LENGTH_LONG);
		Imagetoast.setView(layout);
		Imagetoast.show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		a++;
		}
		
		Button aa=(Button)findViewById(R.id.mainButton);
		Button bb=(Button)findViewById(R.id.mainButton1);
		Button cc=(Button)findViewById((R.id.mainButton2));
		Button dd=(Button)findViewById((R.id.mainButton3));
		
		
		
		
		
		aa.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					
					/*官方加群代码
					这种方式没有网转跳不了
					
					可以进入http://qun.qq.com/join.html这个网站登陆自己的QQ获取自己群的key
					网站里有说明自己看
					下面的是这是我群的群的key*/
					joinQQGroup("Miow_lT2ccTyvxNShCd33miSMDb90jeP");
				}
				public boolean joinQQGroup(String key)
				{
					Intent intent = new Intent();
					intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
					try
					{
						startActivity(intent);
						return true;
					}
					catch (Exception e)
					{
						return false;
					}
				}
			});
			
			
			
			
			
			bb.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					//非官方加群代码
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=234257176&card_type=group&source=qrcode")));
				}
			});
			
			
			
			
			
			cc.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					//临时聊天
					String heng="mqqwpa://im/chat?chat_type=wpa&uin=1919196455";
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(heng)));
				}
			});
			
			
			
			
			
			dd.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					//名片加好友代码
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
				}
			});
			
			
			
			
			
    }
}


/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/