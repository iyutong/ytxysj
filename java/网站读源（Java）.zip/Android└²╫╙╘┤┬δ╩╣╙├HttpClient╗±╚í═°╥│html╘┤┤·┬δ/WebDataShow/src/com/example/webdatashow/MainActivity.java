package com.example.webdatashow;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import android.R.string;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;




public class MainActivity extends Activity implements OnClickListener{
	private String TAG = "webdatashow";
	private Button urlConnection;
	private Button httpClient;
	private TextView webDataShow;
	private String pediyUrl = "http://www.javaapk.com";
	
	private static final int MSG_SUCCESS = 0;
	private static final int MSG_FAILURE = 1;
	private Handler mHandler = null;
	private Thread mThread;
	private Thread httpClientThread;	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webdata);
		urlConnection = (Button)findViewById(R.id.urlConnection);
		httpClient = (Button)findViewById(R.id.httpClient);
		webDataShow = (TextView)findViewById(R.id.webDataShow);
		urlConnection.setOnClickListener(this);
		httpClient.setOnClickListener(this);
		mHandler = new Handler()
		{

			@Override
			public void handleMessage(Message msg) {
				
				switch (msg.what) {
				case MSG_SUCCESS:
					Toast.makeText(getApplicationContext(), "URLConnection ���ӳɹ�", Toast.LENGTH_SHORT).show();	
					webDataShow.setText((String)msg.obj);
					break;
				case MSG_FAILURE:	
					Toast.makeText(getApplicationContext(), "URLConnection ����ʧ��", Toast.LENGTH_SHORT).show();
				default:
					break;
				}
			}
			
		};
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.urlConnection:
			if(mThread == null)
			{				
				mThread = new Thread(urlConnRunnable);
				mThread.start();
			}						
			break;
		case R.id.httpClient:
			if(httpClientThread == null)
			{
				httpClientThread = new Thread(httpClientRunnable);
				httpClientThread.start();
			}
			break;
		default:
			break;
		}
		
		
	}

	Runnable httpClientRunnable = new Runnable() {
		
		@Override
		public void run() {
			
			httpClientWebData();
			
		}
	};
	
	
	Runnable urlConnRunnable = new Runnable() {
		
		@Override
		public void run() {
			
			try {
				urlConGetWebData();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	};
	
	
	private void urlConGetWebData() throws IOException {
		URL url = new URL(pediyUrl);
		HttpURLConnection httpConn = (HttpURLConnection)url.openConnection();
		if(httpConn.getResponseCode() == HttpURLConnection.HTTP_OK)
		{		
			Log.d("TAG", "---into-----urlConnection---success--");
			
			InputStreamReader isr = new InputStreamReader(httpConn.getInputStream(), "utf-8");
			int i;
			String content = "";
			while((i = isr.read()) != -1)
			{
				content = content + (char)i;
			}
			mHandler.obtainMessage(MSG_SUCCESS,content).sendToTarget();
			isr.close();
			httpConn.disconnect();
		}else
		{
			Log.d("TAG", "---into-----urlConnection---fail--");
			
		}
		
	}

	protected void httpClientWebData() {
		DefaultHttpClient httpClinet = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(pediyUrl);
		ResponseHandler<String> responseHandler = new BasicResponseHandler();
		try {
			String content = httpClinet.execute(httpGet, responseHandler);
			mHandler.obtainMessage(MSG_SUCCESS,content).sendToTarget();
		} catch (ClientProtocolException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	

}
