package top.yokey.miuidialog;

@SuppressWarnings("ALL")
public interface MiuiMutilInputListener {

    void onClick(String content);

}
