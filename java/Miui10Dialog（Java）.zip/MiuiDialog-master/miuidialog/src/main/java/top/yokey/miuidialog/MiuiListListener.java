package top.yokey.miuidialog;

@SuppressWarnings("ALL")
public interface MiuiListListener {

    void onClick(int position, String content);

}
