package top.yokey.miuidialog;

@SuppressWarnings("ALL")
public interface MiuiInputListener {

    void onClick(String content);

}
