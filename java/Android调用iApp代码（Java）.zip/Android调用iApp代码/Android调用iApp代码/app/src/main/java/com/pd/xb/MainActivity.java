package com.pd.xb;

import android.app.*;
import android.os.*;
import com.iapp.app.Aid_javaCode;
import com.iapp.app.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Aid_javaCode iapp=new Aid_javaCode(this);
		iapp.tw("调用iApp示例");
		iapp.utw(null,"弹窗标题","弹窗内容",false);
		iapp.hws("http://baidu.com");
		iapp.ftz("nm","sl","gb","null","null");
		iapp.usms("10086","123");
    }
}
