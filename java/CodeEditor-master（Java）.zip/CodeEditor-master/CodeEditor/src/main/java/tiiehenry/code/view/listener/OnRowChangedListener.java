package tiiehenry.code.view.listener;

public interface OnRowChangedListener {
	public void onRowChanged(int newRowIndex);
}
