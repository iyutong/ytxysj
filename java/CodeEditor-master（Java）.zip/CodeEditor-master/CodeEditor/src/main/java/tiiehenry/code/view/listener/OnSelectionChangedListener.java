package tiiehenry.code.view.listener;

public interface OnSelectionChangedListener
{
	 void onSelectionChanged(boolean active,int selStart, int selEnd);
}
