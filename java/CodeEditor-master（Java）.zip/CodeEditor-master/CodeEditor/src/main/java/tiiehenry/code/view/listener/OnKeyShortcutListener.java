package tiiehenry.code.view.listener;
import android.view.*;

public interface OnKeyShortcutListener
{
	boolean onKeyShortcut(int keyCode,KeyEvent event);
}
