package com.example.canvas;

import android.app.*;
import android.os.*;
import android.view.MotionEvent;
import android.view.Window;
import android.widget.SeekBar;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final TextView text=findViewById(R.id.mainTextView);
	final MySurfaceView m=    new MySurfaceView(this);
		SeekBar s=findViewById(R.id.mainSeekBar);
	s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
			@Override
			public void onProgressChanged(SeekBar p1, int p2, boolean p3)
			{
				
		int i=	p1.getProgress();
		text.setText("比例:"+i+"    100时进入输入界面");
		m.destroyDrawingCache();
Constant.RATE=i;
if(i==100){
	Intent f=new Intent(MainActivity.this,ControlActivity.class);
	startActivity(f);
	finish();
}
			}

			@Override
			public void onStartTrackingTouch(SeekBar p1)
			{
			// TODO: Implement this method
			
			}

			@Override
			public void onStopTrackingTouch(SeekBar p1)
			{
			// TODO: Implement this method
			}
		});
    }

}
