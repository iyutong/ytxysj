package com.example.canvas;
import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class ControlActivity extends Activity
{
	EditText A,B,C;
  Button bt_get;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	setContentView(R.layout.control);
	A=findViewById(R.id.controlEditTexta);
	B=findViewById(R.id.controlEditTextb);
	C=findViewById(R.id.controlEditTextc);
	bt_get=findViewById(R.id.controlButton);
	bt_get.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View p1)
			{
	String    a=	A.getText().toString();
		String b=B.getText().toString();
		String c=C.getText().toString();
	  float A=Float.parseFloat(a);
		float B=Float.parseFloat(b);
		float C=Float.parseFloat(c);
		Constant.A=A;
		Constant.B=B;
		Constant.C=C;
		Intent intent=new Intent(ControlActivity.this,MainActivity.class);
		startActivity(intent);
		finish();
			}
		});
	}

}
