package com.example.canvas;

public class DrawThread1 extends Thread
{
}
