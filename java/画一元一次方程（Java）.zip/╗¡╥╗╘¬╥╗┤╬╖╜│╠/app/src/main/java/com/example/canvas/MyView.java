package com.example.canvas;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.MotionEvent;

public class MyView extends View
{
Context context;

	MyView(Context context){
		super(context);
		this.context=context;
	}

	@Override
	protected void onDraw(Canvas canvas){
		int x=Constant.getScreenWidth(context);
		int h=Constant.getStateBar(context);
	int y=Constant.getScreenHeight(context)-h;
	super.onDraw(canvas);
Paint paint=new Paint();
paint.setColor(Color.RED);
paint.setAntiAlias(true);
canvas.drawLine(0,y/2, x ,y/2,    paint);
canvas.drawLine(x/2,0,x/2,y,paint);
canvas.drawPoint(270,496-h,paint);

}
}
