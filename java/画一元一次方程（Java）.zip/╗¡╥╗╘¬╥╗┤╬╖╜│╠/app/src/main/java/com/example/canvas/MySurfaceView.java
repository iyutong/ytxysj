package com.example.canvas;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView implements
SurfaceHolder.Callback
{

    DrawThread mThread = null;
 Context context;
    public MySurfaceView(Context context, AttributeSet attrs, int defStyle)
    {
	super(context, attrs, defStyle);
	this.context=context;
	init();
	
    }

    public MySurfaceView(Context context, AttributeSet attrs)
    {
	super(context, attrs);
	this.context=context;
	init();
    }
    public MySurfaceView(Context context)
    {
	super(context);
	this.context=context;
	
	init();
    }

    private void init()
    {
	  SurfaceHolder holder = getHolder();
	holder.addCallback(this);

	mThread = new DrawThread(holder,context);

    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh)
    {
	
	super.onSizeChanged(w, h, oldw, oldh);

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {

	mThread.setRun(true);
	mThread.start();

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
							   int height)
    {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {

	mThread.setRun(false);

    }

    /**
     * 绘制线程类
     * 
     */


}

