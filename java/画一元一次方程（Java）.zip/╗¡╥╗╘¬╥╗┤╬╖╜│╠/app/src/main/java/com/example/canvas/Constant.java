package com.example.canvas;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

public class Constant
{
	public static  float A=1,B=1,C=-5;
public static int RATE=10;
	public static int getScreenWidth(Context context) {
	WindowManager manager = (WindowManager) context
		.getSystemService(Context.WINDOW_SERVICE);
	Display display = manager.getDefaultDisplay();
	return display.getWidth();
	}
	//获取屏幕的高度
	public static int getScreenHeight(Context context) {
	WindowManager manager = (WindowManager) context
		.getSystemService(Context.WINDOW_SERVICE);
	Display display = manager.getDefaultDisplay();
	return display.getHeight();
	}
	public static int getStateBar(Context context){
	int result = 0;
	int resourceId =context.getResources().getIdentifier("status_bar_height", "dimen", "android");
	if (resourceId > 0) {
	result = context.getResources().getDimensionPixelSize(resourceId);
	
	}

	return result;
    }
	
}
