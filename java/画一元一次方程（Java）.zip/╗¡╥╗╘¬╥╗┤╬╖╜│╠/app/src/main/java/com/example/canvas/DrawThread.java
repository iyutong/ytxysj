package com.example.canvas;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.SurfaceHolder;
import android.content.Context;

public class DrawThread extends Thread
{

	Context context=null;
	int width=0;
	int height=0;
     float x0=0;
	float  y0=0;
	private SurfaceHolder mHolder = null;
	private boolean isRun = false;

	public DrawThread(SurfaceHolder holder ,Context context)
	{
this.context=context;
	mHolder = holder;
	width=Constant.getScreenWidth(context);
	height=Constant.getScreenHeight(context);
	y0=height/2;
	x0=width/2;
	
	}

	DrawThread(){
		
	}
	public void setRun(boolean isRun)
	{
	
	this.isRun = isRun;
	}

	@Override
	public void run()
	{
	while (isRun)
	{
	Canvas canvas = null;
	synchronized (mHolder)
	{
	try
	{

	canvas = mHolder.lockCanvas();
	canvas.drawColor(Color.WHITE);
	Paint p = new Paint();
	p.setColor(Color.BLACK);
canvas.drawLine(0,height/2,width,height/2,p);
canvas.drawLine(width/2,0,width/2,height,p);
float x=-100;
p.setColor(Color.BLUE);
// ax+by+c=0
canvas.drawLine(x0+1*Constant.RATE,0,x0+1*Constant.RATE,y0+height/2,p);
canvas.drawLine(x0-width/2,y0-1*Constant.RATE,x0+width/2,y0-1*Constant.RATE,p);
	float a=x0+1*Constant.RATE+5;
	float b=y0-1*Constant.RATE-5;
	float c=(-Constant.C/Constant.B);
	float d=(-Constant.C/Constant.A);
	p.setColor(Color.BLACK);
	int r=(int) (x0+d*Constant.RATE);
	int m=(int) (y0-c*Constant.RATE);
	canvas.drawText("("+1+","+1+")",a,b,p);
	
	//y (0,y0-(-c/b);
	canvas.drawText("("+d+","+0+")",r,y0-15,p);
	canvas.drawText("("+0+","+c+")",x0+15,m,p);
p.setColor(Color.RED);
for(int i=0;i<=20000;i++){
//y=x+6
	//by=-ax-c   y=(-ax-c)/b  x=
x=x+0.01f;
	canvas.drawPoint(x0+(x*Constant.RATE),y0-(((-Constant.A*x-Constant.C))*Constant.RATE/Constant.B),p);
}

	}
	catch (Exception e)
	{
	
	e.printStackTrace();

	}
	finally
	{
	if (null != canvas)
	{
	mHolder.unlockCanvasAndPost(canvas);
	}
	}

	}

	}
	}

}
