package com.xiaoheng.gengxin;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import java.util.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button button=(Button)findViewById(R.id.mainButton);
		final TextView textview=(TextView)findViewById(R.id.mainTextView);
		final TextView textview1=(TextView)findViewById(R.id.mainTextView1);
		
		Bmob.initialize(this,"06b33db5123a830db41d3095599eba0d");//Application ID
		
		BmobQuery<gengxin>zhidingy=new BmobQuery<gengxin>();
		zhidingy.findObjects(getApplication(), new FindListener<gengxin>(){

				@Override
				public void onSuccess(List<gengxin> p1)
				{
					for(gengxin xiaoheng:p1){
					//设置公告内容
					String aa=xiaoheng.getgonggao();
					textview1.setText(aa);
				}}
				@Override
				public void onError(int p1, String p2){textview1.setText("获取失败,请检查网络");}});
		
				
				
				
		button.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					
					
					BmobQuery<gengxin>zhidingy=new BmobQuery<gengxin>();
					zhidingy.findObjects(getApplication(), new FindListener<gengxin>(){
							//按钮的点击事件
							@Override
							public void onSuccess(List<gengxin> p1)
							{
								//正常
								for(gengxin xiaoheng:p1)
								{
									//设置更新内容
									String gx=xiaoheng.getxh();
									textview.setText(gx);
									//判断获取到的数据
									if(gx.equals("开"))
									{
										//判断到开执行这里
										final String lj=xiaoheng.getlj();
										String tcnr=xiaoheng.gettc();
										AlertDialog.Builder ab=new AlertDialog.Builder(MainActivity.this);
										//ab.setIcon(R.drawable.ic_launcher);//图标
										ab.setCancelable(false);//点击界面其他地方弹窗不会消失
										ab.setTitle("发现新版本");//标题
										ab.setMessage(tcnr);//弹窗内容
										ab.setPositiveButton("前往更新", new DialogInterface.OnClickListener()
										{
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(lj)));
													finish();
										}});
										ab.setNegativeButton("退出",new DialogInterface.OnClickListener(){
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													finish();
												}
											});
											ab.show();
										Toast.makeText(MainActivity.this,"有可更新",Toast.LENGTH_LONG).show();
										
									}
									else if(gx.equals("关"))
									{
										//判断到关执行这里
										Toast.makeText(MainActivity.this,"没有可更新",Toast.LENGTH_LONG).show();
									}
								}
							}
							@Override
							public void onError(int p1, String p2)
							{
								//异常
								//无网络或其他情况执行这里
								Toast.makeText(MainActivity.this,"获取数据失败\n请检查设备是否联网",Toast.LENGTH_LONG).show();
							}
						});
				}});
				
				
				
    }
}
/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/