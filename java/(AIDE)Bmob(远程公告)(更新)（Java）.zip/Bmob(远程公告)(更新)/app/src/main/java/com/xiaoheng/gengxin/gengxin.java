package com.xiaoheng.gengxin;
import cn.bmob.v3.*;

public class gengxin extends BmobObject
{
	private String gx;//后台截取gx(更新字符)
	public String getxh(){return gx;}
	public void setxh(String gx){this.gx=gx;}
	
	private String gonggao;//后台截取gongg(公告)
	public String getgonggao(){return gonggao;}
	public void setgonggao(String gonggao){this.gonggao=gonggao;}
	
	private String lj;//后台截取lj(更新链接)
	public String getlj(){return lj;}
	public void setlj(String lj){this.lj=lj;}
	
	private String tc;//后台截取tc(弹窗内容)
	public String gettc(){return tc;}
	public void settc(String tc){this.tc=tc;}
}
