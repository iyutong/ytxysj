package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import java.io.*;
import android.provider.*;
import android.widget.*;

public class MainActivity extends Activity 
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		choosePicture();
		
    }
	private void choosePicture(){
		
		Intent it = new Intent(Intent.ACTION_PICK);
		//设置格式
		it.setType("image/*");
		startActivityForResult(it, 1000);
	}
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		//得到相册里的图片进行裁剪
		if(requestCode == 1000 && resultCode == RESULT_OK){
			//得到相册图片
			
			
			
			String aa = RealPathFromUriUtils.getRealPathFromUri(this, data.getData());
			
			
			TextView a=(TextView)findViewById(R.id.r);
			a.setText(aa);
			}
			}
			
			
			
			
}
