package com.bmobrjgx;

import android.app.*;
import android.os.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import cn.bmob.v3.update.*;
import com.bmobrjgx.*;

public class MainActivity extends Activity 
{
	UpdateResponse ur;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Bmob.initialize(this,"7b5fbce7bf8dec16d6d8c83410407e58");
		//BmobUpdateAgent.initAppVersion(this);
		BmobUpdateAgent.update(this);
		BmobUpdateAgent.setUpdateOnlyWifi(false);
		BmobUpdateAgent.setUpdateListener(new BmobUpdateListener() {

				@Override
				public void onUpdateReturned(int updateStatus, UpdateResponse updateInfo) {
					// TODO Auto-generated method stub
					//根据updateStatus来判断更新是否成功
					if (updateStatus == UpdateStatus.Yes) {
						ur = updateInfo;
					}else if(updateStatus==UpdateStatus.IGNORED){//新增忽略版本更新
						Toast.makeText(MainActivity.this, "该版本已经被忽略更新", Toast.LENGTH_SHORT).show();
					}
				}
	
			
			});
    }
}
