/** Automatically generated file. DO NOT MODIFY */
package com.lxb.window;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}