package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import java.util.*;
import android.support.v4.view.*;
import android.view.*;
import java.security.acl.*;
import android.widget.*;
//转载请著明出处
//欢迎加入IAPP专修技术群，这里有更多的事例源码，群聊号码：596834623
public class MainActivity extends Activity 
{

	private ViewPager vp;
	 private    List<View> lis;
	private Thread th;
	private boolean bl=false;
	private myViewPager pager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		vp=(ViewPager)findViewById(R.id.view_pager);
		View itemView1;
		View itemView2;
		View itemView3;
		lis=new ArrayList<View>();
		LayoutInflater loy=getLayoutInflater();
		itemView1=loy.inflate(R.layout.item1,null);
		itemView2=loy.inflate(R.layout.item2,null);
		itemView3=loy.inflate(R.layout.item3,null);
		lis.add(itemView1);
		lis.add(itemView2);
		lis.add(itemView3);
		vp.setPageTransformer(true,new ScrollOffsetTransformer());
		vp.setOffscreenPageLimit(3);
		vp.setPageMargin(1);
//vp.setCurrentItem(1);
		 pager= new myViewPager();
		vp.setOnPageChangeListener(new ViewPager.OnPageChangeListener(){

				@Override
				public void onPageScrolled(int p1, float p2, int p3)
				{
					// TODO: Implement this method
				}

				@Override
				public void onPageSelected(int p1)
				{
					// TODO: Implement this method
				}

				@Override
				public void onPageScrollStateChanged(int p1)
				{
					// TODO: Implement this method
				}
			});
		th = new Thread(new Runnable(){

				@Override
				public void run()
				{
					bl=true;
					while(bl)
					{
						// startPoin= vp.getCurrentItem();
						try
						{
							Thread.sleep(3000);
						}
						catch (InterruptedException e)
						{}
						//han=new Handler();
						runOnUiThread(new Runnable(){

								@Override
								public void run()
								{
									TextView te=(TextView)findViewById(R.id.mainTextView1);
									//te.setText("哈哈还白");
									//Toast.makeText(MainActivity.this,"好好",Toast.LENGTH_SHORT).show();
									int size= pager. getCount();
									if(vp.getCurrentItem()!=size-1)
									{
										
										//int yushu=size%vp.getCurrentItem();
										//Toast.makeText(MainActivity.this,String.valueOf( size),Toast.LENGTH_SHORT).show();
									vp.setCurrentItem(vp.getCurrentItem()+1);
									}
									else
									{
										vp.setCurrentItem(0);
									}
									// TODO: Implement this method
								}
							});
					}
					// TODO: Implement this method
				}
			});
		th.start();
		vp.setAdapter(pager);
    }
	public class ScrollOffsetTransformer implements ViewPager. PageTransformer {
		private static final float MIN_SCALE = 0.85F;
		/**
		 * position参数指明给定页面相对于屏幕中心的位置。它是一个动态属性，会随着页面的滚动而改变。
		 * 当一个页面（page)填充整个屏幕时，positoin值为0； 当一个页面（page)刚刚离开屏幕右(左）侧时，position值为1（-1）；
		 * 当两个页面分别滚动到一半时，其中一个页面是-0.5，另一个页面是0.5。
		 * 基于屏幕上页面的位置，通过诸如setAlpha()、setTranslationX
		 * ()或setScaleY()方法来设置页面的属性，创建自定义的滑动动画。
		 */
		
		public void transformPage(View view, float position) {
			// TODO Auto-generated method stub
			float scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position));
			float rotate = 30 * Math.abs(position);
			float transla = 50 * Math.abs(position);
			if (position > 0) {
				view.setScaleX(scaleFactor);
				view.setScaleY(scaleFactor);
				view.setRotationY(-rotate);
				view.setTranslationX(-transla);
			} else {
				view.setScaleX(scaleFactor);
				view.setScaleY(scaleFactor);
				view.setRotationY(rotate);
				view.setTranslationX(transla);
			}
		}
	}
	class myViewPager extends PagerAdapter
	{
		@Override
		public int getCount()
		{
		  return lis.size();
		}

		@Override
		public boolean isViewFromObject(View p1, Object p2)
		{
			// TODO: Implement this method
			return p1==p2;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position)
		{
			
			container.addView(lis.get(position));
			// TODO: Implement this method
			return lis.get(position);
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object)
		{
			
			container.removeView(lis.get(position));
			// TODO: Implement this method
		}
		
	}
}
