package com.szy.dialog;

import com.szy.R;
import com.szy.fileUtils.FileUtils;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/**
 *创建文件夹
 * @author Administrator
 *
 */
public class CreateDirDialog extends Dialog {
	private Context context;
	private EditText dirname;
	private Button dirsub;
	private Button dialogcancel;
	private View view;
	private String url;	//文件夹的路径
	private FileUtils fileutils;
	public CreateDirDialog(Context context,String url) {
		super(context);
		this.context=context;
		this.url=url;		
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		fileutils=new FileUtils();
		LayoutInflater inflater=LayoutInflater.from(context);
		view=inflater.inflate(R.layout.createdir, null);
		findview();
		setListener();
		this.setContentView(view);
	}
	private void findview(){
		dirname=(EditText)view.findViewById(R.id.dirname);
		dirsub=(Button)view.findViewById(R.id.dirsub);
		dialogcancel=(Button)view.findViewById(R.id.cancel);
	}
	private void setListener(){
		dirsub.setOnClickListener(new SubClickListener());;
		dialogcancel.setOnClickListener(new CancelListener());
	}
	/**
	 * 提交
	 * @author Administrator
	 *
	 */
	class SubClickListener implements View.OnClickListener{

		@Override
		public void onClick(View arg0) {
			String name=dirname.getText().toString().trim();
			if (name.length()<1) {
				Toast.makeText(context, "文件夹名称不能为空", 3000).show();
				return ;
			}else{
				if(fileutils.isFileExits(url+"/"+name)){
					Toast.makeText(context, "此文件已存在！", 3000).show();
					return ;
				}else{
					if (fileutils.creatSDDir(url+"/"+name)) {
						Toast.makeText(context, "文件夹创建成功！", 3000).show();
						CreateDirDialog.this.dismiss();
						return;
					}else{
						Toast.makeText(context, "文件夹创建失败！", 3000).show();
						return;
					}
				}
			}
		}
		
	}
	/**
	 *取消
	 */
	class CancelListener implements View.OnClickListener{

		@Override
		public void onClick(View arg0) {
			CreateDirDialog.this.dismiss();
			
		}		
	}
	
}
