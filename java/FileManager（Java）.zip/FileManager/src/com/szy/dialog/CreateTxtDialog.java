package com.szy.dialog;

import com.szy.MainActivity;
import com.szy.R;
import com.szy.fileUtils.FileUtils;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateTxtDialog extends Dialog {

	private Context context;
	private View view;
	private String url;	//文件夹的路径
	private FileUtils fileutils;
	private EditText createTxtName;
	private EditText createTxtContent;
	private Button createTxtsub;
	private Button cancel;
	public CreateTxtDialog(Context context,String url) {
		super(context);	
		this.context=context;
		this.url=url;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		fileutils=new FileUtils();
		LayoutInflater inflater=LayoutInflater.from(context);
		view=inflater.inflate(R.layout.createtxt, null);
		findView();
		this.setContentView(view);
	}
	private void findView(){
		createTxtName=(EditText)view.findViewById(R.id.txtname);
		createTxtContent=(EditText)view.findViewById(R.id.txtcontent);
		createTxtsub=(Button)view.findViewById(R.id.createtxtsub);				
		createTxtsub.setOnClickListener(new CreateTxtListener());
		cancel=(Button)view.findViewById(R.id.cancel);
		cancel.setOnClickListener(new CancelClickListener());
	}
	/**
	 * 新建 文本的确定事件
	 * @author Administrator
	 *
	 */
	class CreateTxtListener implements Button.OnClickListener{
		@Override
		public void onClick(View arg0) {
			String name=createTxtName.getText().toString().trim();
			if (name.length()<1) {
				Toast.makeText(context, "请输入文件名", 3000).show();
				return;
			}
			String txtcontent=createTxtContent.getText().toString().trim();
			if(txtcontent.length()<1){
				Toast.makeText(context, "请输入文件内容", 3000).show();
				return;
			}
			if(fileutils.isFileExits(url+"/"+name+".txt")==false){							
				if (fileutils.writeToSDCardFromInput(url+"/"+name+".txt", txtcontent)) {
					Toast.makeText(context, "文件保存成功", 3000).show();
					CreateTxtDialog.this.dismiss();
					
				}else{
					Toast.makeText(context, "文件保存失败", 3000).show();
					return;
				}
			}else{
				Toast.makeText(context,"文件已经存在",3000).show();
			}
		}
	}
	
	/**
	 *取消
	 */
	class CancelClickListener implements View.OnClickListener{
		@Override
		public void onClick(View v) {
			CreateTxtDialog.this.dismiss();
			
		}
	}
	
}

