package com.szy;

import java.io.File;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

import com.szy.adpter.Myadapter;
import com.szy.dialog.CreateDirDialog;
import com.szy.dialog.CreateTxtDialog;
import com.szy.fileUtils.FileUtils;
import com.szy.fileUtils.OpenFileUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	/** Called when the activity is first created. */
	private static final String sdCard = Environment
			.getExternalStorageDirectory().getAbsolutePath();
	private String url = "";// 内部路径
	private EditText path; // 输入框的路径
	private ImageView btnOk; // 确定
	private ImageView btnback; // 返回
	private TextView createFolder; // 新建文件
	private TextView search; // 搜索
	private TextView selectfile; // 选择
	private TextView fuzi; // 复制
	private TextView copy; // 粘贴
	private TextView delete; // 删除
	private TextView cancel;// 取消

	private ImageView fview; // 显示列表方式
	private int isView = 0; // 0为九宫格显示，1为列表显示
	private GridView gridview;
	private FileUtils fileutils = new FileUtils();
	private ScrollView scroll;
	private File[] files = null;

	private int selectIndex; // 选中的列表索引
	private List<String> selectFiles; // 选中的文件路径
	private int selectType = 0; // 选择的模式 0为正常模式，1为选择模式

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // 去标题
		setContentView(R.layout.filemain);
		selectFiles = new ArrayList<String>();
		// System.out.println(sdCard);
		findView();
		setListener();
		initData(sdCard);
		gridview.setOnItemLongClickListener(new GridViewLongClickListener());
	}

	/**
	 * 初始化控件
	 */
	private void findView() {
		path = (EditText) this.findViewById(R.id.path);
		btnOk = (ImageView) this.findViewById(R.id.btnOk);
		btnback = (ImageView) this.findViewById(R.id.btnback);
		createFolder = (TextView) this.findViewById(R.id.createFolder);
		search = (TextView) this.findViewById(R.id.search);
		selectfile = (TextView) this.findViewById(R.id.select);
		fuzi = (TextView) this.findViewById(R.id.fuzi);
		copy = (TextView) this.findViewById(R.id.copy);
		delete = (TextView) this.findViewById(R.id.delete);
		cancel = (TextView) this.findViewById(R.id.cancel);

		fview = (ImageView) this.findViewById(R.id.fileview);
		gridview = (GridView) this.findViewById(R.id.gridView1);
		gridview.setOnItemClickListener(new FileItemOnClickListener());
		path.setText(sdCard);
		url = sdCard;
		// scroll=(ScrollView)this.findViewById(R.id.scrollView1);
	}

	/**
	 * 绑定事件
	 */
	private void setListener() {
		btnOk.setOnClickListener(new BtnOkOnClickListener()); // 确定按钮
		fview.setOnClickListener(new FviewOnClickListener()); // 显示列表方式
		btnback.setOnClickListener(new BtnbackOnClickListener()); // 返回
		createFolder.setOnClickListener(new FolderOnClickListener()); // 新建
		search.setOnClickListener(new SearchOnclickListener()); // 搜索
		selectfile.setOnClickListener(new SelectOnClickListener());// 选择
		cancel.setOnClickListener(new SelectOnClickListener()); // 取消
		copy.setOnClickListener(new MenuOnClickListener());	//粘贴
		fuzi.setOnClickListener(new MenuOnClickListener());	//复制
		delete.setOnClickListener(new MenuOnClickListener());	//删除
	}
	/**
	 * 选择的监听
	 * 
	 * @author Administrator
	 * 
	 */
	class SelectOnClickListener implements OnClickListener {
		/**
		 * android view setVisibility(): 有三个参数：Parameters:visibility One of
		 * VISIBLE, INVISIBLE, or GONE，想对应的三个常量值：0、4、8 VISIBLE:0 意思是可见的
		 * INVISIBILITY:4 意思是不可见的，但还占着原来的空间 GONE:8 意思是不可见的，不占用原来的布局空间
		 */
		@Override
		public void onClick(View v) {
			if (v.getId() == R.id.select) {
				// 如果是点的选择
				selectType = 1;
				fuzi.setVisibility(0);
				copy.setVisibility(0);
				delete.setVisibility(0);
				cancel.setVisibility(0);

				selectfile.setVisibility(8);
				createFolder.setVisibility(8);
				search.setVisibility(8);

			} else {
				// 如果是点的取消
				selectType = 0;
				fuzi.setVisibility(8);
				copy.setVisibility(8);
				delete.setVisibility(8);
				cancel.setVisibility(8);

				selectfile.setVisibility(0);
				createFolder.setVisibility(0);
				search.setVisibility(0);
				selectFiles.clear();	//清除一下
				initData(url);
			}
		}

	}

	/**
	 * 粘贴、复制、删除监听
	 * @author Administrator
	 *
	 */
	class MenuOnClickListener implements OnClickListener{
		@Override
		public void onClick(View v) {
			if (v.getId()==R.id.copy) {	//粘贴
				copyFile();	
			}else if(v.getId()==R.id.fuzi){
				//复制
				if (selectFiles.size()==0) {
					Toast.makeText(MainActivity.this, "请选择文件", 3000).show();
				}				
				Toast.makeText(MainActivity.this, "已复制到粘贴板上了！", 3000).show();
			}else if(v.getId()==R.id.delete){
				//删除
				deleteFile();
			}					
		}		
	}
	
	/**
	 * 搜索
	 * 
	 * @author Administrator
	 * 
	 */
	class SearchOnclickListener implements OnClickListener {

		@Override
		public void onClick(View arg0) {
			AlertDialog.Builder builder = new Builder(MainActivity.this);
			builder.setTitle("搜索");
			builder.setMessage("请输入搜索关键字：");
			final EditText searchcontent = new EditText(MainActivity.this);
			searchcontent.setWidth(250);
			builder.setView(searchcontent);
			builder.setPositiveButton("搜索",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							String search = searchcontent.getText().toString()
									.trim();
							searchFile(search);
						}
					});
			builder.create().show();

		}

	}

	/**
	 * 搜索文件
	 * 
	 * @param name
	 */
	private void searchFile(String name) {
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < files.length; i++) {
			File file = files[i];
			String filename = file.getName().toLowerCase(); // 全转成小写

			String reg = "^[\u4e00-\u9fa5_a-zA-Z0-9]+" + name.toLowerCase()
					+ "[\u4e00-\u9fa5_a-zA-Z0-9]+$"; // 匹配中文，英文字母和数字及_:
			if (filename.startsWith(name.toLowerCase())) {
				// 如果成匹配
				list.add(file.getAbsolutePath());
			}
		}
		File[] newfile = new File[list.size()];
		for (int i = 0; i < list.size(); i++) {
			newfile[i] = new File(list.get(i));
		}
		files = newfile;
		// 重新绑定数据
		gridview.setAdapter(new Myadapter(this, files, isView));

	}

	/**
	 * 新建事件
	 * 
	 * @author Administrator
	 * 
	 */
	class FolderOnClickListener implements OnClickListener {
		public void onClick(View arg0) {
			new Builder(MainActivity.this)
					.setTitle("新建 ")
					.setItems(new String[] { "新建 文件夹", "新建文本文件" },
							new FolderDiglogListener()).create().show();

		}
	}

	/**
	 * 新建 事件的对话框监听
	 * 
	 * @author Administrator
	 * 
	 */
	class FolderDiglogListener implements DialogInterface.OnClickListener {
		AlertDialog.Builder build = new Builder(MainActivity.this);

		@Override
		public void onClick(DialogInterface arg0, int position) {

			switch (position) {
			case 0:
				CreateDirDialog dirdialog = new CreateDirDialog(
						MainActivity.this, url);
				dirdialog.setTitle("新建文件夹");
				dirdialog.show();
				break;
			case 1:

				CreateTxtDialog txtDialog = new CreateTxtDialog(
						MainActivity.this, url);
				txtDialog.setTitle("新建文件");
				txtDialog.show();

				break;
			default:
				break;
			}
			initData(url); // 更新一下数据
		}
	}

	/**
	 * 返回监听
	 * 
	 * @author Administrator
	 * 
	 */
	class BtnbackOnClickListener implements OnClickListener {
		@Override
		public void onClick(View arg0) {
			if (url.equals("/")) {
				Toast.makeText(MainActivity.this, "已经是根目录了", 3000).show();
				return;
			}
			String path2 = url.substring(0, url.lastIndexOf("/"));
			if (path2.equals("")) {
				path2 = "/";
			}
			url = path2;
			initData(url); // 重新加载一次
		}

	}

	/**
	 * 切换列表显示方式
	 * 
	 * @author Administrator
	 * 
	 */
	class FviewOnClickListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			if (isView == 0) {
				// 切换到列表
				isView = 1;
				fview.setImageResource(R.drawable.flist);
				gridview.setNumColumns(1);
			} else {
				// 切换到九宫图
				isView = 0;
				fview.setImageResource(R.drawable.fview);
				gridview.setNumColumns(3);
			}
			initData(url); // 重新加载一次
		}

	}

	/**
	 * 查询所有目录下的所有文件夹和文件
	 */
	public void initData(String findurl) {
		File file = new File(findurl);
		files = file.listFiles(); // 得到文件列表集合
		if (files == null) {
			files = new File[0];
			Toast.makeText(this, "该目录下没有文件了", 3000).show();
		}
		path.setText(findurl);
		gridview.setAdapter(new Myadapter(this, files, isView));
	}

	/**
	 * 确定监听
	 * 
	 * @author Administrator
	 * 
	 */
	class BtnOkOnClickListener implements OnClickListener {

		@Override
		public void onClick(View v) {
			String str = path.getText().toString().trim(); // 得到输入的框的内容
			if (str.equals("")) {
				Toast.makeText(MainActivity.this, "地址不能为空", 3000).show();
				return;
			}
			boolean isfind = fileutils.isFileExits(str); // 查看文件是否找到
			if (isfind) {
				// 如果找到调用查询
				initData(str);
			} else {
				// 如果找不到
				Toast.makeText(MainActivity.this, "找不到文件", 3000).show();
			}
		}
	}

	/**
	 * 列表单击事件
	 * 
	 * @author Administrator
	 * 
	 */
	class FileItemOnClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			if (selectType==1) {
				TextView textview=null;
				if (isView==0) {
					//九宫模式
					textview=(TextView)arg1.findViewById(R.id.viewname);
				}else{
					//列表模式
					textview=(TextView)arg1.findViewById(R.id.listname);
				}
				//选择模式时
				boolean flag=false;
				int index=0;
				
				for (int i = 0; i < selectFiles.size(); i++) {
					if (selectFiles.get(i).equals(files[position].getAbsolutePath())) {
						flag=true;	//找到此文件
						index=i;
						break;
					}
				}
				if(flag==false){
					//没有找到，就添加 进来
					selectFiles.add(files[position].getAbsolutePath().toString());
					textview.setTextColor(android.graphics.Color.RED);
				}else{
					//找到了，表示以前添加过了，这次就取消
					selectFiles.remove(index);
					textview.setTextColor(android.graphics.Color.BLACK);
				}			
				return;
			}
			String absurl = files[position].getAbsolutePath();
			if (files[position].isDirectory()) {
				// 如果是文件夹
				url = absurl;
				initData(url);
			} else {
				Intent intent = OpenFileUtils.openFile(absurl);
				MainActivity.this.startActivity(intent);
			}
		}
	}

	/**
	 * 自适应 高度
	 * 
	 * @param listview
	 */
	private void autoheight(ListView listview) {
		ListAdapter adapter = listview.getAdapter();
		int count = adapter.getCount(); // 总行数
		int total = 0; // 总高度
		for (int i = 0; i < count; i++) {
			View view = adapter.getView(i, null, listview);
			// 测试Viewr高宽
			view.measure(View.MeasureSpec.UNSPECIFIED,
					View.MeasureSpec.UNSPECIFIED);
			total += view.getMeasuredHeight();
		}
		total += listview.getDividerHeight() * (count - 1); // 分隔线的高度
		LayoutParams params = listview.getLayoutParams();
		params.height = total;
		listview.setLayoutParams(params);
	}

	/**
	 * 列表长按事件
	 * 
	 * @author Administrator
	 * 
	 */
	class GridViewLongClickListener implements OnItemLongClickListener {

		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
				int position, long arg3) {
			if (selectType==1) {
				//选择模式时
				return false;
			}
			AlertDialog.Builder builder = new Builder(MainActivity.this);
			selectIndex = position;
			builder.setTitle("文件操作");
			builder.setItems(new String[] { "复制", "粘贴", "查看详情", "删除", },
					new DiaglogClick());
			builder.create().show();
			return false;
		}
	}

	/**
	 * 列表长按事件对话框监听
	 * @author Administrator
	 *
	 */
	class DiaglogClick implements DialogInterface.OnClickListener {
		@Override
		public void onClick(DialogInterface arg0, int position) {

			switch (position) {
			case 0:
				// 复制
				selectFiles.clear(); // 清空一下
				selectFiles.add(files[selectIndex].getAbsolutePath());
				break;
			case 1:
				// 粘贴
				copyFile();
				break;
			case 2:
				// 详情
				File select = files[selectIndex];
				AlertDialog.Builder builder = new Builder(MainActivity.this);
				builder.setTitle("文件详情");
				builder.setMessage("文件名：" + select.getName() + "\n文件大小："
						+ fileutils.getIntToString(select.length()) + "\n路径："
						+ select.getAbsolutePath() + "\n");
				builder.setPositiveButton("确定", null);
				builder.create().show();
				break;
			case 3:
				// 删除
				selectFiles.clear(); // 清空一下
				selectFiles.add(files[selectIndex].getAbsolutePath());
				deleteFile();
				break;
			default:
				break;
			}
		}

	}

	/**
	 * 复制文件
	 */
	private void copyFile() {
		if (selectFiles.size() == 0) {
			Toast.makeText(this, "请选择文件！", 3000).show();
			return;
		}
		for (int i = 0; i < selectFiles.size(); i++) {
			int flag = fileutils.copy(selectFiles.get(i), url);
			String name = selectFiles.get(i).substring(
					selectFiles.get(i).lastIndexOf("/") + 1);
			if (flag == 2) {
				// 复制失败时停止
				Toast.makeText(this, "文件     " + name + "  复制失败", 3000).show();
				return;
			} else if (flag == 1) {
				// 文件已经存在时
				Toast.makeText(this, "文件     " + name + "  已经在在", 3000).show();
				continue;
			}
		}
		selectFiles.clear(); // 粘贴完后清空
		initData(url);// 重新加载数据
	}

	/**
	 * 删除文件
	 */
	private void deleteFile() {
		if (selectFiles.size() == 0) {
			Toast.makeText(MainActivity.this, "请选择文件！", 3000).show();
			return;
		}
		for (int i = 0; i < selectFiles.size(); i++) {
			int flag = fileutils.deleteFile(selectFiles.get(i));
			if (flag == 2) {
				Toast.makeText(this, "文件删除失败！", 3000).show();
				// 停止
				return;
			}
			// 其它情况默认继续
		}

		selectFiles.clear(); // 清空
		initData(url);
	}

	/**
	 * ------->>>>>>>>>菜单
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		menu.clear();
		menu.add(0, 1, 1, "退出");
		menu.add(0, 2, 2, "关于");
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case 1:
			System.out.println(1);
			break;
		case 2:
			Toast.makeText(this, "超级文件管理", 3000).show();
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

}