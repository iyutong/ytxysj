package com.szy.adpter;

import java.io.File;

import org.w3c.dom.Text;

import com.szy.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Myadapter extends BaseAdapter {
	private Context context;
	private File[] files;
	private int isView=0;		//显示方式
	
	public Myadapter(Context context, File[] files, int isView) {
		super();
		this.context = context;
		this.files = files;
		this.isView = isView;
	}

	@Override
	public int getCount() {
		
		return files.length;
	}

	@Override
	public Object getItem(int postion) {		
		return files[postion];
	}

	@Override
	public long getItemId(int postion) {
		// TODO Auto-generated method stub
		return postion;
	}

	@Override
	public View getView(int postion, View arg1, ViewGroup arg2) {
		/*if (files.length<1) {
			TextView text=new TextView(context);
			text.setText("记目录下没有文件");
			return text;
		}*/
		File file=files[postion];
		LayoutInflater inflater=LayoutInflater.from(context);
		View view=null;
		if (isView==0) {
			//如果是九宫图
			view=inflater.inflate(R.layout.fview, null);
			ImageView image=(ImageView)view.findViewById(R.id.fviewImage);
			image.setAdjustViewBounds(true);
			if (file.isDirectory()) {
				//如果是文件夹
				image.setImageResource(R.drawable.folderbig);
			}else{
				image.setImageResource(R.drawable.filebig);
			}			
			TextView name=(TextView)view.findViewById(R.id.viewname);
			name.setText(file.getName());
		}else {
			//如果是列表
			view=inflater.inflate(R.layout.flist, null);
			ImageView image=(ImageView)view.findViewById(R.id.listimage);
			image.setAdjustViewBounds(true);
			if (file.isDirectory()) {
				//如果是文件夹就用文件夹的图标
				image.setImageResource(R.drawable.foldersmall);
			}else{
				image.setImageResource(R.drawable.filesmall);
			}			
			TextView name=(TextView)view.findViewById(R.id.listname);
			name.setText(file.getName());
		}
		return view;
	}

}
