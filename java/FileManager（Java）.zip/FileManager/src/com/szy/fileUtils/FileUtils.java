package com.szy.fileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;


import android.os.Environment;

public class FileUtils {
	private String SDCardRoot;

	public FileUtils() {
		//得到SD卡的根目录
		SDCardRoot = Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator;
	}
	
	/**
	 * 在SD卡创建文件
	 * @param filename 文件名
	 * @param dir 目录
	 * @return boolean 0为成功
	 * @throws Exception
	 */
	public boolean creatFileInSDCard(String filename,String dir) throws Exception{
		File file=new File(SDCardRoot+dir+File.separator+filename);
		if (file.isDirectory()) {
			//如果是文件夹
			 if (!file.exists()) {
				return file.mkdirs();
				 
			}else{
				return false;
			}
		}
		return file.createNewFile();
		
	}
	/**
	 * 在SD卡上创建目录
	 * @param dir
	 * @return
	 */
	public boolean creatSDDir(String filename){
		File file=new File(filename);
		return file.mkdirs();
	}
	/**
	 *判断文件是否存在
	 * @param filename 文凭或文件夹
	 
	 * @return
	 */
	public boolean isFileExits(String filename){
		File file=new File(filename);	
		return file.exists();
	}
	/**
	 * 把流里的数据写到内存卡上去
	 * @param filename	文件名
	 * @param content 文件内容
	 * @return
	 */
	public boolean writeToSDCardFromInput(String filename,String content){
		boolean flag=false;
		File file=null;
		FileOutputStream  out=null;	//输出流
		try {
			file=new File(filename);
			if (file.createNewFile()==false) {
				flag=false;
				return flag;
			}
			out=new FileOutputStream(file);
			out.write(content.getBytes());
			out.flush();
			flag=true;
		} catch (Exception e) {
			e.printStackTrace();
			flag=false;
		}finally{
			try {
				if (out!=null) {
					out.close();
				}				
			} catch (IOException e) {
				e.printStackTrace();
				flag=false;
			}
		}
		return flag;
	}
	/**
	 * 删除文件和文件夹
	 * @param filepath
	 * @return int 0为正常，1文件不存在，2，失败
	 */
	public int deleteFile(String path){
		
		File file=new File(path);
		if (file.exists()==false) {
			//找不到文件了
			return 1;
		}
		if ( file.delete()==false) {
			//删除失败
			return 2;
		}
		return 0;
	}
	/**
	 * 将文件大小转化成字符串
	 * @param size 文件长度
	 * @return 文件长符串度字
	 */
	public String getIntToString(long size){
		int KB=1024;
		int MB=1024*KB;
		int GB=1024*MB;
		String length="";
		if (size<KB) {
			length=String.format("%d Byte",(int)size);
		}else if(size>=KB &&size<MB){
			length=String.format("%.2f KB", (float)size/KB);
		}else if(size>=MB &&size<GB){
			length=String.format("%.2f MB", (float)size/MB);
		}else{
			length=String.format("%.2f GB", (float)size/GB);
		}
		return length;
	}
	/**
	 * 将文件大小转化成字符串
	 * @param size 文件长度
	 * @return 文件长符串度字
	 */
	private String getIntToString(int size){
		int KB=1024;
		int MB=1024*KB;
		int GB=1024*MB;
		String length="";
		if (size<KB) {
			length=String.format("%d Byte",(int)size);
		}else if(size>=KB &&size<MB){
			length=String.format("%.2f KB", (float)size/KB);
		}else if(size>=MB &&size<GB){
			length=String.format("%.2f MB", (float)size/MB);
		}else{
			length=String.format("%.2f GB", (float)size/GB);
		}
		return length;
	}
	/**
	 * 复制文件
	 * @param fromUrl
	 * @param toUrl
	 * @return 0为正常 ，1为文件已经存在，2复制失败
	 */
	public int copy(String fromUrl,String toUrl){
		int flag=0;
		File fileFrom=new File(fromUrl);
		
		if(isFileExits(toUrl+"/"+fileFrom.getName())){
			//如果打找到
			return 1;
		}
		 InputStream input = null;	//输入流
		 OutputStream out=null;//输出流
		File fileTo=new File(toUrl+"/"+fileFrom.getName());
		try {
			input=new FileInputStream(fileFrom);
			if(fileTo.createNewFile()==false){
				//创建文件失败
				flag=2;
				return 2;
			}
			//创建输出流
			out=new FileOutputStream(fileTo);
			byte[] bb=new byte[1024];
			int sates;
			while ((sates=input.read(bb))!=-1) {
				out.write(bb,0,sates);
				out.flush();
			}
			flag=0;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if (input!=null) {
					input.close();
				}
				if (out!=null){
					out.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 0;
	}
	
}
