package com.miao.qqwidget;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;
import com.tencent.qq.widget.QQDialog;
import com.tencent.qq.widget.QQMenuDialog;
import com.tencent.qq.widget.QQProgress;
import com.tencent.qq.widget.QQToast;
import android.app.Dialog;

public class MainActivity extends Activity { 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

    public void toast(View v) {
        //使用弹窗静态方法设置内容、主题，并显示弹窗
        QQToast.makeText(getApplicationContext(), "我是一个弹窗，你是谁", QQToast.setTheme.DEFAULT).show();
    }

    public void progress(View v) {
        //使用进度弹窗的静态方法设置内容、主题
        final Dialog progress = QQProgress.showPorgressBar(this, "我在加载呢，你在干嘛", QQProgress.setTheme.DEFAULT);
        //设置点击其他地方可以取消
        progress.setCanceledOnTouchOutside(true);
        //设置返回键可以取消
        progress.setCancelable(true);
        //显示对话框
        progress.show();
        //创建子线程
        new Thread(new Runnable(){

                @Override
                public void run() {
                    try {
                        //暂停两秒
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //更新ui
                    runOnUiThread(new Runnable(){

                            @Override
                            public void run() {
                                //关闭进度对话框
                                progress.dismiss();
                                //有礼貌的对你说😂
                                Toast.makeText(getApplicationContext(), "我加载完毕啦，拜拜", Toast.LENGTH_LONG).show();
                            }
                        });
                }
            }).start();//执行
    }

    public void dialog(View v) {
        //初始化对话框
        final QQDialog dialog = new QQDialog(MainActivity.this);
        //设置标题
        dialog.setTitle("标题")
            //设置内容
            .setMessage("你好，我是内容")
            //设置上面的线条颜色为蓝色
            .setLineColor(QQDialog.Colors.BLUE)
            //设置确定按钮并设置按钮颜色为红色
            .setPositiveButton("确定", QQDialog.setTextColor.RED , new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    //确定按钮点击事件
                    Toast.makeText(getApplicationContext(), "你点我。。。", Toast.LENGTH_SHORT).show();
                    //关闭对话框
                    dialog.dismiss();
                }
            })
            //设置中间的按钮
            .setNegativeButton("中间" , new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    //中间的按钮点击事件
                    Toast.makeText(getApplicationContext(), "你点我。。", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            })
            //设置取消按钮
            .setNeutralButton("取消", new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    //取消按钮点击事件
                    Toast.makeText(getApplicationContext(), "你点我。", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            }).show();//显示对话框
    }

    public void input(View v) {
        //初始化对话框
        final QQDialog dialog = new QQDialog(MainActivity.this);
        //设置标题
        dialog.setTitle("标题")
            //设置内容
            .setMessage("你好，我是内容")
            //设置上面的线条颜色为蓝色
            .setLineColor(QQDialog.Colors.BLUE)
            //设置编辑框内容和提示内容
            .setEditText("我才是内容", "我是提示的内容")
            //设置确定按钮
            .setPositiveButton("确定", new OnClickListener(){

                @Override
                public void onClick(View p1) {
                    //确定按钮点击事件
                    Toast.makeText(getApplicationContext(), "你输入肯定是" + dialog.getEditText(), Toast.LENGTH_SHORT).show();
                    //关闭对话框
                    dialog.dismiss();
                }
            }).show();//显示弹窗
    }

    public void menu(View v) {
        //初始化一个菜单
        QQMenuDialog menu = new QQMenuDialog(this);
        //设置标题
        menu.setTitle("你知不知道我可是一个标题")
            //设置点击其他地方可以取消
            .setCanceledOnTouchOutside(true)
            //设置返回键可以取消
            .setCancelable(true)
            //设置取消按钮
            .setButton("取消")
            //设置第一个列表按钮，并设置颜色为默认
            .addItem("第一按钮", QQMenuDialog.setTextColor.DEFAULT, new QQMenuDialog.OnSheetItemClickListener(){

                @Override
                public void onClick(int p1) {
                    //列表按钮一点击事件
                    Toast.makeText(getApplicationContext(), "第一名，真开心", Toast.LENGTH_LONG).show();
                }
            })
            //设置第二个列表按钮，并设置颜色为默认
            .addItem("我排第二", QQMenuDialog.setTextColor.DEFAULT, new QQMenuDialog.OnSheetItemClickListener(){

                @Override
                public void onClick(int p1) {
                    //列表按钮二点击事件
                    Toast.makeText(getApplicationContext(), "为啥我排第二", Toast.LENGTH_LONG).show();
                }
            })
            //设置第三个列表按钮，并设置颜色为红色
            .addItem("倒数第一", QQMenuDialog.setTextColor.RED, new QQMenuDialog.OnSheetItemClickListener(){

                @Override
                public void onClick(int p1) {
                    //列表是按钮三自定义事件
                    Toast.makeText(getApplicationContext(), "我好惨呀", Toast.LENGTH_LONG).show();
                }
            }).show();//显示菜单，其实还可以添加的无数个
    }
} 
