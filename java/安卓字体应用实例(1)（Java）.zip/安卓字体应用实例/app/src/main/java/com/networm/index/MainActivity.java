package com.networm.index;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.Typeface;

public class MainActivity extends Activity 
{
	TextView networm;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Typeface 字体样式 = Typeface.createFromAsset(getAssets(), "fonts/Raleway-Light.ttf");
		networm=(TextView)findViewById(R.id.networmtext);
		networm.setTypeface(字体样式);
    }
}
