package org.tecunhuman;

import org.tecunhuman.jni.SoundStretch;

public class AndroidJNI {
    public final static SoundStretch soundStretch = new SoundStretch();
}
