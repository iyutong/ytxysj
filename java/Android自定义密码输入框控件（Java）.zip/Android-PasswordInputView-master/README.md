# Android-PasswordInputView

  Android自定义密码输入框控件

![PasswordInputView.jpg](https://github.com/tianshaojie/Android-PasswordInputView/blob/master/PasswordInputView.jpg)
