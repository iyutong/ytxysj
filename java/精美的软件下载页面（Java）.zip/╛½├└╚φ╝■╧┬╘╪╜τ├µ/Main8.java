package com.example.testproject;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

public class Main8 extends AppCompatActivity implements YusScrollView.ScrollViewListener {
    private YusScrollView yusScrollView;
    private RelativeLayout relativeLayout,relativeLayout1;
    private ImageView imageView3,imageView4;
    private TextView textView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main14);
        ImageView imageView1=findViewById(R.id.main14card1);
        ImageView imageView2=findViewById(R.id.main14card2);
        yusScrollView=findViewById(R.id.sv);
        relativeLayout=findViewById(R.id.main14layout2);
        relativeLayout1=findViewById(R.id.header);
        imageView3=findViewById(R.id.t1);
        imageView4=findViewById(R.id.t3);
        textView=findViewById(R.id.t2);
        yusScrollView.setScrollViewListener(this);

        Glide.with(Main8.this).load("http://m.qpic.cn/psc?/V10mmRGi4FpJwu/ubiEST8aMMlZjEEUGVmWIpUcyFtm1Z4i0G9ug5PTF8OH1o9XxD8ie04rHhXP7rdIwH.vK0Gc3jayU6mEQcs*b6nJacqB3c5Assft9obQtHU!/b&bo=OAQhCQAAAAARFzQ!&rf=viewer_4").into(imageView1);
        Glide.with(Main8.this).load("http://m.qpic.cn/psc?/V10mmRGi4FpJwu/ubiEST8aMMlZjEEUGVmWIio8.zq4dRo4JgGV9jB4CwGTFTvUEqgF*7P0y.tQQt.qECEo67fEo18raHVNh4T9M03rFpvoWGMNYdCBJScHedc!/b&bo=2gSACtoEgAoRJxA!&rf=viewer_4").into(imageView2);



    }
    @Override
    public void onScrollChanged(YusScrollView scrollView, int x, int y, int oldx, int oldy) {
        int tvHeight=textView.getHeight();
        int ivHeight=relativeLayout.getHeight();
        if(y<=0){
            relativeLayout1.setBackgroundColor(Color.TRANSPARENT);
            textView.setVisibility(View.INVISIBLE);
            imageView3.setVisibility(View.INVISIBLE);
            imageView4.setVisibility(View.INVISIBLE);

        }else if(y<ivHeight){
            float scale = (float) y / (float) ivHeight;
            float alpha = 255 * scale;

//            llHeader.setBackgroundColor(Color.argb((int) alpha, 144, 151, 166));
//            tvHeader.setVisibility(View.INVISIBLE);
            //先设置一个背景，然后在让背景乘以透明度
            relativeLayout1.setBackgroundColor(getResources().getColor(R.color.jjjj));
            relativeLayout1.getBackground().setAlpha((int)alpha);
            textView.setVisibility(View.INVISIBLE);
            imageView3.setVisibility(View.INVISIBLE);
            imageView4.setVisibility(View.INVISIBLE);


        }
        else if(y>=ivHeight){
            relativeLayout1.setBackgroundColor(getResources().getColor(R.color.jjjj));
            textView.setVisibility(View.VISIBLE);
            imageView3.setVisibility(View.VISIBLE);
            imageView4.setVisibility(View.VISIBLE);
        }
    }
}
