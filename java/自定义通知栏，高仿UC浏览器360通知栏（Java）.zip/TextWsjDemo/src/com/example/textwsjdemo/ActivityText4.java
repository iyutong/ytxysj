package com.example.textwsjdemo;

import android.app.Activity;
import android.os.Bundle;

public class ActivityText4 extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_text4);
	}
}
