package com.Google.Inc.hostencode;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.content.res.*;
import java.io.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		TextView tv1 = (TextView) findViewById(R.id.tv1);
		try{
		tv1.setText(类库.异或解密(类库.读取txt(this,this.getAssets().open("host.txt"))));
		}catch(Exception e){
			Toast.makeText(this,e.toString(),500).show();
		}
    }
}
