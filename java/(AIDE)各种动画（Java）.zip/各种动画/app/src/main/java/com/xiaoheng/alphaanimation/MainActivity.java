package com.xiaoheng.alphaanimation;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		TextView txv=(TextView)findViewById(R.id.mainTextView);
		txv.setText(this.getString(R.string.xiaohengstring));
		final ImageView Imageview=(ImageView)findViewById(R.id.mainImageView);
		Imageview.setOnLongClickListener(new OnLongClickListener(){

				@Override
				public boolean onLongClick(View p1)
				{
					//图片长按事件
					try
					{Vibrator heng=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
						heng.vibrate(1000);
						//heng.cancel();
						startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
					}catch(Exception xiaoheng)
					{Toast.makeText(MainActivity.this,"转跳到小亨QQ异常",Toast.LENGTH_SHORT).show();}
					return false;
				}});
		Toast.makeText(MainActivity.this,"长按图片加我QQ哦",Toast.LENGTH_LONG).show();
		
		//这里开始都是是核心代码↓↓↓↓↓
		Button button=(Button)findViewById(R.id.button);
		Button button2=(Button)findViewById(R.id.mainButton1);
		Button button3=(Button)findViewById(R.id.mainButton2);
		Button button4=(Button)findViewById(R.id.mainButton3);
		
		button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//渐变动画
					Animation a=AnimationUtils.loadAnimation(MainActivity. this,R.anim.jianbian);
					Imageview.startAnimation(a);
				}});
			
			
		button2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//旋转动画
					Animation a=AnimationUtils.loadAnimation(MainActivity. this,R.anim.xuanzuan);
					Imageview.startAnimation(a);
				}});
				
		button3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//缩放动画
					Animation a=AnimationUtils.loadAnimation(MainActivity. this,R.anim.suofang);
					Imageview.startAnimation(a);
				}});
			
		button4.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//移动动画
					Animation a=AnimationUtils.loadAnimation(MainActivity. this,R.anim.yidong);
					Imageview.startAnimation(a);
				}});
				//这里以上是核心代码↑↑↑↑↑
				
			
    }
}


/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *      2017.8.10                       *
 ****************************************/
