package com.panda.pandabox.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.panda.pandabox.R;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //转跳主页面
        final Intent TiaoMain=new Intent(MainActivity.this, PandaActivity.class);
        Timer timer=new Timer();
        TimerTask task=new TimerTask(){
            @Override
            public void run(){
                startActivity(TiaoMain);
            }
        };
        timer.schedule(task, 3000);

    }
}
