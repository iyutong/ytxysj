package com.panda.pandabox.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import com.panda.pandabox.fragment.HomeFirstFragment;
import com.panda.pandabox.fragment.HomeSecondFragment;
import com.panda.pandabox.fragment.HomeThirdFragment;
import com.panda.pandabox.fragment.HomeFourthFragment;

import java.util.*;
public class ViewPagerAdapter extends FragmentPagerAdapter{
    private ArrayList<Fragment> mFragmentList = new ArrayList<>();
    public ViewPagerAdapter(android.support.v4.app.FragmentManager fm){
        super(fm);
        mFragmentList.add(HomeFirstFragment.newInstance());
        mFragmentList.add(HomeSecondFragment.newInstance());
        mFragmentList.add(HomeThirdFragment.newInstance());
        mFragmentList.add(HomeFourthFragment.newInstance());
    }

    @Override
    public Fragment getItem(int position) {
        return mFragmentList.get(position);
    }

    @Override
    public int getCount(){
        return mFragmentList.size();
    }
}