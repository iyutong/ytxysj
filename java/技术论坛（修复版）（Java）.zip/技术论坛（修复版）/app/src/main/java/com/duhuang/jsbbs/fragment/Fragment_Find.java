package com.duhuang.jsbbs.fragment;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v4.app.*;
import android.view.*;
import android.widget.*;
import com.duhuang.jsbbs.*;

public class Fragment_Find extends Fragment
{
	private LinearLayout item,l;
	private View v1;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		View v=inflater.inflate(R.layout.fragment_find, container, false);
		item = (LinearLayout) v.findViewById(R.id.fragmentfindLinearLayout1);
		l = (LinearLayout) v.findViewById(R.id.fragmentfindLinearLayout2);
		v1 = v.findViewById(R.id.fragmentfindView1);

		SharedPreferences settings=getActivity().getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);
		if (THEME == true)
		{
			l.setBackgroundColor(Color.parseColor("#EEEEEE"));
			item.setBackgroundResource(android.R.color.white);
			v1.setBackgroundColor(Color.parseColor("#EEEEEE"));
		}
		else
		{
			item.setBackgroundResource(R.drawable.item_selector);
		}
		return v;
	}

	public static Fragment_Find newInstance()
	{
		Fragment_Find ff=new Fragment_Find();
		return ff;
	}
}
