package com.duhuang.jsbbs.plate;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;
import android.widget.AdapterView.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.View.OnClickListener;

public class IappActivity extends AppCompatActivity implements OnItemClickListener
{
	private ListView lv;
	private ProgressDialog dialog;
	private ProgressDialog dialog2;
	private SwipeRefreshLayout swipeView;
	private Intent intent;
	private TextView ht,bz;
	private FloatingActionButton fab;
	private Toolbar tool;
	private AlertDialog dialog1;
	private EditText title,message;
	private Button qx,tj;
	private TextView ft;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.iapp_activity);
		swipeView = (SwipeRefreshLayout)findViewById(R.id.iapp_swipe);
		lv = (ListView) findViewById(R.id.iappListView);
		ht = (TextView) findViewById(R.id.iapp_ht);
		bz = (TextView) findViewById(R.id.iapp_bz);
		tool = (Toolbar) findViewById(R.id.iappToolbar1);
		fab = (FloatingActionButton) findViewById(R.id.iapp_fab);

		lv.setOnItemClickListener(this);

		mHuTi();
		mBzs();
		mRead();
		mToolbar();
		mProgressDialog();
		mSwipe();

		fab.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					mFtDialog();
				}
			});

		if (THEME == true)
		{
			tool.setBackgroundResource(R.color.colorPrimary);
		}
		else
		{
			tool.setBackgroundResource(R.color.nightColorPrimary);
		}
	}

	//加载贴纸
	private void mRead()
	{
		BmobQuery<Post> query=new BmobQuery<Post>();
		query.addWhereEqualTo("bk", "iApp");
		query.setMaxCacheAge(TimeUnit.DAYS.toMillis(7));//此表示缓存一天
		query.order("-createdAt");//依照maps排序时间排序
		//返回50条maps，如果不加上这条语句，默认返回10条maps
		query.setLimit(50);
		query.include("authors");
		query.setCachePolicy(BmobQuery.CachePolicy.NETWORK_ELSE_CACHE);
		query.findObjects(new FindListener<Post>() {

				@Override
				public void done(List<Post> p1, BmobException p2)
				{
					if (p2 == null)
					{
						dialog.dismiss();
						swipeView.setRefreshing(false);
						// TODO Auto-generated method stub
						//创建集合放审核通过的帖子
						List<Post>data=new ArrayList<>();
						for (Post am:p1)//遍历原始数据，查找已审核通过的帖子
						{
							if (am.getSh() == true)
							{
								data.add(am);//审核通过放入新集合
							}
							else
							{
								//审核不通过
							}
						}

						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, IappActivity.this);
							lv.setAdapter(adapter);

							//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							lv.setLayoutAnimation(controller);
						}
						else
						{
							//没有审核通过的帖子
						}
					}
					else
					{
						dialog.dismiss();
						swipeView.setRefreshing(false);
						Util.error(IappActivity.this, "加载失败，请检查网络连接！");
					}
				}
			});
	}

//内部类MyAdapter
	class MyAdapter extends BaseAdapter
	{
		private List<Post>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Post>list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			final ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.item_1, null);
				holder.rz = (ImageView) convertView.findViewById(R.id.item1ImageView2);
				holder.title = (TextView) convertView.findViewById(R.id.item1TextView2);
				holder.message = (TextView) convertView.findViewById(R.id.item1TextView3);
				holder.author = (TextView) convertView.findViewById(R.id.item1TextView4);
				holder.time = (TextView) convertView.findViewById(R.id.item1TextView5);
				holder.tp = (RelativeLayout) convertView.findViewById(R.id.item1RelativeLayout1);
				holder.authorTx = (ImageView) convertView.findViewById(R.id.item1ImageView1);
				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			Post am=list.get(position);

			Boolean rz=am.getRz();
			//如果为true则认证
			if (rz == true)
			{
				holder.rz.setVisibility(View.VISIBLE);
			}
			else if (rz == false)
			{
				holder.rz.setVisibility(View.GONE);
			}

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/            
			holder.title.setText(am.getTitle());
			holder.message.setText(am.getMessage());
			holder.author.setText(am.getAuthors().getUsername());
			holder.time.setText(am.getCreatedAt());
			//加载作者头像
			ImageRequest imageRequest=new ImageRequest(am.getAuthors().getTx(), new Response.Listener<Bitmap>() 
				{
					@Override
					public void onResponse(Bitmap response)
					{
						holder.authorTx.setImageBitmap(response);
					}
				}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error)
					{
						holder.authorTx.setImageResource(R.drawable.beij18);//失败用这张图片
					}
				});
			RequestQueue mQueue = Volley.newRequestQueue(getApplicationContext());//创建一个volley队列
			mQueue.add(imageRequest);//加入队列 开始下载
			dialog.dismiss();
			return convertView;
		}

		class ViewHolder
		{
			public RelativeLayout tp;
			public ImageView authorTx;
			public ImageView rz;
			public TextView title;
			public TextView message;
			public TextView author;
			public TextView time;
		}
	}

	private void mSwipe()
	{
		swipeView.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
        swipeView.setEnabled(true);
        swipeView.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

				@Override
				public void onRefresh()
				{
					//swipeView.setRefreshing(false);
					(new Handler()).postDelayed(new Runnable() {

							@Override
							public void run()
							{
								mHuTi();
								mBzs();
								mRead();
							}

						}, 1000);
				}
			});
	}

	private void mBzs()
	{
		BmobQuery<BanZhu> query=new BmobQuery<>();
		query.include("iApp");
		query.findObjects(new FindListener<BanZhu>() {

				@Override
				public void done(List<BanZhu> p1, BmobException p2)
				{
					if (p2 == null)
					{
						// TODO Auto-generated method stub
						for (BanZhu gameScore : p1)
						{
							String bzs=gameScore.getIApp().getUsername();
							bz.setText(bzs);
						}
					}
				}
			});
	}

	//发帖
	private void mFtDialog()
	{
		LayoutInflater lf=LayoutInflater.from(this);
		View v=lf.inflate(R.layout.ft_dialog, null);
		AlertDialog.Builder ad=new AlertDialog.Builder(this);
		ad.setView(v);
		dialog1 = ad.show();

		title = (EditText) v.findViewById(R.id.ftdialogEditText1);
		message = (EditText) v.findViewById(R.id.ftdialogEditText2);
		qx = (Button) v.findViewById(R.id.ftdialogButton1);
		tj = (Button) v.findViewById(R.id.ftdialogButton2);
		ft = (TextView) v.findViewById(R.id.ftdialogTextView1);

		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}
		
		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
			ft.setTextColor(Color.BLACK);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}

		qx.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					dialog1.dismiss();
				}
			});

		tj.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String nr= title.getText().toString().trim();
					String nr2=message.getText().toString().trim();
					if (nr.isEmpty() || nr2.isEmpty())
					{
						Util.error(IappActivity.this, "发帖标题或内容不能为空！");
					}
					else
					{
						dialog2 = new ProgressDialog(IappActivity.this);
						dialog2.setTitle("提示：");
						dialog2.setCancelable(false);
						dialog2.setProgressStyle(dialog.STYLE_SPINNER);
						dialog2.setMessage("发帖中...");
						dialog2.show();

						MyUser bu=BmobUser.getCurrentUser(MyUser.class);

						Post XianLiao=new Post();
						XianLiao.setTitle(nr);
						XianLiao.setMessage(nr2);
						XianLiao.setAuthors(bu);
						XianLiao.setBk("iApp");
						XianLiao.setSh(false);
						XianLiao.setRz(false);
						XianLiao.save(new SaveListener<String>(){
								@Override
								public void done(String p1, BmobException p2)
								{
									if (p2 == null)
									{
										Util.success(getApplicationContext(), "您刚发的帖子需要审核，审核成功后才会显示！");
										dialog2.dismiss();
										dialog1.dismiss();
									}
									else
									{
										Util.error(getApplicationContext(), "发帖失败，请重试！");
										dialog2.dismiss();
										dialog1.dismiss();
									}
								}
							});
					}
				}
			});
	}

	private void mToolbar()
	{
		tool.setTitle("iApp");
		setSupportActionBar(tool);
		tool.setNavigationIcon(R.drawable.back);
		tool.setNavigationOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});
	}

	private void mHuTi()
	{
		BmobQuery<Post> query = new BmobQuery<Post>();
		query.addWhereEqualTo("bk", "iApp");
		query.count(Post.class, new CountListener() {
				@Override
				public void done(Integer count, BmobException e)
				{
					if (e == null)
					{
						ht.setText(count + "");
					}
				}
			});
	}

	private void mProgressDialog()
	{
		dialog = new ProgressDialog(this);
		dialog.setTitle("提示：");
		dialog.setMessage("加载中...");
		dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		dialog.setCancelable(false);
		dialog.show();
	}

	@Override 
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
	{
		Post am=(Post) lv.getAdapter().getItem(position);
		Bundle bd=new Bundle();
		bd.putString("title", am.getTitle());
		bd.putString("message", am.getMessage());
		bd.putString("authors", am.getAuthors().getUsername());
		bd.putString("time", am.getCreatedAt());
		bd.putString("bk", am.getBk());
		bd.putBoolean("rz", am.getRz());
		bd.putString("tx", am.getAuthors().getTx());
		bd.putString("aide", am.getObjectId());

		intent = new Intent();
		intent.setClass(this, iAppCkTz.class);
		intent.putExtras(bd);
		startActivity(intent);
	}
}

