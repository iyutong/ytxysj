package com.duhuang.jsbbs;
import android.content.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v4.app.*;
import android.support.v4.view.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.duhuang.jsbbs.fragment.*;
import java.io.*;
import java.util.*;
import android.graphics.*;

public class MyPost extends AppCompatActivity
{
	private TabLayout mTabLayout;
    private ViewPager viewPager;
	private ImageView back;
    private ArrayList<Fragment> fragments;
    private String[] titles={"已通过","审核中"};
	private ImageView xx;
	private LinearLayout toolbar;
	private View view;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.mypost);
		mTabLayout = (TabLayout) findViewById(R.id.tab_my);
		viewPager = (ViewPager) findViewById(R.id.viewpager);
		back = (ImageView) findViewById(R.id.mypostImageView1);
		xx = (ImageView) findViewById(R.id.mypostImageView2);
		toolbar = (LinearLayout) findViewById(R.id.mypostLinearLayout1);
		view = findViewById(R.id.mypostView1);
		back.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					finish();
				}
			});

		xx.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Util.error(MyPost.this, "此版本暂不支持");
				}
			});
		setViewPager();

		if (THEME)
		{
			toolbar.setBackgroundResource(R.color.colorPrimary);
		}
		else
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
			mTabLayout.setBackgroundResource(R.color.nightColorPrimary);
			view.setVisibility(View.GONE);
			mTabLayout.setTabTextColors(Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF"));
			mTabLayout.setSelectedTabIndicatorColor(Color.parseColor("#FFFFFF"));
		}
	}

	private void setViewPager()
	{
		fragments = new ArrayList<Fragment>();
        fragments.add(new Fragment_Ytg());
        fragments.add(new Fragment_Shing());
        viewPager.setAdapter(viewPagerAdapter);
        //viewPager.setOnPageChangeListener(this);

		// mTabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);设置后Tab标签往左边靠
        mTabLayout.setupWithViewPager(viewPager);
        mTabLayout.setTabsFromPagerAdapter(viewPagerAdapter);
    }

    FragmentStatePagerAdapter viewPagerAdapter=new FragmentStatePagerAdapter(
        getSupportFragmentManager()) {
        @Override
        public int getCount()
		{
            return fragments.size();
        }
        public CharSequence getPageTitle(int position)
		{
            return titles[position];
        }
        @Override
        public Fragment getItem(int arg0)
		{
            return fragments.get(arg0);
        }
	};

}
