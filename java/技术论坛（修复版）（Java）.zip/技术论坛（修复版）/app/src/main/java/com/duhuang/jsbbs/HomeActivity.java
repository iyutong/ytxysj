package com.duhuang.jsbbs;
import android.content.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import cn.bmob.v3.update.*;
import com.ashokvarma.bottomnavigation.*;
import com.duhuang.jsbbs.*;
import com.duhuang.jsbbs.bmob.*;
import com.duhuang.jsbbs.fragment.*;
import java.io.*;

import com.duhuang.jsbbs.R;

public class HomeActivity extends AppCompatActivity implements BottomNavigationBar.OnTabSelectedListener
{
	private BottomNavigationBar mBottomNavigationBar;
	private Fragment_Resource mFr;
	private Fragment_Community mFc;
	private Fragment_Find mFf;
	private Fragment_Space mFs;
	private ImageView xx;
	private LinearLayout toolbar;
	private WebView wv;

	private long firstTime;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		BmobUpdateAgent.setUpdateOnlyWifi(false);
		BmobUpdateAgent.update(this);

		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
			settings.edit().putBoolean("Check", false).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.home);
		wv = (WebView) findViewById(R.id.homeWebView);
		toolbar = (LinearLayout) findViewById(R.id.homeLinearLayout1);
		xx = (ImageView) findViewById(R.id.homeImageView1);
		mBottomNavigationBar = (BottomNavigationBar) findViewById(R.id.bottom_navigation_bar);

		AlertDialog.Builder dialog=new AlertDialog.Builder(this);
		dialog.setTitle("开源说明：");
		dialog.setMessage("此源码由葫芦侠三楼.Rain.毒皇编写，现已开源！");
		dialog.show();
		
		wv.loadUrl("http://j3.lm.berryfree.cn/ssss/detail/1356318/67636");
		wv.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url)
				{
					view.loadUrl(url);
					return true;
				}
			});

		onFh();//封号
		fetchUserInfo();//更新本地用户信息

		//MODE_FIXED （固定大小）
		//填充模式，未选中的Item会显示文字，没有换挡动画。
		mBottomNavigationBar.setMode(BottomNavigationBar.MODE_FIXED);

		//MODE_SHIFTING （不固定大小）
		//换挡模式，未选中的Item不会显示文字，选中的会显示文字。在切换的时候会有一个像换挡的动画
		//mBottomNavigationBar.setMode(BottomNavigationBar.MODE_SHIFTING);

		//mBottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_STATIC);

		mBottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_RIPPLE);

		//表示未选中Item中的图标和文本颜色。默认为 Color.LTGRAY
		//mBottomNavigationBar.setInActiveColor(R.color.nightColorAccent);

		//在BACKGROUND_STYLE_STATIC下，表示选中Item的图标和文本颜色。而在BACKGROUND_STYLE_RIPPLE下，表示整个容器的背景色。
		//mBottomNavigationBar.setActiveColor(android.R.color.white);

		//在BACKGROUND_STYLE_STATIC下，表示整个容器的背景色。而在BACKGROUND_STYLE_RIPPLE下，表示选中Item的图标和文本颜色。
		//mBottomNavigationBar.setBarBackgroundColor(R.color.colorAccent);

		mBottomNavigationBar.addItem(new BottomNavigationItem(R.drawable.ic_cloud, "资源"))
			.addItem(new BottomNavigationItem(R.drawable.ic_store_mall_directory, "社区"))
			.addItem(new BottomNavigationItem(R.drawable.ic_filter_hdr, "发现"))
			.addItem(new BottomNavigationItem(R.drawable.ic_record_voice_over, "空间"))
			.setFirstSelectedPosition(0)
			.initialise();

        mBottomNavigationBar.setTabSelectedListener(this);
        setDefaultFragment();

		if (THEME == true)
		{
			toolbar.setBackgroundResource(R.color.colorPrimary);
			mBottomNavigationBar.setActiveColor(android.R.color.white);
			mBottomNavigationBar.setBarBackgroundColor(R.color.colorAccent);
			mBottomNavigationBar.setInActiveColor(R.color.nightColorAccent);
			mBottomNavigationBar.setFirstSelectedPosition(0).initialise();
		}
		else
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
			mBottomNavigationBar.setActiveColor(R.color.nightColorPrimary);
			mBottomNavigationBar.setFirstSelectedPosition(0).initialise();
		}

		xx.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Util.error(HomeActivity.this, "此版本暂不支持");
				}
			});

		BmobUpdateAgent.setDialogListener(new BmobDialogButtonListener() {

				@Override
				public void onClick(int status)
				{
					// TODO Auto-generated method stub
					switch (status)
					{
						case UpdateStatus.Update:
							Util.success(getApplicationContext(), "正在更新，更新文件路径/sdcard/");
							break;
					}
				}
			});
	}

	private void fetchUserInfo()
	{
        BmobUser.fetchUserJsonInfo(new FetchUserInfoListener<String>() {
				@Override
				public void done(String s, BmobException e)
				{}
			});
    }

	private void onFh()
	{
		MyUser m=BmobUser.getCurrentUser(MyUser.class);
		BmobQuery<MyUser> query=new BmobQuery<>();
		String id=m.getObjectId();
		query.getObject(id, new QueryListener<MyUser>(){

				@Override
				public void done(MyUser p1, BmobException p2)
				{
					if (p2 == null)
					{
						if (p1.getIs())
						{
							Util.error(getApplicationContext(), "该帐号已被封停");
							MyUser.logOut();
							finish();
						}
					}
				}
			});
	}

	private void setDefaultFragment()
	{
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        mFr = mFr.newInstance();
        transaction.replace(R.id.ll_content, mFr).commit();
    }

    @Override
    public void onTabSelected(int position)
	{
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        switch (position)
		{
            case 0:
                if (mFr == null)
				{
                    mFr = Fragment_Resource.newInstance();
                }
                transaction.replace(R.id.ll_content, mFr);
                break;
			case 1:
                if (mFc == null)
				{
                    mFc = Fragment_Community.newInstance();
                }
                transaction.replace(R.id.ll_content, mFc);
                break;
			case 2:
                if (mFf == null)
				{
                    mFf = Fragment_Find.newInstance();
                }
                transaction.replace(R.id.ll_content, mFf);
                break;
			case 3:
                if (mFs == null)
				{
                    mFs = Fragment_Space.newInstance();
                }
                transaction.replace(R.id.ll_content, mFs);
                break;
			default:
                if (mFr == null)
				{
                    mFr = Fragment_Resource.newInstance();
                }
                transaction.replace(R.id.ll_content, mFr);
                break;
        }
        transaction.commit();

    }

    @Override
    public void onTabUnselected(int position)
	{

    }

    @Override
    public void onTabReselected(int position)
	{

    }

	@Override 
    public boolean onKeyUp(int keyCode, KeyEvent event)
	{ 
        if (keyCode == KeyEvent.KEYCODE_BACK)
		{ 
            long secondTime = System.currentTimeMillis(); 
            if (secondTime - firstTime > 2000)
			{//如果两次按键时间间隔大于800毫秒，则不退出 
                Util.warning(this, "再按一次退出程序"); 
                firstTime = secondTime;//更新firstTime 
                return true; 
            }
			else
			{ 
                System.exit(0);//否则退出程序 
            } 
        } 
        return super.onKeyUp(keyCode, event); 
	}

}
