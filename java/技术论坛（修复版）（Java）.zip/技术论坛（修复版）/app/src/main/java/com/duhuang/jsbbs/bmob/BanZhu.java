package com.duhuang.jsbbs.bmob;

import cn.bmob.v3.*;

public class BanZhu extends BmobObject
{
	private MyUser AIDE,iApp,Bmob,Java,Lua,Syrj,XtGg,YiJian;


	public void setAIDE(MyUser aIDE)
	{
		AIDE = aIDE;
	}

	public MyUser getAIDE()
	{
		return AIDE;
	}

	public void setIApp(MyUser iApp)
	{
		this.iApp = iApp;
	}

	public MyUser getIApp()
	{
		return iApp;
	}

	public void setBmob(MyUser bmob)
	{
		Bmob = bmob;
	}

	public MyUser getBmob()
	{
		return Bmob;
	}

	public void setJava(MyUser java)
	{
		Java = java;
	}

	public MyUser getJava()
	{
		return Java;
	}

	public void setLua(MyUser lua)
	{
		Lua = lua;
	}

	public MyUser getLua()
	{
		return Lua;
	}

	public void setSyrj(MyUser syrj)
	{
		Syrj = syrj;
	}

	public MyUser getSyrj()
	{
		return Syrj;
	}

	public void setXtGg(MyUser xtGg)
	{
		XtGg = xtGg;
	}

	public MyUser getXtGg()
	{
		return XtGg;
	}

	public void setYiJian(MyUser yiJian)
	{
		YiJian = yiJian;
	}

	public MyUser getYiJian()
	{
		return YiJian;
	}}
