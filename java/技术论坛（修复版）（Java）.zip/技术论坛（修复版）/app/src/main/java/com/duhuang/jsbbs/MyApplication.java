package com.duhuang.jsbbs;
import android.app.Application;
import cn.bmob.v3.Bmob;

public class MyApplication extends Application
{

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		Bmob.initialize(this, "Bmob ID");
		CrashHandler crashHandler = CrashHandler.getInstance();
		crashHandler.init(this);
	}

}
