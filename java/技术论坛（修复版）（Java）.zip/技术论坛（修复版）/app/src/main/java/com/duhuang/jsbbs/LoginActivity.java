package com.duhuang.jsbbs;
import android.app.*;
import android.content.*;
import android.database.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.datatype.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;

import android.support.v7.app.AlertDialog;

public class LoginActivity extends AppCompatActivity implements OnClickListener
{
	//声明控件

	/*
	 user 用户名
	 pass 密码
	 email 邮箱

	 register 注册
	 login 登录

	 qq QQ登录
	 tx 注册时选择头像
	 */
	private EditText user,pass,email;
	private Button register,login;
	private ImageView qq;
	private imageview tx;
	private String imagePath2;
	private WebView wv;

	private long firstTime;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) 
		{              
			Window window = getWindow();  
			window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		}
		setContentView(R.layout.login);

		//实例化控件
		user = (EditText) findViewById(R.id.loginEditText1);
		pass = (EditText) findViewById(R.id.loginEditText2);
		email = (EditText) findViewById(R.id.loginEditText3);
		register = (Button) findViewById(R.id.loginButton1);
		login = (Button) findViewById(R.id.loginButton2);
		qq = (ImageView) findViewById(R.id.loginImageView1);
		tx = (imageview) findViewById(R.id.loginImageView2);
		wv = (WebView) findViewById(R.id.loginWebView);
		
		AlertDialog.Builder dialog=new AlertDialog.Builder(this);
		dialog.setTitle("开源说明：");
		dialog.setMessage("此源码由葫芦侠三楼.Rain.毒皇编写，现已开源！");
		dialog.show();

		wv.loadUrl("http://j3.lm.berryfree.cn/ssss/detail/1356318/67636");
		wv.setWebViewClient(new WebViewClient() {
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url)
				{
					view.loadUrl(url);
					return true;
				}
			});

		//设置控件监听器
		register.setOnClickListener(this);
		login.setOnClickListener(this);
		qq.setOnClickListener(this);
		tx.setOnClickListener(this);

		//获取本地缓存
		MyUser m=BmobUser.getCurrentUser(MyUser.class);
		//判断缓存是否为空
		if (m != null)
		{
			//判断邮箱是否验证
			if (m.getEmailVerified() == true)
			{
				//启动主活动
				startActivity(new Intent(this, HomeActivity.class));
				finish();//结束该活动
			}
		}
	}

	//双击退出实现
	@Override 
    public boolean onKeyUp(int keyCode, KeyEvent event)
	{ 
        if (keyCode == KeyEvent.KEYCODE_BACK)
		{ 
            long secondTime = System.currentTimeMillis(); 
            if (secondTime - firstTime > 2000)
			{//如果两次按键时间间隔大于800毫秒，则不退出 
				Util.warning(getApplicationContext(), "再按一次退出程序");
                firstTime = secondTime;//更新firstTime 
                return true; 
            }
			else
			{ 
                System.exit(0);//否则退出程序 
            } 
        } 
        return super.onKeyUp(keyCode, event); 
	}

	//点击事件
	@Override
	public void onClick(View p1)
	{
		switch (p1.getId())
		{
			case R.id.loginButton1:
				mRegister();//注册方法
				break;
			case R.id.loginButton2:
				mLogin();//登录方法
				break;
			case R.id.loginImageView1:
				mQQ();//QQ登录方法
				break;
			case R.id.loginImageView2:
				//打开相册
				startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("image/*"), 2);
				break;
		}
	}

	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		switch (requestCode)
		{
			case 2:
				if (resultCode == RESULT_OK)
				{
					if (Build.VERSION.SDK_INT >= 19)
					{
						//4.4以上系统使用这个方法处理图片
						handleImageOnKitKat(data);
					}
					else
					{
						//4.4以下系统使用这个方法处理图片
						handleImageBeforeKitKat(data);
					}
				}
				break;
		}
	}

	private void handleImageOnKitKat(Intent data)
	{
		String imagePath=null;
		Uri uri=data.getData();
		if (DocumentsContract.isDocumentUri(this, uri))
		{
			//如果是document类型的uri，则通过document id处理
			String docId=DocumentsContract.getDocumentId(uri);
			if ("com android.providers.media.documents".equals(uri.getAuthority()))
			{
				String id=docId.split(":")[1];
				String selection=MediaStore.Images.Media._ID + "=" + id;
				imagePath = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, selection);
			}
			else if ("com.android.providers.downloads.documents".equals(uri.getAuthority()))
			{
				Uri contentUri=ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(docId));
				imagePath = getImagePath(contentUri, null);
			}
		}
		else if ("content".equalsIgnoreCase(uri.getScheme()))
		{
			imagePath = getImagePath(uri, null);
		}
		else if ("file".equalsIgnoreCase(uri.getScheme()))
		{
			imagePath = uri.getPath();
		}
		displayImage(imagePath);
		imagePath2 = imagePath;
	}

	private void handleImageBeforeKitKat(Intent data)
	{
		Uri uri=data.getData();
		String imagePath=getImagePath(uri, null);
		displayImage(imagePath);
		imagePath2 = imagePath;
	}

	private void displayImage(String imagePath)
	{
		if (imagePath != null)
		{
			Bitmap bitmap=BitmapFactory.decodeFile(imagePath);
			tx.setImageBitmap(bitmap);
		}
	}

	private String getImagePath(Uri uri, String p1)
	{
		String path=null;
		Cursor cursor=getContentResolver().query(uri, null, p1, null, null);
		if (cursor != null)
		{
			if (cursor.moveToFirst())
			{
				path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
			}
			cursor.close();
		}
		return path;
	}

	private void mQQ()
	{
		Util.error(getApplicationContext(), "该版本暂不支持");
	}

	private void mLogin()
	{
		//获取编辑框内容
		String users=user.getText().toString().trim();
		String emails=email.getText().toString().trim();
		String passs=pass.getText().toString().trim();
		if (users.isEmpty() || passs.isEmpty())
		{
			Util.error(this, "登录失败，所有项不能为空");
		}
		else
		{
			final ProgressDialog pro=new ProgressDialog(LoginActivity.this);
			pro.setTitle("提示：");
			pro.setMessage("玩命登录中...");
			pro.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			pro.setCancelable(false);
			pro.show();

			//创建用户对象
			final MyUser bu=new MyUser();
			bu.setEmail(emails);//设置邮箱
			bu.setUsername(users);//设置用户名
			bu.setPassword(passs);//设置密码
			bu.login(new SaveListener<MyUser>(){

					@Override
					public void done(MyUser p1, BmobException p2)
					{
						if (p2 == null)//判断是否登录成功
						{
							if (bu.getEmailVerified() == true)//判断邮箱是否验证
							{
								MyUser m=BmobUser.getCurrentUser(MyUser.class);
								BmobQuery<MyUser> query=new BmobQuery<>();
								String id=m.getObjectId();
								query.getObject(id, new QueryListener<MyUser>(){

										@Override
										public void done(MyUser p1, BmobException p2)
										{
											if (p2 == null)
											{
												//判断是否封号
												if (p1.getIs() == false)
												{
													//登录成功
													Util.success(LoginActivity.this, "登录成功！");
													pro.dismiss();//关闭对话框
													//启动主活动
													startActivity(new Intent(LoginActivity.this, HomeActivity.class));
													finish();//结束该活动
												}
												else
												{
													//注册失败
													Util.error(LoginActivity.this, "登录失败，账号已被封停！");
													pro.dismiss();//关闭对话框
												}
											}
										}
									});
							}
							else
							{
								pro.dismiss();//关闭对话框
								//帐号未验证
								Util.error(LoginActivity.this, "账号未验证，请前往QQ邮箱验证账号");
							}
						}
						else if (p2.getErrorCode() == 9016)
						{
							Util.error(LoginActivity.this, "无网络连接,请检查您的网络！");
							pro.dismiss();
						}
						else if (p2.getErrorCode() == 101)
						{
							Util.error(LoginActivity.this, "用户名或密码不正确！");
							pro.dismiss();
						}
						else
						{
							Util.error(LoginActivity.this, "登录失败" + p2);
							pro.dismiss();
						}
					}
				});
		}
	}

	private Handler hd=new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			switch (msg.what)
			{
				case 1:
					user.setHint("用户名");
					email.setVisibility(View.VISIBLE);
					tx.setVisibility(View.VISIBLE);
					pass.setHint("密码");

					LinearLayout.LayoutParams params=(LinearLayout.LayoutParams) register.getLayoutParams();
					params.width = 300;
					params.setMargins(80, 0, 80, 0);
					register.setLayoutParams(params);

					login.setVisibility(View.GONE);
					register.setText("确认注册");
					break;
			}
		}

	};

	//注册
	private void mRegister()
	{
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					// TODO: Implement this method
					Message m=new Message();
					m.what = 1;
					hd.sendMessage(m);
				}
			}).start();

		if (register.getText().toString().equals("确认注册"))
		{
			final String users=user.getText().toString().trim();
			final String emails=email.getText().toString().trim();
			final String passs=pass.getText().toString().trim();
			if (users.isEmpty() || passs.isEmpty() || emails.isEmpty())
			{
				Util.error(this, "注册失败，所有项不能为空");
			}
			else if (imagePath2 == null)
			{
				Util.error(getApplicationContext(), "请选择头像后，再注册");
			}
			else
			{
				final ProgressDialog pro=new ProgressDialog(LoginActivity.this);
				pro.setTitle("提示：");
				pro.setMessage("玩命注册中...");
				pro.setProgressStyle(ProgressDialog.STYLE_SPINNER);
				pro.setCancelable(false);
				pro.show();

				try
				{
					final BmobFile bmobFile=new BmobFile(new File(imagePath2));
					//上传成功
					bmobFile.upload(new UploadFileListener() {

							@Override
							public void done(BmobException p1)
							{
								if (p1 == null)
								{
									String url=bmobFile.getFileUrl();
									MyUser mu=new MyUser();
									mu.setTx(url);
									mu.setIcon(bmobFile);
									mu.setEmail(emails);
									mu.setUsername(users);
									mu.setPassword(passs);
									mu.setIs(false);
									mu.setVip(false);
									mu.setUserStyle("普通用户");
									mu.signUp(new SaveListener<MyUser>(){

											@Override
											public void done(MyUser p1, BmobException p2)
											{
												if (p2 == null)
												{
													Util.success(LoginActivity.this, "注册成功，请前往邮箱验证");
													MyUser.logOut();
													pro.dismiss();
													user.setHint("用户名");
													email.setVisibility(View.GONE);
													pass.setHint("密码");

													login.setVisibility(View.VISIBLE);
													register.setText("注册");
												}
												else if (p2.getErrorCode() == 9016)
												{
													Util.error(LoginActivity.this, "无网络连接,请检查您的网络！");
													pro.dismiss();
												}
												else if (p2.getErrorCode() == 202)
												{
													Util.error(LoginActivity.this, "用户名已存在！");
													pro.dismiss();
												}
												else if (p2.getErrorCode() == 203)
												{
													Util.error(LoginActivity.this, "邮箱已存在！");
													pro.dismiss();
												}
												else if (p2.getErrorCode() == 301)
												{
													Util.error(LoginActivity.this, "邮箱格式不正确！");
													pro.dismiss();
												}
												else
												{
													Util.error(LoginActivity.this, "注册失败：" + p2);
													pro.dismiss();
												}
											}
										});
								}
								else
								{
								}
							}
						});
				}
				catch (Exception e)
				{}
			}
		}
	}
}
