package com.duhuang.jsbbs;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v7.app.*;
import android.view.*;

public class MainActivity extends AppCompatActivity 
{
	private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
		"android.permission.READ_EXTERNAL_STORAGE",
		"android.permission.WRITE_EXTERNAL_STORAGE" };
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//去掉信息栏
		setContentView(R.layout.main);
		verifyStoragePermissions(this);

		//开启一个新线程
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					try
					{
						//3秒后跳转到登录界面
						Thread.sleep(3000);
						startActivity(new Intent(getApplicationContext(), LoginActivity.class));
						finish();//结束界面
					}
					catch (Exception e)
					{}
				}
			}).start();
    }

	public static void verifyStoragePermissions(Activity activity)
	{
		//获取系统sdk版本
		int version=Integer.valueOf(android.os.Build.VERSION.SDK);
		if (version >= 23)
		{
			try
			{
				//检测是否有写的权限
				int permission = ActivityCompat.checkSelfPermission(activity,
																	"android.permission.WRITE_EXTERNAL_STORAGE");
				if (permission != PackageManager.PERMISSION_GRANTED)
				{
					// 没有写的权限，去申请写的权限，会弹出对话框
					ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
