package com.duhuang.jsbbs;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.datatype.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;
import java.util.*;
import thereisnospon.codeview.*;

import android.support.v7.widget.Toolbar;

public class ShingCkTz extends AppCompatActivity
{
	private Toolbar toolbar;
	private TextView author,bk,time,title1;
	private CodeView message;
	private ImageView rz;
	private ImageView tx;
	private Button tj;
	private EditText nr;
	private ListView pl;
	private String aide;
	private LinearLayout code;
	private String tx1s;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.cktz);
		tj = (Button) findViewById(R.id.cktzButton1);
		nr = (EditText) findViewById(R.id.cktzEditText1);
		pl = (ListView) findViewById(R.id.cktzListView1);
		toolbar = (Toolbar) findViewById(R.id.cktzToolbar1);

		Bundle b=getIntent().getExtras();
		String title=b.getString("title");
		String message1=b.getString("message");
		String author1=b.getString("authors");
		String time1=b.getString("time");
		String bk1=b.getString("bk");
		Boolean rz1=b.getBoolean("rz");
		tx1s = b.getString("tx");
		aide = b.getString("aide");

		View v= getLayoutInflater().inflate(R.layout.comment_item2, null);

		author = (TextView) v.findViewById(R.id.cktzTextView1);
		bk = (TextView) v.findViewById(R.id.cktzTextView2);
		time = (TextView) v.findViewById(R.id.cktzTextView3);
		message = (CodeView) v.findViewById(R.id.codeview);
		title1 = (TextView) v.findViewById(R.id.cktzTextView5);
		rz = (ImageView) v.findViewById(R.id.cktzImageView2);
		tx = (ImageView) v.findViewById(R.id.cktzImageView1);
		code = (LinearLayout) v.findViewById(R.id.cktzLinearLayout1);

		//这边就是代码显示的地方
		pl.addHeaderView(v);
		
		//设置适配器
		List<Comment>data=new ArrayList<>();
		pl.setAdapter(new MyAdapter(data, getApplicationContext()));

		//发表评论
		tj.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					if (nr.getText().toString().trim().isEmpty())
					{
						Util.error(getApplicationContext(), "请填写评论内容");
					}
					else
					{
						MyUser user = BmobUser.getCurrentUser(MyUser.class);
						Post post = new Post();
						post.setObjectId(aide);
						Comment comment = new Comment();
						comment.setContent(nr.getText().toString());
						comment.setPost(post);
						comment.setAuthor(user);
						comment.save(new SaveListener<String>() {
								@Override
								public void done(String s, BmobException e)
								{
									if (e == null)
									{
										Util.success(getApplicationContext(), "评论成功");
										ShingCkTz.this.recreate();//重新加载Activity
										nr.setText(null);
									}
									else
									{
										Util.error(getApplicationContext(), "评论失败");
									}
								}
							});
					}
				}
			});

		if (rz1 == true)
		{
			rz.setVisibility(View.VISIBLE);
		}
		else
		{
			rz.setVisibility(View.GONE);
		}

		author.setText(author1);
		time.setText(time1);
		bk.setText(bk1);
		title1.setText(title);

		read();

		if (THEME == true)
		{
			message.setTheme(CodeViewTheme.ARDUINO_LIGHT);
			code.setBackgroundResource(android.R.color.white);
			message.fillColor();
			message.showCode(message1);
			message.clearFocus();
			message.setFocusable(true);
			message.setFocusableInTouchMode(true);
			toolbar.setBackgroundResource(R.color.colorPrimary);
			tj.setBackgroundResource(R.color.colorAccent);
		}
		else
		{
			message.setTheme(CodeViewTheme.ANDROIDSTUDIO);
			code.setBackgroundResource(android.R.color.black);
			message.fillColor();
			message.showCode(message1);
			message.clearFocus();
			message.setFocusable(true);
			message.setFocusableInTouchMode(true);
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
			tj.setBackgroundResource(R.color.nightColorPrimary);
		}

		String cc=tx1s;
		ImageRequest imageRequest=new ImageRequest(cc, new Response.Listener<Bitmap>() 
			{
				@Override
				public void onResponse(Bitmap response)
				{
					tx.setImageBitmap(response);
				}
			}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
				@Override
				public void onErrorResponse(VolleyError error)
				{
					tx.setImageResource(R.drawable.beij18);//失败用这张图片
				}
			});

		RequestQueue mQueue = Volley.newRequestQueue(ShingCkTz.this);//创建一个volley队列
		mQueue.add(imageRequest);//加入队列 开始下载

		toolbar.setTitle(bk1);
		setSupportActionBar(toolbar);
		toolbar.setNavigationIcon(R.drawable.back);
		toolbar.setNavigationOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});
	}

	private void read()
	{
		//查询评论
		BmobQuery<Comment> query = new BmobQuery<>();
        Post post  = new Post();
        post.setObjectId(aide);
        query.addWhereEqualTo("post", new BmobPointer(post));
        // 希望查询到评论发布者的具体信息 用下内部查询
        // 这里稍复杂些 查询评论发布者的信息 和 帖子作者的信息 参见include的并列对象查询和内嵌对象的查询
        query.include("author");
        query.findObjects(new FindListener<Comment>() {
				@Override
				public void done(List<Comment> list, BmobException e)
				{
					if (e == null)
					{
						//创建集合放审核通过的帖子
						List<Comment>data=new ArrayList<>();
						for (Comment cm:list)
						{
							data.add(cm);
						}

						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, ShingCkTz.this);
							pl.setAdapter(adapter);

							//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							pl.setLayoutAnimation(controller);
						}
						else
						{
							//没有审核通过的帖子
						}
					}
					else
					{
					}
				}
			});
	}

	class MyAdapter extends BaseAdapter
	{
		private List<Comment>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Comment>list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			final ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.comment_item, null);

				holder.tx = (imageview) convertView.findViewById(R.id.commentitemRelativeLayout1);
				holder.username = (TextView) convertView.findViewById(R.id.commentitemTextView1);
				holder.lou = (TextView) convertView.findViewById(R.id.commentitemTextView2);
				holder.date = (TextView) convertView.findViewById(R.id.commentitemTextView4);
				holder.plcontent = (TextView) convertView.findViewById(R.id.commentitemTextView3);

				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			Comment am=list.get(position);

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/            
			holder.username.setText(am.getAuthor().getUsername());
			holder.date.setText(am.getCreatedAt());
			holder.plcontent.setText(am.getContent());

			//评论楼层
			int x=position + 1;
			String s=String.valueOf(x);
			holder.lou.setText(s + "楼");

			//加载作者头像
			ImageRequest imageRequest=new ImageRequest(am.getAuthor().getTx(), new Response.Listener<Bitmap>() 
				{
					@Override
					public void onResponse(Bitmap response)
					{
						holder.tx.setImageBitmap(response);
					}
				}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error)
					{
						holder.tx.setImageResource(R.drawable.beij18);//失败用这张图片
					}
				});
			RequestQueue mQueue = Volley.newRequestQueue(ShingCkTz.this);//创建一个volley队列
			mQueue.add(imageRequest);//加入队列 开始下载
			return convertView;
		}

		class ViewHolder
		{
			public imageview tx;
			public TextView username;
			public TextView lou;
			public TextView date;
			public TextView plcontent;
		}
	}
}
