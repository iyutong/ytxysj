package com.duhuang.jsbbs.bmob;
import cn.bmob.v3.*;
import cn.bmob.v3.datatype.*;

public class Crash extends BmobObject
{
	private BmobFile log;
	private String url;


	public void setLog(BmobFile log)
	{
		this.log = log;
	}

	public BmobFile getLog()
	{
		return log;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getUrl()
	{
		return url;
	}}
