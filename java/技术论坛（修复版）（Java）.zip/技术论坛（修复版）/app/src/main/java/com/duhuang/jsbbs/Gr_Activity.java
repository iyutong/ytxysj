package com.duhuang.jsbbs;
import android.content.*;
import android.database.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.datatype.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;

import android.support.v7.widget.Toolbar;

public class Gr_Activity extends AppCompatActivity
{
	private Toolbar toolbar;
	private ImageView tp;
	private TextView author,email,registerDate,updateDate;
	private Button update;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.gr_activity);
		toolbar = (Toolbar) findViewById(R.id.grToolbar1);
		toolbar.setTitle("个人中心");
		author = (TextView) findViewById(R.id.grTextView1);
		tp = (ImageView) findViewById(R.id.grImageView1);
		email = (TextView) findViewById(R.id.grTextView2);
		registerDate = (TextView) findViewById(R.id.grTextView4);
		updateDate = (TextView) findViewById(R.id.grTextView5);
		update = (Button) findViewById(R.id.grButton);

		if (THEME == true)
		{
			update.setBackgroundResource(R.color.colorAccent);
			toolbar.setBackgroundResource(R.color.colorPrimary);
		}
		else
		{
			update.setBackgroundResource(R.color.nightColorPrimary);
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
		}

		update.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					startActivity(new Intent(Gr_Activity.this, UpdateXx.class));
				}
			});

		tp.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//打开相册
					startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("image/*"), 2);
				}
			});

		read();//加载资料
		mTx();//加载头像
	}

	private void mTx()
	{
		// TODO: Implement this metho
		MyUser user=BmobUser.getCurrentUser(MyUser.class);
		if (user.getTx() == null || user.getIcon() == null)
		{
			tp.setImageResource(R.drawable.beij18);
		}
		else
		{
			BmobFile bb=user.getIcon();
			String cc=bb.getFileUrl();
			ImageRequest imageRequest=new ImageRequest(cc, new Response.Listener<Bitmap>() {
					@Override
					public void onResponse(Bitmap response)
					{
						tp.setImageBitmap(response);
					}
				}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error)
					{
						tp.setImageResource(R.drawable.beij18);//失败用这张图片
					}
				});
			RequestQueue mQueue = Volley.newRequestQueue(Gr_Activity.this);//创建一个volley队列
			mQueue.add(imageRequest);//加入队列 开始下载
			// Toast.makeText(MainActivity.this, "下载成功", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		switch (requestCode)
		{
			case 2:
				if (resultCode == RESULT_OK)
				{
					if (Build.VERSION.SDK_INT >= 19)
					{
						//4.4以上系统使用这个方法处理图片
						handleImageOnKitKat(data);
					}
					else
					{
						//4.4以下系统使用这个方法处理图片
						handleImageBeforeKitKat(data);
					}
				}
				break;
		}
	}

	private void handleImageOnKitKat(Intent data)
	{
		String imagePath=null;
		Uri uri=data.getData();
		if (DocumentsContract.isDocumentUri(this, uri))
		{
			//如果是document类型的uri，则通过document id处理
			String docId=DocumentsContract.getDocumentId(uri);
			if ("com android.providers.media.documents".equals(uri.getAuthority()))
			{
				String id=docId.split(":")[1];
				String selection=MediaStore.Images.Media._ID + "=" + id;
				imagePath = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, selection);
			}
			else if ("com.android.providers.downloads.documents".equals(uri.getAuthority()))
			{
				Uri contentUri=ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(docId));
				imagePath = getImagePath(contentUri, null);
			}
		}
		else if ("content".equalsIgnoreCase(uri.getScheme()))
		{
			imagePath = getImagePath(uri, null);
		}
		else if ("file".equalsIgnoreCase(uri.getScheme()))
		{
			imagePath = uri.getPath();
		}
		displayImage(imagePath);
		updateTp(imagePath);//上传头像
	}

	private void handleImageBeforeKitKat(Intent data)
	{
		Uri uri=data.getData();
		String imagePath=getImagePath(uri, null);
		displayImage(imagePath);
		updateTp(imagePath);
	}

	private void displayImage(String imagePath)
	{
		if (imagePath != null)
		{
			Bitmap bitmap=BitmapFactory.decodeFile(imagePath);
			tp.setImageBitmap(bitmap);
		}
		else
		{

		}
	}

	private String getImagePath(Uri uri, String p1)
	{
		String path=null;
		Cursor cursor=getContentResolver().query(uri, null, p1, null, null);
		if (cursor != null)
		{
			if (cursor.moveToFirst())
			{
				path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
			}
			cursor.close();
		}
		return path;
	}

	public void updateTp(String Filepath)
	{
		try
		{
			final BmobFile bmobFile=new BmobFile(new File(Filepath));
			//上传成功
			bmobFile.upload(new UploadFileListener() {

					@Override
					public void done(BmobException p1)
					{
						if (p1 == null)
						{
							String url=bmobFile.getFileUrl();
							MyUser mu=new MyUser();
							MyUser m=BmobUser.getCurrentUser(MyUser.class);
							mu.setTx(url);
							mu.setIcon(bmobFile);
							mu.update(m.getObjectId(), new UpdateListener(){

									@Override
									public void done(BmobException p1)
									{
										// TODO: Implement this method
										if (p1 == null)
										{
											Util.success(Gr_Activity.this, "上传头像成功");
										}
										else
										{
											Util.error(Gr_Activity.this, "上传头像失败" + p1);
										}
									}
								});
						}
						else
						{
							Util.error(Gr_Activity.this, "上传头像失败" + p1);
						}
					}
				});
		}
		catch (Exception e)
		{}
	}

	private void read()
	{
		// TODO: Implement this method
		MyUser mu=BmobUser.getCurrentUser(MyUser.class);
		author.setText(mu.getUsername());
		email.setText("用户邮箱：" + mu.getEmail());
		registerDate.setText("用户注册日期：" + mu.getCreatedAt());
		updateDate.setText("最后操作日期：" + mu.getUpdatedAt());
	}

}

