package com.duhuang.jsbbs;
import android.content.*;
import es.dmoral.toasty.*;

public class Util
{
	public static void success(Context c, String nr)
	{
		Toasty.success(c, nr).show();
	}

	public static void error(Context c, String nr)
	{
		Toasty.error(c, nr).show();
	}

	public static void warning(Context c, String nr)
	{
		Toasty.warning(c, nr).show();
	}
}
