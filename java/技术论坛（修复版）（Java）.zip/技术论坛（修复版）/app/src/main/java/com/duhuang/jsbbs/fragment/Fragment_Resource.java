package com.duhuang.jsbbs.fragment;
import android.app.*;
import android.content.*;
import android.database.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v4.widget.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.ashokvarma.bottomnavigation.*;
import com.duhuang.jsbbs.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import android.support.v4.app.Fragment;
import com.ashokvarma.bottomnavigation.R;

public class Fragment_Resource extends Fragment implements OnClickListener
{
	private SwipeRefreshLayout sr;
	private ListView lv;
	private long mTaskId;
	private DownloadManager downloadManager;
	private LinearLayout game,resources,jingpin,ym;
	private LinearLayout top,l;
	private View view;
	private TextView net;
	private ProgressBar pro;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		View v=inflater.inflate(R.layout.fragment_resource, container, false);
		sr = (SwipeRefreshLayout) v.findViewById(R.id.swipe_1);
		lv = (ListView) v.findViewById(R.id.fragment_resourceListView1);
		game = (LinearLayout) v.findViewById(R.id.fragmentresourceLinearLayout1);
		resources = (LinearLayout) v.findViewById(R.id.fragmentresourceLinearLayout2);
		jingpin = (LinearLayout) v.findViewById(R.id.fragmentresourceLinearLayout3);
		ym = (LinearLayout) v.findViewById(R.id.fragmentresourceLinearLayout4);
		top = (LinearLayout) v.findViewById(R.id.fragment_resourceLinearLayout);
		view = v.findViewById(R.id.fragmentresourceView1);
		net = (TextView) v.findViewById(R.id.fragment_resourceTextView);
		pro = (ProgressBar) v.findViewById(R.id.fragment_resourceProgressBar);
		l = (LinearLayout) v.findViewById(R.id.fragmentresourceLinearLayout5);

		game.setOnClickListener(this);
		resources.setOnClickListener(this);
		jingpin.setOnClickListener(this);
		ym.setOnClickListener(this);

		SharedPreferences settings=getActivity().getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			getActivity().setTheme(R.style.AppTheme);
			top.setBackgroundResource(android.R.color.white);
			l.setBackgroundColor(Color.parseColor("#EEEEEE"));
		}
		else
		{
			getActivity().setTheme(R.style.NightAppTheme);
			top.setBackgroundResource(R.color.nightColorPrimary);
		}

		mSwipe();
		mRead();
		return v;
	}

	@Override
	public void onClick(View p1)
	{
		switch (p1.getId())
		{
			case R.id.fragmentresourceLinearLayout1:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentresourceLinearLayout2:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentresourceLinearLayout3:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentresourceLinearLayout4:
				startActivity(new Intent(getContext(), ResourcesYm.class));
				break;
		}
	}

	private void mRead()
	{
// TODO: Implement this method
		BmobQuery<Resources> query=new BmobQuery<Resources>();
		query.addWhereEqualTo("id", "源码");
		query.setMaxCacheAge(TimeUnit.DAYS.toMillis(7));//此表示缓存一天
		query.order("-createdAt");//依照maps排序时间排序
//返回50条maps，如果不加上这条语句，默认返回10条maps
		query.setLimit(50);
		query.setCachePolicy(BmobQuery.CachePolicy.NETWORK_ELSE_CACHE);
		query.findObjects(new FindListener<Resources>() {

				@Override
				public void done(List<Resources> p1, BmobException p2)
				{
					if (p2 == null)
					{
						sr.setVisibility(View.VISIBLE);
						view.setVisibility(View.VISIBLE);
						top.setVisibility(View.VISIBLE);
						sr.setRefreshing(false);
// TODO Auto-generated method stub
//创建集合放审核通过的帖子
						List<Resources>data=new ArrayList<>();
						for (Resources rs:p1)
						{
							data.add(rs);
						}

						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, getContext());
							lv.setAdapter(adapter);

//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							lv.setLayoutAnimation(controller);
						}
					}
					else
					{
						pro.setVisibility(View.GONE);
						net.setVisibility(View.VISIBLE);
						sr.setRefreshing(false);
					}
				}
			});
	}

	private void mSwipe()
	{
// TODO: Implement this method
		sr.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
		sr.setEnabled(true);
		sr.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

				@Override
				public void onRefresh()
				{
//sr.setRefreshing(false);
					(new Handler()).postDelayed(new Runnable() {

							@Override
							public void run()
							{
								mRead();
							}

						}, 1000);
				}
			});
	}

//内部类MyAdapter
	class MyAdapter extends BaseAdapter
	{
		private List<Resources>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Resources> list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.resource_list, null);
				holder.name = (TextView) convertView.findViewById(R.id.resourcelistTextView1);
				holder.style = (TextView) convertView.findViewById(R.id.resourcelistTextView2);
				holder.size = (TextView) convertView.findViewById(R.id.resourcelistTextView3);
				holder.download = (Button) convertView.findViewById(R.id.resourcelistButton1);
				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			final Resources pes=list.get(position);

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/
			holder.name.setText(pes.getName());
			holder.style.setText(pes.getStyle());
			holder.size.setText(pes.getSize());

			holder.download.setOnClickListener(new OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						//使用系统下载
						download(pes.getUrl(), pes.getName() + ".zip");
						Util.warning(getActivity(), "正在下载...");

						/*final AlertDialog ad=new AlertDialog.Builder(getContext()).create();
						 ad.show();
						 Window window = ad.getWindow();  
						 window.setContentView(R.layout.download); 
						 WindowManager m = getActivity().getWindowManager();
						 Display d = m.getDefaultDisplay(); // 获取屏幕宽、高度
						 WindowManager.LayoutParams params = window.getAttributes();  
						 params.width = (int) (d.getWidth() * 0.8);
						 window.setAttributes(params);//此句代码一定要放在show()后面，否则不起作用  
						 ad.setCanceledOnTouchOutside(false); 
						 final TextView xz=(TextView) window.findViewById(R.id.xz);

						 final Download down=new Download();
						 down.setondown(new Download.ondown()
						 {
						 @Override
						 public void downing(int len, int oklen)
						 {
						 xz.setText("下载进度：" + (int)(((double)oklen / (double)len) * 100) + "%");
						 }
						 @Override
						 public void downok(String ruest)
						 {
						 ad.dismiss();
						 Util.success(getContext(), "下载完成\n/sdcard/技术论坛/文件下载/源码/" + pes.getName() + ".zip");
						 }
						 });
						 down.dowmFile(pes.getUrl(), "/sdcard/技术论坛/文件下载/源码/" + pes.getName() + ".zip");
						 */
					}
				});
			return convertView;
		}

		class ViewHolder
		{
			public TextView name;
			public TextView style;
			public TextView size;
			public Button download;
		}
	}

	//使用系统下载器下载
	private void download(String versionUrl, String versionName)
	{
        //创建下载任务
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(versionUrl));
        request.setAllowedOverRoaming(true);//漫游网络是否可以下载

        //设置文件类型，可以在下载结束后自动打开该文件
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        String mimeString = mimeTypeMap.getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(versionUrl));
        request.setMimeType(mimeString);

        //在通知栏中显示，默认就是显示的
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setVisibleInDownloadsUi(true);

        //文件下载路径，必须设置
        request.setDestinationInExternalPublicDir("/技术论坛/文件下载/源码/", versionName);
        //request.setDestinationInExternalFilesDir(getContext(), "/技术论坛/文件下载/", versionName);//也可以自己制定下载路径

        //将下载请求加入下载队列
        downloadManager = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
        //加入下载队列后会给该任务返回一个long型的id，
        //通过该id可以取消任务，重启任务等等，看上面源码中框起来的方法
		mTaskId = downloadManager.enqueue(request);


		// 获取下载管理器服务的实例
		DownloadManager manager = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);

// 创建一个查询对象
		DownloadManager.Query query = new DownloadManager.Query();

// 根据 下载ID 过滤结果
		query.setFilterById(mTaskId);

// 还可以根据状态过滤结果
// query.setFilterByStatus(DownloadManager.STATUS_SUCCESSFUL);

// 执行查询, 返回一个 Cursor (相当于查询数据库)
		Cursor cursor = manager.query(query);

		if (!cursor.moveToFirst())
		{
			cursor.close();
			return;
		}

// 下载ID
		long id = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_ID));
// 下载请求的状态
		int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
// 下载文件在本地保存的路径（Android 7.0 以后 COLUMN_LOCAL_FILENAME 字段被弃用, 需要用 COLUMN_LOCAL_URI 字段来获取本地文件路径的 Uri）
		String localFilename = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
// 已下载的字节大小
		long downloadedSoFar = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
// 下载文件的总字节大小
		long totalSize = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

		cursor.close();

		System.out.println("下载进度: " + downloadedSoFar  + "/" + totalSize);

		/*
		 * 判断是否下载成功，其中状态 status 的值有 5 种:
		 *     DownloadManager.STATUS_SUCCESSFUL:   下载成功
		 *     DownloadManager.STATUS_FAILED:       下载失败
		 *     DownloadManager.STATUS_PENDING:      等待下载
		 *     DownloadManager.STATUS_RUNNING:      正在下载
		 *     DownloadManager.STATUS_PAUSED:       下载暂停
		 */
		if (status == DownloadManager.STATUS_SUCCESSFUL)
		{
			/*
			 * 特别注意: 查询获取到的 localFilename 才是下载文件真正的保存路径，在创建
			 * 请求时设置的保存路径不一定是最终的保存路径，因为当设置的路径已是存在的文件时，
			 * 下载器会自动重命名保存路径，例如: .../demo-1.apk, .../demo-2.apk
			 */
			Util.success(getContext(), "下载成功,文件路径：" + localFilename);
		}
    }

	public static Fragment_Resource newInstance()
	{
		Fragment_Resource fr=new Fragment_Resource();
		return fr;
	}

}
