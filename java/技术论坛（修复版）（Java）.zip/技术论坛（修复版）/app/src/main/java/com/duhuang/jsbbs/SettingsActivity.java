package com.duhuang.jsbbs;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;

import android.support.v7.widget.Toolbar;

public class SettingsActivity extends AppCompatActivity implements OnClickListener
{
	@Override
	public void onClick(View p1)
	{
		switch(p1.getId())
		{
			case R.id.settingsRelativeLayout1:
				MyUser.logOut();//清除缓存对象
				startActivity(new Intent(getApplicationContext(), LoginActivity.class));
				finish();
				break;
		}
	}
	
	private RelativeLayout exit;
	private Toolbar toolbar;
	private LinearLayout l;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.settings);
		exit = (RelativeLayout) findViewById(R.id.settingsRelativeLayout1);
		toolbar = (Toolbar) findViewById(R.id.settingsToolbar1);
		l = (LinearLayout) findViewById(R.id.settingsLinearLayout);
		toolbar.setTitle("设置");
		setSupportActionBar(toolbar);
		toolbar.setNavigationIcon(R.drawable.back);
		toolbar.setNavigationOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});

		exit.setOnClickListener(this);

		if (THEME)
		{
			toolbar.setBackgroundResource(R.color.colorPrimary);
			exit.setBackgroundResource(android.R.color.white);
			l.setBackgroundColor(Color.parseColor("#EEEEEE"));
		}
		else
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
			exit.setBackgroundResource(R.drawable.item_selector);
		}
	}
}
