package com.duhuang.jsbbs;
import android.content.*;
import android.os.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

import android.support.v7.widget.Toolbar;

public class ResourcesYm extends AppCompatActivity
{
	private Toolbar toolbar;
	private ListView lv;
	private SwipeRefreshLayout sr;
	private ProgressBar pro;
	private TextView net;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.resources_ym);
		sr = (SwipeRefreshLayout) findViewById(R.id.resourcesSwipeRefreshLayout1);
		lv = (ListView) findViewById(R.id.resourcesListView1);
		toolbar = (Toolbar) findViewById(R.id.resourcesToolbar1);
		pro = (ProgressBar) findViewById(R.id.resources_ymProgressBar);
		net = (TextView) findViewById(R.id.resources_ymTextView);
		
		if(THEME==false)
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
		}

		toolbar.setTitle("源码");
		toolbar.setNavigationIcon(R.drawable.back);
		setSupportActionBar(toolbar);
		toolbar.setNavigationOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					finish();
				}
			});
		mSwipe();
		mRead();
	}

	private void mRead()
	{
		// TODO: Implement this method
		BmobQuery<Resources> query=new BmobQuery<Resources>();
		query.addWhereEqualTo("id", "源码");
		query.setMaxCacheAge(TimeUnit.DAYS.toMillis(7));//此表示缓存一天
		query.order("-createdAt");//依照maps排序时间排序
		//返回50条maps，如果不加上这条语句，默认返回10条maps
		query.setLimit(50);
		query.setCachePolicy(BmobQuery.CachePolicy.NETWORK_ELSE_CACHE);
		query.findObjects(new FindListener<Resources>() {

				@Override
				public void done(List<Resources> p1, BmobException p2)
				{
					if (p2 == null)
					{
						pro.setVisibility(View.GONE);
						sr.setVisibility(View.VISIBLE);
						sr.setRefreshing(false);
						// TODO Auto-generated method stub
						//创建集合放审核通过的帖子
						List<Resources>data=new ArrayList<>();
						for (Resources rs:p1)
						{
							data.add(rs);
						}

						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, ResourcesYm.this);
							lv.setAdapter(adapter);

							//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							lv.setLayoutAnimation(controller);
						}
					}
					else
					{
						pro.setVisibility(View.GONE);
						net.setVisibility(View.VISIBLE);
						sr.setRefreshing(false);
					}
				}
			});
	}

	//内部类MyAdapter
	class MyAdapter extends BaseAdapter
	{
		private List<Resources>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Resources> list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.resource_list, null);
				holder.name = (TextView) convertView.findViewById(R.id.resourcelistTextView1);
				holder.style = (TextView) convertView.findViewById(R.id.resourcelistTextView2);
				holder.size = (TextView) convertView.findViewById(R.id.resourcelistTextView3);
				holder.download = (Button) convertView.findViewById(R.id.resourcelistButton1);
				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			final Resources pes=list.get(position);

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/            
			holder.name.setText(pes.getName());
			holder.style.setText(pes.getStyle());
			holder.size.setText(pes.getSize());

			holder.download.setOnClickListener(new OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						final AlertDialog ad=new AlertDialog.Builder(ResourcesYm.this).create();
						ad.show();
						Window window = ad.getWindow();  
						window.setContentView(R.layout.download); 
						WindowManager m = ResourcesYm.this.getWindowManager();
						Display d = m.getDefaultDisplay(); // 获取屏幕宽、高度
						WindowManager.LayoutParams params = window.getAttributes();  
						params.width = (int) (d.getWidth() * 0.8);
						window.setAttributes(params);//此句代码一定要放在show()后面，否则不起作用  
						ad.setCanceledOnTouchOutside(false); 
						final TextView xz=(TextView) window.findViewById(R.id.xz);

						final Download down=new Download();
						down.setondown(new Download.ondown()
							{
								@Override
								public void downing(int len, int oklen)
								{
									xz.setText("下载进度：" + (int)(((double)oklen / (double)len) * 100) + "%");
								}
								@Override
								public void downok(String ruest)
								{
									ad.dismiss();
									Util.success(ResourcesYm.this, "下载完成\n/sdcard/技术论坛/文件下载/源码/" + pes.getName() + ".zip");
								}
							});
						down.dowmFile(pes.getUrl(), "/sdcard/技术论坛/文件下载/源码/" + pes.getName() + ".zip");
					}
				});
			return convertView;
		}

		class ViewHolder
		{
			public TextView name;
			public TextView style;
			public TextView size;
			public Button download;
		}
	}

	//下拉刷新
	private void mSwipe()
	{
		// TODO: Implement this method
		sr.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
		sr.setEnabled(true);
		sr.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

				@Override
				public void onRefresh()
				{
					//sr.setRefreshing(false);
					(new Handler()).postDelayed(new Runnable() {

							@Override
							public void run()
							{
								//加载资源
								mRead();
							}

						}, 1000);
				}
			});
	}
}
