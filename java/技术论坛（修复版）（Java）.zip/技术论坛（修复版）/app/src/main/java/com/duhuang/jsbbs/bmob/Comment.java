package com.duhuang.jsbbs.bmob;
import cn.bmob.v3.*;

public class Comment extends BmobObject
{
	private String content;
	private MyUser author;
	private Post post;

	public void setPost(Post post)
	{
		this.post = post;
	}

	public Post getPost()
	{
		return post;
	}


	public void setContent(String content)
	{
		this.content = content;
	}

	public String getContent()
	{
		return content;
	}

	public void setAuthor(MyUser author)
	{
		this.author = author;
	}

	public MyUser getAuthor()
	{
		return author;
	}
}
