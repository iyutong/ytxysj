package com.duhuang.jsbbs;

import android.content.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;

import android.support.v7.widget.Toolbar;

public class UpdateXx extends AppCompatActivity
{
	private EditText ed1;
	private Button b;
	private Toolbar toolbar;
	private LinearLayout e;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.updatexx);
		ed1 = (EditText) findViewById(R.id.updatexxEditText1);
		toolbar = (Toolbar) findViewById(R.id.updatexxToolbar1);
		e = (LinearLayout) findViewById(R.id.updatexxLinearLayout1);
		toolbar.setTitle("编辑资料");
		b = (Button) findViewById(R.id.updatexxButton1);

		if (THEME)
		{
			toolbar.setBackgroundResource(R.color.colorPrimary);
			b.setBackgroundResource(R.color.colorAccent);
		}
		else
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
			b.setBackgroundResource(R.color.nightColorPrimary);
			e.setBackgroundResource(R.color.nightColorPrimary);
		}

		b.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					MyUser mu=new MyUser();
					MyUser m=BmobUser.getCurrentUser(MyUser.class);
					mu.setUsername(ed1.getText().toString().trim());
					mu.update(m.getObjectId(), new UpdateListener(){

							@Override
							public void done(BmobException p1)
							{
								// TODO: Implement this method
								if (p1 == null)
								{
									Util.success(UpdateXx.this, "修改成功");
									finish();
								}
								else
								{
									Util.error(UpdateXx.this, "修改失败" + p1);
								}
							}
						});
				}
			});
	}

}

