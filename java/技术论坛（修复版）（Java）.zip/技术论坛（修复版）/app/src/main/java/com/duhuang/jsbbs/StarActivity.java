package com.duhuang.jsbbs;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;
import android.widget.AdapterView.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.bmob.*;
import java.io.*;
import java.util.*;

import android.support.v7.widget.Toolbar;
import android.view.View.OnClickListener;

public class StarActivity extends AppCompatActivity implements OnItemClickListener
{
	@Override 
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
	{
		Post am=(Post) lv.getAdapter().getItem(position);
		Bundle bd=new Bundle();
		bd.putString("title", am.getTitle());
		bd.putString("message", am.getMessage());
		bd.putString("authors", am.getAuthors().getUsername());
		bd.putString("time", am.getCreatedAt());
		bd.putString("bk", am.getBk());
		bd.putBoolean("rz", am.getRz());
		bd.putString("tx", am.getAuthors().getTx());
		bd.putString("aide", am.getObjectId());

		Intent intent = new Intent();
		intent.setClass(this, StarCkTz.class);
		intent.putExtras(bd);
		startActivity(intent);
	}

	private Toolbar toolbar;
	private ListView lv;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		SharedPreferences settings=this.getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			this.setTheme(R.style.AppTheme);
		}
		else
		{
			this.setTheme(R.style.NightAppTheme);
		}
		setContentView(R.layout.my_star);
		toolbar = (Toolbar) findViewById(R.id.starToolbar1);
		lv = (ListView) findViewById(R.id.mystarListView1);
		lv.setOnItemClickListener(this);

		toolbar.setTitle("我的收藏");
		setSupportActionBar(toolbar);
		toolbar.setNavigationIcon(R.drawable.back);
		toolbar.setNavigationOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					finish();
				}
			});

		if (THEME == true)
		{
			toolbar.setBackgroundResource(R.color.colorPrimary);
		}
		else
		{
			toolbar.setBackgroundResource(R.color.nightColorPrimary);
		}

		read();
	}

	private void read()
	{
		MyUser m=BmobUser.getCurrentUser(MyUser.class);
		BmobQuery<Post> query=new BmobQuery<>();
		query.addWhereEqualTo("likes", m);
		query.include("authors");
		query.findObjects(new FindListener<Post>(){

				@Override
				public void done(List<Post> p1, BmobException p2)
				{
					if (p2 == null)
					{
						//创建集合放审核通过的帖子
						List<Post>data=new ArrayList<>();
						for (Post p:p1)
						{
							if (p.getSh() == true)
							{
								data.add(p);//审核通过放入新集合
							}
							else
							{
								//审核不通过
							}
						}
						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, StarActivity.this);
							lv.setAdapter(adapter);

							//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							lv.setLayoutAnimation(controller);
						}
						else
						{
							//没有审核通过的帖子
						}
					}
					else
					{
						Util.error(StarActivity.this, "加载失败");
					}
				}
			});
	}

	//内部类MyAdapter
	class MyAdapter extends BaseAdapter
	{
		private List<Post>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Post>list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			final ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.item_1, null);

				holder.tp = (RelativeLayout) convertView.findViewById(R.id.item1RelativeLayout1);
				holder.authorTx = (ImageView) convertView.findViewById(R.id.item1ImageView1);
				holder.rz = (ImageView) convertView.findViewById(R.id.item1ImageView2);
				holder.title = (TextView) convertView.findViewById(R.id.item1TextView2);
				holder.message = (TextView) convertView.findViewById(R.id.item1TextView3);
				holder.author = (TextView) convertView.findViewById(R.id.item1TextView4);
				holder.time = (TextView) convertView.findViewById(R.id.item1TextView5);
				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			Post am=list.get(position);

			Boolean rz=am.getRz();
			//如果为true则认证
			if (rz == true)
			{
				holder.rz.setVisibility(View.VISIBLE);
			}
			else if (rz == false)
			{
				holder.rz.setVisibility(View.GONE);
			}

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/            
			holder.title.setText(am.getTitle());
			holder.message.setText(am.getMessage());
			holder.author.setText(am.getAuthors().getUsername());
			holder.time.setText(am.getCreatedAt());

			//加载作者头像
			ImageRequest imageRequest=new ImageRequest(am.getAuthors().getTx(), new Response.Listener<Bitmap>() 
				{
					@Override
					public void onResponse(Bitmap response)
					{
						holder.authorTx.setImageBitmap(response);
					}
				}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error)
					{
						holder.authorTx.setImageResource(R.drawable.beij18);//失败用这张图片
					}
				});
			RequestQueue mQueue = Volley.newRequestQueue(StarActivity.this);//创建一个volley队列
			mQueue.add(imageRequest);//加入队列 开始下载
			return convertView;
		}

		class ViewHolder
		{
			public RelativeLayout tp;
			public ImageView rz;
			public ImageView authorTx;
			public TextView title;
			public TextView message;
			public TextView author;
			public TextView time;
		}
	}

}
