package com.duhuang.jsbbs.fragment;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v4.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.*;
import com.duhuang.jsbbs.bmob.*;
import com.duhuang.jsbbs.plate.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class Fragment_Community extends Fragment implements OnClickListener
{
	private LinearLayout top,aide,syrj,iapp,java,lua,bmob,xtgg,yj,gd,post,vis;
	private ImageView rz,tx;
	private TextView title,nr,author,date;
	private ProgressBar pro;
	private TextView net;
	private View v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		View view=inflater.inflate(R.layout.fragment_community, container, false);
		aide = (LinearLayout) view.findViewById(R.id.aide);
		syrj = (LinearLayout) view.findViewById(R.id.syrj);
		iapp = (LinearLayout) view.findViewById(R.id.iapp);
		java = (LinearLayout) view.findViewById(R.id.java);
		lua = (LinearLayout) view.findViewById(R.id.lua);
		bmob = (LinearLayout) view.findViewById(R.id.bmob);
		xtgg = (LinearLayout) view.findViewById(R.id.xtgg);
		yj = (LinearLayout) view.findViewById(R.id.yjfk);
		post = (LinearLayout) view.findViewById(R.id.fragmentcommunityLinearLayout3);
		gd = (LinearLayout) view.findViewById(R.id.fragmentcommunityLinearLayout2);
		rz = (ImageView) view.findViewById(R.id.fragmentcommunityImageView1);
		tx = (imageview) view.findViewById(R.id.fragmentcommunityimageview1);
		title = (TextView) view.findViewById(R.id.fragmentcommunityTextView1);
		nr = (TextView) view.findViewById(R.id.fragmentcommunityTextView2);
		author = (TextView) view.findViewById(R.id.fragmentcommunityTextView3);
		date = (TextView) view.findViewById(R.id.fragmentcommunityTextView4);
		vis = (LinearLayout) view.findViewById(R.id.fragmentcommunityLinearLayout4);
		pro = (ProgressBar) view.findViewById(R.id.fragment_communityProgressBar);
		net = (TextView) view.findViewById(R.id.fragment_communityTextView);
		top = (LinearLayout) view.findViewById(R.id.fragmentcommunityLinearLayout3);

		v1 = view.findViewById(R.id.fragmentcommunityView1);
		v2 = view.findViewById(R.id.fragmentcommunityView2);
		v3 = view.findViewById(R.id.fragmentcommunityView3);
		v4 = view.findViewById(R.id.fragmentcommunityView4);
		v5 = view.findViewById(R.id.fragmentcommunityView5);
		v6 = view.findViewById(R.id.fragmentcommunityView6);
		v7 = view.findViewById(R.id.fragmentcommunityView7);
		v8 = view.findViewById(R.id.fragmentcommunityView8);
		v9 = view.findViewById(R.id.fragmentcommunityView9);
		v10 = view.findViewById(R.id.fragmentcommunityView10);
		v11 = view.findViewById(R.id.fragmentcommunityView11);
		v12 = view.findViewById(R.id.fragmentcommunityView12);

		aide.setOnClickListener(this);
		syrj.setOnClickListener(this);
		iapp.setOnClickListener(this);
		java.setOnClickListener(this);
		lua.setOnClickListener(this);
		bmob.setOnClickListener(this);
		xtgg.setOnClickListener(this);
		yj.setOnClickListener(this);
		gd.setOnClickListener(this);
		post.setOnClickListener(this);

		SharedPreferences settings=getActivity().getSharedPreferences("INFO", 0);
		boolean THEME=settings.getBoolean("THEME", true);

		//判断配置文件是否存在
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
		}
		else
		{
			//不存在
			settings.edit().putBoolean("THEME", true).commit();
		}

		if (THEME == true)
		{
			vis.setBackgroundColor(Color.parseColor("#EEEEEE"));
			aide.setBackgroundResource(android.R.color.white);
			syrj.setBackgroundResource(android.R.color.white);
			bmob.setBackgroundResource(android.R.color.white);
			java.setBackgroundResource(android.R.color.white);
			lua.setBackgroundResource(android.R.color.white);
			iapp.setBackgroundResource(android.R.color.white);
			xtgg.setBackgroundResource(android.R.color.white);
			yj.setBackgroundResource(android.R.color.white);
			top.setBackgroundResource(android.R.color.white);
			post.setBackgroundResource(android.R.color.white);
			gd.setBackgroundResource(android.R.color.white);

			v1.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v2.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v3.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v4.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v5.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v6.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v7.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v8.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v9.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v10.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v11.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v12.setBackgroundColor(Color.parseColor("#EEEEEE"));
		}
		else
		{
			top.setBackgroundResource(R.drawable.item_selector);
			gd.setBackgroundResource(R.drawable.item_selector);
			aide.setBackgroundResource(R.drawable.item_selector);
			bmob.setBackgroundResource(R.drawable.item_selector);
			iapp.setBackgroundResource(R.drawable.item_selector);
			java.setBackgroundResource(R.drawable.item_selector);
			lua.setBackgroundResource(R.drawable.item_selector);
			syrj.setBackgroundResource(R.drawable.item_selector);
			xtgg.setBackgroundResource(R.drawable.item_selector);
			yj.setBackgroundResource(R.drawable.item_selector);
		}

		BmobQuery<Post> query=new BmobQuery<Post>();
		query.addWhereEqualTo("home", "true");
		query.setMaxCacheAge(TimeUnit.DAYS.toMillis(7));//此表示缓存一天
		query.order("-createdAt");//依照maps排序时间排序
		//返回50条maps，如果不加上这条语句，默认返回10条maps
		query.setLimit(50);
		query.include("authors");
		query.setCachePolicy(BmobQuery.CachePolicy.NETWORK_ELSE_CACHE);
		query.findObjects(new FindListener<Post>(){

				@Override
				public void done(List<Post> p1, BmobException p2)
				{
					// TODO: Implement this method
					if (p2 == null)
					{
						vis.setVisibility(View.VISIBLE);
						pro.setVisibility(View.GONE);
						for (Post am:p1)
						{
							Boolean rzs=am.getRz();
							if (rzs == true)
							{
								rz.setVisibility(View.VISIBLE);
							}
							else
							{
								rz.setVisibility(View.GONE);
							}

							title.setText(am.getTitle());
							nr.setText(am.getMessage());
							author.setText(am.getAuthors().getUsername());
							date.setText(am.getCreatedAt());

							String txurl=am.getAuthors().getTx();
							//加载作者头像
							ImageRequest imageRequest=new ImageRequest(txurl, new Response.Listener<Bitmap>() 
								{
									@Override
									public void onResponse(Bitmap response)
									{
										tx.setImageBitmap(response);
									}
								}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
									@Override
									public void onErrorResponse(VolleyError error)
									{
										tx.setImageResource(R.drawable.favicon);//失败用这张图片
									}
								});
							RequestQueue mQueue = Volley.newRequestQueue(getContext());//创建一个volley队列
							mQueue.add(imageRequest);//加入队列 开始下载
						}
					}
					else
					{
						pro.setVisibility(View.GONE);
						net.setVisibility(View.VISIBLE);
					}
				}
			});
		return view;
	}

	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
		switch (p1.getId())
		{
			case R.id.aide:
				startActivity(new Intent(getContext(), AideActivity.class));
				break;
			case R.id.syrj:
				startActivity(new Intent(getContext(), SyrjActivity.class));
				break;
			case R.id.iapp:
				startActivity(new Intent(getContext(), IappActivity.class));
				break;
			case R.id.java:
				startActivity(new Intent(getContext(), JavaActivity.class));
				break;
			case R.id.lua:
				startActivity(new Intent(getContext(), LuaActivity.class));
				break;
			case R.id.bmob:
				startActivity(new Intent(getContext(), BmobActivity.class));
				break;
			case R.id.xtgg:
				startActivity(new Intent(getContext(), XtGgActivity.class));
				break;
			case R.id.yjfk:
				startActivity(new Intent(getContext(), YiJianActivity.class));
				break;
			case R.id.fragmentcommunityLinearLayout2:
				Util.error(getContext(), "暂无更多");
				break;
			case R.id.fragmentcommunityLinearLayout3:
				BmobQuery<Post> query=new BmobQuery<Post>();
				query.addWhereEqualTo("home", "true");
				query.setMaxCacheAge(TimeUnit.DAYS.toMillis(7));//此表示缓存一天
				query.order("-createdAt");//依照maps排序时间排序
				//返回50条maps，如果不加上这条语句，默认返回10条maps
				query.setLimit(50);
				query.include("authors");
				query.setCachePolicy(BmobQuery.CachePolicy.NETWORK_ELSE_CACHE);
				query.findObjects(new FindListener<Post>(){

						@Override
						public void done(List<Post> p1, BmobException p2)
						{
							// TODO: Implement this method
							if (p2 == null)
							{
								for (Post am:p1)
								{
									Intent intent=new Intent();
									Bundle bd=new Bundle();
									bd.putString("title", am.getTitle());
									bd.putString("message", am.getMessage());
									bd.putString("authors", am.getAuthors().getUsername());
									bd.putString("time", am.getCreatedAt());
									bd.putString("bk", am.getBk());
									bd.putBoolean("rz", am.getRz());
									bd.putString("tx", am.getAuthors().getTx());
									bd.putString("aide", am.getObjectId());

									intent = new Intent();
									intent.setClass(getContext(), AideCkTz.class);
									intent.putExtras(bd);
									startActivity(intent);
								}
							}
						}
					});
				break;
		}
	}

	public static Fragment_Community newInstance()
	{
		Fragment_Community fc=new Fragment_Community();
		return fc;
	}

}
