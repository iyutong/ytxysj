package com.duhuang.jsbbs.fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.CountListener;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.duhuang.jsbbs.Gr_Activity;
import com.duhuang.jsbbs.MyPost;
import com.duhuang.jsbbs.R;
import com.duhuang.jsbbs.SettingsActivity;
import com.duhuang.jsbbs.StarActivity;
import com.duhuang.jsbbs.Util;
import com.duhuang.jsbbs.bmob.MyUser;
import com.duhuang.jsbbs.bmob.Post;
import com.duhuang.jsbbs.imageview;
import java.io.File;


public class Fragment_Space extends Fragment implements OnClickListener
{
	private imageview gr;
	private LinearLayout iPost,huifu,star,gz,fs,settings,ms;
	private TextView t,user;
	private imageview tx;
	private Switch night;
	private LinearLayout l;
	private View v1,v2,v3,v4,v6;
	private TextView star_tv;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		View v=inflater.inflate(R.layout.fragment_space, container, false);
		iPost = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout1);
		gr = (imageview) v.findViewById(R.id.fragmentspaceRelativeLayout1);
		t = (TextView) v.findViewById(R.id.fragmentspaceTextView1);
		tx = (imageview) v.findViewById(R.id.fragmentspaceRelativeLayout1);
		user = (TextView) v.findViewById(R.id.fragmentspaceTextView2);
		huifu = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout2);
		star = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout3);
		gz = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout4);
		fs = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout5);
		settings = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout6);
		night = (Switch) v.findViewById(R.id.fragmentspaceSwitch1);
		ms = (LinearLayout) v.findViewById(R.id.fragmentspaceLinearLayout7);
		l = (LinearLayout) v.findViewById(R.id.fragment_spaceLinearLayout);
		star_tv = (TextView) v.findViewById(R.id.fragmentspaceTextView3);

		v1 = v.findViewById(R.id.fragmentspaceView1);
		v2 = v.findViewById(R.id.fragmentspaceView2);
		v3 = v.findViewById(R.id.fragmentspaceView3);
		v4 = v.findViewById(R.id.fragmentspaceView4);
		v6 = v.findViewById(R.id.fragmentspaceView6);

		iPost.setOnClickListener(this);
		gr.setOnClickListener(this);
		huifu.setOnClickListener(this);
		star.setOnClickListener(this);
		gz.setOnClickListener(this);
		fs.setOnClickListener(this);
		settings.setOnClickListener(this);

		SharedPreferences setting=getActivity().getSharedPreferences("INFO", 0);
		boolean THEME=setting.getBoolean("THEME", true);
		File f=new File("/data/data/com.duhuang.jsbbs/shared_prefs/INFO.xml");
		if (f.exists())
		{
			//存在
			if (setting.getBoolean("Check", true))
			{
				night.setChecked(true);
			}
			else
			{
				night.setChecked(false);
			}
		}
		else
		{
			//不存在
			setting.edit().putBoolean("Check", false).commit();
		}

		if (THEME == true)
		{
			iPost.setBackgroundResource(android.R.color.white);
			huifu.setBackgroundResource(android.R.color.white);
			star.setBackgroundResource(android.R.color.white);
			gz.setBackgroundResource(android.R.color.white);
			fs.setBackgroundResource(android.R.color.white);
			settings.setBackgroundResource(android.R.color.white);
			ms.setBackgroundResource(android.R.color.white);

			l.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v1.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v2.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v3.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v4.setBackgroundColor(Color.parseColor("#EEEEEE"));
			v6.setBackgroundColor(Color.parseColor("#EEEEEE"));
		}
		else
		{
			iPost.setBackgroundResource(R.drawable.item_selector);
			huifu.setBackgroundResource(R.drawable.item_selector);
			star.setBackgroundResource(R.drawable.item_selector);
			gz.setBackgroundResource(R.drawable.item_selector);
			fs.setBackgroundResource(R.drawable.item_selector);
			settings.setBackgroundResource(R.drawable.item_selector);
			ms.setBackgroundResource(R.drawable.item_selector);
		}

		night.setOnCheckedChangeListener(new OnCheckedChangeListener(){

				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
				{
					if (isChecked)
					{
						// 开启switch，设置夜间模式
						SharedPreferences settings=getActivity().getSharedPreferences("INFO", 0);
						settings.edit().putBoolean("THEME", false).commit();
						settings.edit().putBoolean("Check", true).commit();
						getActivity().recreate();
					}
					else
					{
						// 关闭swtich，设置日间模式
						SharedPreferences settings=getActivity().getSharedPreferences("INFO", 0);
						settings.edit().putBoolean("THEME", true).commit();
						settings.edit().putBoolean("Check", false).commit();
						getActivity().recreate();
					}
				}
			});

		MyUser m=BmobUser.getCurrentUser(MyUser.class);
		BmobFile bb=m.getIcon();
		String cc=bb.getFileUrl();

		//加载用户名
		user.setText(BmobUser.getCurrentUser(MyUser.class).getUsername());
		//加载作者头像
		ImageRequest imageRequest=new ImageRequest(cc, new Response.Listener<Bitmap>() 
			{
				@Override
				public void onResponse(Bitmap response)
				{
					tx.setImageBitmap(response);
				}
			}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
				@Override
				public void onErrorResponse(VolleyError error)
				{
					tx.setImageResource(R.drawable.estirection);//失败用这张图片
				}
			});
		RequestQueue mQueue = Volley.newRequestQueue(getContext());//创建一个volley队列
		mQueue.add(imageRequest);//加入队列 开始下载

		//查询当前用户发帖数量
		MyUser user = BmobUser.getCurrentUser(MyUser.class);
		BmobQuery<Post> query = new BmobQuery<Post>();
		query.addWhereEqualTo("authors", user);
		query.count(Post.class, new CountListener() {
				@Override
				public void done(Integer count, BmobException e)
				{
					if (e == null)
					{
						t.setText(count + "");
					}
				}
			});

		//加载当前用户收藏的帖子数量
		MyUser star_m=BmobUser.getCurrentUser(MyUser.class);
		BmobQuery<Post> queryStar=new BmobQuery<Post>();
		queryStar.addWhereEqualTo("likes", star_m);
		queryStar.count(Post.class, new CountListener(){

				@Override
				public void done(Integer p1, BmobException p2)
				{
					if (p2 == null)
					{
						star_tv.setText(p1.toString());
					}
				}
			});
		return v;
	}

	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
		switch (p1.getId())
		{
			case R.id.fragmentspaceRelativeLayout1:
				startActivity(new Intent(getContext(), Gr_Activity.class));
				break;
			case R.id.fragmentspaceLinearLayout1:
				onPost();
				break;
			case R.id.fragmentspaceLinearLayout2:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentspaceLinearLayout3:
				startActivity(new Intent(getContext(), StarActivity.class));
				break;
			case R.id.fragmentspaceLinearLayout4:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentspaceLinearLayout5:
				Util.error(getContext(), "此版本暂不支持");
				break;
			case R.id.fragmentspaceLinearLayout6:
				startActivity(new Intent(getContext(), SettingsActivity.class));
				break;
		}
	}

	//加载当前用户发布的所有帖子
	private void onPost()
	{
		startActivity(new Intent(getContext(), MyPost.class));
	}

	public static Fragment_Space newInstance()
	{
		Fragment_Space fs=new Fragment_Space();
		return fs;
	}
}
