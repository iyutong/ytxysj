package com.duhuang.jsbbs.fragment;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v4.widget.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.widget.AdapterView.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.duhuang.jsbbs.*;
import com.duhuang.jsbbs.bmob.*;
import java.util.*;

import android.support.v4.app.Fragment;

public class Fragment_Shing extends Fragment implements OnItemClickListener
{

	private ListView lv;
	private SwipeRefreshLayout swipeView;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		View v=inflater.inflate(R.layout.shing, container, false);
		lv = (ListView) v.findViewById(R.id.shingListView1);
		swipeView = (SwipeRefreshLayout) v.findViewById(R.id.shingSwipeRefreshLayout1);
		lv.setOnItemClickListener(this);
		mRead();
		mSwipe();
		return v;
	}

	private void mRead()
	{
		//查询当前用户发表的所有审核中的贴纸
		MyUser user = BmobUser.getCurrentUser(MyUser.class);
        BmobQuery<Post> query = new BmobQuery<>();
        query.addWhereEqualTo("authors", user);
        query.order("-updatedAt");
        // 查询完post表后想把发布者的信息查询出来 要用内部查询
        query.include("authors");
        query.findObjects(new FindListener<Post>() {
				@Override
				public void done(List<Post> list, BmobException e)
				{
					if (e == null)
					{
						swipeView.setRefreshing(false);
						// TODO Auto-generated method stub
						//创建集合放审核通过的帖子
						List<Post>data=new ArrayList<>();
						for (Post am:list)//遍历原始数据，查找已审核通过的帖子
						{
							if (am.getSh() == false)
							{
								data.add(am);
							}
						}

						if (data.size() > 0)//有审核通过的帖子
						{
							MyAdapter adapter=new MyAdapter(data, getContext());
							lv.setAdapter(adapter);

							//列表动画
							AlphaAnimation animation = new AlphaAnimation(0f, 1f);
							animation.setDuration(500);
							LayoutAnimationController controller = new LayoutAnimationController(animation, 1f);
							controller.setOrder(LayoutAnimationController.ORDER_NORMAL);
							lv.setLayoutAnimation(controller);
						}
					}
					else
					{
						swipeView.setRefreshing(false);
						Util.error(getContext(), "加载失败，请检查网络连接！");
					}
				}
			});
	}

//内部类MyAdapter
	class MyAdapter extends BaseAdapter
	{
		private List<Post>list=null;
		private Context context;
		private LayoutInflater mInflater=null;
		public MyAdapter(List<Post>list, Context context)
		{
			this.list = list;
			this.context = context;
			this.mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int position)
		{
			return list.get(position);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent)
		{
			final ViewHolder holder;
			if (convertView == null)
			{
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.item_1, null);

				holder.tp = (RelativeLayout) convertView.findViewById(R.id.item1RelativeLayout1);
				holder.authorTx = (ImageView) convertView.findViewById(R.id.item1ImageView1);
				holder.rz = (ImageView) convertView.findViewById(R.id.item1ImageView2);
				holder.title = (TextView) convertView.findViewById(R.id.item1TextView2);
				holder.message = (TextView) convertView.findViewById(R.id.item1TextView3);
				holder.author = (TextView) convertView.findViewById(R.id.item1TextView4);
				holder.time = (TextView) convertView.findViewById(R.id.item1TextView5);
				convertView.setTag(holder);//绑定ViewHolder对象
			}
			else
			{
				holder = (ViewHolder) convertView.getTag();
			}

			Post am=list.get(position);

			Boolean rz=am.getRz();
			//如果为true则认证
			if (rz == true)
			{
				holder.rz.setVisibility(View.VISIBLE);
			}
			else if (rz == false)
			{
				holder.rz.setVisibility(View.GONE);
			}

			/**设置TextView显示的内容，即我们存放在动态数组中的数据*/            
			holder.title.setText(am.getTitle());
			holder.message.setText(am.getMessage());
			holder.author.setText(am.getAuthors().getUsername());
			holder.time.setText(am.getCreatedAt());
			//加载作者头像
			ImageRequest imageRequest=new ImageRequest(am.getAuthors().getTx(), new Response.Listener<Bitmap>() 
				{
					@Override
					public void onResponse(Bitmap response)
					{
						holder.authorTx.setImageBitmap(response);
					}
				}, 0, 0, Bitmap.Config.RGB_565, new Response.ErrorListener() {
					@Override
					public void onErrorResponse(VolleyError error)
					{
						holder.authorTx.setImageResource(R.drawable.beij18);//失败用这张图片
					}
				});
			RequestQueue mQueue = Volley.newRequestQueue(getContext());//创建一个volley队列
			mQueue.add(imageRequest);//加入队列 开始下载
			return convertView;
		}

		class ViewHolder
		{
			public RelativeLayout tp;
			public ImageView rz;
			public ImageView authorTx;
			public TextView title;
			public TextView message;
			public TextView author;
			public TextView time;
		}
	}

	private void mSwipe()
	{
		swipeView.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
        swipeView.setEnabled(true);
        swipeView.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

				@Override
				public void onRefresh()
				{
					//swipeView.setRefreshing(false);
					(new Handler()).postDelayed(new Runnable() {

							@Override
							public void run()
							{
								mRead();
							}

						}, 1000);
				}
			});
	}

	@Override 
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
	{
		Post am=(Post) lv.getAdapter().getItem(position);
		Bundle bd=new Bundle();
		bd.putString("title", am.getTitle());
		bd.putString("message", am.getMessage());
		bd.putString("authors", am.getAuthors().getUsername());
		bd.putString("time", am.getCreatedAt());
		bd.putString("bk", am.getBk());
		bd.putBoolean("rz", am.getRz());
		bd.putString("tx", am.getAuthors().getTx());
		bd.putString("aide", am.getObjectId());

		Intent intent = new Intent();
		intent.setClass(getContext(), ShingCkTz.class);
		intent.putExtras(bd);
		startActivity(intent);
	}


}
