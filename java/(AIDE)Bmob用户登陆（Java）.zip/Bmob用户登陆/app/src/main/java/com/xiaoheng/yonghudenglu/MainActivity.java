package com.xiaoheng.yonghudenglu;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;

public class MainActivity extends Activity 
{
	private EditText edittext1,edittext2;//创建编辑框变量
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaohenglayout);
		
		Bmob.initialize(this,"99a26b3b9e330afec9f24b690cadbe84");//初始化Bmob id
		//Application ID

		edittext1=(EditText)findViewById(R.id.xiaohenglayoutEditText1);//绑定用户名编辑框个id
		edittext2=(EditText)findViewById(R.id.xiaohenglayoutEditText2);//绑定密码编辑框id
		
    }
	
	
	public void xiaohenglayoutbutton(View view)
	{//注册按钮点击事件   开始

		String zhanghao=edittext1.getText().toString();//获取账号编辑框中的字符串
		String mima=edittext2.getText().toString();//获取密码编辑框中的字符串

		xiaohengzhuche denglu=new xiaohengzhuche();//新建一个denglu对象

		denglu.setUsername(zhanghao);//账号编辑框与Bmob中_User表中的username的内容对比
		denglu.setPassword(mima);//密码编辑框与Bmob中_User表中的password的内容对比

		denglu.login(this, new SaveListener()
		{//回调事件  开始

				@Override
				public void onSuccess()
				{
					//登陆成功后运行的事件
					Toast.makeText(MainActivity.this,"登陆成功！",Toast.LENGTH_SHORT).show();//弹出成功的提示
					
					Intent intent = new Intent(MainActivity.this,xiaohengdengluchenggong.class);
					startActivity(intent);//转跳到登陆成功的界面
					
					MainActivity.this.finish();//结束mainactivity界面
				}

				@Override
				public void onFailure(int p1, String p2)
				{
					//登陆成功后运行的事件
					Toast.makeText(MainActivity.this,"登陆失败\n"+p2,Toast.LENGTH_LONG).show();//弹出失败的提示
				}
			});//回调事件   结束
		
	}//注册按钮的点击事件  结束
	
	
	
	
	
	//////////////这里往上是核心代码///////////分割线/////////////这里往下的代码不用管/////////////////////
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.xiaohengmenu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
			case R.id.xiaohengitem3:
				String 小亨QQ号= getResources().getString(R.string.小亨QQ);
				try
				{
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+小亨QQ号)));
				}
				catch(Exception e)
				{
					Toast.makeText(MainActivity.this, "转跳失败，未安装手Q或当前版本不支持", 1000).show();
				}
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem2:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://fir.im/AIDElayout")));
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem1:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://pan.baidu.com/s/1slRXapB")));
		}
		
		switch(item.getItemId())
		{
			case R.id.xiaohengitem4:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://pan.baidu.com/wap/shareview?shareid=2076962829&uk=4048856162&page=2&third=0&fsid=807186733312503&num=20&dir=%2FAIDE%E6%BA%90%E7%A0%81(%E5%B0%8F%E4%BA%A8%E5%8E%9F%E5%88%9B)")));
		}
		return super.onOptionsItemSelected(item);
	}
}


/****************************************
 *      2017.9.3                        *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
