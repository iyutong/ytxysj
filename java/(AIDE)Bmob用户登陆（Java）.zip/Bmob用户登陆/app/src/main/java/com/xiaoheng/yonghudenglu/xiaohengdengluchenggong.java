package com.xiaoheng.yonghudenglu;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class xiaohengdengluchenggong extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaohenglayoutdengluchenggong);
	}
	
	
	static boolean isExit; 
// 点击两次退出变量
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (!isExit) {
				isExit = true;
				Toast.makeText(getApplicationContext(), "再按一次退出",
							   Toast.LENGTH_SHORT).show();
				new Thread(new Runnable() {
						@Override
						public void run() {
							try {
								Thread.sleep(3000);
								isExit = false;
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}).start();
			} else {
				finish();
			}
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	
}}
