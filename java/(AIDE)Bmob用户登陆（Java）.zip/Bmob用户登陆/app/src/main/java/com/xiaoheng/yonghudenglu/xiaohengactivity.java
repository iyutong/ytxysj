package com.xiaoheng.yonghudenglu;
import cn.bmob.v3.*;

class xiaohengzhuche extends BmobUser//让xiaohengzhuche继承BmobUser
{}
