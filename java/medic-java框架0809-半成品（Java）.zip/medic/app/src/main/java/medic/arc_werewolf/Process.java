package medic.arc_werewolf;

import static medic.main.Api.*;
import static medic.main.Main.*;
import static medic.main.Utils.*;

public class Process extends Thread {

    private final int msgType;
    private final String msg;
    private final long group;
    private final long qq;
    private final String nick;
    private final boolean isAdmin;
    private final long msgTime;

    public Process(int msgType, String msg, long group, long qq, boolean isAdmin) {
        this.msgType = msgType;
        this.msg = msg;
        this.group = group;
        this.qq = qq;
        this.nick = api.getGroupNick();
        this.isAdmin = isAdmin;
        this.msgTime = api.getTime();
    }

    @Override
    public void run() {
        if (msg.matches("test1")) {
            send("测试1");
        } else if (msg.matches("test2")) {
            send(qq, "艾特成功");
        }
    }

}
