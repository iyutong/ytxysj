package medic.smallFunction;

public class HPicture {


}
