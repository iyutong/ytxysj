package medic.main;

import java.util.concurrent.locks.ReentrantReadWriteLock;

import static medic.main.Utils.*;
import static medic.main.Api.*;

/**
 * 处理消息主入口.
 * 主要作用是获取之前存储的对象，以及对消息进行分类。
 * 请务必注意，该类定义的任何 static 对象都不是真正的 static！！！
 * 所以不必担心新消息的 api 将未执行完旧消息的 api 覆盖掉。
 * 如果想构建任何真正意义上的 static，请使用 saveInstance。
 * （其实下面的 lock 就是利用了这一点）
 */
public class Main {

    /* Api实例对象，用来获取机器人收到消息数据包的详细信息，以及让机器人向指定位置发送消息等 */
    public static Api api;

    /**
     * 用于反射调用 Api 函数.
     * 【不可主动调用】。
     * 若在处理过程中使用了 api，该方法将会自动调用。
     *
     * @param apiObj api实例对象
     */
    public static void apiSet(Object apiObj) {
        api = new Api(apiObj);
    }

    /**
     * 调用 dex 时自动加载一次，获取之前的实例对象，且存储新的实例对象.
     * 【不可主动调用，不可使用log（锁可能没获取到）】。
     * （所以说，叫 getAndSaveInstance 也许会更贴切吧？）
     * 通常用于保存锁，当然你也可以用它保存别的实例对象。
     * 若想保存多个实例对象，可以使用 Map 等，代码请自行编写。
     *
     * @param obj 之前保存的实例对象
     * @return 想要存储的实例对象
     */
    public static Object saveInstance(Object obj) {
        if (obj == null) {
            // 创建实例并保存
            lock = new ReentrantReadWriteLock();
            obj = lock;
        } else {
            // 获取之前保存的实例并保存
            lock = (ReentrantReadWriteLock) obj;
        }
        return obj;// 保存 obj
    }

    /* 功能唯一标记，定下后【不允许】再次修改，否则可能导致功能开启状态改变 */
    /* 基础功能 */
    public static final int LOG_ERROR = 1;
    public static final int LOG_WARN = 2;
    public static final int LOG_INFO = 3;
    public static final int APPLY_ADD_GROUP = 4;
    public static final int ADD_GROUP_INFO = 5;
    public static final int LEAVE_GROUP_INFO = 6;
    public static final int ADMIN_CHANGE_INFO = 7;
    /* 小功能 */
    public static final int REREAD = 11;
    public static final int AUTO_REPLY = 12;
    public static final int ON_TIME_ALARM = 13;
    public static final int H_PICTURE = 14;
    /* 大功能 */
    public static final int KEEP_KUN = 21;
    public static final int PCR = 22;
    public static final int ARC_QUERY = 23;
    public static final int ARC_PUBG = 24;
    public static final int ARC_WEREWOLF = 25;

    protected static final int[] FUNCTION = {4, 5, 6, 7, 11, 12, 13, 14, 21, 22, 23, 24, 25};

    /**
     * 程序主入口，在hdic.txt中调用并传入对应参数.
     * 调用方法：Lib->dex名称|完整类名|调用方法名(参数1\,参数2\,...)
     * 如 Lib->classes.dex|medic.main.Main|main(groupMsg\,@c0)
     * 消息分为三种，群消息、私聊消息、系统消息
     * 群消息：群里的某个人发送的消息
     * 私聊消息：群里的某个人没有加机器人好友，给机器人发私聊消息；
     * 或者某个人加了机器人好友，给机器人发私聊消息，此时消息与群无关，群号为-1
     * 系统消息：入群申请等
     * 群消息不需要加前缀，私聊消息使用“[临时]”前缀，系统消息在System模块内部
     *
     * @param param 参数
     */
    public static void main(String... param) {
        switch (param[0]) {
            case "groupMsg":// 群消息
                processGroupMsg(param[1]);
                break;
            case "privateMsg":// 私聊消息
                processPrivateMsg(param[1]);
                break;
            case "systemMsg":// 系统消息
                processSystemMsg(param);
                break;
            default:
                logError(new Exception("第一个参数\"" + param[0]
                        + "\"只能是 groupMsg/privateMsg/systemMsg"));
        }
    }

    public static final String GROUP_OF_LAST_MSG = DATA + "groupOfLastMsg";

    public static void processGroupMsg(String msg) {
        long group = api.getGroup();
        long qq = api.getQQ();
        boolean isAdmin = api.checkAdmin(qq);
        set(GROUP_OF_LAST_MSG, qq, group);// 保存群号，用于后续好友消息替代群号
        api.setMsgType(GROUP_MSG);
        logInfo("收群消息：" + qq + "，群 " + group + "\n" + msg);
        processMsg(GROUP_MSG, msg, group, qq, isAdmin);
    }

    public static void processPrivateMsg(String msg) {
        long group = api.getGroup();
        long qq = api.getQQ();
        boolean isAdmin = api.checkAdmin(qq);
        if (group == -1) {
            api.setMsgType(FRIEND_MSG);
            long lastGroup = getLong(GROUP_OF_LAST_MSG, qq);
            if (lastGroup == DEF_LONG) {
                send("请在有我的群中发一次言！");
                logWarn(new Exception("收好友消息：" + qq + "，群 -1（-）" + "\n" + msg));
            } else {
                logInfo("收好友消息：" + qq + "，群 -1（" + lastGroup + "）" + "\n" + msg);
                processMsg(FRIEND_MSG, msg, lastGroup, qq, isAdmin);
            }
        } else {
            api.setMsgType(TEMPORARY_MSG);
            logInfo("收临时消息：" + qq + "，群 " + group + "\n" + msg);
            processMsg(TEMPORARY_MSG, msg, group, qq, isAdmin);
        }
    }

    private static void processMsg(int msgType, String msg,
                                   long group, long qq, boolean isAdmin) {
        if (msg.contains("禁")) {
            new medic.smallFunction.Talk(msgType, msg, group, qq, isAdmin).start();
        } else if (msg.matches("(功能|模块|菜单)(列表|)")) {
            menu(msgType, group);
        } else if (msg.matches("开启(模块|功能)[0-9]+")) {
            int num = Integer.parseInt(msg.substring(4));
            openFunction(msgType, group, qq, isAdmin, num);
        } else if (msg.matches("关闭(模块|功能)[0-9]+")) {
            int num = Integer.parseInt(msg.substring(4));
            closeFunction(msgType, group, qq, isAdmin, num);

        } else {
            // 判断功能是否开启，从而决定执行哪些
            // 在 Process 内部，再根据具体指令决定是否触发
            if (isOpen(group, KEEP_KUN)) {
                new medic.kun.Process(msgType, msg, group, qq, isAdmin).start();
            }
            if (isOpen(group, PCR)) {
                new medic.pcr.Process(msgType, msg, group, qq, isAdmin).start();
            }
            if (isOpen(group, ARC_QUERY)) {
                new medic.arc_query.Process(msgType, msg, group, qq, isAdmin).start();
            }
            if (isOpen(group, ARC_PUBG)) {
                new medic.arc_pubg.Process(msgType, msg, group, qq, isAdmin).start();
            }
            if (isOpen(group, ARC_WEREWOLF)) {
                new medic.arc_werewolf.Process(msgType, msg, group, qq, isAdmin).start();
            }
        }
    }

    public static void processSystemMsg(String... param) {
        if (System.currentTimeMillis() - api.getTime() > 3000) {
            // 因为system消息是长时间多条重复，所以只处理3s内的消息
            return;
        }
        api.setMsgType(GROUP_MSG);
        logInfo("收系统消息：\nrequestId " + param[1]);
        new medic.request.Process(param).process();
    }

    private static void menu(int msgType, long group) {
        if (msgType != GROUP_MSG) {
            send(AUTHOR_NAME + "Bot具有养鲲、pcr会战、arc查分等各种功能，"
                    + "具体请在群中了解各功能开启情况！\n"
                    + "以下是与群无关功能（即log功能）开启情况：\n"
                    + "1.logError：" + isOpenStr(LOG_ERROR) + "\n"
                    + "2.logWarn：" + isOpenStr(LOG_WARN) + "\n"
                    + "3.logInfo：" + isOpenStr(LOG_INFO));
            return;
        }
        send("本群功能开启情况如下：\n"
                + "4.加群提醒：" + isOpenStr(group, APPLY_ADD_GROUP) + "\n"
                + "5.入群欢迎：" + isOpenStr(group, ADD_GROUP_INFO) + "\n"
                + "6.离群提示：" + isOpenStr(group, LEAVE_GROUP_INFO) + "\n"
                + "7.管理变动提示：" + isOpenStr(group, ADMIN_CHANGE_INFO) + "\n"
                + "11.复读：" + isOpenStr(group, REREAD) + "\n"
                + "12.问答：" + isOpenStr(group, AUTO_REPLY) + "\n"
                + "13.整点报时：" + isOpenStr(group, ON_TIME_ALARM) + "\n"
                + "14.色图：" + isOpenStr(group, H_PICTURE) + "\n"
                + "21.养鲲：" + isOpenStr(group, KEEP_KUN) + "\n"
                + "22.PCR会战：" + isOpenStr(group, PCR) + "\n"
                + "23.Arc查询：" + isOpenStr(group, ARC_QUERY) + "\n"
                + "24.Arc吃鸡：" + isOpenStr(group, ARC_PUBG) + "\n"
                + "25.Arc狼人杀：" + isOpenStr(group, ARC_WEREWOLF) + "\n"
                + "tips：【菜单+功能序号】获得对应功能菜单，如【菜单21】");
    }

    private static void openFunction(int msgType, long group, long qq,
                                     boolean isAdmin, int function) {
        if (function == LOG_ERROR || function == LOG_WARN || function == LOG_INFO) {
            if (qq == AUTHOR_QQ) {
                Utils.openFunction(function);
                send("已开启功能" + function + "！");
            } else {
                send("你不是" + AUTHOR_NAME + "，无权开关log功能！");
            }
            return;
        }
        if (msgType != GROUP_MSG) {
            send("请在群内开启相关功能！");
            return;
        }
        if (isAdmin) {
            for (int a : FUNCTION) {
                if (a == function) {
                    Utils.openFunction(group, function);
                    send("已开启功能" + function + "！");
                    return;
                }
            }
            send("功能序号错误，请检查对应序号！");
        } else {
            send(qq, "你不是Bot管理员，无法开关功能！");
        }
    }

    private static void closeFunction(int msgType, long group, long qq,
                                      boolean isAdmin, int function) {
        if ((function == LOG_ERROR || function == LOG_WARN || function == LOG_INFO) && qq == AUTHOR_QQ) {
            Utils.closeFunction(function);
            return;
        }
        if (msgType != GROUP_MSG) {
            send("请在群内关闭相关功能！");
            return;
        }
        if (isAdmin) {
            for (int a : FUNCTION) {
                if (a == function) {
                    Utils.closeFunction(group, function);
                    send("已关闭功能" + function + "！");
                    return;
                }
            }
            send("功能序号错误，请检查对应序号！");
        } else {
            send(qq, "你不是Bot管理员，无法开关功能！");
        }
    }

    /**
     * 不需要机器人艾特人时调用该send.
     *
     * @param str 机器人要发的消息
     */
    public static void send(String str) {
        api.send(str);
    }

    /**
     * 需要机器人艾特人时调用该send.
     * 只有消息为群消息时，才会艾特
     *
     * @param atQQ 机器人要艾特的人的QQ
     * @param str  机器人要发的消息
     */
    public static void send(long atQQ, String str) {
        api.send(atQQ, str);
    }

}
