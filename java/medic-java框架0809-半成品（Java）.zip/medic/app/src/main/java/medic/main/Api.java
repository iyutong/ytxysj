package medic.main;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static medic.main.Utils.*;

public class Api {

    private Object apiObj;
    private int msgType;// 消息类型
    private String msgToBeSent;// 待发送的消息

    public static final int GROUP_MSG = 0;
    public static final int TEMPORARY_MSG = 1;
    public static final int FRIEND_MSG = 2;

    public Api(Object obj) {
        this.apiObj = obj;
        msgType = GROUP_MSG;// 此处有设置是防止忘记赋值
        msgToBeSent = "";
    }

    /**
     * 设置消息类型，分为群消息、临时消息、好友消息（系统消息按群消息处理）.
     *
     * @param type 消息类型
     */
    public void setMsgType(int type) {
        msgType = type;
    }

    /**
     * 调用api中已有功能
     *
     * @param methodName api中已有方法名
     * @param data       方法需要的参数
     * @return 调用结果
     */
    private String exec(String methodName, String... data) {
        try {
            Method method;
            Object result;
            if (data != null && data.length != 0) {
                method = apiObj.getClass().getMethod(methodName, String[].class);
                result = method.invoke(apiObj, (Object) data);
            } else {
                method = apiObj.getClass().getMethod(methodName);
                result = method.invoke(apiObj);
            }
            return result == null ? "" : result.toString();
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            return "";
        }
    }

    /**
     * 添加@呼叫，不会立即发送，直到调用send
     * 自带 @，显示的信息是 @ + info
     */
    public void addAt(long qq, String nick) {
        if (msgType != GROUP_MSG) {
            logError(new Exception(SHOULD_CHECK_CODE + "私聊消息调用艾特"));
            return;
        }
        exec("addAt", qq + "", nick);
        msgToBeSent += "@" + nick;
    }

    /**
     * 添加@呼叫，不会立即发送，直到调用send
     */
    public void addAt(long qq) {
        if (qq == getQQ()) {
            addAt();
        } else {
            addAt(qq, getQQNick(qq));
        }
    }

    /**
     * 添加对消息发送者的@呼叫，不会立即发送，直到调用send
     */
    public void addAt() {
        addAt(getQQ(), getGroupNick());
    }

    /**
     * 添加@全体，不会立即发送，直到调用send
     */
    public void addAtAll(String info) {
        exec("addAt", "0", info);
        msgToBeSent += "@" + info;
    }

    /**
     * 添加@全体，不会立即发送，直到调用send
     */
    public void addAtAll() {
        addAtAll("全体成员");
    }

    /**
     * 添加文本消息，不会立即发送，直到调用send
     */
    public void addText(String text) {
        exec("addText", text);
        msgToBeSent += text;
    }

    /**
     * 添加图片消息，不会立即发送，直到调用send
     */
    public void addImg(String pathOrUrl) {
        exec("addImg", pathOrUrl);
        msgToBeSent += "[图片" + pathOrUrl + "]";
    }

    /**
     * 设置消息发送的群号，默认为消息来源群
     * 仅在往别的群发消息时调用
     */
    public void setGroup(long group) {
        exec("setId", group + "");
    }

    /**
     * 设置消息发送的群Code
     * 仅在收到群消息，且发送群临时消息给成员时调用
     * 如果收到的消息本身就是群临时消息，则不必调用
     */
    private void setCode() {
        exec("setCode", exec("getCode"));
    }

    /**
     * 设置消息发送目标
     * 仅在收到群消息，且发送群临时消息给成员时调用
     * 如果收到的消息本身就是群临时消息，则不必调用
     */
    public void setQQ(long qq) {
        setCode();
        exec("setUin", qq + "");
    }

    /**
     * 发送储存的消息.
     */
    public void send() {
        exec("send");
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + msgToBeSent);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + msgToBeSent);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + msgToBeSent);
        }
        msgToBeSent = "";
    }

    /**
     * 发送参数中的消息，自动识别xml、json
     *
     * @param msg 机器人要发的消息
     */
    public void send(String msg) {
        exec("sendMsg", msg);// 等价于先 addText，再 send
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + msg);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + msg);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + msg);
        }
    }

    /**
     * 需要机器人艾特人时调用该send
     *
     * @param atQQ 机器人要艾特的人的QQ
     * @param msg  机器人要发的消息
     */
    public void send(long atQQ, String msg) {
        if (msgType == GROUP_MSG) {
            addAt(atQQ);
            addText("\n");
        }
        addText(msg);
        send();
    }

    /**
     * 发送参数中的消息，只识别json，其他内容将被无视
     */
    public void sendJson(String json) {
        exec("sendJson", json);
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + json);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + json);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + json);
        }
    }

    /**
     * 发送参数中的消息，只识别xml，其他内容将被无视
     */
    public void sendXml(String xml) {
        exec("sendXml", xml);
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + xml);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + xml);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + xml);
        }
    }

    /**
     * 发送语音消息，参数为直链网址或本地路径
     */
    public void sendVoice(String pathOrUrl) {
        exec("sendPtt", pathOrUrl);
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        }
    }

    /**
     * 发送语音消息，参数为直链网址或本地路径，自定义语音时长（单位秒）
     */
    public void sendVoice(String pathOrUrl, int second) {
        exec("sendPtt", pathOrUrl, second + "");
        if (msgType == GROUP_MSG) {
            logInfo("发群消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        } else if (msgType == TEMPORARY_MSG) {
            logInfo("发临时消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        } else if (msgType == FRIEND_MSG) {
            logInfo("发好友消息：" + getQQ() + "，群 " + getGroup() + "\n" + pathOrUrl);
        }
    }

    /**
     * 撤回当前消息，需要登录账号在群内是管理员
     */
    public void withdrawMsg() {
        exec("withDrawMsg");
    }

    /**
     * 撤回特定消息，需要登录账号在群内是管理员
     * 如果你想连续撤回多条消息，必须自己保存所有想撤回消息对应的群号和mark
     * 群号用 getGroup() 获取，mark用 getMark() 获取
     */
    public void withdrawMsg(long group, String mark) {
        exec("withDrawMsg", group + "", mark);
    }

    /**
     * 获取消息标记，用于撤回消息
     */
    public String getMark() {
        return exec("getMark");
    }

    /**
     * 获取当前登录账号，同@robot
     */
    public long getRobotQQ() {
        return Long.parseLong(exec("getAcct"));
    }

    /**
     * 获取当前消息的来源群，同@group
     * 好友消息返回-1
     */
    public long getGroup() {
        return Long.parseLong(exec("getGroup"));
    }

    /**
     * 获取当前消息的来源群名，同@groupName
     */
    public String getGroupName() {
        return exec("getGroupName");
    }

    /**
     * 获取当前消息的发送者，同@uin
     */
    public long getQQ() {
        return Long.parseLong(exec("getUin"));
    }

    /**
     * 获取任何群的任意QQ的群名片
     * 如果群名片为空，或者该QQ不在群中，返回QQ昵称
     *
     * @deprecated getGroupMembers不一定是所有人，可能是部分人
     * 这导致倒数第二行的log会被经常执行，并且循环耗时有点高
     * 建议将nick存储，以及使用getGroupNick()和getAtNick()获取昵称
     */
    @Deprecated
    public String getGroupNick(long group, long qq) {
        // 下面这个非常的慢。。。大概是群里人太多的缘故
        try {
            JSONObject jsonObject = new JSONObject(getAllGroupMemberInfo(group));
            JSONArray jsonArray = jsonObject.getJSONArray(group + "");
            for (int i = 0; i < jsonArray.length(); i++) {
                GroupMemberInfo member = new GroupMemberInfo(jsonArray.getJSONObject(i));
                if (member.getQQ() == qq) {
                    String groupNick = member.getGroupNick();
                    return groupNick.equals("") ? member.getQQNick() : groupNick;
                }
            }
        } catch (JSONException e) {
            logError(e);
        }
        logError(new Exception("QQ" + qq + "不在群" + group + "中"));
        return getQQNick(qq);
    }

    /**
     * 获取消息来源群的任意QQ的群名片
     * 如果群名片为空，或者该QQ不在群中，返回QQ昵称
     *
     * @deprecated 见getGroupNick(long group, long qq)
     */
    @Deprecated
    public String getGroupNick(long qq) {
        return getGroupNick(getGroup(), qq);
    }

    /**
     * 获取消息来源群的艾特QQ的群名片
     * 如果群名片为空，返回QQ昵称
     *
     * @deprecated 见getGroupNick(long group, long qq)
     */
    @Deprecated
    public String getAtGroupNick() {
        return getGroupNick(getGroup(), getAtQQ());
    }

    /**
     * 获取当前消息发送者群名片昵称，同@nick
     * 如果群名片为空，返回QQ昵称
     */
    public String getGroupNick() {
        String nick = exec("getUinName");
        return nick.equals("") ? getQQNick() : nick;
    }

    /**
     * 获取自己的昵称
     */
    public String getQQNick() {
        return getQQNick(getQQ());
    }

    /**
     * 获取任意QQ的昵称
     */
    private String getQQNick(long qq) {
        String s = getStringFromURL("https://api.vvhan.com/api/qq?qq=" + qq);
        try {
            return new JSONObject(s).getString("name");
        } catch (JSONException e) {
            logError(e);
            return "无法获取昵称";
        }
    }

    /**
     * 用指定格式格式化当前消息的发送时间
     */
    public String getTimeStr(String format) {
        return exec("getTime", format);
    }

    /**
     * 当前消息的发送时间，单位毫秒，同@time
     */
    public long getTime() {
        return Long.parseLong(getTimeStr("format"));
    }

    /**
     * 格式化当前消息的发送时间
     *
     * @return 2020-01-01 00:00:00
     */
    public String getTimeStr() {
        return getTimeStr("yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 获取消息标题，同@title
     */
    public String getTitle() {
        return exec("getTitle");
    }

    /**
     * 获取当前消息code，同@code
     */
    public String getCode() {
        return exec("getCode");
    }

    /**
     * 获取当前消息@的第index个对象的QQ，注意一条消息可以@多个人
     */
    public long getAtQQ(int index) {
        String at = exec("getAt", (index - 1) + "");
        try {
            return new JSONArray(at).getLong(0);
        } catch (JSONException e) {
            logError(e);
            return 0L;
        }
    }

    /**
     * 获取当前消息@的第一个对象的QQ
     */
    public long getAtQQ() {
        return getAtQQ(1);
    }

    /**
     * 获取当前消息@的第index个对象的昵称，注意一条消息可以@多个人
     */
    public String getAtNick(int index) {
        String at = exec("getAt", (index - 1) + "");
        try {
            return new JSONArray(at).getString(1);
        } catch (JSONException e) {
            logError(e);
            return "";
        }
    }

    /**
     * 获取当前消息@的第一个对象的昵称
     */
    public String getAtNick() {
        return getAtNick(1);
    }

    /**
     * 获取当前设备的识别码，需要权限：手机信息
     */
    public String getMachineCode() {
        return exec("getMachineCode");
    }

    /* 默认红包标题 */
    private static final String DEFAULT_TITLE = "恭喜发财";

    /**
     * 发送专属红包，需要权限：红包支付
     * 参数为群号，红包标题，总金额（分为单位），领取人QQ（可以多人）
     */
    private void sendRedPacket(long group, String title, int cent, long... qq) {
        String[] stringArray = new String[qq.length + 3];
        stringArray[0] = group + "";
        stringArray[1] = title == null || title.equals("") ? DEFAULT_TITLE : title;
        stringArray[2] = cent + "";
        for (int i = 3; i < stringArray.length; i++) {
            stringArray[i] = String.valueOf(qq[i - 3]);
        }
        exec("sendRedPacket", stringArray);
    }

    public void sendRedPacket(long group, String title, double yuan, long... qq) {
        int cent = (int) (yuan * 100);
        if (cent > 20000) {
            logError(new Exception("红包金额" + yuan + "r大于200r"));
            return;
        }
        if (cent < qq.length) {
            logError(new Exception("红包金额" + yuan + "r小于" + (0.01 * qq.length) + "r"));
            return;
        }
        sendRedPacket(group, title, cent, qq);
    }

    public void sendRedPacket(double yuan, long... qq) {
        sendRedPacket(getGroup(), DEFAULT_TITLE, yuan, qq);
    }

    public void sendRedPacket(String title, double yuan) {
        sendRedPacket(getGroup(), title, yuan, getQQ());
    }

    public void sendRedPacket(double yuan) {
        sendRedPacket(getGroup(), DEFAULT_TITLE, yuan, getQQ());
    }

    /**
     * 同意/拒绝入群申请，需要管理员权限，此函数仅在内置词条System中有效，
     */
    public void joinRequest(long group, long member, String requestId, boolean agree) {
        exec("joinRequest", group + "",
                member + "", requestId, agree ? "0" : "1");
    }

    /**
     * 删除群成员，需要管理员权限
     */
    public void deleteMember(long group, long member) {
        exec("deleteMember", group + "", member + "");
    }

    /**
     * 禁言，member为-1表示群禁言，time为0表示解除禁言
     */
    private void talk(long member, int time) {
        exec("shotup", getGroup() + "", member + "", time + "");
    }

    /**
     * 禁言群成员
     */
    public void notAllowTalking(long member, int second) {
        talk(member, second);
    }

    /**
     * 解禁群成员
     */
    public void allowTalking(long member) {
        talk(member, 0);
    }

    /**
     * 禁言群
     */
    public void notAllowGroupTalking() {
        talk(-1, 1);
    }

    /**
     * 解禁群
     */
    public void allowGroupTalking() {
        talk(-1, 0);
    }

    /**
     * 设置群成员名片
     */
    public void setGroupNick(long member, String groupNick) {
        exec("setMemberCard", getGroup() + "", member + "", groupNick);
    }

    /**
     * 获取QQSkey，此参数可以用于登录QQ空间等
     */
    public String getSkey() {
        return exec("getSkey");
    }

    /**
     * 同上.
     *
     * @see #getSkey()
     */
    public String getPSkey() {
        return exec("getPSkey");
    }

    /**
     * 获取消息中以文本内容，对于xml和json消息，获取的内容如下：
     * [名片分享]你的QQ版本不支持查看该名片分享内容，请下载最新版本。
     */
    public String getText() {
        return exec("getTextMsg");
    }

    /**
     * 获取消息中JSON的内容，如果没有则返回空文本
     */
    public String getJson() {
        return exec("getJsonMsg");
    }

    /**
     * 获取消息中xml的内容，如果没有则返回空文本
     */
    public String getXml() {
        return exec("getXmlMsg");
    }

    /**
     * 获取消息中图片的文件名
     */
    public String getImageName() {
        return exec("getImageMsg");
    }

    /**
     * 重载词库
     */
    public void reload() {
        exec("reload");
    }

    /**
     * 设置机器人管理员（即主人，作用同 medic 主界面管理员）
     */
    public void setAdmin(long qq, boolean set) {
        exec("setAdmin", qq + "", set + "");
    }

    /**
     * 检查是否为机器人管理员（即主人，作用同 medic 主界面管理员）
     */
    public boolean checkAdmin(long qq) {
        return exec("checkAdmin", qq + "").equals("true");
    }

    private static class GroupBaseInfo {

        String groupName;
        String announcement;
        long group;
        long code;
        int memberNum;

        GroupBaseInfo(JSONObject obj) {
            try {
                groupName = obj.getString("name");
                announcement = obj.getString("info");
                group = obj.getLong("id");
                code = obj.getLong("code");
                memberNum = obj.getInt("memberCnt");
            } catch (JSONException e) {
                logError(e);
                groupName = "";
                announcement = "";
                group = 0L;
                code = 0L;
                memberNum = 0;
            }
        }

        String getGroupName() {
            return groupName;
        }

        String getAnnouncement() {
            return announcement;
        }

        long getGroup() {
            return group;
        }

        long getCode() {
            return code;
        }

        int getMemberNum() {
            return memberNum;
        }

    }

    /**
     * 获取所有群的群名、最新公告、群号、code、群员数量
     */
    private String getAllGroupInfo() {
        return exec("getTroopList");
    }

    /**
     * 获取所有群群号
     */
    public long[] getGroups() {
        long[] groupArray = new long[1];
        try {
            JSONArray jsonArray = new JSONArray(getAllGroupInfo());
            groupArray = new long[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++) {
                GroupBaseInfo group = new GroupBaseInfo(jsonArray.getJSONObject(i));
                groupArray[i] = group.getGroup();
            }
        } catch (JSONException e) {
            logError(e);
        }
        return groupArray;
    }

    private static class GroupMemberInfo {

        String groupNick;
        String qqNick;
        String title;// 头衔
        long qq;

        GroupMemberInfo(JSONObject obj) {
            try {
                groupNick = obj.getString("card");
                qqNick = obj.getString("nick");
                title = obj.getString("title");
                qq = obj.getLong("uin");
            } catch (JSONException e) {
                logError(e);
                groupNick = "";
                qqNick = "";
                title = "";
                qq = 0L;
            }
        }

        String getGroupNick() {
            return groupNick;
        }

        String getQQNick() {
            return qqNick;
        }

        String getTitle() {
            return title;
        }

        long getQQ() {
            return qq;
        }

    }

    /**
     * 获取某个群所有群成员的昵称、群名片、头衔、qq
     *
     * @deprecated 一定情况下并不会返回所有人的数据！例如2k人群只返回500人数据等
     */
    @Deprecated
    private String getAllGroupMemberInfo(long group) {
        return exec("getTroopMemberList", group + "");
    }

    /**
     * 获取某个群所有群成员的qq
     *
     * @deprecated 不一定是所有人，可能是部分人
     */
    @Deprecated
    public long[] getGroupMembers(long group) {
        long[] memberArray = new long[1];
        try {
            JSONObject jsonObject = new JSONObject(getAllGroupMemberInfo(group));
            JSONArray jsonArray = jsonObject.getJSONArray(group + "");
            memberArray = new long[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++) {
                GroupMemberInfo member = new GroupMemberInfo(jsonArray.getJSONObject(i));
                memberArray[i] = member.getQQ();
            }
        } catch (JSONException e) {
            logError(e);
        }
        return memberArray;
    }

}
