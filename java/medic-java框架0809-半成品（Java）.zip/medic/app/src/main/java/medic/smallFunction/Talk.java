package medic.smallFunction;

import static medic.main.Main.api;
import static medic.main.Main.send;
import static medic.main.Api.*;
import static medic.main.Utils.*;

public class Talk extends Thread {

    private final int msgType;
    private final String msg;
    private final long group;
    private final long qq;
    private final boolean isAdmin;
    private final long msgTime;

    public Talk(int msgType, String msg, long group, long qq, boolean isAdmin) {
        this.msgType = msgType;
        this.msg = msg;
        this.group = group;
        this.qq = qq;
        this.isAdmin = isAdmin;
        this.msgTime = api.getTime();
    }

    @Override
    public void run() {
        if (msgType != GROUP_MSG) {
            send("请在群内发送禁言相关命令！");
            return;
        }
        if (!isAdmin) {
            send("你不是" + AUTHOR_NAME + "Bot的管理员，无法设置！");
            return;
        }
        if (msg.matches("(禁|禁言)[0-9]+([smh]|)@.*")) {
            int time = Integer.parseInt(msg.substring(2, msg.indexOf('@')));
           if (msg.contains("m@")) {
                api.notAllowTalking(api.getAtQQ(), time * 60);
            } else if (msg.contains("h@")) {
                api.notAllowTalking(api.getAtQQ(), time * 3600);
            }else {
               api.notAllowTalking(api.getAtQQ(), time );
           }
        } else if (msg.matches("(解|解禁)@.*")) {
            api.allowTalking(api.getAtQQ());
        } else if (msg.matches("群禁|群禁言")) {
            api.notAllowGroupTalking();
        } else if (msg.matches("解禁|群解禁")) {
            api.allowGroupTalking();
        }
    }
}
