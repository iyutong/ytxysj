package medic.pcr;

import java.io.Serializable;

public class BaseAndTime implements Serializable {

    private long qq;
    private int times;
    private boolean isEndAtk;

    private static final long serialVersionUID = 1L;

    BaseAndTime(long qq, int times, boolean isEndAtk) {
        this.qq = qq;
        this.times = times;
        this.isEndAtk = isEndAtk;
    }

    public long getQq() {
        return qq;
    }

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }

    public boolean isEndAtk() {
        return isEndAtk;
    }

    public void setEndAtk(boolean endAtk) {
        isEndAtk = endAtk;
    }

}
