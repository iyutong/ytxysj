package medic.arc_query;

import static medic.main.Api.*;
import static medic.main.Main.*;
import static medic.main.Utils.*;

public class Process extends Thread {

    private final int msgType;
    private final String msg;
    private final long group;
    private final long qq;
    private final String nick;
    private final boolean isAdmin;
    private final long msgTime;

    public Process(int msgType, String msg, long group, long qq, boolean isAdmin) {
        this.msgType = msgType;
        this.msg = msg;
        this.group = group;
        this.qq = qq;
        this.nick = api.getGroupNick();
        this.isAdmin = isAdmin;
        this.msgTime = api.getTime();
    }

    private User getUser()


    @Override
    public void run() {

        if (msg.matches("/arc")) {
            getInfo(user.getArcID);
            Integer.
        } else if (msg.matches("/arc [0-9]{9}")) {
            send(qq, "艾特成功");
        }
    }


}
