package medic.kun;

import java.io.*;

import static medic.main.Utils.*;

public class Boss implements Serializable {

    private final String filePath;

    private String name;
    private int level;
    private int atk;
    private int def;
    private int hp;

    Boss(Rank rank) {
        this.filePath = Process.BOSS_PATH;
        newBoss(rank);
    }

    private static final long serialVersionUID = 1L;

    public int getLevel() {
        return level;
    }

    public String getName() {
        return name;
    }

    public int getAtk() {
        return atk;
    }

    public int getDef() {
        return def;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    /**
     * 以所有群等级最高者为基础，生成新的boss
     * 如果无人上榜，boss等级默认5000级
     */
    public void newBoss(Rank rank) {
        level = Math.max(5000, rank.getMaxLevel());
        name = getRandomString(1, 4);
        atk = level * 2;
        def = level;
        hp = level * 10000;
    }

}
