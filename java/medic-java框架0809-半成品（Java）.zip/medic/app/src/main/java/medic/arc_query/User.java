package medic.arc_query;

import java.io.Serializable;

public class User implements Serializable {

    private long qq;
    private int arcID;

    User(long qq, int arcID) {
        this.qq = qq;
        this.arcID = arcID;
    }

    private static final long serialVersionUID = 1L;

    public long getQq() {
        return qq;
    }

    public void setQq(long qq) {
        this.qq = qq;
    }

    public int getArcID() {
        return arcID;
    }

    public void setArcID(int arcID) {
        this.arcID = arcID;
    }
}
