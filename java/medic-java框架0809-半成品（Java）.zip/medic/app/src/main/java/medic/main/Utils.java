package medic.main;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.*;
import android.graphics.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.net.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static medic.main.Main.*;

/**
 * 该类是工具类，可以便捷进行读取文件、取随机数等操作
 */
public class Utils {

    Utils() {
    }

    /* -- 作者信息 -- */

    /* 该账户是唯一的，具有最高权限，可以增删管理员、开关 Log */
    public static final String AUTHOR_NAME = "萌泪";
    public static final long AUTHOR_QQ = 605738729L;
    public static final String AUTHOR_TIP
            = "\n【请将此消息发送给" + AUTHOR_NAME + "（" + AUTHOR_QQ + "）】";
    public static final String SHOULD_CHECK_CODE
            = "此 log 不应出现，请检查相关代码\n";

    /* -- 目录定义 -- */

    /* 数据目录，存储各个模块的数据，可以根据自己需要更改 */
    public static final String DATA = sdCardPath() + "/DIC/data/";

    /* 日志目录，存储各种日志，可以根据自己需要更改 */
    public static final String LOG_PATH = sdCardPath() + "/DIC/log/"
            + getDateStr(System.currentTimeMillis()) + ".txt";

    /* 设置目录，存储各个模块开关情况，可以根据自己需要更改 */
    public static final String SETTINGS = sdCardPath() + "/DIC/settings/";


    /* -- 功能开启、关闭 -- */

    public static final String OPEN = "open";
    public static final String CLOSE = "close";
    // OPEN、CLOSE 必须是字符串，以减少冗余代码
    // 具体原因请参考 getString(String path, Object key)

    public static final String LOG_STATE_FILE_NAME = "log";// 该文件存储log功能开关状态

    /**
     * 检查功能开关状态.
     * 如果功能是 log，在检查时不会使用 log.
     * 反之则会使用 log 记录.
     * 返回默认值 DEF_STRING，说明功能未设置，应写入该功能默认开关状态；
     * 返回错误值 ERR_STRING，说明文件无法读取，应删除对应文件；
     * 返回开启/关闭（OPEN/CLOSE），说明成功读取到对应功能开关状态。
     *
     * @param fileName 功能开关状态所存储文件名
     * @param function 功能序号，定义在 medic.main.Main 中
     * @return 功能状态
     */
    private static String getFunctionState(String fileName, int function) {
        return getString(SETTINGS + fileName, function,
                function != LOG_ERROR && function != LOG_WARN && function != LOG_INFO);
    }

    /**
     * 检查 非Log功能 是否启用，默认关闭.
     * 临时消息正常处理，好友消息使用上一次发言的群号。
     *
     * @param group    群号
     * @param function 功能序号，定义在 medic.main.Main 中
     * @return 功能是否开启
     */
    public static boolean isOpen(long group, int function) {
        if (group != -1) {
            String s = getFunctionState(group + "", function);
            if (s.equals(DEF_STRING)) {
                closeFunction(group, function);
                return false;
            } else if (s.equals(ERR_STRING)) {
                // do nothing，已经使用 log 记录了该 Error
                return false;
            } else {
                return s.equals(OPEN);
            }
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "group:" + group + " function:" + function
                    + "\ntip：群参数-1，应替换为上一次发言群"));
            return false;
        }
    }

    /**
     * 检查 Log功能 是否启用，默认 Error/Warn 开启，Info 关闭.
     *
     * @param logFunction log功能序号，定义在 medic.main.Main 中
     * @return 功能是否开启
     */
    public static boolean isOpen(int logFunction) {
        if (logFunction == LOG_ERROR || logFunction == LOG_WARN || logFunction == LOG_INFO) {
            String s = getFunctionState(LOG_STATE_FILE_NAME, logFunction);
            boolean shouldOpen = logFunction != LOG_INFO;
            if (s.equals(DEF_STRING)) {
                if (shouldOpen) {
                    openFunction(logFunction);
                } else {
                    closeFunction(logFunction);
                }
                return shouldOpen;
            } else if (s.equals(ERR_STRING)) {
                // do nothing
                return shouldOpen;
            } else {
                return s.equals(OPEN);
            }
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "logFunction:" + logFunction
                    + "\ntip：参数只能是log功能对应的序号"));
            return false;
        }
    }

    public static String isOpenStr(long group, int function) {
        return isOpen(group, function) ? "开启" : "关闭";
    }

    public static String isOpenStr(int logFunction) {
        return isOpen(logFunction) ? "开启" : "关闭";
    }

    /**
     * 开启/关闭指定功能.
     *
     * @param fileName 功能开关状态所存储文件名
     * @param function 功能序号，定义在 medic.main.Main 中
     * @param status   功能开关，使用本类上面定义的 OPEN/CLOSE
     */
    private static void setFunctionState(String fileName, int function, String status) {
        set(SETTINGS + fileName, function, status);
    }

    public static void openFunction(long group, int function) {
        if (group != -1) {
            setFunctionState(group + "", function, OPEN);
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "group:" + group + " function:" + function
                    + "\ntip：群参数-1，仅用于群消息处理，不可用于临时/好友消息"));
        }
    }

    public static void openFunction(int logFunction) {
        if (logFunction == LOG_ERROR || logFunction == LOG_WARN || logFunction == LOG_INFO) {
            setFunctionState(LOG_STATE_FILE_NAME, logFunction, OPEN);
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "logFunction:" + logFunction
                    + "\ntip：参数只能是log功能对应的序号"));
        }
    }

    public static void closeFunction(long group, int function) {
        if (group != -1) {
            setFunctionState(group + "", function, CLOSE);
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "group:" + group + " function:" + function
                    + "\ntip：群参数-1，仅用于群消息处理，不可用于临时/好友消息"));
        }
    }

    public static void closeFunction(int logFunction) {
        if (logFunction == LOG_ERROR || logFunction == LOG_WARN || logFunction == LOG_INFO) {
            setFunctionState(LOG_STATE_FILE_NAME, logFunction, CLOSE);
        } else {
            logError(new Exception(SHOULD_CHECK_CODE
                    + "logFunction:" + logFunction
                    + "\ntip：参数只能是log功能对应的序号"));
        }
    }


    /* -- Log相关 -- */

    /**
     * 在 medic 日志界面记录信息，并将其写入文件.
     * data 可以传入一个或两个参数.
     * 传入 "e"/"w"/"i" 和字符串，将以 Error/Warn/Info 的级别 log.
     * 仅传入字符串，将以 Info 的级别 log.
     * saveInFile 为 true 时，将该记录保存在文件中。
     *
     * @param saveInFile 是否需要文件存储
     * @param data       要记录的信息
     */
    private static void log(boolean saveInFile, String... data) {
        try {
            Method methodLog = Class.forName("app.yashiro.medic.app.dic.Toolkit")
                    .getMethod("log", String[].class);
            methodLog.invoke(null, (Object) data);
        } catch (ClassNotFoundException | NoSuchMethodException
                | InvocationTargetException | IllegalAccessException e) {
            // do nothing
        }
        if (!saveInFile) {
            return;
        }
        try {
            File f = new File(LOG_PATH);
            if (!f.exists()) {
                f.getParentFile().mkdirs();
                f.createNewFile();
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(f, true));
            String s;
            if (data[0].equals("e")) {
                s = "Error";
            } else if (data[0].equals("w")) {
                s = "Warn";
            } else {
                s = "Info";
            }
            bw.write(s + " " + getFullTimeStr(System.currentTimeMillis()));
            bw.newLine();
            bw.write(data[1]);
            bw.newLine();
            bw.newLine();// 便于区分各个 log，空两行
            bw.close();
        } catch (IOException e) {
            // do nothing
        }
    }

    /**
     * 将异常转化为字符串.
     * 返回的字符串包含异常在代码中的详细调用情况，便于调试.
     *
     * @param e 异常
     * @return 异常转化后的字符串
     */
    private static String logException(Exception e) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        e.printStackTrace(new PrintStream(baos));
        return baos.toString();
    }

    /**
     * 记录并发送一个 Error.
     * 仅在影响词条正常运行情况下调用.
     * <p>
     * 若调用 logError 的方法有返回值，调用后应返回代表异常情况的默认值，
     * 以告知上层方法出现异常，并让其处理。
     * 使用样例如下，需要记录参数时：
     * {@code
     * logError(new Exception("[Error详细原因及解决方案]"));
     * }
     * 或
     * {@code
     * try {
     * ...
     * } catch (Exception e) {
     * logError(e);
     * }
     * }
     *
     * @param e 该异常应包含Error的详细信息，必要时应有相关解决方法
     */
    public static void logError(Exception e) {
        logError("", e);
    }

    /**
     * 需要记录参数以便定位时使用.
     * 使用样例如下：
     * {@code
     * try {
     * ...
     * } catch (Exception e) {
     * logError("[出现Error的方法名及参数]", e);
     * }
     * }
     *
     * @param s 方法及相关传入的参数
     * @param e 用于定位代码位置的异常
     */
    public static void logError(String s, Exception e) {
        if (isOpen(LOG_ERROR)) {
            String log = s + "\n" + logException(e);
            send(log + AUTHOR_TIP);
            log(true, "e", log);
        }
    }

    /**
     * 记录一个Warn，传入异常以记录报错位置.
     * 该方法仅在词条出现不影响程序执行的情况下使用.
     * <p>
     * 使用样例如下：
     * {@code
     * logWarn("[出现Warn的方法名]警告", new Exception(
     * "[Warn详细原因及解决方案]"));
     * }
     *
     * @param e 该异常应包含Warn的详细信息，必要时应有相关解决方法
     */
    public static void logWarn(Exception e) {
        if (isOpen(LOG_WARN)) {
            log(true, "w", logException(e));
        }
    }

    /**
     * 记录一个Info.
     * 使用样例如下：
     * {@code
     * logInfo("[要记录的信息]");
     * }
     *
     * @param s 要记录的信息
     */
    public static void logInfo(String s) {
        if (isOpen(LOG_INFO)) {
            log(true, "i", s);// 等价于log(s)
        }
    }

    /**
     * 记录一个 Info，一般用于调试阶段.
     * 使用样例如下：
     * {@code
     * logDebug(new Exception("[要记录的信息]"));
     * }
     *
     * @param e 包含要记录信息的异常，以便于定位相关代码
     */
    public static void logInfo(Exception e) {
        logInfo(logException(e));
    }


    /* -- 根目录路径、线程休眠 -- */

    /**
     * 返回SD卡路径.
     * 【不可使用 log（log 需要从文件获取开关状态，将进入死循环）】
     * 【安卓Q（即安卓10）使用极为严格的权限控制，无法访问外部路径】
     *
     * @return SD卡路径
     */
    private static String sdCardPath() {
        File sdDir = null;
        boolean sdCardExist = Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED);
        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();
            // 获取根目录，安卓Q以上获取不到
        }
        return sdDir == null ? "/storage/emulated/0" : sdDir.toString();
    }

    /**
     * 休眠
     *
     * @param millis 休眠时间
     */
    public static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            logError(e);
            Thread.currentThread().interrupt();
        }
    }


    /* -- 读写键值对 -- */

    /* 读写锁，通过自动加载的 Main.saveInstance(Object obj) 获得初值 */
    public static ReentrantReadWriteLock lock;

    /* 默认值，仅用做标识 */
    private static final int DEF_VAL = 0x80000000;// -2147483648
    public static final String DEF_STRING = DEF_VAL + "";
    public static final int DEF_INT = DEF_VAL;
    public static final long DEF_LONG = DEF_VAL;
    public static final double DEF_DOUBLE = DEF_VAL;
    /* 错误值，仅用做标识 */
    private static final int ERR_VAL = 0x80000001;// -2147483647
    public static final String ERR_STRING = ERR_VAL + "";
    public static final int ERR_INT = ERR_VAL;
    public static final long ERR_LONG = ERR_VAL;
    public static final double ERR_DOUBLE = ERR_VAL;

    /**
     * 以 UTF_8 编码读取一个字符串.
     * 通常情况下，useLog 应传入 true，表示在读取过程中使用 log.
     * 但该方法由 log 调用时（判断 log 是否开启），为避免递归死循环，useLog 应传入 false.
     * 文件存在，且其中有关键字对应的值时，返回该值；
     * 文件不存在，或文件存在但无该关键字时，返回默认值 DEF_STRING；
     * 出错返回错误值 ERR_STRING.
     *
     * @param path   路径
     * @param key    关键字
     * @param useLog 该方法内部是否需要使用 log
     * @return 获取到的字符串
     */
    private static String getString(String path, Object key, boolean useLog) {
        if (!(key instanceof String) && !(key instanceof Integer) && !(key instanceof Long)) {
            if (useLog) {
                logError(new Exception("关键字只能是String、Integer或Long\npath：" + path));
            }
            return ERR_STRING;
        }
        File file = new File(path);
        if (!file.exists()) {
            if (useLog) {
                logWarn(new Exception("文件不存在，返回默认值\npath：" + path + "\nkey：" + key));
            }
            return DEF_STRING;
        }
        if (file.isDirectory()) {
            if (useLog) {
                logError(new Exception("已存在文件夹\npath：" + path + "\nkey：" + key));
            }
            return ERR_STRING;
        }
        if (!file.canRead()) {
            if (useLog) {
                logError(new Exception("文件无法读取\npath：" + path + "\nkey：" + key));
            }
            return ERR_STRING;
        }
        lock.readLock().lock();
        Properties properties = new Properties();
        try (InputStreamReader input = new InputStreamReader
                (new FileInputStream(file), StandardCharsets.UTF_8)) {
            properties.load(input);
            String ret = properties.getProperty(key + "");
            if (ret == null) {
                if (useLog) {
                    logWarn(new Exception("文件中未找到该关键字对应的值，返回默认值\n" +
                            "path：" + path + "\nkey：" + key));
                }
                ret = DEF_STRING;
            }
            return ret;
        } catch (IOException e) {
            if (useLog) {
                logError("path：" + path + "\nkey：" + key, e);
            }
            return ERR_STRING;
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * 以 UTF_8 编码读取一个字符串.
     * 为避免 log 影响太多代码，规定 log 标记必须为字符串。
     * useLog 参数解释见 getString(String, Object, boolean)
     *
     * @see #getString(String, Object, boolean)
     */
    public static String getString(String path, Object key) {
        return getString(path, key, true);
    }

    public static int getInt(String path, Object key) {
        return Integer.parseInt(getString(path, key));
    }

    public static long getLong(String path, Object key) {
        return Long.parseLong(getString(path, key));
    }

    public static double getDouble(String path, Object key) {
        return Double.parseDouble(getString(path, key));
    }

    /**
     * 以 UTF_8 编码写入一个字符串.
     *
     * @param path 路径
     * @param key  关键字
     * @param val  要写入的值
     */
    public static void set(String path, Object key, Object val) {
        if (!(key instanceof String) && !(key instanceof Integer) && !(key instanceof Long)) {
            logError("写入键值对错误", new Exception(
                    "关键字只能是String、Integer或Long\n" + path));
            return;
        }
        if (!(val instanceof String) && !(val instanceof Integer)
                && !(val instanceof Long) && !(val instanceof Double)) {
            logError("写入键值对错误", new Exception(
                    "值只能是String、Integer、Long或Double\n" + path));
            return;
        }
        File file = new File(path);
        if (!file.exists()) {
            Objects.requireNonNull(file.getParentFile()).mkdirs();
            try {
                if (!file.createNewFile()) {
                    logError(new Exception(
                            "文件无法创建\npath:" + path + "\nkey：" + key + "\nval：" + val));
                    return;
                }
            } catch (IOException e) {
                logError("path:" + path + "\nkey：" + key + "\nval：" + val, e);
                return;
            }
        }
        if (file.isDirectory()) {
            logError(new Exception(
                    "已存在文件夹\npath:" + path + "\nkey：" + key + "\nval：" + val));
            return;
        }
        if (!file.canRead()) {
            logError(new Exception(
                    "文件无法读取\npath:" + path + "\nkey：" + key + "\nval：" + val));
            return;
        }
        if (!file.canWrite()) {
            logError(new Exception(
                    "文件无法写入\npath:" + path + "\nkey：" + key + "\nval：" + val));
            return;
        }
        lock.writeLock().lock();
        Properties properties = new Properties();
        try (InputStreamReader input = new InputStreamReader
                (new FileInputStream(file), StandardCharsets.UTF_8)) {
            properties.load(input);
        } catch (IOException e) {
            logError("path:" + path + "\nkey：" + key + "\nval：" + val, e);
            lock.writeLock().unlock();
            return;
        }
        properties.setProperty(key + "", val + "");
        try (OutputStreamWriter output = new OutputStreamWriter
                (new FileOutputStream(file), StandardCharsets.UTF_8)) {
            // 注意，new的时候，由于没有append，所以文件已经被清空
            // 如果跟上面的输入流一起建立，输入流就只能读空文件
            properties.store(output, null);
        } catch (IOException e) {
            logError("path:" + path + "\nkey：" + key + "\nval：" + val, e);
        } finally {
            lock.writeLock().unlock();
        }
    }


    /* -- 数据库存取 -- */

    public static void execSQL(String path, String sql) {
        SQLiteDatabase database = SQLiteDatabase.openOrCreateDatabase(path, null);
        database.execSQL(sql);
        database.close();
    }

    public static String[][] query(String path, String sql, String... selectionArgs) {
        SQLiteDatabase database = SQLiteDatabase.openOrCreateDatabase(path, null);
        Cursor cursor = database.rawQuery(sql, selectionArgs);
        String[][] data = new String[cursor.getCount()][cursor.getColumnCount()];
        for (int row = 0; row < data.length; row++) {
            cursor.moveToNext();
            for (int col = 0; col < data[row].length; col++) {
                data[row][col] = cursor.getString(col);
            }
        }
        cursor.close();
        database.close();
        return data;
    }


    /* -- 序列化与反序列化 -- */

    /**
     * 序列化对象.
     *
     * @param obj      将要被序列化的对象
     * @param filePath 序列化后对象的存储位置
     */
    public static void serialize(Object obj, String filePath) {
        if (obj == null) {
            logError(new Exception("对象为空\npath：" + filePath));
            return;
        }
        String cls = obj.getClass().getCanonicalName();
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                Objects.requireNonNull(file.getParentFile()).mkdirs();
                if (!file.createNewFile()) {
                    logError("序列化" + cls + "错误", new Exception(
                            "无法创建文件\npath：" + filePath));
                    return;
                }
            }
            if (file.isDirectory() || !file.canWrite()) {
                logError("序列化" + cls + "错误", new Exception(
                        "已存在文件夹或文件无法写入\npath：" + filePath));
                return;
            }
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(obj);
            oos.close();
        } catch (IOException e) {
            logError("序列化" + cls + "错误\npath：" + filePath, e);
        }
    }

    public static void serialize(Object obj, File file) {
        serialize(obj, file.getPath());
    }


    /**
     * 反序列化对象.
     *
     * @param filePath 被序列化的对象的存储位置
     * @return Object对象
     */
    public static Object deserialize(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            logWarn(new Exception("反序列化错误，文件不存在\npath：" + filePath));
            return null;
        } else {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                return ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                logError("反序列化错误", e);
                return null;
            }
        }
    }

    /* -- 本机文件操作 -- */

    private static boolean canMove(File oldFile, File newFile) {
        try {
            String oldPath = oldFile.getCanonicalPath();
            if (!oldFile.exists()) {
                logError("判断能否移动文件错误", new Exception(
                        "原始文件/文件夹不存在\n" + oldPath));
                return false;
            }
            if (!newFile.exists()) {
                return true;
            }
            String newPath = newFile.getCanonicalPath();
            if (oldFile.isDirectory()) {
                if (newFile.isFile()) {
                    logError("判断能否移动文件错误", new Exception(
                            "原始类型不同于目标类型\n旧文件夹：" + oldPath + "\n新文件：" + newPath));
                    return false;
                }
                File[] children = oldFile.listFiles();
                if (children != null) {
                    for (File f : children) {
                        if (!canMove(f, new File(newFile, f.getName()))) {
                            return false;
                        }
                    }
                }
            } else {
                if (newFile.isDirectory()) {
                    logError("判断能否移动文件错误", new Exception(
                            "原始类型不同于目标类型\n旧文件夹：" + oldPath + "\n新文件：" + newPath));
                    return false;
                }
            }
            return true;
        } catch (IOException e) {
            logError("获取绝对路径错误", e);
            return false;
        }
    }

    public static void move0(File oldFile, File newFile, boolean overlap) {
        if (newFile.isDirectory()) {
            newFile.mkdirs();
            File[] children = oldFile.listFiles();
            if (children != null) {
                for (File f : children) {
                    move0(new File(oldFile, f.getName()), newFile, overlap);
                }
            }
        } else {
            if (newFile.exists() && overlap) {
                newFile.delete();
            }
            oldFile.renameTo(newFile);
        }
    }

    /**
     * 移动文件或文件夹.
     * oldFile 与 newFile 必须类型相同
     *
     * @param oldFile 原文件/文件夹
     * @param newFile 新文件/文件夹
     * @param overlap 是否覆盖
     * @return 移动成功返回true，否则返回false
     */
    public static boolean move(File oldFile, File newFile, boolean overlap) {
        if (canMove(oldFile, newFile)) {
            move0(oldFile, newFile, overlap);
            return true;
        } else {
            return false;
        }
    }

    public static boolean move(String oldFile, String newFile, boolean overlap) {
        return move(new File(oldFile), new File(newFile), overlap);
    }

    /**
     * 重命名文件或文件夹.
     *
     * @param file    原文件/文件夹
     * @param newName 新文件名/文件夹名，文件名不需要写后缀
     * @return 重命名成功返回true，否则返回false
     */
    public static boolean rename(File file, String newName) {
        try {
            String oldPath = file.getCanonicalPath();
            if (!file.exists()) {
                logError("重命名文件错误", new Exception(
                        "原文件不存在\n" + oldPath));
                return false;
            }
            String newPath = oldPath.substring(0, oldPath.lastIndexOf(File.separator))
                    + File.separator + newName;
            if (file.isFile() && file.getName().contains(".")) {
                String fileName = file.getName();
                String type = fileName.substring(fileName.lastIndexOf('.') + 1);
                newPath += "." + type;
            }
            return file.renameTo(new File(newPath));
        } catch (IOException e) {
            logError("重命名文件时，获取文件完整路径错误", e);
            return false;
        }
    }

    public static boolean rename(String filePath, String newName) {
        return rename(new File(filePath), newName);
    }

    /**
     * 复制文件或文件夹.
     *
     * @param oldFile 原文件/文件夹
     * @param newFile 新文件/文件夹
     * @param overlap 是否覆盖
     * @return 复制成功返回true，否则返回false
     */
    public static boolean copy(File oldFile, File newFile, boolean overlap) {
        if (canMove(oldFile, newFile)) {
            copy0(oldFile, newFile, overlap);
            return true;
        } else {
            return false;
        }
    }

    public static boolean copy(String oldFile, String newFile, boolean overlap) {
        return copy(new File(oldFile), new File(newFile), overlap);
    }

    public static void copy0(File oldFile, File newFile, boolean overlap) {
        if (newFile.isDirectory()) {
            newFile.mkdirs();
            File[] children = oldFile.listFiles();
            if (children != null) {
                for (File f : children) {
                    copy0(new File(oldFile, f.getName()), newFile, overlap);
                }
            }
        } else {
            if (newFile.exists() && !overlap) {
                return;
            }
            try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(oldFile));
                 BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(newFile))) {
                byte[] buff = new byte[1024];
                int len;
                while ((len = bis.read(buff)) != -1) {
                    bos.write(buff, 0, len);
                }
            } catch (IOException e) {
                logError("读写文件错误", e);
            }
        }
    }

    /**
     * 删除文件或文件夹.
     *
     * @param filePath 想删除的文件/文件夹
     * @return 删除成功返回true，否则返回false
     */
    public static boolean delete(String filePath) {
        File file = new File(filePath);
        if (file.isDirectory()) {// 如果是目录，先删除里面所有的东西
            String[] children = file.list();// 获取文件夹内所有文件路径
            if (children != null) {// 判断文件夹里面有没有东西，有就删除
                for (String f : children) {
                    delete(filePath + File.separator + f);
                }
            }
        }
        return file.delete();// 文件或空目录可以直接删除
    }

    /**
     * 获取文件夹里面的所有文件名
     *
     * @param directoryPath 文件夹
     * @return 如果传入文件，或者不存在的路径，返回null；
     * 如果传入空文件夹，返回空的String数组；
     * 如果传入非空文件夹，返回所有文件名
     */
    public static String[] getAllFileName(String directoryPath) {
        return new File(directoryPath).list();
    }


    /* -- 随机数、随机长度字符串等 -- */

    /**
     * 斐波那契数列的某一项的值
     *
     * @param index 下标，从1开始
     * @return 斐波那契数列对应下标的值
     */
    public static int getFibonacci(int index) {
        if (index <= 0) {
            throw new IllegalArgumentException("传入的数字" + index + "低于1");
        }
        if (index == 1 || index == 2) {
            return 1;
        } else {
            return getFibonacci(index - 1) + getFibonacci(index - 2);
        }
    }

    public static final Random random = new Random();

    /**
     * 返回一个均匀分布的随机整数（包括上下限）.
     *
     * @param min 下限
     * @param max 上限
     * @return 随机整数
     */
    public static int getRandomInt(int min, int max) {
        if (min > max) {
            int temp = min;
            min = max;
            max = temp;
        }
        // random.nextInt(a)随机生成[0,a)的随机数
        return random.nextInt(max - min + 1) + min;
    }

    /**
     * 返回一个均匀分布的随机小数（包括上下限）.
     *
     * @param min 下限
     * @param max 上限
     * @return 随机小数
     */
    public static double getRandomDouble(double min, double max) {
        if (min > max) {
            double temp = min;
            min = max;
            max = temp;
        }
        // random.nextDouble()随机生成[0,1]的随机数
        return random.nextDouble() * (max - min) + min;
    }

    public static final double TWENTY_PERCENT = 0.84;
    public static final double TEN_PERCENT = 1.28;
    public static final double FIVE_PERCENT = 1.64;
    public static final double THREE_PERCENT = 1.88;
    public static final double TWO_PERCENT = 2.05;
    public static final double ONE_PERCENT = 2.32;
    public static final double FIVE_PER_THOUSAND = 2.57;
    public static final double THREE_PER_THOUSAND = 2.75;
    public static final double TWO_PER_THOUSAND = 2.88;
    public static final double ONE_PER_THOUSAND = 3.08;

    /**
     * 返回一个正态分布的随机小数（包括上下限）.
     *
     * @param min      下限
     * @param max      上限
     * @param coverage 以标准正态分布表为准，确定正态分布有效范围
     *                 传入Mx.ONE_PERCENT等数值，或者自定义数值（必须为正）
     *                 比如，查表得2.32为0.9898，2.33为0.9901，
     *                 则传入2.32代表取得上限概率约为1%，取得下限概率约为1%
     * @return 随机小数
     */
    public static double getNormalDistributionDouble(double min, double max, double coverage) {
        if (coverage <= 0) {
            return (max + min) / 2;
        }
        double a = random.nextGaussian();
        if (a > coverage) {
            a = coverage;
        } else if (a < -coverage) {
            a = -coverage;
        }
        a = a / (coverage * 2) + 0.5;// [0,1]
        return (max - min) * a + min;
    }

    public static double getNormalDistributionDouble(double min, double max) {
        return getNormalDistributionDouble(min, max, ONE_PERCENT);
    }

    /**
     * 返回一个正态分布的随机整数（包括上下限）.
     * 利用正态分布小数，扩充范围至[min,max+1)
     *
     * @param min      下限
     * @param max      上限
     * @param coverage 以标准正态分布表为准，确定正态分布有效范围
     *                 传入Mx.ONE_PERCENT等数值，或者自定义数值（必须为正）
     *                 比如，查表得2.32为0.9898，2.33为0.9901，
     *                 则传入2.32代表取得上限概率约为1%，取得下限概率约为1%
     * @return 随机小数
     */
    public static int getNormalDistributionInt(int min, int max, double coverage) {
        double num = getNormalDistributionDouble(min, max + 1.0, coverage);
        return num >= max + 1.0 ? max : (int) num;
    }

    public static int getNormalDistributionInt(int min, int max) {
        return getNormalDistributionInt(min, max, ONE_PERCENT);
    }

    /**
     * 返回一个中文随机字符
     *
     * @return 随机中文字符
     */
    public static char getRandomChar() {
        String str = "";
        byte[] b = new byte[2];
        b[0] = (byte) (176 + Math.abs(random.nextInt(39)));// 高位
        b[1] = (byte) (161 + Math.abs(random.nextInt(93)));// 低位
        try {
            str = new String(b, "GBK");
        } catch (UnsupportedEncodingException e) {
            logError("getRandomChar错误", e);
        }
        return str.charAt(0);
    }

    /**
     * 返回指定长度随机中文字符串
     *
     * @return 指定长度随机中文字符串
     */
    public static String getRandomString(int len) {
        if (len <= 0) {
            throw new IllegalArgumentException("getRandomString的len小于等于0");
        }
        StringBuilder name = new StringBuilder();
        int charNum = getRandomInt(1, 4);
        for (int i = 0; i < charNum; i++) {
            name.append(getRandomChar());
        }
        return name.toString();
    }

    /**
     * 返回随机长度随机中文字符串
     *
     * @return 指定长度随机中文字符串
     */
    public static String getRandomString(int lenMin, int lenMax) {
        if (lenMin <= 0) {
            throw new IllegalArgumentException("getRandomString的lenMin小于等于0");
        }
        if (lenMax <= 0) {
            throw new IllegalArgumentException("getRandomString的lenMax小于等于0");
        }
        return getRandomString(getRandomInt(lenMin, lenMax));
    }


    /* -- 画图相关 -- */

    /**
     * 将本地图片转成Bitmap.
     *
     * @param path 已有图片的路径
     * @return Bitmap
     */
    public static Bitmap openImage(String path) {
        Bitmap bitmap;
        try {
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(path));
            bitmap = BitmapFactory.decodeStream(bis);
            bis.close();
        } catch (IOException e) {
            // log exception
            return null;
        }
        return bitmap;
    }

    /**
     * 从网址获取Bitmap
     *
     * @param src 网址
     * @return 解析完毕的Bitmap
     */
    public static Bitmap returnBitMap(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
        } catch (IOException e) {
            // log exception
            return null;
        }
    }


    /* -- 从网站获取数据 -- */

    /**
     * 从网站获取字符串，通常是别人的 api 返回的 json 格式数据.
     * 获取到字符串后，应检查是否为""，再进行后续处理。
     *
     * @param url 要获取信息的网站
     * @return 获取到的字符串，由于不能确定json类型，只能返回String
     */
    public static String getStringFromURL(String url) {
        try {
            StringBuilder result = new StringBuilder();
            BufferedReader br;
            URLConnection connection = new URL(url).openConnection();
            connection.connect();
            br = new BufferedReader(new InputStreamReader(
                    connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                result.append(line);
            }
            br.close();
            return result.toString();
        } catch (IOException e) {
            logError(e);
            return "";
        }
    }


    /* -- 时间相关 -- */

    /**
     * 将long类型的时间（以毫秒ms为单位）改成字符串.
     *
     * @param time   通常是System.currentTimeMillis()
     * @param format 格式标准
     * @return 返回指定格式的字符串
     */
    public static String getTimeStr(long time, String format) {
        return new SimpleDateFormat(format, Locale.CHINA).format(new Date(time));
    }

    /**
     * 将long类型的时间（以毫秒ms为单位）改成完整时间字符串.
     *
     * @param time 通常是System.currentTimeMillis()
     * @return 返回格式为"2020-01-01 00:00:00"的字符串
     */
    public static String getFullTimeStr(long time) {
        return getTimeStr(time, "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 将long类型的时间（以毫秒ms为单位）改成年月日字符串.
     *
     * @param time 通常是System.currentTimeMillis()
     * @return 返回格式为"2020-01-01"的字符串
     */
    public static String getDateStr(long time) {
        return getTimeStr(time, "yyyy-MM-dd");
    }

    /**
     * 将long类型的时间（以毫秒ms为单位）改成时分秒字符串.
     *
     * @param time 通常是System.currentTimeMillis()
     * @return 返回格式为"00:00:00"的字符串
     */
    public static String getTimeStr(long time) {
        return getTimeStr(time, "HH:mm:ss");
    }

    /**
     * 返回传入时间所在周的周一日期
     *
     * @param time 通常是System.currentTimeMillis()
     * @return 返回格式为"2020-01-01"的字符串
     */
    public static String getMondayOfThisWeek(long time) {
        Calendar calendar = new GregorianCalendar(Locale.CHINA);
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setTime(new Date(time));
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
                .format(calendar.getTime());
    }

    /**
     * 返回传入时间下周的周一日期
     *
     * @param time 通常是System.currentTimeMillis()
     * @return 返回格式为"2020-01-01"的字符串
     */
    public static String getNextMonday(long time) {
        return getMondayOfThisWeek(time + 604800000L);
    }

    /**
     * 将以秒s为单位的时间差改成字符串.
     *
     * @param timeDiff 时间差
     * @return 返回格式为"a天b小时c分d秒"的字符串
     * 如果数字为0，则不会显示该部分
     * 比如传入60，输出为"1分"
     */
    public static String timeDiffStr(int timeDiff) {
        if (timeDiff < 0) {
            throw new IndexOutOfBoundsException("时间差" + timeDiff + "必须为正");
        }
        String str = "";
        if (timeDiff >= 86400) {
            int day = timeDiff / 86400;
            timeDiff -= day * 86400;
            str = str + day + "天";
        }
        if (timeDiff >= 3600) {
            int hour = timeDiff / 3600;
            timeDiff -= hour * 3600;
            str = str + hour + "时";
        }
        if (timeDiff >= 60) {
            int minute = timeDiff / 60;
            timeDiff -= minute * 60;
            str = str + minute + "分";
        }
        if (timeDiff != 0) {
            str = str + timeDiff + "秒";
        }
        return str;
    }

    /**
     * 获取输入时间当天零点的时间戳
     *
     * @param time 任意时间，毫秒
     * @return 返回当天零点时间戳
     */
    public static long getZeroTime(long time) {
        return time - (time + TimeZone.getDefault().getRawOffset()) % (1000 * 3600 * 24);
    }

}
