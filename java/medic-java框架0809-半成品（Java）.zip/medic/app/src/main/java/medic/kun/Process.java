package medic.kun;

import medic.main.Utils;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static medic.main.Api.*;
import static medic.main.Main.*;
import static medic.main.Utils.*;

public class Process extends Thread {

    /* -- 1.基础构造 -- */

    private final int msgType;
    private final String msg;
    private final long group;
    private final long qq;
    private final String nick;
    private final boolean isAdmin;
    private final long msgTime;

    public Process(int msgType, String msg, long group, long qq, boolean isAdmin) {
        this.msgType = msgType;
        this.msg = msg;
        this.group = group;
        this.qq = qq;
        this.nick = api.getGroupNick();
        this.isAdmin = isAdmin;
        this.msgTime = api.getTime();
        int a = getInt(ROOT_PATH + "当前赛季", 1);
        nowSeason = a == DEF_INT ? 1 : a;
    }


    /* -- 2.实例对象 -- */

    private static final String ROOT_PATH = DATA + "鲲/";

    public static final String BASE_PATH = ROOT_PATH + "base/";
    private Base base;
    private Base atBase;

    /**
     * 群聊消息使用该构造，将昵称存起来.
     */
    Base getBase(long qq, String nick) {
        Base b = (Base) deserialize(BASE_PATH + qq);
        if (b == null) {
            return null;
        }
        // 正确性验证
        b.setQQNick(nick);
        int level = b.getLevel();
        if (level == 1) {
            return b;
        }
        b.setAtk(Math.max((int) (level * 1.0), Math.min(b.getAtk(), (int) (level * 1.5))));
        b.setDef(Math.max((int) (level * 0.6), Math.min(b.getDef(), (int) (level * 0.9))));
        b.setHp(Math.max((int) (level * 4.0), Math.min(b.getHp(), (int) (level * 6.0))));
        return b;
    }

    /**
     * 私聊消息使用该构造.
     */
    Base getBase(long qq) {
        Base b = (Base) deserialize(BASE_PATH + qq);
        if (b == null) {
            return null;
        }
        // 正确性验证
        int level = b.getLevel();
        if (level == 1) {
            return b;
        }
        b.setAtk(Math.max((int) (level * 1.0), Math.min(b.getAtk(), (int) (level * 1.5))));
        b.setDef(Math.max((int) (level * 0.6), Math.min(b.getDef(), (int) (level * 0.9))));
        b.setHp(Math.max((int) (level * 4.0), Math.min(b.getHp(), (int) (level * 6.0))));
        return b;
    }

    public static final String ITEM_PATH = ROOT_PATH + "item/";
    private Item item;
    private Item atItem;

    Item getItem(long qq) {
        File baseFile = new File(ITEM_PATH + qq);
        if (!baseFile.exists()) {
            return new Item(qq);
        } else {
            return (Item) deserialize(ITEM_PATH + qq);
        }
    }

    public static final String TIME_PATH = ROOT_PATH + "time/";
    private Time time;

    Time getTime() {
        if (time != null) {
            return time;
        }
        File baseFile = new File(TIME_PATH + qq);
        if (!baseFile.exists()) {
            return new Time(qq);
        } else {
            return (Time) deserialize(TIME_PATH + qq);
        }
    }

    public static final String RANK_PATH = ROOT_PATH + "rank";
    private Rank rank;

    Rank getRank() {
        if (rank != null) {
            return rank;
        }
        File baseFile = new File(RANK_PATH);
        if (!baseFile.exists()) {
            return new Rank();
        } else {
            return (Rank) deserialize(RANK_PATH);
        }
    }

    public static final String BOSS_PATH = ROOT_PATH + "boss";
    private Boss boss;

    Boss getBoss() {
        rank = getRank();
        if (boss != null) {
            return boss;
        }
        File baseFile = new File(BOSS_PATH);
        if (!baseFile.exists()) {
            return new Boss(rank);
        } else {
            return (Boss) deserialize(BOSS_PATH);
        }
    }


    /* -- 3.被动调用 -- */

    static int nowSeason;

    /**
     * 赛季结算.
     */
    private void seasonSettlement(Base base, Item item) {
        int level = base.getLevel();
        int newLevel = 0;
        int addMoney = 0;
        for (int i = base.getSeason(); i < nowSeason; i++) {
            newLevel = getNewLv(level);
            addMoney += level / 3;
        }
        base.setSeason(nowSeason);
        base.setLevel(newLevel);
        item.addMoney(addMoney);
        getOnTheList(base);
        api.send(base.getQQ(), "S" + nowSeason + "赛季现已开启！\n" +
                base.getName() + "鲲初始等级为" + newLevel + "\n" +
                "获得萌泪币" + addMoney + "枚\n快去养鲲吧！");
    }

    /**
     * 赛季结算等级继承.
     *
     * @param level 原先鲲的等级
     * @return 继承后的等级
     */
    private static int getNewLv(int level) {
        int newLevel = 0;
        int i = 10;
        for (; i > 1; i--) {
            int q = (10 - i) * (10 - i) * 300 + 3000;
            if (level <= q) {
                break;
            } else {
                newLevel = newLevel + q * i / 10;
                level = level - q;
            }
        }
        return newLevel + level * i / 10;
    }

    /**
     * 开启新赛季
     */
    private void setNewSeason() {
        set(ROOT_PATH + "当前赛季", 1, nowSeason + 1);
        rank.clear();
        delete(BOSS_PATH);
    }


    /* -- 4.主动调用 -- */

    /**
     * 正则处理消息.
     * 标△的是最常用的.
     * <p>
     * 常用元字符
     * .	匹配除换行符以外的任意字符。要匹配 .，请使用 \。△
     * \	将下一个字符标记为或特殊字符、或原义字符、或向后引用、或八进制转义符
     * 要匹配 \ 字符，请使用 \\。
     * \w	匹配字母或数字或下划线，等价于[A-Za-z0-9_]
     * \s	匹配任意的空白符
     * \d	匹配数字，等价于[0-9]
     * \b	匹配单词的开始或结束
     * ^	匹配字符串的开始。要匹配 ^ 字符，请使用 \^。
     * $	匹配字符串的结束。要匹配 $ 字符，请使用 \$。
     * <p>
     * 常用限定符
     * *	重复零次或更多次。要匹配 * 字符，请使用 \*。△
     * +	重复一次或更多次。要匹配 + 字符，请使用 \+。△
     * ?	重复零次或一次
     * {n}	重复n次
     * {n,}	重复n次或更多次
     * {n,m}	重复n到m次
     * |	匹配左侧或右侧任意一个。要匹配 |，请使用 \|。△
     * ()	标记一个子表达式的开始和结束位置。子表达式可以获取供以后使用。
     * 通常用于优先级的确立。要匹配 (，请使用 \(。△
     * []	标记一个中括号表达式的开始。通常用于匹配内部任意一个。
     * 要匹配 [，请使用 \[。△
     * {}	标记限定符表达式的开始。要匹配 {，请使用 \{。
     * <p>
     * 常用反义词
     * \W	匹配任意不是字母，数字，下划线的字符，等价于[^A-Za-z0-9_]
     * \S	匹配任意不是空白符的字符
     * \D	匹配任意非数字的字符，等价于[^0-9]
     * \B	匹配不是单词开头或结束的位置
     * [^x]	匹配除了x以外的任意字符
     * [^aeiou]	匹配除了aeiou这几个字母以外的任意字符
     * <p>
     * 示例：
     * [0-9]	匹配任意一个数字
     * [0-9A-Za-z]	匹配任意一个数字或字母
     * [0-9]*	匹配任意零个或多个数字
     * [0-9]+	匹配任意一个或多个数字
     * (查看|)[Bb]oss(属性|)
     * 匹配查看Boss、查看boss、Boss属性、boss属性、查看Boss属性、查看boss属性
     */
    @Override
    public void run() {
        if (msg.matches("养鲲菜单|菜单21|功能21")) {
            if (msgType == GROUP_MSG) {
                send("菜单过长，请私聊我！\n" +
                        "tips：养鲲相关大部分指令都只能私聊触发哦！\n" +
                        "具体情况见菜单~");
                return;
            }
            send("[g]表示群聊可用，[p]表示私聊可用\n"
                    + "[p]养鲲：从无尽之海抓一条奇怪的鲲\n"
                    + "[p]属性：查看鲲的属性\n"
                    + "[g]查看：查看别人鲲的属性，栗子【查看@xx】\n"
                    + "[p]洗练：洗练指定属性，栗子【洗练攻防血 12】\n"
                    + "[g]进击：互相挑战，栗子【进击@xx】\n"
                    + "[p]挑战：全群挑战Boss，可得丰厚奖励\n"
                    + "[p]Boss：查看Boss属性");
            Utils.sleep(300);
            send("[gp]排行：查看本群鲲界等级前十\n"
                    + "[p]背包：查看自己的所有道具\n"
                    + "[p]命名：消耗改名卡将鲲界的鲲改名，栗子【命名戮鲲】\n"
                    + "[g]赠送：赠送萌泪币，栗子【赠送200@xxx】\n"
                    + "[p]商城：查看道具列表，显示买/卖价格\n"
                    + "[p]购买/出售：买卖道具，栗子【购买洗练卡 3】\n"
                    + "[gp]签到：每日签到，可得一定量萌泪币，连续签到奖励更多\n"
                    + "[p]重置时间：自定义摸鲲等功能的每日重置时间，栗子【设置重置时间8】\n"
                    + "当前为S" + nowSeason + "赛季！");
            return;
        } else if (msg.matches("排行|排行榜")) {
            rankingList();
            return;
        } else if (msg.matches("商城")) {
            if (msgType == GROUP_MSG) {
                return;
            }
            send("———— 商城 ————\n"
                    + " 道具    购买    出售\n"
                    + "改名卡：18888 / 15110\n"
                    + "洗练卡：     30 /    24\n"
                    + "挑战券：   100 /     -\n"
                    + "查看卡：   100 /    80\n");
            return;
        }

        base = getBase(qq, api.getGroupNick());
        if (base != null) {
            item = getItem(qq);
            if (base.getSeason() != nowSeason) {
                seasonSettlement(base, item);
            }
        }

        if (msg.matches("养鲲|摸鲲|抓鲲|捕鲲")) {
            if (msgType == GROUP_MSG) {
                return;
            }
            time = getTime();
            mkInit();// 方法内判断是否初始化
            serialize(base, BASE_PATH + qq);
            serialize(item, ITEM_PATH + qq);
            serialize(time, TIME_PATH + qq);
            return;
        }

        if (msg.matches("属性")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            attribute();
        } else if (msg.matches("洗练.+ +[0-9]+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            int a = Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1));
            if (a != 0) {
                washout(msg.substring(2, msg.indexOf(' ')), a);
            }
        } else if (msg.matches("挑战")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            time = getTime();
            boss = getBoss();
            attackBossInit();
            serialize(time, TIME_PATH + qq);
            serialize(boss, BOSS_PATH);
        } else if (msg.matches("(查看|)[Bb]oss(属性|)")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            boss = getBoss();
            viewBossAttribute();
            serialize(boss, BOSS_PATH);
        } else if (msg.matches("道具|背包")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            bag();
        } else if (msg.matches("购买.+ +[0-9]+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            int a = Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1));
            if (a != 0) {
                buy(msg.substring(2, msg.indexOf(' ')), a);
            }
        } else if (msg.matches("出售.+ +[0-9]+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            int a = Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1));
            if (a != 0) {
                sell(msg.substring(2, msg.indexOf(' ')), a);
            }
        } else if (msg.matches("购买.+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            buy(msg.substring(2), 1);
        } else if (msg.matches("出售.+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            sell(msg.substring(2), 1);
        } else if (msg.matches("签到")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            dailyAttendance();
        } else if (isAdmin && msg.matches("更改.+ +[0-9]+")) {
            int a = Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1));
            if (a != 0) {
                change(msg.substring(2, msg.indexOf(' ')), a);
            }
        } else if (msg.matches("设置重置时间 *[0-9]+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            int a;
            if (msg.contains(" ")) {
                a = Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1));
            } else {
                a = Integer.parseInt(msg.substring(6));
            }
            if (a >= 0 && a <= 23) {
                time = getTime();
                setResetTime(a);
                serialize(time, TIME_PATH + qq);
            }
        } else if (msg.matches("命名.+")) {
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            if (msgType == GROUP_MSG) {
                return;
            }
            name(msg.substring(2));
        }

        if (msg.contains("@")) {
            if (msgType != GROUP_MSG) {
                return;
            }
            if (!msg.matches("查看@.+")
                    && !msg.matches("进击@.+")
                    && !msg.matches("赠送[0-9]+@.+")) {
                return;
            }
            if (base == null) {
                send(qq, "在无尽之海，也许你会有所发现....\ntips：私聊发送【摸鲲】");
                return;
            }
            long atQQ = api.getAtQQ();
            if (atQQ == 0L) {
                send(qq, "你发送的消息是假艾特，无法获取被艾特人的QQ！\n" +
                        "请不要复制别人发的消息，要自己手动艾特哦~");
                return;
            }
            atBase = getBase(atQQ, api.getAtNick());
            atItem = getItem(atQQ);
            if (atBase == null || atBase.getLevel() == 1) {
                send(qq, "对方还没鲲呢！");
                return;
            }
            if (atBase.getSeason() != nowSeason) {
                seasonSettlement(atBase, atItem);
            }
            if (msg.matches("查看@.+")) {
                viewOthersAttribute();
            } else if (msg.matches("进击@.+")) {
                time = getTime();
                attackOthersInit();
                serialize(time, TIME_PATH + qq);
            } else if (msg.matches("赠送[0-9]+@.+")) {
                giveMoney(Integer.parseInt(msg.substring(2, msg.indexOf('@'))));
            }
            if (atBase != null) {
                serialize(atBase, BASE_PATH + atQQ);
                serialize(atItem, ITEM_PATH + atQQ);
            }
        }

        if (base != null) {
            serialize(base, BASE_PATH + qq);
            serialize(item, ITEM_PATH + qq);
        }
    }

    private void change(String key, int newValue) {
        if (key.equals("萌泪币")) {
            item.setMoney(newValue);
        } else if (key.equals("等级")) {
            base.setLevel(newValue);
        }
    }

    private void setResetTime(int resetTime) {
        if (time.getResetTime() == resetTime) {
            send(qq, "当前重置时间是" + resetTime + "时，无需更改！");
            return;
        }
        long lastSetTime = time.getLastSetTime();
        if (msgTime - lastSetTime < 604800000L) {
            send(qq, "距上一次设置重置时间不足一周！\n请于"
                    + getFullTimeStr(lastSetTime + 604800000L) + "后再试！");
            return;
        }
        time.setResetTime(resetTime);
        time.setLastSetTime(msgTime);
        send(qq, "当前重置时间已更改为" + resetTime + "时！");
    }

    /**
     * 判断摸鲲条件，并进行时间处理.
     */
    private void mkInit() {
        long targetTime = time.mkTargetTime(msgTime);
        if (isAdmin || targetTime == msgTime) {
            mk();
        } else {
            int timeDiff = (int) (targetTime - msgTime) / 1000;
            send(qq, "下次摸鲲时间为" + getTimeStr(targetTime, "HH:mm:ss") +
                    "，还需等待" + timeDiffStr(timeDiff) + "~");
        }
    }

    /**
     * 摸鲲.
     */
    private void mk() {
        int level = base.getLevel();
        String name = base.getName();
        if (level == 1) {
            base.setLevel(getNormalDistributionInt(50, 300));// 最小值必须大于NORMAL_INT，即1
            send(qq, "你孤身一人去无尽之海，发现一只小鲲崽遗弃在海岸边。\n"
                    + "你看它非常可爱，便给它取名为" + name
                    + "鲲，决定抚养它成为最强的鲲王。\n"
                    + "只是这无尽之海非常广阔，你还需要抓更多的鲲喂给它，使其慢慢成长....");
            return;
        }
        int money = item.getMoney();
        int event = getRandomInt(0, 99);
        if (event < 10) {
            // 无事发生（0-9）
            send(qq, "你去无尽之海，结果什么都没摸到！\n"
                    + "只好带着" + name + "鲲回去了。");
        } else if (event < 20) {
            // 被偷走钱（10-19）
            int subMoney = (int) getRandomDouble(money * 0.001, money * 0.015);
            subMoney = Math.min(subMoney, level / 200);
            item.setMoney(money - subMoney);
            send(qq, "你去无尽之海，结果什么都没摸到！\n"
                    + "一摸背包，发现萌泪币少了" + subMoney + "！\n"
                    + "你很生气，却不知是谁偷了你的钱，只好带着" + name + "鲲回去了。");
        } else if (event < 30) {
            // 等级降低（20-29）
            int subLevel = getNormalDistributionInt(20, 50 + level / 500);
            base.setLevel(level - subLevel);
            send(qq, "你去无尽之海，忽然一只巨鲲向你咬来！\n"
                    + "这时，" + name + "鲲挺身而出，替你挡下了这一击，"
                    + "自己却受伤，等级降低了" + subLevel + "！\n"
                    + "你立刻离开无尽之海，带着" + name + "鲲回去休养了。");
        } else {
            // 正常摸鲲（30-99）
            int addLevel = event < 36 ?
                    getNormalDistributionInt(100, 250 + level / 100)
                    : getNormalDistributionInt(20, 50 + level / 500);
            int addMoney = event > 33 && event < 40 ?
                    getNormalDistributionInt(addLevel * 10, addLevel * 30)
                    : getNormalDistributionInt(addLevel * 2, addLevel * 6);
            base.setLevel(level + addLevel);
            item.setMoney(money + addMoney);
            if (event < 34) {
                // 鲲等级提高（30-33）
                send(qq, "你去无尽之海，抓了很多很多的鲲！\n"
                        + "你将大部分鲲喂给" + name + "鲲，等级提高" + addLevel + "！\n"
                        + "剩余的鲲都被你卖掉，获得" + addMoney + "枚萌泪币！");
            } else if (event < 36) {
                // 鲲等级、萌泪币提高（34-35）
                send(qq, "你去无尽之海，不仅抓了很多鲲，还捞上来一个大宝箱！\n"
                        + "你将鲲喂给" + name + "鲲，等级提高" + addLevel + "！\n"
                        + "你又打开宝箱，发现里面竟然有" + addMoney + "枚萌泪币！");
            } else if (event < 40) {
                // 萌泪币提高（36-39）
                send(qq, "你去无尽之海，抓了一些鲲，还捞上来一个小宝箱！\n"
                        + "你将鲲喂给" + name + "鲲，等级提高" + addLevel + "！\n"
                        + "你又打开宝箱，发现里面竟然有" + addMoney + "枚萌泪币！");
            } else {
                // 正常（40-99）
                send(qq, "你去无尽之海，抓了一些鲲！\n"
                        + "你将大部分鲲喂给" + name + "鲲，等级提高" + addLevel + "！\n"
                        + "剩余的鲲都被你卖掉，获得" + addMoney + "枚萌泪币！");
            }
            if (level + addLevel > 120000) {
                setNewSeason();
            }
            getOnTheList(base);
            serialize(rank, RANK_PATH);
        }
    }

    /**
     * 整理排行榜
     *
     * @param base 鲲基础属性
     */
    private void getOnTheList(Base base) {
        if (rank == null) {
            rank = getRank();
        }
        rank.put(base);
    }

    /**
     * 属性
     */
    private void attribute() {
        int level = base.getLevel();
        int atk = base.getAtk();
        int def = base.getDef();
        int hp = base.getHp();
        String atkGrade = grade(atk, level, 1, 1.5);
        String defGrade = grade(def, level, 0.6, 0.9);
        String hpGrade = grade(hp, level, 4, 6);
        rank = getRank();
        int nowRank = rank.getRank(base);
        int allNum = rank.getSize();
        String send = base.getName() + "鲲正在到处游弋。\n"
                + "等级：" + level + "\n"
                + "血量：" + hp + "（" + hpGrade + "）\n"
                + "攻击：" + atk + "（" + atkGrade + "）\n"
                + "防御：" + def + "（" + defGrade + "）\n"
                + "当前排名：" + nowRank + "\n";
        if (nowRank == 1) {
            send(qq, send + "超过了所有人！太强了鸭！");
        } else if (nowRank == allNum) {
            send(qq, send + "谁都没有超过！太惨了鸭！");
        } else {
            String s = String.format(Locale.CHINA, "%.2f",
                    (allNum - nowRank) * 100.0 / allNum);
            send(qq, send + "超过了" + s + "%的人！");
        }
    }

    private String grade(int attributeValue, int level, double min, double max) {
        if (attributeValue == (int) (level * max)) {
            return "MAX";
        }
        if (attributeValue == (int) (level * min)) {
            return "MIN";
        }
        double cha = level * (max - min);
        double overPart = attributeValue - level * min;

        String str;
        if (overPart < cha / 8) {
            str = "E";
        } else if (overPart < cha * 2 / 8) {
            str = "D";
            overPart -= cha / 8;
        } else if (overPart < cha * 3 / 8) {
            str = "C";
            overPart -= cha * 2 / 8;
        } else if (overPart < cha * 4 / 8) {
            str = "B";
            overPart -= cha * 3 / 8;
        } else if (overPart < cha * 5 / 8) {
            str = "A";
            overPart -= cha * 4 / 8;
        } else if (overPart < cha * 6 / 8) {
            str = "S";
            overPart -= cha * 5 / 8;
        } else if (overPart < cha * 7 / 8) {
            str = "SS";
            overPart -= cha * 6 / 8;
        } else {
            str = "SSS";
            overPart -= cha * 7 / 8;
        }
        cha /= 8;
        if (overPart < cha / 3) {
            return str + "-";
        } else if (overPart < cha * 2 / 3) {
            return str;
        } else {
            return str + "+";
        }
    }

    private void viewOthersAttribute() {
        int ckk = item.getCkk();
        if (ckk <= 0) {
            send(qq, "你没有查看卡，无权查看对方信息！");
            return;
        }
        item.setCkk(ckk - 1);
        int level = atBase.getLevel();
        int atk = atBase.getAtk();
        int def = atBase.getDef();
        int hp = atBase.getHp();
        String atkGrade = grade(atk, level, 1, 1.5);
        String defGrade = grade(def, level, 0.6, 0.9);
        String hpGrade = grade(hp, level, 4, 6);
        send(qq, atBase.getName() + "鲲\n"
                + "主人：" + atBase.getQQNick() + "\n"
                + "等级：" + level + "\n"
                + "血量：" + hp + "（" + hpGrade + "）\n"
                + "攻击：" + atk + "（" + atkGrade + "）\n"
                + "防御：" + def + "（" + defGrade + "）");
    }

    /**
     * 洗练.
     *
     * @param type  要洗练的属性
     * @param times 每个属性洗练的次数
     */
    private void washout(String type, int times) {
        int level = base.getLevel();
        boolean atk = type.contains("攻");
        boolean def = type.contains("防");
        boolean hp = type.contains("血");
        int xlkNum = item.getXlk();
        int useNum = 0;
        useNum = atk ? useNum + times : useNum;
        useNum = def ? useNum + times : useNum;
        useNum = hp ? useNum + times : useNum;
        if (xlkNum < useNum) {
            send(qq, "洗练卡不足" + useNum + "！");
            return;
        }
        item.setXlk(xlkNum - useNum);
        String s = base.getName() + "鲲正在洗练....";
        if (atk) {
            int maxNum = 0;
            for (int i = 0; i < times; i++) {
                maxNum = Math.max(maxNum, (int) getNormalDistributionDouble(level * 1.0, level * 1.5));
            }
            s = s + "\n洗练攻击" + times + "次，最高" + maxNum;
            base.setAtk(maxNum);
        }
        if (def) {
            int maxNum = 0;
            for (int i = 0; i < times; i++) {
                maxNum = Math.max(maxNum, (int) getNormalDistributionDouble(level * 0.6, level * 0.9));
            }
            s = s + "\n洗练防御" + times + "次，最高" + maxNum;
            base.setDef(maxNum);
        }
        if (hp) {
            int maxNum = 0;
            for (int i = 0; i < times; i++) {
                maxNum = Math.max(maxNum, (int) getNormalDistributionDouble(level * 4.0, level * 6.0));
            }
            s = s + "\n洗练血量" + times + "次，最高" + maxNum;
            base.setHp(maxNum);
        }
        send(qq, atk || def || hp ? s : "你要洗练神马？\n大声点，人家听不清啦！\n" +
                "栗子【洗练攻防血 3】\n（至少洗练一项）");
    }

    private void attackOthersInit() {
        int myLevel = base.getLevel();
        int atLevel = atBase.getLevel();
        if (atLevel * 1.5 < myLevel) {
            send(qq, "你的鲲等级太高了，是想欺负萌新吗？");
            return;
        } else if (api.getAtQQ() == qq) {
            send(qq, base.getName() + "鲲表示不想打自己，并向你丢了一个白眼！");
            return;
        }
        long targetTime = time.jjTargetTime(msgTime);
        if (isAdmin || targetTime == msgTime) {
            attackOthers();
        } else {
            int timeDiff = (int) (targetTime - msgTime) / 1000;
            send(qq, "下次进击时间为" + getTimeStr(targetTime, "HH:mm:ss") +
                    "，还需等待" + timeDiffStr(timeDiff) + "~");
        }
    }

    private void attackOthers() {
        int num1 = getRandomInt(100, 110);
        int num2 = getRandomInt(90, 100);
        int myAtk = base.getAtk() * num1 / 100;
        int atAtk = atBase.getAtk() * num2 / 100;
        int myDef = base.getDef() * num1 / 100;
        int atDef = atBase.getDef() * num2 / 100;
        int myHp = base.getHp() * num1 / 100;
        int atHp = atBase.getHp() * num2 / 100;
        int myAtkTimes = 0;
        int atAtkTimes = 0;
        int myAllDam = 0;
        int atAllDam = 0;
        String myName = base.getName();
        String atName = atBase.getName();
        StringBuilder str = new StringBuilder(myName + "鲲 VS " + atName + "鲲\n");
        boolean isWin;

        while (true) {
            int myDam = Math.max(myAtk - atDef, 1);
            myAtkTimes++;
            myAllDam += myDam;
            if (atHp <= myAllDam) {
                str.append(myName).append("鲲攻击").append(myAtkTimes).append("次\n")
                        .append("共造成伤害").append(myAllDam).append("点\n");
                if (myAtkTimes > 1) {
                    str.append(atName).append("鲲反击").append(atAtkTimes).append("次\n")
                            .append("共造成伤害").append(atAllDam).append("点\n");
                }
                str.append("获胜啦！\n");
                isWin = true;
                break;
            }
            int atDam = Math.max(atAtk - myDef, 1);
            atAtkTimes++;
            atAllDam += atDam;
            if (myHp <= atAllDam) {
                str.append(myName).append("鲲攻击").append(myAtkTimes).append("次\n")
                        .append("共造成伤害").append(myAllDam).append("点\n")
                        .append(atName).append("鲲反击").append(atAtkTimes).append("次\n")
                        .append("共造成伤害").append(atAllDam).append("点\n")
                        .append("失败了！\n");
                isWin = false;
                break;
            }
        }
        int myLevel = base.getLevel();
        int atLevel = atBase.getLevel();
        int myAdd = isWin ? getAdd(myLevel) : (int) (getAdd(myLevel) * 0.7);
        int atAdd = (int) (getAdd(atLevel) * 0.25);
        myLevel += myAdd;
        atLevel += atAdd;
        send(qq, str + "经过磨炼，\n" +
                myName + "鲲等级增加" + myAdd + "！\n" +
                atName + "鲲等级增加" + atAdd + "！");
        base.setLevel(myLevel);
        atBase.setLevel(atLevel);
        if (myLevel > 120000 || atLevel > 120000) {
            setNewSeason();
        }
        getOnTheList(base);
        getOnTheList(atBase);
        serialize(rank, RANK_PATH);
    }

    private int getAdd(int level) {
        int maxLevel = getRank().getMaxLevel();
        double fj1 = maxLevel * 0.4;
        double fj2 = maxLevel * 0.65;
        double fj3 = maxLevel * 0.9;
        if (level < fj1) {
            return getNormalDistributionInt(400, 800);
        } else if (level < fj2) {
            return getNormalDistributionInt(200, 400);
        } else if (level < fj3) {
            return getNormalDistributionInt(100, 200);
        } else {
            return getNormalDistributionInt(50, 100);
        }
    }

    private void attackBossInit() {
        int ticket = item.getTzq();
        if (ticket <= 0) {
            send(qq, "你还没挑战券呢！");
            return;
        }
        long targetTime = time.tzTargetTime(msgTime);
        if (isAdmin || targetTime == msgTime) {
            item.setTzq(ticket - 1);
            attackBoss();
        } else {
            int timeDiff = (int) (targetTime - msgTime) / 1000;
            send(qq, "下次挑战时间为" + getTimeStr(targetTime, "HH:mm:ss") +
                    "，还需等待" + timeDiffStr(timeDiff) + "~");
        }
    }

    private void attackBoss() {
        int bossHp = boss.getHp();
        if (bossHp <= 0) {
            boss.newBoss(rank);
            bossHp = boss.getHp();
        }
        int bossAtk = boss.getAtk();
        int bossDef = boss.getDef();
        int myAtk = base.getAtk();
        int myDef = base.getDef();
        int myHp = base.getHp();
        int myAtkTimes = 0;
        int bossAtkTimes = 0;
        int myAllDam = 0;
        int bossAllDam = 0;
        String myName = base.getName();
        String bossName = boss.getName();
        double attributeIncrease;
        if (getRandomDouble(4, 14) < 7) {
            attributeIncrease = getNormalDistributionDouble(4, 10);
            if (attributeIncrease > 7) {
                attributeIncrease = 14 - attributeIncrease;
            }
        } else {
            attributeIncrease = getNormalDistributionDouble(0, 14);
            if (attributeIncrease < 7) {
                attributeIncrease = 14 - attributeIncrease;
            }
        }
        myAtk = (int) (myAtk * attributeIncrease);
        myDef = (int) (myDef * attributeIncrease * 0.1);
        myHp = (int) (myHp * attributeIncrease * 0.5);
        StringBuilder str = new StringBuilder(myName + "鲲 VS "
                + bossName + "鲲\n" + "随机加成倍数："
                + String.format(Locale.CHINA, "%.2f", attributeIncrease) + "\n");
        boolean isWin;
        while (true) {
            int myDam = Math.max(myAtk - bossDef, 1);
            myAtkTimes++;
            myAllDam += myDam;
            if (bossHp <= myAllDam) {
                str.append(myName).append("鲲攻击").append(myAtkTimes).append("次\n")
                        .append("共造成伤害").append(myAllDam).append("点\n");
                if (myAtkTimes > 1) {
                    str.append(bossName).append("鲲反击").append(bossAtkTimes).append("次\n")
                            .append("共造成伤害").append(bossAllDam).append("点\n");
                }
                str.append("获胜啦！\n");
                isWin = true;
                break;
            }
            int atDam = Math.max(bossAtk - myDef, 1);
            bossAtkTimes++;
            bossAllDam += atDam;
            if (myHp <= bossAllDam) {
                str.append(myName).append("鲲攻击").append(myAtkTimes).append("次\n")
                        .append("共造成伤害").append(myAllDam).append("点\n")
                        .append(bossName).append("鲲反击").append(bossAtkTimes).append("次\n")
                        .append("共造成伤害").append(bossAllDam).append("点\n")
                        .append("失败了！\n");
                isWin = false;
                break;
            }
        }
        boss.setHp(bossHp - myAllDam);
        int bossLevel = boss.getLevel();
        int getMoney = isWin ? (int) ((long) myAllDam * 2 / bossLevel + 10000)
                : (int) ((long) myAllDam * 2 / bossLevel + 1000);
        item.addMoney(getMoney);
        send(qq, str.append("获得了").append(getMoney).append("枚萌泪币！").toString());
    }

    private void viewBossAttribute() {
        int ckk = item.getCkk();
        if (ckk <= 0) {
            send(qq, "你没有查看卡，无权查看对方信息！");
            return;
        }
        item.setCkk(ckk - 1);
        int hp = boss.getHp();
        if (hp <= 0) {
            boss.newBoss(rank);
            hp = boss.getHp();
        }
        send(qq, "Boss " + boss.getName() + "鲲\n" +
                "攻击：" + boss.getAtk() + "\n" +
                "防御：" + boss.getDef() + "\n" +
                "剩余血量：" + hp);
    }

    private void rankingList() {
        rank = getRank();
        List<Map.Entry<Long, Integer>> list = rank.getList();
        int size = list.size();
        if (size == 0) {
            send(qq, "当前无人上榜！\n（摸鲲、进击均可上榜）");
            return;
        }
        if (msgType == GROUP_MSG) {
            size = Math.min(size, 10);
        } else {
            size = Math.min(size, 100);
        }
        StringBuilder sb = new StringBuilder();
        int j;
        for (int i = 0; i < size; i++) {
            long rankQQ = list.get(i).getKey();
            Base b = getBase(rankQQ);
            j = i % 10;
            if (j != 0) {
                sb.append("\n");
            }
            sb.append(i + 1).append(" Lv.").append(b.getLevel())
                    .append(" ").append(b.getName()).append("鲲\n")
                    .append(b.getQQNick()).append("(").append(b.getQQ()).append(")");
            if (j == 9) {
                send(sb.toString());
                Utils.sleep(300);
                sb = new StringBuilder();
            }
        }
        if (!sb.toString().equals("")) {
            send(sb.toString());
        }
    }

    private void bag() {
        send("改名卡：" + item.getGmk() + "张\n" +
                "洗练卡：" + item.getXlk() + "张\n" +
                "挑战券：" + item.getTzq() + "张\n" +
                "查看卡：" + item.getCkk() + "张\n" +
                "萌泪币：" + item.getMoney() + "枚");
    }

    private void name(String newName) {
        newName = newName.replaceAll("\\s*", "");
        if (newName.substring(newName.length() - 1).equals("鲲")) {
            newName = newName.substring(0, newName.length() - 1);
        }
        if (newName.equals("")) {
            send(qq, "指令提示：命名xx（鲲）");
            return;
        }
        int gmk = item.getGmk();
        String oldName = base.getName();
        if (gmk <= 0) {
            send(qq, oldName + "鲲摇了摇头，表示不喜欢这个名字！\n" +
                    "（缺少改名卡，请在商城购买！）");
            return;
        }
        item.setGmk(gmk - 1);
        base.setName(newName);
        send(qq, oldName + "鲲高兴地绕着你转了两圈，" +
                "看来它很喜欢这个名字！\n" +
                "以后它就叫" + newName + "鲲啦！");
    }

    private void giveMoney(int giveMoney) {
        if (giveMoney <= 0) {
            send(qq, "难道你想偷窃吗？？？");
            return;
        }
        int myMoney = item.getMoney();
        if (giveMoney > myMoney) {
            send(qq, "钱不够！\n你在想peach？");
            return;
        }
        item.subMoney(giveMoney);
        int fee = (int) (giveMoney * 0.15);
        int add = giveMoney - fee;
        atItem.addMoney(add);
        send(qq, "收取" + fee + "手续费，已赠送" + add + "枚萌泪币！");
    }

    private void buy(String itemName, int buyNum) {
        if (buyNum <= 0) {
            send(qq, "购买数量有误！");
            return;
        }
        int money = item.getMoney();
        int price;
        int itemNum;
        switch (itemName) {
            case "改名卡":
                itemNum = item.getGmk();
                if (itemNum + buyNum > 1) {
                    send(qq, "改名卡上限为1！");
                    return;
                }
                price = 18888;
                break;
            case "洗练卡":
                itemNum = item.getXlk();
                if (itemNum + buyNum > 9999) {
                    send(qq, "洗练卡上限为9999！");
                    return;
                }
                price = 30;
                break;
            case "挑战券":
                itemNum = item.getTzq();
                if (itemNum + buyNum > 99) {
                    send(qq, "挑战券上限为99！");
                    return;
                }
                price = 100;
                break;
            case "查看卡":
                itemNum = item.getCkk();
                if (itemNum + buyNum > 99) {
                    send(qq, "查看卡上限为99！");
                    return;
                }
                price = 100;
                break;
            default:
                send(qq, "你要买神马东西？\n大声一点，人家听不清啦！");
                return;
        }
        if (money < price * buyNum) {
            send(qq, "现有萌泪币：" + money + "\n不足" + price * buyNum + "，无法购买！");
            return;
        }
        switch (itemName) {
            case "改名卡":
                item.setGmk(itemNum + buyNum);
                break;
            case "洗练卡":
                item.setXlk(itemNum + buyNum);
                break;
            case "挑战券":
                item.setTzq(itemNum + buyNum);
                break;
            case "查看卡":
                item.setCkk(itemNum + buyNum);
                break;
            default:
        }
        item.subMoney(price * buyNum);
        send(qq, "成功购买" + itemName + "×" + buyNum + "！\n" +
                "花费" + price * buyNum + "枚萌泪币！\n" +
                "现有萌泪币：" + item.getMoney() + "枚");
    }

    private void sell(String itemName, int soldNum) {
        if (soldNum <= 0) {
            send(qq, "出售数量有误！");
            return;
        }
        int price;
        int itemNum;
        switch (itemName) {
            case "改名卡":
                price = 15110;
                itemNum = item.getGmk();
                break;
            case "洗练卡":
                price = 24;
                itemNum = item.getXlk();
                break;
            case "查看卡":
                price = 80;
                itemNum = item.getCkk();
                break;
            default:
                send(qq, "你要卖神马东西？\n大声一点，人家听不清啦！");
                return;
        }
        if (itemNum < soldNum) {
            send(qq, itemName + "在哪？\n你在想peach？");
            return;
        }
        switch (itemName) {
            case "改名卡":
                item.setGmk(itemNum - soldNum);
                break;
            case "洗练卡":
                item.setXlk(itemNum - soldNum);
                break;
            case "查看卡":
                item.setCkk(itemNum - soldNum);
                break;
            default:
        }
        item.addMoney(price * soldNum);
        send(qq, "成功出售" + itemName + "×" + soldNum + "！\n" +
                "获得" + price * soldNum + "枚萌泪币！\n" +
                "现有萌泪币：" + item.getMoney() + "枚");
    }

    private void dailyAttendance() {
        String today = getDateStr(msgTime);
        String lastSignInDate = base.getLastSignInDate();
        int allTimes = base.getAllSignInTimes();
        int weekTimes = base.getWeekSignInTimes();
        if (lastSignInDate.equals(today)) {
            send(qq, "共签到" + allTimes + "次\n" +
                    "本周已签到" + weekTimes + "天\n" +
                    "明天再来签到吧！");
            return;
        }
        base.setLastSignInDate(today);
        base.setAllSignInTimes(++allTimes);
        String thisMonday = getMondayOfThisWeek(msgTime);
        if (thisMonday.compareTo(lastSignInDate) > 0) {
            weekTimes = 1;
            base.setWeekSignInTimes(weekTimes);
        } else {
            base.setWeekSignInTimes(++weekTimes);
        }
        int getMoney;
        switch (weekTimes) {
            case 1:
                getMoney = 666;
                break;
            case 2:
                getMoney = 999;
                break;
            case 3:
                getMoney = 1314;
                break;
            case 4:
                getMoney = 1888;
                break;
            case 5:
                getMoney = 2888;
                break;
            case 6:
                getMoney = 3888;
                break;
            case 7:
                getMoney = 6666;
                break;
            default:
                getMoney = 0;
        }
        item.addMoney(getMoney);
        send(qq, "共签到" + allTimes + "次\n" +
                "本周已签到" + weekTimes + "天\n" +
                "获得" + getMoney + "枚萌泪币！");
    }

}
