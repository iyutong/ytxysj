package medic.kun;

import java.io.*;

import static medic.main.Utils.*;

public class Time implements Serializable {

    private final String filePath;

    private int resetTime = 0;// 何时更新，0-23某一个整点
    private long lastSetTime = 0;// 上次设置resetTime的时间
    private long mkTime = 0;// 上一次摸的时间
    private int mkTimes = 0;// 已经摸的次数
    private long jjTime = 0;
    private int jjTimes = 0;
    private long tzTime = 0;
    private int tzTimes = 0;

    Time(long qq) {
        this.filePath = Process.TIME_PATH + qq;
    }

    private static final long serialVersionUID = 1L;

    public int getResetTime() {
        return resetTime;
    }

    public void setResetTime(int resetTime) {
        this.resetTime = resetTime;
    }

    public long getLastSetTime() {
        return lastSetTime;
    }

    public void setLastSetTime(long lastSetTime) {
        this.lastSetTime = lastSetTime;
    }

    public long mkTargetTime(long msgTime) {
        long reset = getZeroTime(msgTime) + resetTime * 3600000;// 当日resetTime点
        if (reset > msgTime) {
            reset -= 86400000;// 上一个resetTime点
        }
        // 不同天：上一次在reset前，且现在在reset后（必然），则重置
        if (mkTime < reset) {
            mkTime = msgTime;
            mkTimes = 1;
            return msgTime;
        }
        // 相同天：判断时间
        long targetTime = mkTime + Math.min(getFibonacci(mkTimes + 1), 180) * 60000;
        if (targetTime > msgTime) {
            // 返回目标时间和下一个resetTime点中较小的一个
            return Math.min(targetTime, reset + 86400000);
        } else {
            mkTime = msgTime;
            mkTimes++;
            return msgTime;
        }
    }

    public long jjTargetTime(long msgTime) {
        long reset = getZeroTime(msgTime) + resetTime * 3600000;
        if (reset > msgTime) {
            reset -= 86400000;
        }
        if (jjTime < reset) {
            jjTime = msgTime;
            jjTimes = 1;
            return msgTime;
        }
        long targetTime = jjTime + Math.min(getFibonacci(jjTimes + 1), 180) * 60000;
        if (targetTime > msgTime) {
            return Math.min(targetTime, reset + 86400000);
        } else {
            jjTime = msgTime;
            jjTimes++;
            return msgTime;
        }
    }

    public long tzTargetTime(long msgTime) {
        long reset = getZeroTime(msgTime) + resetTime * 3600000;
        if (reset > msgTime) {
            reset -= 86400000;
        }
        if (tzTime < reset) {
            tzTime = msgTime;
            tzTimes = 1;
            return msgTime;
        }
        long targetTime = tzTimes == 1 || tzTimes == 2 ?
                tzTime + 3600000 * 3 : tzTime + 3600000 * 24;
        if (targetTime > msgTime) {
            return Math.min(targetTime, reset + 86400000);
        } else {
            tzTime = msgTime;
            tzTimes++;
            return msgTime;
        }
    }


}
