package medic.kun;

import android.annotation.SuppressLint;

import java.io.*;
import java.util.*;

public class Rank implements Serializable {

    private final String filePath;

    private HashMap<Long, Integer> baseMap;// <qq, level>

    @SuppressLint("UseSparseArrays")
    Rank() {
        this.filePath = Process.RANK_PATH;
        baseMap = new HashMap<>();// SparseArrays倒序插入非常耗时，不推荐
    }

    private static final long serialVersionUID = 1L;

    public List<Map.Entry<Long, Integer>> getList() {
        List<Map.Entry<Long, Integer>> baseList = new ArrayList<>(baseMap.entrySet());
        baseList.sort(new Comparator<Map.Entry<Long, Integer>>() {
            public int compare(Map.Entry<Long, Integer> o1, Map.Entry<Long, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());// 降序排序
            }
        });
        return baseList;
    }

    public void put(Base base) {
        baseMap.put(base.getQQ(), base.getLevel());
    }

    public int getMaxLevel() {
        int maxLevel = 0;
        for (Map.Entry<Long, Integer> entry : baseMap.entrySet()) {
            int level = entry.getValue();
            if (level > maxLevel) {
                maxLevel = level;
            }
        }
        return maxLevel;
    }

    public int getRank(Base base) {
        if (!baseMap.containsKey(base.getQQ())) {
            return 0;
        }
        int rank = 1;
        int myLevel = base.getLevel();
        for (Map.Entry<Long, Integer> entry : baseMap.entrySet()) {
            int level = entry.getValue();
            if (level > myLevel) {
                rank++;
            }
        }
        return rank;
    }

    public int getSize(){
        return baseMap.size();
    }

    public void clear() {
        baseMap.clear();
    }

}
