package medic.pcr;

import java.io.*;
import java.util.ArrayList;

public class Boss implements Serializable {

    private final String filePath;

    private String name;
    private int zhoumu;
    private int num;
    private int maxHp;
    private int nowHp;
    private ArrayList<BaseAndTime> atkList;

    Boss(long group) {
        this.filePath = Process.ROOT_PATH + group + "/boss";
        this.zhoumu = 1;
        this.num = 1;
        newBoss(1, 1);
        this.atkList = new ArrayList<>(30);
    }

    private static final long serialVersionUID = 1L;

    public String getName() {
        return name;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public int getNowHp() {
        return nowHp;
    }

    public void setNowHp(int nowHp) {
        this.nowHp = nowHp;
    }

    public int getZhoumu() {
        return zhoumu;
    }

    public int getNum() {
        return num;
    }

    public BaseAndTime getAtkList(int index) {
        if (atkList.isEmpty()) {
            return null;
        } else {
            return atkList.get(index);
        }
    }

    public void add(long qq, int times, boolean isEndAtk) {
        atkList.add(new BaseAndTime(qq, times, isEndAtk));
    }

    public void set(int index, BaseAndTime b) {
        atkList.set(index, b);
    }

    public void remove(long qq, int minTimes, int maxTimes) {
        for (int i = atkList.size() - 1; i >= 0; i--) {
            BaseAndTime bt = atkList.get(i);
            if (bt.getQq() == qq && bt.getTimes() >= minTimes && bt.getTimes() <= maxTimes) {
                remove(i);
            }
        }
    }

    public void remove(int index) {
        atkList.remove(index);
    }

    public int getSize() {
        return atkList.size();
    }

    public int getMyIndex(long qq) {
        for (int i = 0; i < atkList.size(); i++) {
            BaseAndTime bt = atkList.get(i);
            if (bt.getQq() == qq) {
                return i;
            }
        }
        return -1;
    }

    public int getMyIndex(long qq, int times) {
        for (int i = 0; i < atkList.size(); i++) {
            BaseAndTime bt = atkList.get(i);
            if (bt.getQq() == qq && bt.getTimes() == times) {
                return i;
            }
        }
        return -1;
    }

    public void clear(){
        atkList.clear();
    }

    /**
     * 更改boss至下一个
     */
    public void newBoss() {
        if (num == 5) {
            zhoumu++;
            num = 1;
        } else {
            num++;
        }
        newBoss(zhoumu, num);
    }

    public void newBoss(int zhoumu, int num) {
        this.zhoumu = zhoumu;
        this.num = num;
        if (num == 1) {
            name = "龙";
            maxHp = 6000000;
        } else if (num == 2) {
            name = "鸟";
            maxHp = 8000000;
        } else if (num == 3) {
            name = "？";
            maxHp = 10000000;
        } else if (num == 4) {
            name = "？";
            maxHp = 12000000;
        } else if (num == 5) {
            name = "？";
            maxHp = 20000000;
        }
        nowHp = maxHp;
    }

}
