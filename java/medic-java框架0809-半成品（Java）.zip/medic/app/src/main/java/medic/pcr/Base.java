package medic.pcr;

import java.io.*;

public class Base implements Serializable {

    private final String filePath;

    private String nick;
    private int atkTimes;// 已经出刀次数
    private int applyTimes;// 已经排刀次数，保证 出刀次数<=排刀次数<=3
    private boolean isEndAtk;
    private long lastTime;
    private int treeZhouMu;
    private int treeNum;

    Base(long group, long qq, String nick, long time) {
        this.nick = nick;
        this.filePath = Process.ROOT_PATH + "/" + group + "/member/" + qq;
        this.atkTimes = 0;
        this.applyTimes = 0;
        this.isEndAtk = false;
        this.lastTime = time;
        this.treeZhouMu = 0;
        this.treeNum = 0;
    }

    private static final long serialVersionUID = 1L;

    public int getAtkTimes() {
        return atkTimes;
    }

    public void setAtkTimes(int atkTimes) {
        this.atkTimes = atkTimes;
    }

    public boolean isEndAtk() {
        return isEndAtk;
    }

    public void setEndAtk(boolean endAtk) {
        isEndAtk = endAtk;
    }

    public long getLastTime() {
        return lastTime;
    }

    public void setLastTime(long lastTime) {
        this.lastTime = lastTime;
    }

    public int getTreeZhouMu() {
        return treeZhouMu;
    }

    public void setTreeZhouMu(int treeZhouMu) {
        this.treeZhouMu = treeZhouMu;
    }

    public int getTreeNum() {
        return treeNum;
    }

    public void setTreeNum(int treeNum) {
        this.treeNum = treeNum;
    }

    public String getNick() {
        return nick;
    }

    public int getApplyTimes() {
        return applyTimes;
    }

    public void setApplyTimes(int applyTimes) {
        this.applyTimes = applyTimes;
    }

}
