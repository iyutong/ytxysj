package medic.kun;

import java.io.*;

import static medic.main.Utils.*;

public class Base implements Serializable {

    /*
    在今后对属性进行扩充时，一定要记得在定义的同时赋初值。
    否则该属性将会一直为空，无法利用！
    */
    private long qq;
    private String qqNick;
    private final String filePath;
    private int season = Process.nowSeason;
    private String name = getRandomString(1, 4);
    private int level = 1;
    private int atk = 1;
    private int def = 1;
    private int hp = 1;
    private int signInTimes = 0;
    private int keepSignInTimes = 0;
    private String lastSignInDate = "";
    //private int[] favorite = new int[7];// 好感度，最近七天操作次数，影响属性加成

    /**
     * 注意，不要在这里赋初值，尽量在定义的同时就进行赋值操作。
     * 因为反序列化一个对象，并不会调用该构造函数，新属性也就无初值，无法使用。
     */
    Base(long qq, String qqNick) {
        this.qq = qq;
        this.qqNick = qqNick;
        this.filePath = Process.BASE_PATH + qq;
    }

    private static final long serialVersionUID = 1L;

    public long getQQ() {
        return qq;
    }

    public String getQQNick() {
        return qqNick;
    }

    public void setQQNick(String qqNick) {
        this.qqNick = qqNick;
    }

    public int getSeason() {
        return season;
    }

    public void setSeason(int season) {
        this.season = season;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getAllSignInTimes() {
        return signInTimes;
    }

    public void setAllSignInTimes(int signInTimes) {
        this.signInTimes = signInTimes;
    }

    public int getWeekSignInTimes() {
        return keepSignInTimes;
    }

    public void setWeekSignInTimes(int keepSignInTimes) {
        this.keepSignInTimes = keepSignInTimes;
    }

    public String getLastSignInDate() {
        return lastSignInDate;
    }

    public void setLastSignInDate(String lastSignInDate) {
        this.lastSignInDate = lastSignInDate;
    }

}
