package medic.pcr;

import medic.main.Utils;

import java.io.File;
import java.util.Objects;

import static medic.main.Utils.*;
import static medic.main.Main.*;

public class Process extends Thread {

    /*
    新增指令：sl
    新增伤害预计值，不超过预计的都可以出刀；
    新增伤害提前结算，超过预计值的人提前结算将有警告
    允许修改最近一刀的数值，更早的刀没法改，等着被鲨吧
    新增伤害列表，记录每个人每个boss出刀次数、总伤害
    （这需要每个人伤害正常记录为前提，不能有报0的那种
    新增伤害总排行，显示各部分伤害；
    新增伤害平均值总排行（个人排行的合并
    个人排行（xxx：100w，200w，……\n
    boss排行（xxx：100w\n
    （一周目按照一定比例削弱？
    修改现有指令表述，更方便调用
     */

    private final int msgType;
    private final String msg;
    private final long group;
    private final long qq;
    private final String nick;
    private final boolean isAdmin;
    private final long msgTime;

    public Process(int msgType, String msg, long group, long qq, boolean isAdmin) {
        this.msgType = msgType;
        this.msg = msg;
        this.group = group;
        this.qq = qq;
        this.nick = api.getGroupNick();
        this.isAdmin = isAdmin;
        this.msgTime = api.getTime();
    }

    public static final String ROOT_PATH = DATA + "公主连结R/";

    private Base base;

    void createBase(long qq) {
        File f = new File(ROOT_PATH + group + "/member/" + qq);
        if (!f.exists()) {
            serialize(new Base(group, qq, nick, msgTime), f);
            send(qq, "欢迎你加入该行会！");
        } else {
            send(qq, "你已加入该行会，无法重复加入！");
        }
    }

    Base getBase(long qq) {
        String filePath = ROOT_PATH + group + "/member/" + qq;
        Base b = (Base) deserialize(filePath);
        if (b == null) {
            return null;
        }
        long todayFiveAM = getZeroTime(msgTime) + 18000000;
        if (b.getLastTime() < todayFiveAM && todayFiveAM < msgTime) {
            b.setAtkTimes(0);
            b.setApplyTimes(0);
            b.setEndAtk(false);
            b.setLastTime(msgTime);
        }
        return b;
    }

    private Boss boss;

    Boss getBoss() {
        File f = new File(ROOT_PATH + group + "/boss");
        if (!f.exists()) {
            return new Boss(group);
        } else {
            return (Boss) deserialize(ROOT_PATH + group + "/boss");
        }
    }

    @Override
    public void run() {
        if (msg.matches("指令|列表|指令列表|菜单|[公工行]会战")) {
            send("boss：查看boss信息\n" +
                    "修改/更改 [周目] [第几个] 剩余血量：修改boss信息\n" +
                    "排刀：申请出刀，可申请多次直至可出刀上限\n" +
                    "取消：取消自己的所有排刀\n" +
                    "打掉的血量/击杀：输入打掉boss多少血，杀了可以发击杀\n" +
                    "上树：会长也救不了你.jpg\n" +
                    "下树+伤害：在没人救你的情况下强制下树\n" +
                    "查树：查看树上挂了哪些人");
            Utils.sleep(300);
            send("出刀：查看当前出刀顺序\n" +
                    "查询：查看自己排刀、出刀次数\n" +
                    "查询@xxx：查看指定人排刀、出刀次数\n" +
                    "公会/行会：查看所有人排刀、出刀次数\n" +
                    "加入：加入公会\n" +
                    "退出：退出公会\n" +
                    "踢+艾特/qq：将某位成员踢出行会，只有管理可以用\n" +
                    "取消@xxx：取消被艾特人的所有排刀，只有管理可以用\n" +
                    "取消全部：取消所有排刀，只有管理可以用");
            return;
        }
        if (msg.matches("查询@.+")) {
            long atq = api.getAtQQ();
            File file = new File(ROOT_PATH + group + "/member/" + atq);
            if (!file.exists()) {
                send(qq, "该成员不在行会中！");
                return;
            }
            memberInfo(atq);
        } else if (msg.matches("[公工行]会")) {
            membersInfo();
        } else if (isAdmin) {
            if (msg.matches("踢 *(@.*|[0-9]+)")) {
                long atq;
                if (msg.contains("@")) {
                    atq = api.getAtQQ();
                } else {
                    atq = msg.contains(" ") ?
                            Long.parseLong(msg.substring(msg.lastIndexOf(' ') + 1)) :
                            Long.parseLong(msg.substring(2));
                }
                File file = new File(ROOT_PATH + group + "/member/" + atq);
                if (!file.exists()) {
                    send(qq, "该成员不在行会中！");
                    return;
                }
                Base b0 = getBase(atq);
                send(qq, "已从行会中踢出" + b0.getNick() + "(" + atq + ")！");
                deleteMember(atq);
            } else if (msg.matches("取消@.+")) {
                cancel(api.getAtQQ());
            } else if (msg.matches("取消全部")) {
                cancelAll();
            }
            return;
        }
        if (msg.matches("加入")) {
            createBase(qq);
            return;
        }
        boss = getBoss();
        if (msg.matches("退出")) {
            deleteMember(qq);
            send(qq, "你已退出该行会！");
            return;
        }
        base = getBase(qq);
        if (msg.matches("[Bb]oss")) {
            bossInfo();
        } else if (msg.matches("[修|更]改 [0-9]+ [1-5] [0-9]+")) {
            String m = msg.substring(3);
            int zhoumu = Integer.parseInt(m.substring(0, m.indexOf(' ')));
            if (zhoumu <= 0 || zhoumu >= 1000) {
                return;
            }
            int num = Integer.parseInt(m.substring(m.indexOf(' ') + 1, m.lastIndexOf(' ')));
            if (num < 1 || num > 5) {
                return;
            }
            int nowHp = Integer.parseInt(m.substring(m.lastIndexOf(' ') + 1));
            changeBoss(zhoumu, num, nowHp);
        } else if (msg.matches("[修|更]改 *[0-9]+")) {
            changeBoss(boss.getZhoumu(), boss.getNum(), msg.contains(" ") ?
                    Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1)) :
                    Integer.parseInt(msg.substring(2)));
        } else if (msg.matches("排刀")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            addToList();
        } else if (msg.matches("取消")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            cancel();
        } else if (msg.matches("[0-9]+")) {
            if (base == null) {
                return;
            }
            if (boss.getAtkList(0).getQq() != qq) {
                return;
            }
            finish(Integer.parseInt(msg));
        } else if (msg.matches("击杀")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            killed();
        } else if (msg.matches("上树")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            onTree();
        } else if (msg.matches("下树 *[0-9]+")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            leaveTree(msg.contains(" ") ?
                    Integer.parseInt(msg.substring(msg.lastIndexOf(' ') + 1)) :
                    Integer.parseInt(msg.substring(2)));
        } else if (msg.matches("查树")) {
            treeInfo();
        } else if (msg.matches("出刀")) {
            atkInfo();
        } else if (msg.matches("查询")) {
            if (base == null) {
                send(qq, "你还未加入该行会！\n指令提示：加入");
                return;
            }
            memberInfo(qq);
        }
        if (base != null) {
            serialize(base, ROOT_PATH + group + "/member/" + qq);
        }
        if (boss != null) {
            serialize(boss, ROOT_PATH + group + "/boss");
        }
    }

    private void bossInfo() {
        send("当前为" + boss.getZhoumu() + "周目，第" + boss.getNum() + "只\n"
                + "hp：" + boss.getNowHp() + " / " + boss.getMaxHp());
    }

    private void changeBoss(int zhoumu, int num, int nowHp) {
        boss.newBoss(zhoumu, num);
        boss.setNowHp(nowHp);
        send(qq, "修改完毕！");
    }

    private void addToList() {// 仅加入序列
        if (base.isEndAtk()) {
            base.setEndAtk(false);
            boss.add(qq, base.getAtkTimes(), true);
            if (boss.getMyIndex(qq, base.getAtkTimes()) == 0) {
                send(qq, "已将你产生的尾刀加入出刀队列，现在你可以出刀了！");
            } else {
                send(qq, "已将你产生的尾刀加入出刀队列，请耐心等候！");
            }
        } else {
            if (base.getTreeZhouMu() == boss.getZhoumu()
                    && base.getTreeNum() == boss.getNum()) {
                send(qq, "你正在树上，请等待大佬救你QAQ！");
            } else if (base.getApplyTimes() == 3) {
                send(qq, "你可出的刀均已在队列中！");
            } else if (base.getAtkTimes() == 3) {
                send(qq, "你已打满三刀，明天再打吧！");
            } else {
                base.setApplyTimes(base.getApplyTimes() + 1);
                boss.add(qq, base.getApplyTimes(), false);
                if (boss.getMyIndex(qq, base.getAtkTimes() + 1) == 0) {
                    send(qq, "已将你的第" + base.getApplyTimes() +
                            "刀加入出刀队列，现在你可以出刀了！");
                } else {
                    send(qq, "已将你的第" + base.getApplyTimes() +
                            "刀加入出刀队列，请耐心等候！");
                }
            }
        }
    }

    private void cancel() {
        int index = boss.getMyIndex(qq);
        if (index == -1) {
            send(qq, "当前排刀列表没有你的刀，无法取消！");
            return;
        }
        for (int i = boss.getSize() - 1; i >= 0; i--) {
            BaseAndTime bt = boss.getAtkList(i);
            if (bt.getQq() == qq) {
                if (bt.isEndAtk()) {
                    base.setEndAtk(true);
                } else {
                    base.setApplyTimes(base.getApplyTimes() - 1);
                }
                boss.remove(i);
            }
        }
        api.addAt();
        api.addText("\n已经取消你的所有排刀！\n\n");
        if (boss.getSize() == 0) {
            api.addText("现在无人出刀！");
        } else {
            long qq0 = boss.getAtkList(0).getQq();
            api.addAt(qq0, getBase(qq0).getNick());
            api.addText("\n现在轮到你出刀了！");
        }
        api.send();
    }

    private void finish(int dam) {
        if (base.getTreeZhouMu() == boss.getZhoumu() && base.getTreeNum() == boss.getNum()) {
            send(qq, "你正在树上，无法进行伤害结算！\n" +
                    "强制下树指令格式：【下树+空格+伤害】");
            return;
        }
        if (dam >= boss.getNowHp()) {
            killed();
            return;
        }
        base.setLastTime(msgTime);
        boss.setNowHp(boss.getNowHp() - dam);
        BaseAndTime bt = boss.getAtkList(0);
        if (!bt.isEndAtk()) {
            base.setAtkTimes(base.getAtkTimes() + 1);
        }
        boss.remove(0);
        if (boss.getSize() == 0) {
            send(qq, "你已经出刀完毕！\n现在无人出刀！");
        } else {
            api.addAt();
            api.addText("\n你已经出刀完毕！\n\n");
            long qq0 = boss.getAtkList(0).getQq();
            api.addAt(qq0, getBase(qq0).getNick());
            api.addText("\n现在轮到你出刀了！");
            api.send();
        }
    }

    private void killed() {
        base.setLastTime(msgTime);
        boss.newBoss();
        BaseAndTime bt = boss.getAtkList(0);
        boss.remove(0);
        if (bt.isEndAtk()) {
            api.addAt();
            api.addText("\n你是笨蛋吗？\n尾刀不能产生新的尾刀！\n\n");
            if (boss.getSize() == 0) {
                api.addText("现在无人出刀！");
                api.send();
            } else {
                long qq0 = boss.getAtkList(0).getQq();
                api.addAt(qq0, getBase(qq0).getNick());
                api.addText("\n现在轮到你出刀了！");
                api.send();
            }
        } else {
            base.setAtkTimes(base.getAtkTimes() + 1);
            base.setEndAtk(true);
            boolean b = false;
            for (int i = 0; i < boss.getSize(); i++) {
                bt = boss.getAtkList(i);
                if (bt.getQq() == qq) {
                    b = true;
                    break;
                }
            }
            api.addAt();
            api.addText("你已经出刀完毕！\n产生了一个尾刀！\n\n");
            if (b) {
                base.setApplyTimes(base.getApplyTimes() - 1);
                for (int i = 0; i < boss.getSize(); i++) {
                    bt = boss.getAtkList(i);
                    if (base.isEndAtk()) {
                        base.setEndAtk(false);
                        bt.setEndAtk(true);
                    }
                    bt.setTimes(bt.getTimes() - 1);
                    boss.set(i, bt);
                }
            }
            if (boss.getSize() == 0) {
                api.addText("现在无人出刀！");
            } else {
                long qq0 = boss.getAtkList(0).getQq();
                api.addAt(qq0, getBase(qq0).getNick());
                api.addText("\n现在轮到你出刀了！");
            }
            api.send();
        }
    }

    private void onTree() {
        int index = boss.getMyIndex(qq, base.getAtkTimes() + 1);
        if (index != 0) {
            send(qq, "现在不是你出刀，无法上树！");
            return;
        }
        BaseAndTime bt = boss.getAtkList(index);
        if (bt.isEndAtk()) {
            base.setEndAtk(true);
        } else {
            base.setApplyTimes(base.getAtkTimes());
        }
        base.setTreeZhouMu(boss.getZhoumu());
        base.setTreeNum(boss.getNum());
        boss.remove(qq, 1, 3);
        base.setApplyTimes(base.getAtkTimes());
        send(qq, "已经上树，请耐心等待大佬救场！");
    }

    private void leaveTree(int dam) {
        if (base.getTreeZhouMu() != boss.getZhoumu() || base.getTreeNum() != boss.getNum()) {
            send(qq, "你不在树上，无法强制下树！");
            return;
        }
        base.setTreeZhouMu(0);
        base.setTreeNum(0);
        base.setLastTime(msgTime);
        api.addAt();
        api.addText("\n你已下树，下次小心点哦！\n\n");
        if (base.isEndAtk()) {
            base.setEndAtk(false);
            if (dam >= boss.getNowHp()) {
                boss.newBoss();
                api.addText("你是笨蛋吗？\n尾刀不能产生新的尾刀！\n\n");
                if (boss.getSize() == 0) {
                    api.addText("现在无人出刀！");
                } else {
                    long qq0 = boss.getAtkList(0).getQq();
                    api.addAt(qq0, getBase(qq0).getNick());
                    api.addText("\n你出刀的boss变化了，请注意！！！");
                }
            } else {
                boss.setNowHp(boss.getNowHp() - dam);
                if (boss.getSize() == 0) {
                    api.addText("现在无人出刀！");
                }
            }
        } else {
            base.setAtkTimes(base.getAtkTimes() + 1);
            base.setApplyTimes(base.getApplyTimes() + 1);
            if (dam >= boss.getNowHp()) {
                boss.newBoss();
                api.addText("产生新的尾刀！\n\n");
                base.setEndAtk(true);
                if (boss.getSize() == 0) {
                    api.addText("现在无人出刀！");
                } else {
                    long qq0 = boss.getAtkList(0).getQq();
                    api.addAt(qq0, getBase(qq0).getNick());
                    api.addText("\n现在轮到你出刀了！");
                }
            } else {
                boss.setNowHp(boss.getNowHp() - dam);
                if (boss.getSize() == 0) {
                    api.addText("现在无人出刀！");
                }
            }
        }
        api.send();
    }

    private void treeInfo() {
        File file = new File(ROOT_PATH + group + "/member");
        if (file.listFiles() == null) {
            send("当前无人上树！");
            return;
        }
        StringBuilder sb = new StringBuilder("当前上树：\n");
        int i = 0;
        for (File f : Objects.requireNonNull(file.listFiles())) {
            Base b = getBase(Long.parseLong(f.getName()));
            if (b.getTreeZhouMu() == boss.getZhoumu() && b.getTreeNum() == boss.getNum()) {
                sb.append(i % 10 == 0 ? "" : "\n").append(i).append(".")
                        .append(b.getNick());
                if (i % 10 == 9) {
                    send(sb.toString());
                    Utils.sleep(300);
                    sb = new StringBuilder();
                }
                i++;
            }
        }
        if (sb.toString().equals("当前上树：\n")) {
            send("当前无人上树！");
        } else if (!sb.toString().equals("")) {
            send(sb.toString());
        }
    }

    private void atkInfo() {
        if (boss.getSize() == 0) {
            send("当前无人出刀！");
        }
        StringBuilder sb = new StringBuilder("出刀序列：\n");
        for (int i = 0; i < boss.getSize(); i++) {
            BaseAndTime bt = boss.getAtkList(i);
            Base b = getBase(bt.getQq());
            sb.append(i % 10 == 0 ? "" : "\n").append(i + 1).append(".")
                    .append(b.getNick()).append("\n")
                    .append("第").append(bt.getTimes()).append("刀");
            if (bt.isEndAtk()) {
                sb.append("尾刀");
            }
            if (i == boss.getSize() - 1) {
                send(sb.toString());
                return;
            }
            if (i % 10 == 9) {
                send(sb.toString());
                Utils.sleep(300);
                sb = new StringBuilder();
            }
        }
    }

    private void memberInfo(long qq) {
        File file = new File(ROOT_PATH + group + "/member/" + qq);
        if (!file.exists()) {
            send("该成员不在行会中！");
            return;
        }
        Base b = qq == this.qq ? base : getBase(qq);
        send("排刀、出刀情况如下：\n" + b.getNick() + "\n" +
                "已排刀" + b.getApplyTimes() + "次，已出刀" + b.getAtkTimes() + "次");
    }

    private void membersInfo() {
        File file = new File(ROOT_PATH + group + "/member");
        if (file.listFiles() == null) {
            send("本行会暂无人加入！");
            return;
        }
        StringBuilder sb = new StringBuilder("排刀、出刀情况如下：\n");
        int i = 0;
        for (File f : Objects.requireNonNull(file.listFiles())) {
            Base b = getBase(Long.parseLong(f.getName()));
            sb.append(i % 10 == 0 ? "" : "\n").append(i + 1).append(".")
                    .append(b.getNick()).append("\n")
                    .append("已排刀").append(b.getApplyTimes()).append("次，已出刀")
                    .append(b.getAtkTimes()).append("次");
            if (i % 10 == 9) {
                send(sb.toString());
                Utils.sleep(300);
                sb = new StringBuilder();
            }
            i++;
        }
        if (!sb.toString().equals("")) {
            send(sb.toString());
        }
    }


    private void deleteMember(long qq) {
        delete(ROOT_PATH + group + "/member/" + qq);
        boss.remove(qq, 1, 3);
    }

    private void cancel(long atq) {
        int index = boss.getMyIndex(atq);
        Base b = getBase(atq);
        if (index == -1) {
            send(qq, "当前排刀列表没有" + b.getNick() + "的刀，无法取消！");
            return;
        }
        for (int i = boss.getSize() - 1; i >= 0; i--) {
            BaseAndTime bt = boss.getAtkList(i);
            if (bt.getQq() == atq) {
                if (bt.isEndAtk()) {
                    b.setEndAtk(true);
                } else {
                    b.setApplyTimes(b.getApplyTimes() - 1);
                }
                boss.remove(i);
            }
        }
        serialize(base, ROOT_PATH + group + "/member/" + atq);
        api.addAt(atq, b.getNick());
        api.addText("\n你的所有排刀已被管理员取消！\n\n");
        if (boss.getSize() == 0) {
            api.addText("现在无人出刀！");
        } else {
            long qq0 = boss.getAtkList(0).getQq();
            api.addAt(qq0, getBase(qq0).getNick());
            api.addText("\n现在轮到你出刀了！");
        }
        api.send();
    }

    private void cancelAll() {
        File file = new File(ROOT_PATH + group + "/member");
        if (file.listFiles() == null) {
            send("本行会暂无人加入！");
            return;
        }
        if (boss.getSize() == 0) {
            send("当前无人出刀！");
            return;
        }
        for (int i = boss.getSize() - 1; i >= 0; i--) {
            BaseAndTime bt = boss.getAtkList(i);
            long qq0 = bt.getQq();
            Base b = getBase(qq0);
            if (bt.isEndAtk()) {
                b.setEndAtk(true);
            } else {
                b.setApplyTimes(b.getApplyTimes() - 1);
            }
            serialize(base, ROOT_PATH + group + "/member/" + qq0);
            boss.remove(i);
        }
        send(qq, "已取消本群所有人排刀！");
    }

}
