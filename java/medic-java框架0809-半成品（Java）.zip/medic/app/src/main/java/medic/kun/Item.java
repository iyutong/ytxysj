package medic.kun;

import java.io.*;

public class Item implements Serializable {

    private final String filePath;

    private int money = 0;
    private int gmk = 0;
    private int xlk = 0;
    private int ckk = 0;
    private int tzq = 0;

    Item(long qq) {
        this.filePath = Process.ITEM_PATH + qq;
    }

    private static final long serialVersionUID = 1L;

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public void addMoney(int add) {
        this.money += add;
    }

    public void subMoney(int sub) {
        this.money -= sub;
    }

    public int getGmk() {
        return gmk;
    }

    public void setGmk(int gmk) {
        this.gmk = gmk;
    }

    public int getXlk() {
        return xlk;
    }

    public void setXlk(int xlk) {
        this.xlk = xlk;
    }

    public int getCkk() {
        return ckk;
    }

    public void setCkk(int ckk) {
        this.ckk = ckk;
    }

    public int getTzq() {
        return tzq;
    }

    public void setTzq(int tzq) {
        this.tzq = tzq;
    }
}
