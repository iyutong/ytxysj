package medic.main;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;

public class DBTest extends AppCompatActivity {

    public void test() {
        createDatabase("test_db",1);
    }

    DatabaseHelper dbh;
    SQLiteDatabase db;

    public void createDatabase(String name,int version) {
        dbh = new DatabaseHelper(this, name, version);
        db = dbh.getWritableDatabase();
    }

    public void updateDatabase(String name) {
        dbh = new DatabaseHelper(this, name, 2);
        db = dbh.getWritableDatabase();
    }

    public void insert() {
        ContentValues values = new ContentValues();
        values.put("id", 1);
        values.put("name", "张三");
        db.insert("user", null, values);
    }

    public void delete() {
        db.delete("user", "id=?", new String[]{"1"});
    }

    public void update() {
        ContentValues values = new ContentValues();
        values.put("name", "李四");
        db.update("user", values, "id=?", new String[]{"1"});
    }

    public void query() {
        Cursor cursor = db.query("user", new String[]{"id", "name"},
                "id=?", new String[]{"1"},
                null, null, null, null);
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex("name"));
        }
        cursor.close();
    }

}
