package medic.request;

import org.json.JSONArray;
import org.json.JSONException;

import static medic.main.Main.*;
import static medic.main.Main.send;
import static medic.main.Utils.*;

public class Process {

    private final long group;
    private final long qq;
    private final String nick;
    private final String requestId;
    private final long inviteQQ;
    private final String inviteNick;
    private String title;// 标题
    private String info;// 内容
    private String result;// 处理结果

    public Process(String... param) {
        this.group = api.getGroup();
        this.qq = api.getQQ();
        this.nick = api.getGroupNick();
        this.requestId = param[1];
        this.inviteQQ = Long.parseLong(param[2]);
        this.inviteNick = param[3];

        try {
            JSONArray jsonArray = new JSONArray(param[4]);
            this.title = jsonArray.getString(0);
            this.info = jsonArray.getString(1);
            this.result = jsonArray.getString(2);
        } catch (JSONException e) {
            logError("System消息处理错误", e);
            this.title = "";
            this.info = "";
            this.result = "";
        }
    }

    public void process() {
        switch (title) {
            case "加群申请":
                joinGroup();
                break;
            case "退群消息":
                quitGroup();
                break;
            case "管理员变动":
                changeAdmin();
                break;
            default:
        }
    }

    void joinGroup() {
        switch (result) {
            case "":// 说明入群申请还未处理
                if (isOpen(group, APPLY_ADD_GROUP)) {
                    return;
                }
                boolean agree;
                if (info.matches("问题：.*\\\\n答案：.*")) {// 需要回答问题并由管理员审核
                    String question = info.substring(3, info.indexOf("\\n"));
                    String answer = info.substring(info.indexOf("\\n") + 5);
                    // 这里写判断条件
                    if (answer.contains("1745")) {
                        agree = true;
                        send(nick + "（" + qq + "）想加群哎！\n问题：" + question
                                + "\n回答：" + answer + "\n嗯，回答正确，那就让你进群吧！");
                    } else {
                        agree = false;
                        send(nick + "（" + qq + "）想加群哎！" + "\n问题：" + question
                                + "\n答案：" + answer + "\n哼，回答错误，才不让你进群呢！");
                    }
                } else {// 需要验证消息
                    agree = true;
                    send(nick + "（" + qq + "）想加群哎！" + "\n验证消息："
                            + (info.equals("") ? "无" : info) + "\n既然你想来，那就让你进来咯！");
                }
                api.joinRequest(group, qq, requestId, agree);
                break;
            case "已同意":// 说明入群申请已同意
                if (isOpen(group, ADD_GROUP_INFO)) {
                    return;
                }
                switch (group + "") {
                    case "319567534":
                        send(qq, "欢迎新人！\n养鲲请私聊！");
                        break;
                    case "1121508667":
                        send(qq, "欢迎来到萌泪的Arcaea爬梯群！\n" +
                                "请先仔细阅读公告哦~\n看不懂在群里问就好啦QwQ");
                        break;
                    case "516286670":
                        send(qq, "欢迎来到萌泪的测试群！\n" +
                                "此群为萌泪开发机器人的新功能测试群~\n希望各位能积极参与测试哦QwQ");
                        break;
                    default:
                        send(qq, "欢迎大佬！\ngroupPosition--;");
                }
                break;
            case "已拒绝":// 说明入群申请已拒绝
                // 对拒绝入群消息做处理
                break;
            default:
        }
    }

    void quitGroup() {
        if (isOpen(group, LEAVE_GROUP_INFO)) {
            return;
        }
        send(nick + "（" + qq + "）" + "离开了本群QAQ"
                + "\n请珍惜在本群的每一刻！");
    }

    void changeAdmin() {
        if (isOpen(group, ADMIN_CHANGE_INFO)) {
            return;
        }
        logInfo("info:\n" + info + "\nresult:\n" + result);
        // api.sendMsg("有一位小可爱离开了本群QAQ\nQQ：" + qq + "\n昵称：" + nick
        //         + "\n请珍惜在本群的每一刻！");
    }

}
