/** Automatically generated file. DO NOT MODIFY */
package com.xl.codeedit;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}