/** Automatically generated file. DO NOT MODIFY */
package com.test.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}