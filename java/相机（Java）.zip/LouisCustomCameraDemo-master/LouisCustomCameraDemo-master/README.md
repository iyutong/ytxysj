# LouisCustomCameraDemo
Android 自定义相机 切换相机 参考线(辅助线) 闪光灯 缩放 自动聚焦

![image](https://raw.githubusercontent.com/louisgeek/LouisCustomCameraDemo/master/screenshots/pic.jpg)
![image](https://raw.githubusercontent.com/louisgeek/LouisCustomCameraDemo/master/screenshots/picA.jpg)
