import java.util.*;
import java.lang.reflect.*;

public class Main
{
	public static void main(String[] args)
	{
		try {
			Class<?>cls=Class.forName("android.widget.Toast");
			Method method=cls.getMethod("makeText",Context.class);
			System.out.println(method);
			
		} catch (Exception e) {}
	}
}
