package com.my;

import android.annotation.*;
import android.content.*;
import android.os.*;
import android.service.notification.*;
import android.util.*;
import android.widget.ListView;
import java.io.*;
import java.text.*;
import java.util.*;
import android.app.*;
import android.content.pm.*;
import java.lang.reflect.*;
import android.net.*;
import android.provider.*;
//Chinese
/*
 *by MUS
 *转载请注明版权
 *QQ168028056
 *我们的编程交流群676343719
 */

//English
/*
 *powered by Mus
 *Reprint please indicate copyright
 *My QQ number is 168028056
 *Our programming QQ group number is 676343719
 */

@SuppressLint("OverrideAbstract")
public class MyNotifiService extends NotificationListenerService
{
	
    private BufferedWriter bw;
    private SimpleDateFormat sdf;
    private MyHandler handler = new MyHandler();
    private String nMessage;
    private String data;
    List<String[]> mli;
    Handler mHandler = new Handler(Looper.getMainLooper())
	{
        @Override
        public void handleMessage(Message msg)
		{
            mli=new ArrayList<String[]>();
            String[] msgString = ((String) msg.obj).split(";;;");
            MainActivity.li.add(msgString);
            for(int i=MainActivity.li.size()-1;i>0;i--)
            {
                mli.add(MainActivity.li.get(i));
            }
            MainActivity.adp.setFilter(mli);
            
	    }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
	{
        data = intent.getStringExtra("data");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn)
	{
        try
		{
            //有些通知不能解析出TEXT内容，这里做个信息能判断
            if (sbn.getNotification().tickerText != null)
			{
                SharedPreferences sp = getSharedPreferences("msg", MODE_PRIVATE);
				
                nMessage = sbn.getPackageName()+";;;"+sbn.getNotification().tickerText.toString()+";;;"+sbn.getGroupKey();
                sp.edit().putString("getMsg", nMessage).apply();
                Message obtain = Message.obtain();
                obtain.obj = nMessage;
                mHandler.sendMessage(obtain);
                init();
                if (nMessage.contains(data))
				{
                    Message message = handler.obtainMessage();
                    message.what = 1;
                    handler.sendMessage(message);
                    writeData(sdf.format(new Date(System.currentTimeMillis())) + ":" + nMessage);
                }
            }
        }
		catch (Exception e)
		{
		}
		

    }
   
	
   
   private void writeData(String str)
	{
        try
		{
//            bw.newLine();
//            bw.write("NOTE");
            bw.newLine();
            bw.write(str);
            bw.newLine();
//            bw.newLine();
            bw.close();
        }
		catch (IOException e)
		{
            e.printStackTrace();
        }
    }

    private void init()
	{
        sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try
		{
            FileOutputStream fos = new FileOutputStream(newFile(), true);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            bw = new BufferedWriter(osw);
        }
		catch (IOException e)
		{
            Log.d("KEVIN", "BufferedWriter Initialization error");
        }
        Log.d("KEVIN", "Initialization Successful");
    }

    private File newFile()
	{
        File fileDir = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + "ANotification");
        fileDir.mkdir();
        String basePath = Environment.getExternalStorageDirectory() + File.separator + "ANotification" + File.separator + "record.txt";
        return new File(basePath);

    }


    class MyHandler extends Handler
	{
        @Override
        public void handleMessage(Message msg)
		{
            switch (msg.what)
			{
                case 1:
//                    Toast.makeText(MyService.this,"Bingo",Toast.LENGTH_SHORT).show();
            }
        }

    }
	public static void write(String content)
	{
		try
		{
			BufferedOutputStream w=new BufferedOutputStream(new FileOutputStream(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/mus.txt")));
			try
			{
				w.write(content.getBytes());

				w.close();
			}
			catch (IOException e)
			{}
		}
		catch (FileNotFoundException e)
		{}

	}

}

