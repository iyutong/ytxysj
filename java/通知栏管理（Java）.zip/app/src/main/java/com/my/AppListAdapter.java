package com.my;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class AppListAdapter extends BaseAdapter
{
    List<String[]> xx;
    public void setFilter(List<String[]>filterWords)
    {
        this.xx = filterWords;
        this.notifyDataSetChanged();
    }
    public AppListAdapter(List<String[]> xx)
    {
        this.xx = xx;
    }
    @Override
    public int getCount()
    {
        //返回数据总数
        return xx.size();
    }
    @Override
    public Object getItem(int position)
    {
        //返回当前position位置的item
        return xx.get(position);
    }
    @Override
    public long getItemId(int position)
    {
        //返回当前position位置的item的id
        return position;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        //处理view与data，进行数据填充
        MainActivity.text.setVisibility(8);
        convertView = LayoutInflater.from(MainActivity.context).inflate(R.layout.item, parent, false);
        TextView a = convertView.findViewById(R.id.a);
        TextView b = convertView.findViewById(R.id.b);
        a.setText(xx.get(position)[0]);
        b.setText(xx.get(position)[1]);
        LinearLayout la=convertView.findViewById(R.id.click);
        la.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                copy(MainActivity.context,"包名："+xx.get(position)[0]+"\n"+"消息："+xx.get(position)[1]);
                Toast.makeText(MainActivity.context,"已复制到剪切板",0).show();
            } 
        });
        return convertView;
    }
    public static void copy(Context context,String str)
    {
        ClipboardManager clipboardManager = (ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clipData = ClipData.newPlainText("label",str);  
        clipboardManager.setPrimaryClip(clipData); 
	}
}
