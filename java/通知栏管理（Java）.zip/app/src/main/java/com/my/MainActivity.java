package com.my;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;


//Chinese
/*
 *by MUS
 *转载请注明版权
 *QQ168028056
 *我们的编程交流群676343719
 */

//English
/*
 *powered by Mus
 *Reprint please indicate copyright
 *My QQ number is 168028056
 *Our programming QQ group number is 676343719
*/


public class MainActivity extends Activity 
{
    static List<String[]> li;
    static ListView ls;
    static AppListAdapter adp;
    static Context context;
    static TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        getActionBar().setTitle("通知栏管理 by Mus");
        text=findViewById(R.id.text);
        context = this;
        li = new ArrayList<String[]>();
        ls = findViewById(R.id.listview);
        adp = new AppListAdapter(li);
        ls.setAdapter(adp);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) 
    {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
    {
        int id = item.getItemId();
        switch (id)
        {
            case R.id.one:
               adp.setFilter(new ArrayList<String[]>());
               text.setVisibility(0);
            break;
        }
        return super.onOptionsItemSelected(item);
    }

	public void start()
	{
		if (!notificationListenerEnable())
		{
			gotoNotificationAccessSetting();
		}
		Intent o=new Intent(this, MyNotifiService.class);
		startService(o);
	}
    private boolean gotoNotificationAccessSetting()
    {
		try
        {
			Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);
			return true;
		}
        catch (ActivityNotFoundException e)
        {
			try
            {
				Intent intent = new Intent();
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				ComponentName cn = new ComponentName("com.android.settings", "com.android.settings.Settings$NotificationAccessSettingsActivity");
				intent.setComponent(cn);
				intent.putExtra(":settings:show_fragment", "NotificationAccessSettings");
				startActivity(intent);
				return true;
			}
            catch (Exception ex)
            {
				ex.printStackTrace();
			}
			return false;
		}
	}
	private boolean notificationListenerEnable()
    {
		boolean enable = false;
		String packageName = getPackageName();
		String flat= Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
		if (flat != null)
        {
			enable = flat.contains(packageName);
		}
		return enable;
	}

}
