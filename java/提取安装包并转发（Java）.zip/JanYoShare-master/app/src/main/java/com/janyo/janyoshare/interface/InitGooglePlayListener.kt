package com.janyo.janyoshare.`interface`

interface InitGooglePlayListener
{
	fun onSuccess()
	fun onFailed()
}