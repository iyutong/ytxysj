package com.janyo.janyoshare.classes

data class Response(val code: Int, val message: String)