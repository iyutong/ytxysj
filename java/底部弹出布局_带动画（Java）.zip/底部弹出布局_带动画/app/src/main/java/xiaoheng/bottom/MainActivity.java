package xiaoheng.bottom;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private Button btn1;
	private LinearLayout ll;
	private TranslateAnimation animation1,animation2;
	private ViewTreeObserver vto1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		btn1 = (Button)findViewById(R.id.mainButton1);

		ll = (LinearLayout)findViewById(R.id.mainLinearLayout1);


		vto1 = ll.getViewTreeObserver();
		vto1.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener()
			{
				public boolean onPreDraw()
				{
					animation1 = new TranslateAnimation(0, 0, 0, ll.getMeasuredHeight());
					animation1.setDuration(800);
					animation1.setFillAfter(true);

					animation2 = new TranslateAnimation(0, 0, ll.getMeasuredHeight(), 0);
					animation2.setDuration(500);
					animation2.setFillAfter(true);

					return true;
				}
			});

		btn1.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					//如果获取到的控件状态为显示则设置它为隐藏状态，反之亦然
					if (ll.getVisibility() == 0)
					{
						//设置为隐藏
						//ll.setVisibility(8);
						//落
						ll.startAnimation(animation1);
						ll.setVisibility(8);

					}
					else if (ll.getVisibility() == 8)
					{
						//设置为显示
						//ll.setVisibility(0);
						//起
						ll.startAnimation(animation2);
						ll.setVisibility(0);


					}
				}
			});



    }
}
