package xiaoheng.daxiaoxiezuanhuan;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
	private EditText ext;
	private Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		/*
		作者：小亨
		写于2018年6月15日
		*/
		
		
		ext=(EditText)findViewById(R.id.mainEditText1);
		
		//换成大写
		btn1=(Button)findViewById(R.id.mainButton1);
		btn1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Toast.makeText(MainActivity.this, ext.getText().toString().toUpperCase() ,Toast.LENGTH_SHORT).show();
				}
			});
			
			
		//换成小写
		btn2=(Button)findViewById(R.id.mainButton2);
		btn2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Toast.makeText(MainActivity.this, ext.getText().toString().toLowerCase() ,Toast.LENGTH_SHORT).show();
				}
			});
			
		
    }
}
