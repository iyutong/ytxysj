package com.example.testproject;

public class bean {

    private String name;
    private String content;
    private int imageId;

    public bean(String name,String content,int imageId){
        this.name=name;
        this.content=content;
        this.imageId=imageId;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }

    public int getImageId() {
        return imageId;
    }
}
