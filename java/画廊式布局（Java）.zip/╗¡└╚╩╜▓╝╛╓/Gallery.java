package com.example.testproject;

import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;

public class Gallery extends AppCompatActivity {
    RecyclerView recyclerview;
    private ColorAdapter colorAdpter;
    List<bean> color2s=new ArrayList<>();
    private Toolbar toolbar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gallery);

        recyclerview=findViewById(R.id.gallery_list);
        toolbar=findViewById(R.id.gallery_toolbar);
        setSupportActionBar(toolbar);

        init();
        setadapter();



        //recyclerview滑动监听
       recyclerview.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int childCount = recyclerView.getChildCount();//总item的数量
                int width = recyclerView.getChildAt(0).getWidth();//第一个item的宽度
                int padding = (recyclerView.getWidth() - width) / 2;//这个padding是 recycler的宽度减去第一个item的宽度然后除以2，作为padding
                for (int j = 0; j < childCount; j++) {
                    View v = recyclerView.getChildAt(j);//获取每一个child
                    float rate = 0;//是一个缩放比例
                    if (v.getLeft() <= padding) {//如果view距离左边的宽度 小于等于 左侧剩余空间(padding) （意味着这个view开始往左边滑动了，并且有遮挡）
                        if (v.getLeft() >= padding - v.getWidth()) {//如果view距离左边的距离 小于等于滑进去的距离 （其实就是说滑动到一半的时候）
                            rate = (padding - v.getLeft()) * 1f / v.getWidth();//（这个比例的计算结果一般都会大于1，这样一来，根据下面的 1- rate * 0.1 得出，这个比例最多不会到达1，也就是 1- 0.1， 也就是 0.9， 所以这个view的宽度最大不会小于他本身的90%）
                        } else {
                            rate = 1;
                        }
                        v.setScaleY(1 - rate * 0.2f);
                    } else {
                        if (v.getLeft() <= recyclerView.getWidth() - padding) {//这个过程大概是指这个view 从最后侧刚刚出现的时候开始滑动过padding的距离
                            rate = (recyclerView.getWidth() - padding - v.getLeft()) * 1f / v.getWidth();
                        }
                        v.setScaleY(0.9f + rate * 0.1f);
                    }
                }

            }
        });


//加载完成后的监听
        recyclerview.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                if (recyclerview.getChildCount() < 3) {
                    if (recyclerview.getChildAt(1) != null) {
                        View v1 = recyclerview.getChildAt(1);
                        v1.setScaleY(0.9f);
                    }
                } else {
                    if (recyclerview.getChildAt(0) != null) {
                        View v0 =recyclerview.getChildAt(0);
                        v0.setScaleY(0.9f);
                    }
                    if (recyclerview.getChildAt(2) != null) {
                        View v2 = recyclerview.getChildAt(2);
                        v2.setScaleY(0.9f);
                    }
                }
            }
        });
    }

    public void setadapter(){
        LinearLayoutManager layoutManager = new LinearLayoutManager(Gallery.this);
        layoutManager.setOrientation(recyclerview.HORIZONTAL);
        //GridLayoutManager layoutManager = new GridLayoutManager(ColorActivity.this, 3);
        recyclerview.setLayoutManager(layoutManager);
        colorAdpter = new ColorAdapter(color2s);
        recyclerview.setAdapter(colorAdpter);
    }

    public void init(){
        bean bean1=new bean("http://m.qpic.cn/psc?/V10mmRGi4FpJwu/45NBuzDIW489QBoVep5mcUXC4iNZ*9*P4lxzDonq4KLVK6T5MjUs.SLFCO6UgzW6WCgkWsCf9gZtWNZaSF6iJ4QjcpBB6LdSm9G50lbwIzA!/b&bo=OAToCDgE6AgBFzA!&rf=viewer_4","",R.mipmap.d2);
        color2s.add(bean1);
        bean bean2=new bean("http://img.yoolin.cc/appImg/ccefc19e-e34f-4947-84d9-fa3b9a5f89cf.PNG","",R.mipmap.d2);
        color2s.add(bean1);
        bean bean3=new bean("http://img.yoolin.cc/appImg/ccefc19e-e34f-4947-84d9-fa3b9a5f89cf.PNG","",R.mipmap.d2);
        color2s.add(bean1);
        bean bean4=new bean("http://m.qpic.cn/psc?/V10mmRGi4FpJwu/45NBuzDIW489QBoVep5mcUXC4iNZ*9*P4lxzDonq4KLVK6T5MjUs.SLFCO6UgzW6WCgkWsCf9gZtWNZaSF6iJ4QjcpBB6LdSm9G50lbwIzA!/b&bo=OAToCDgE6AgBFzA!&rf=viewer_4","",R.mipmap.d2);
        color2s.add(bean1);

    }

    class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.ViewHolder> {

        private List<bean> color2s;
        public ColorAdapter(List<bean> color2s){
            this.color2s =color2s;
        }
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.test_item, viewGroup, false);
            ViewHolder holder = new ViewHolder(view);
            //获取屏幕宽度


            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            bean bean=color2s.get(position);


            Glide.with(Gallery.this).load(color2s.get(position).getName())
                    //.override(layoutParams.width,layoutParams.height)
                    .placeholder(R.mipmap.c3).error(R.mipmap.c3)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .into(holder.imageView);
        }

        @Override
        public int getItemCount() {
            return color2s.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            private ImageView imageView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.testimg);


            }
        }

    }}
