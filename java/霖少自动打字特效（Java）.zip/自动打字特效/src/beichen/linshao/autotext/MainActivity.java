package beichen.linshao.autotext;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.*;


/*
*    @create:2018-1-21
*    by:linshao
*/
public class MainActivity extends Activity 
{
	int i=0;
	private static String s="//风轻轻吹起,云渐渐堆积,/笼罩了山峰，/旁边的斜日;/笼罩了我,心中的你"
	+"//洁白的天空，衔接着，/梦幻般的蓝色，/将鸟儿托起;/划过了天际，却落进，/某人的眼底"
	+"//我收回目光，任凭那，/水晶般的泪滴，/把空气润湿:/浸入了土里，散发出，/久违的香气"
	+"//有人在想象，是不是，/只要把头抬起，/就能找回彩虹;/在当初的位置，然而却，/只剩下，朦胧的影子"
	+"//风轻轻停止，云渐渐散去，/现出了山峰，/旁边的斜日，/却不再现，/当时的你，在哪里？"
	+ "//   --------by:linshao-------";
	private EditText ed;
	private Timer timer;
	private TimerTask task;
	private Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		//requestWindowFeature(4);
        setContentView(R.layout.main);

		//找到控件
		ed=(EditText)findViewById(R.id.ed);
		bt=(Button)findViewById(R.id.bt);
		//设置ed编辑框不接受输入
		ed.setEnabled(false);
		//设置ed编辑框字符为'_'
		ed.setText("_");
		//设置按钮点击事件
		bt.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(i<s.length()){}else{
					i=0;
					}
					//拿到timer，timerTask容器
					timer=new Timer();
					task=new TimerTask(){

						@Override
						public void run()
						{
							//构造一个message用于通信
							Message message=new Message();
							//额，这个就是放置一个int类型的值，用来区别是哪一个massage
							message.what=1;
							h.sendMessage(message);

						}
					};
					//定时器开始启动，100毫秒后启动，循环周期100毫秒
					timer.schedule(task,100,100);
				}
			});
		
		
    }
	//handler 译:-执行者
	Handler h=new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			switch(msg.what){

				case 1:
					//如果长度小于文本长度，说明未显示完，继续
					if(i<s.length()){
						//把文本转为char[]数组
						char c[]=s.toCharArray();
						//取下标为i的字符
						String str=String.valueOf(c[i]);					
						if(str.equals("/")){
							//如果读到'/'换行
							ed.getText().delete(ed.getText().length()-1,ed.getText().length());
							ed.append("\n"+" ");
							i++;
						}else{
							//不是“/“则添加到ed显示
							ed.getText().delete(ed.getText().length()-1,ed.getText().length());
							ed.append(str+"_");
							i++;
						}
					}else{
						try{
						//把文本末尾的“_”删除
						ed.getText().delete(ed.getText().length()-1,ed.getText().length());
						}catch(Exception e){}//取消定时器
						timer.cancel();
						ed.setText(" ");

					}
					break;
			}

		}

	};
	public void linshao(View v){
		//跳转QQ
		startActivity(new Intent().setData(Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=1640095730"))
		.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
		Toast.makeText(getApplication(),"正在连接霖少...",0).show();
		Toast.makeText(getApplication(),"♚已连接到霖少！",0).show();
		}
	public void jiaru(View v){
		startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=476373887&card_type=group&source=qrcode")));
		Toast.makeText(getApplication(), "正在跳转QQ群...", 0).show();
		Toast.makeText(getApplication(), "●欢迎加入，java之路期待与你同行！", 0).show();
		
	}
}
