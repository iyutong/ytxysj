/** Automatically generated file. DO NOT MODIFY */
package beichen.linshao.autotext;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}