package com.example.seuxiaosi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {
	
	
	
	
	//���ٶȼơ������ǡ���̬�ǵ�����
	public static int VAL_ACC_X = 0;
	public static int VAL_ACC_Y = 0;
	public static int VAL_ACC_Z = 0;
	public static int VAL_GYR_X = 0;
	public static int VAL_GYR_Y = 0;
	public static int VAL_GYR_Z = 0;
	public static float VAL_ANG_X = 0;
	public static float VAL_ANG_Y = 0;
	public static float VAL_ANG_Z = 0;
	

	
	//���ص���Ϣ
	public static final int MESSAGE_STATIC_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME =4;
	public static final int MESSAGE_TOAST = 5;
	
	//��ȡ�豸����
	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";
	
	//����ʹ�������豸
	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;
	
	//��������صı���
	private String mConnectedDeviceName = null;
	private BluetoothAdapter mBluetoothAdapter = null;
	private static BluetoothRfcommClient  mRfcommClient = null;
	
	private TextView mStatus;//��ʾ��������״̬
	
	
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        //��ʾ����״̬
        mStatus = (TextView) findViewById(R.id.message);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        
        if(mBluetoothAdapter == null){
        	Toast.makeText(this, "����������", Toast.LENGTH_LONG).show();
        	finish();
        	return;
        }
        
        
        //���������
        if(!mBluetoothAdapter.isEnabled()){
        	Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        	startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
        
        mRfcommClient = new BluetoothRfcommClient(this,mHandler);
        
        ImageButton mImageButton = (ImageButton) findViewById(R.id.bluetooth);
        mImageButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, MyBluetooth.class);
				
				//��������ƥ����Ϣ			
				startActivityForResult(intent, REQUEST_CONNECT_DEVICE);
			
			}
		});
        
        
        
        mImageButton = (ImageButton) findViewById(R.id.control);
        mImageButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//����ʽIntent�򿪷��п��ƽ���
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, MyControl.class);
				startActivity(intent);
			
			}
		});     
        
     
    }
    

    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

	
    @Override
    public synchronized void onResume(){
    	
    	super.onResume();
    	if(mRfcommClient != null){
    		if(mRfcommClient.getState()==BluetoothRfcommClient.STATE_NONE ){
    			//��������
    			mRfcommClient.start();
    		}
    	}
    }
    
    @Override
    public void onDestroy() {
        if (mRfcommClient != null) mRfcommClient.stop();
        super.onDestroy();
        //�رտͻ���
    }

    
    //�˳�����
    @Override
    public void onBackPressed(){
    	Builder mBuilder = new AlertDialog.Builder(this);
        mBuilder.setTitle("С��")
    	.setMessage("�뿪����");
        
        mBuilder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				finish();
			}
		});
        
        mBuilder.setNegativeButton("ȡ��", null).show();
    }
    

    public void onActivityResult(int requestCode, int resultCode, Intent data){
    	switch(requestCode){
    	case REQUEST_CONNECT_DEVICE:
    	//���մ��������ӽ��淵�ص���Ϣ
    		if(resultCode == Activity.RESULT_OK){
    			String address = data.getExtras().getString(MyBluetooth.EXTRA_DEVICE_ADDRESS);
    			BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
    			mRfcommClient.connect(device);
    		
    			}
    		break;
  	
    	case REQUEST_ENABLE_BT:
    		if(resultCode != Activity.RESULT_OK){
    			Toast.makeText(this, "����ʧ�ܡ�", Toast.LENGTH_SHORT).show();
    			finish();
    		}
    		break;
    	}
    }
    
    @SuppressLint("HandlerLeak")
    private final Handler mHandler = new Handler(){
    
    @Override
    public void handleMessage(Message mMessage){
    	
    	switch(mMessage.what){
    	
    	case MESSAGE_STATIC_CHANGE:
    		
    		switch(mMessage.arg1){//��arg1��arg2��������Ա����������Ϣ
    		case BluetoothRfcommClient.STATE_CONNECTED:
    			mStatus.setText("���ӵ�");
    			mStatus.append("" + mConnectedDeviceName);
    			break;
    		
    		case BluetoothRfcommClient.STATE_CONNECTING:
    			mStatus.setText("�������ӡ�");
    			break;
    			
    		case BluetoothRfcommClient.STATE_NONE:
    			mStatus.setText("����ʧ�ܡ�");
    			break;
    			
    		}
    	break;
    	
    	case MESSAGE_READ:
    		byte[] mRead = (byte[]) mMessage.obj;
    		DataAnl(mRead , mMessage.arg1);
    		break;
    		
    	case MESSAGE_DEVICE_NAME:
    		//�������ӵ��豸����
    		mConnectedDeviceName = mMessage.getData().getString(DEVICE_NAME);
    		Toast.makeText(getApplicationContext(), "���ӵ�"+mConnectedDeviceName, Toast.LENGTH_SHORT).show();
    		break;
    		
    	case MESSAGE_TOAST:
    		Toast.makeText(getApplicationContext(), mMessage.getData().getString(TOAST), Toast.LENGTH_SHORT).show();
    		break;
    	}
    }
   };
    
    
    //�ַ������ݷ��ͺ���
   static void SendData(String message){
    	//ȷ�������豸�Ƿ�������
    	if(mRfcommClient.getState()!= BluetoothRfcommClient.STATE_CONNECTED){
    		//Toast.makeText(this,"δ���ӵ������豸", Toast.LENGTH_SHORT).show();
    		return;
    	}
    	
    	if(message.length() >0 ){
    		byte[] send = message.getBytes();
    		mRfcommClient.write(send);
    	}
    }
    
    
   //�ַ����ݷ��ͺ���
   static void SendData_Byte(byte[] data){
    	if(mRfcommClient.getState() != BluetoothRfcommClient.STATE_CONNECTED)
    		return;
    	
    	mRfcommClient.write(data);
    }
  
    
    //��������ͺ���
    static void Send_Command(byte data){
    	byte[] bytes = new byte[6];
    	byte sum = 0;
    	
    	if(mRfcommClient.getState() != BluetoothRfcommClient.STATE_CONNECTED)
    		return;
    	
    	bytes[0] = (byte)0xaa;
    	bytes[1] = (byte)0xaf;
    	bytes[2] = (byte)0x01;
    	bytes[3] = (byte)0x01;
    	bytes[4] = (byte)data;
    	
    	for(int i=0; i<5; i++)
    		sum += bytes[i];
    	
    	bytes[5] = sum;	
    	SendData_Byte(bytes);
    	
    }
    

    
    

    static int Buffer_Length = 1000;
    static byte[] Read = new byte[Buffer_Length];
    static int ReadLength = 0;//��ȡ�����ݳ���
    static int ReadState = 0;//��ȡ���ݵ�״̬
    static int ReadCount = 0;//����
    
    
    //���ݽ��մ�������
    static void DataAnl(byte[] data, int length){
    	for(int i=0; i<length; i++){
    		
    		
    		//����һ��AA
    		if(ReadState == 0){
    			if(data[i] == (byte)0xaa){
    				ReadState = 1;
    				Read[0] = (byte)0xaa;
    			}  
    		}
    		
    		//���ڶ���AA
    		else if(ReadState == 1){
    			if(data[i] == (byte)0xaa){
    				ReadState = 2;
    				Read[1] = (byte)0xaa;
    			}
    			else
    				ReadState = 0;
    		}

    		
    		else if(ReadState == 2){
    			ReadState = 3;
    			Read[2] = data[i];
    		}
    		
    		else if(ReadState == 3){
    			if(data[i] > 45)
    				ReadState = 0;  			
    			else{
    			ReadState = 4;
    			Read[3] = data[i];
    			ReadLength = data[i];
    			if(ReadLength < 0)
    				ReadLength = -ReadLength;
    			ReadCount = 4;
    			}
    		}
    		
    		else if(ReadState == 4){
    			ReadLength--;
    			Read[ReadCount] = data[i];
    			ReadCount++;
    			if(ReadLength <= 0)
    				ReadState = 5;
    			
    		}
    		
    		else if(ReadState == 5){
    			Read[ReadCount] = data[i];
    			if(ReadCount <= (Buffer_Length-1))
    				FrameAnl(ReadCount+1);
    			ReadState = 0;
    			
    			
    		}
    	}
    }
    
    
    static void FrameAnl(int length){
    	byte sum = 0;
    	for(int i=0; i<(length-1); i++)
    		sum += Read[i];
    	if(sum==Read[length-1])//�����ܺ�ֵ���
    	{

    		if(Read[2]==1)//���ص��ǼӼ�
    		{
    			VAL_ANG_X = ((float)(BytetoUint(4)))/100;
    			VAL_ANG_Y = ((float)(BytetoUint(6)))/100;
    			VAL_ANG_Z = ((float)(BytetoUint(8)))/100;
    		}
    		if(Read[2]==2)//���ص��мӼƺ�������
    		{
    			VAL_ACC_X = BytetoUint(4);
    			VAL_ACC_Y = BytetoUint(6);
    			VAL_ACC_Z = BytetoUint(8);
    			VAL_GYR_X = BytetoUint(10);
    			VAL_GYR_Y = BytetoUint(12);
    			VAL_GYR_Z = BytetoUint(14);
    		}    		
    		
    	}
    }
    
    static short BytetoUint(int count)
    {
		short r = 0;  
		r <<= 8;  //r����8λ
		r |= (Read[count] & 0x00ff);  
		r <<= 8;  
		r |= (Read[count+1] & 0x00ff);  
		return r;	
    } 
}