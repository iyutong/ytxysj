package com.example.seuxiaosi;

import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class MyBluetooth extends Activity {

	//�����豸��ַ
	public static String EXTRA_DEVICE_ADDRESS = "device_addres";
	
	private BluetoothAdapter mBtAdapter;
	private ArrayAdapter<String>mPairedDevicesArrayAdapter;
	private ArrayAdapter<String> mNewDevicesArrayAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);//�������ڲ����Ӳ�ȷ��������
		setContentView(R.layout.activity_my_bluetooth);
		
		
		setResult(Activity.RESULT_CANCELED);
		Button mButton = (Button) findViewById(R.id.Scan);
		mButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				doDiscovery();
				v.setVisibility(View.GONE);//���ؿؼ�
			}
		});
		
		//��view���ֵķ�ʽ��ʾ�豸����
		mPairedDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.device_name);
		mNewDevicesArrayAdapter = new ArrayAdapter<String>(this,R.layout.device_name);
		
		//�����б��������
		ListView pairedListView = (ListView) findViewById(R.id.paired_devices);
		pairedListView.setAdapter(mPairedDevicesArrayAdapter);
		pairedListView.setOnItemClickListener(mClickListener);
		
		ListView newDeviceListView = (ListView) findViewById(R.id.new_devices);
		newDeviceListView.setAdapter(mNewDevicesArrayAdapter);
		newDeviceListView.setOnItemClickListener(mClickListener);
		
		//ע���·��ֵ������豸
		IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
		this.registerReceiver(mReceiver, filter);
		
		filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		this.registerReceiver(mReceiver, filter);
		
		//��������������
		mBtAdapter = BluetoothAdapter.getDefaultAdapter();
		
		//��ʾ������豸
		Set<BluetoothDevice>paireDevices = mBtAdapter.getBondedDevices();
		if(paireDevices.size() >0 ){
			findViewById(R.id.title_paired_devices).setVisibility(View.VISIBLE);
			for(BluetoothDevice device : paireDevices){
				mPairedDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
			}
		}
		else
			mPairedDevicesArrayAdapter.add("��������豸");
	}
	
	@Override
	protected void onDestroy(){
		super.onDestroy();
		
		//��ֹ�ظ����������豸
		if(mBtAdapter != null)
			mBtAdapter.cancelDiscovery();
		
		this.unregisterReceiver(mReceiver);
	}
	
	private void doDiscovery(){
		setProgressBarIndeterminate(true);
		setTitle("������������");
		
		findViewById(R.id.title_new_devices).setVisibility(View.VISIBLE);
		
		if(mBtAdapter.isDiscovering())
			mBtAdapter.cancelDiscovery();
		
		mBtAdapter.startDiscovery();
	}
	
	//�ú������������豸�����ֺ͵�ַ
	private OnItemClickListener mClickListener = new OnItemClickListener() {
		
		public void onItemClick(AdapterView<?>arg0, View arg1, int arg2, long arg3){
			mBtAdapter.cancelDiscovery();
			String info = ((TextView)arg1).getText().toString();
			String address = info.substring(info.length()-17);
			
			Intent intent = new Intent();
			intent.putExtra(EXTRA_DEVICE_ADDRESS, address);
			
			setResult(Activity.RESULT_OK,intent);
			finish();
		}
	};
	
	//�㲥������
	private final BroadcastReceiver mReceiver = new BroadcastReceiver(){
		@Override
		public void onReceive(Context context, Intent intent){
			String action = intent.getAction();
			
			if(BluetoothDevice.ACTION_FOUND.equals(action)){
				BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
			
			
			if(device.getBondState() != BluetoothDevice.BOND_BONDED)
				mNewDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
			}
			else 
				if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                setProgressBarIndeterminateVisibility(false);
                setTitle("ѡ��Ҫ���ӵ������豸");
                
                if (mNewDevicesArrayAdapter.getCount() == 0) 
                    mNewDevicesArrayAdapter.add("δ�����µ������豸");
 
			}
		}
	};
}
