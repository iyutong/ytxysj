package com.example.seuxiaosi;


import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.annotation.SuppressLint;



public class MyControl extends Activity {
	
	
	//����ͼ����ת�ı���
	private ImageView mImageView_yaw;
	private ImageView mImageView_rol;
	private ImageView mImageView_pit;
	private ImageView mImageView_thr;

	private Matrix mMatrix = new Matrix();
	private float mAngle_thr = 0;
	Bitmap mBitmap;
	Paint paint = new Paint();
	
	private int thrTF = 0;//
	
	//�Զ��尴�������¼���
	mImageListenter mImageButtonListener = new mImageListenter();
	
	//�������ţ� yaw��pit��rol�ĳ�ʼֵ
	private int VAL_THR = 1000;
	private int VAL_YAW = 1500, VAL_ROL = 1500, VAL_PIT = 1500;
	
	//������ʾ
	TextView 	 acc_x_show , acc_y_show , acc_z_show ,
	 			 gyr_x_show , gyr_y_show , gyr_z_show ;

	
	
	//ͼƬ��ť����
	private ImageButton image;
	
	
	//�ɿؽ���  LOCK=0����������LOCK=1��������
	private int LOCK = 0;
	
	//ʱ�������
	Timer send_timer = new Timer();
	
	
	private final Handler myHandler = new Handler();
	//handler���Էַ�Message�����Runnable�������߳���
	//handler�� ��ִ��ʱ������������������������������
	
	private final Runnable myRunable = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			 //0.1�����ô�Runnable����,���ڿ������ݵĸ���
			myHandler.postDelayed(this,100);
			
			
			//���ƽ������ݵĸ���			
			acc_x_show.setText("X: " + MainActivity.VAL_ACC_X);			
			acc_y_show.setText("Y: " + MainActivity.VAL_ACC_Y);
			acc_z_show.setText("Z: " + MainActivity.VAL_ACC_Z);			
			
			gyr_x_show.setText("X: " + MainActivity.VAL_GYR_X);			
			gyr_y_show.setText("Y: " + MainActivity.VAL_GYR_Y);			
			gyr_z_show.setText("Z: " + MainActivity.VAL_GYR_Z);

			mRotate_yaw();//��תͼ��
			mRotate_pit();
			mRotate_rol();
			if(LOCK == 1){
				
			if(thrTF == 1)
				VAL_THR += 2;
			else if(thrTF == 2)
				VAL_THR -= 2;
			mRotate_thr_up();
		
			}		
	
		}
	};
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		
		
		
		super.onCreate(savedInstanceState);
		//����ģʽ
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
				
		//������Ļ����
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_my_control);
		
		
		ImageButton mImageButton;
		
		 acc_x_show = (TextView) findViewById(R.id.acc_x);
		 acc_y_show = (TextView) findViewById(R.id.acc_y);
		 acc_z_show = (TextView) findViewById(R.id.acc_z);
		 
		 
		 gyr_x_show = (TextView) findViewById(R.id.gyr_x);
		 gyr_y_show = (TextView) findViewById(R.id.gyr_y);
		 gyr_z_show = (TextView) findViewById(R.id.gyr_z);
	
		 
		 
		//������תͼ��
	     mImageView_yaw = (ImageView) findViewById(R.id.yaw_image);
	     mImageView_rol = (ImageView) findViewById(R.id.rol_image);
	     mImageView_pit = (ImageView) findViewById(R.id.pit_image);
	     mImageView_thr = (ImageView) findViewById(R.id.thr_image);

	       
	     DisplayMetrics dm =new DisplayMetrics();
	     getWindowManager().getDefaultDisplay().getMetrics(dm);


		
		
		//��ť������
		mImageButton = (ImageButton) findViewById(R.id.thr_up);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.thr_down);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.rol_you);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.rol_zuo);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.pit_qian);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.pit_hou);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.yaw_zuo);
		mImageButton.setOnTouchListener(mImageButtonListener);
		
		mImageButton = (ImageButton) findViewById(R.id.yaw_you);
		mImageButton.setOnTouchListener(mImageButtonListener);
				
		mImageButton = (ImageButton) findViewById(R.id.suo);
		mImageButton.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				image = (ImageButton) findViewById(R.id.suo);
				
				if(LOCK == 0){
					LOCK = 1;//����״̬��1
					
					//���ͽ�������			
					MainActivity.Send_Command((byte)0xa1);
					image.setImageResource(R.drawable.jie);					
				}
				else{
					
					//������������			
					MainActivity.Send_Command((byte)0xa0);
					image.setImageResource(R.drawable.suo);
					VAL_THR = 1000;//������0
					mRotate_thr_up();														
					LOCK = 0;//����״̬��0
					
				}
			}
		});
		
		
	    //�ӳ�1���ִ������send_task,Ȼ�󾭹�0.05���ٴ�ִ��send_task������ѭ������
		send_timer.schedule(send_task,1000,50);

		//ÿ0.1��ִ��һ��runnable
		myHandler.postDelayed(myRunable, 100);
		
	}
	
	class mImageListenter implements OnTouchListener{

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
						
			if(LOCK == 1){
			
			//yaw��ť
			if(v.getId() == R.id.yaw_zuo){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_YAW = 1200;  															
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_YAW = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_YAW = 1500;
				
				
			}
			
			if(v.getId() == R.id.yaw_you){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_YAW = 1800;
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_YAW = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_YAW = 1500;
				
			}
			
			//pit��ť
			if(v.getId() == R.id.pit_qian){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_PIT = 1650;
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_PIT = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_PIT = 1500;
				

			}
			
			if(v.getId() == R.id.pit_hou){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_PIT = 1350;
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_PIT = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_PIT = 1500;
				
			}
			
			
			//rol��ť
			if(v.getId() == R.id.rol_zuo){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_ROL = 1200;					
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_ROL = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_ROL = 1500;
				
			}
			
			if(v.getId() == R.id.rol_you){
				if(event.getAction() == MotionEvent.ACTION_DOWN)
					VAL_ROL = 1800;
				if(event.getAction() == MotionEvent.ACTION_CANCEL)
					VAL_ROL = 1500;
				if(event.getAction() == MotionEvent.ACTION_UP)
					VAL_ROL = 1500;
				
				
			}
			
			
			//����
			if(v.getId() == R.id.thr_up){
				if( VAL_THR >= 2000)
						{VAL_THR = 2000;}//ִ�п����
				
				else{ 
					if(event.getAction() == MotionEvent.ACTION_DOWN)
						thrTF = 1;
					//{VAL_THR += 15;	mRotate_thr_up();}
					if(event.getAction() == MotionEvent.ACTION_CANCEL)
						thrTF = 0;
					if(event.getAction() == MotionEvent.ACTION_UP)
						thrTF = 0;
				}
				
			}
			
			if(v.getId() == R.id.thr_down){
				if(VAL_THR <= 1000)
					{VAL_THR = 1000;}
				
				else{
					if(event.getAction() == MotionEvent.ACTION_DOWN)
						thrTF = 2;
					if(event.getAction() == MotionEvent.ACTION_CANCEL)
						thrTF = 0;
					if(event.getAction() == MotionEvent.ACTION_UP)
						thrTF = 0;
					}
			}
			}
			return false;
		}
	}
	

	TimerTask send_task = new TimerTask(){ 
    	//Timer��һ���߳���ʩ�����ڰ����Ժ��ں�̨�߳���ִ�е�����
    	//�ɰ�������ִ��һ�Σ����߶����ظ�ִ�У����Կ���һ����ʱ�������Ե���TimerTask��
    	//TimerTask��һ�������࣬ʵ����Runnable�ӿڣ����Ծ߱��˶��̵߳�������
    	byte[] bytes = new byte[25];
    	public void run () 
    	{   		
    		
    		byte sum=0;
    		
    		bytes[0] = (byte) 0xaa;
    		bytes[1] = (byte) 0xaf;
    		bytes[2] = (byte) 0x03;
    		bytes[3] = (byte) 20;
    		bytes[4] = (byte) (VAL_THR/0xff);//ȡ��   ����
    		bytes[5] = (byte) (VAL_THR%0xff);//ȡ����
    		bytes[6] = (byte) (VAL_YAW/0xff);//����
    		bytes[7] = (byte) (VAL_YAW%0xff);
    		bytes[8] = (byte) (VAL_ROL/0xff);//���
    		bytes[9] = (byte) (VAL_ROL%0xff);
    		bytes[10] = (byte) (VAL_PIT/0xff);//����
    		bytes[11] = (byte) (VAL_PIT%0xff);
    		bytes[12] = 1;
    		bytes[13] = 2;
    		bytes[14] = 3;
    		bytes[15] = 4;
    		bytes[16] = 0;
    		bytes[17] = 0;
    		bytes[18] = 0;
    		bytes[19] = 0;
    		bytes[20] = 0;
    		bytes[21] = 0;
    		bytes[22] = 0;
    		bytes[23] = 0;
    		for(int i=0;i<24;i++) sum += bytes[i];
    		bytes[24] = sum;
    		
    		MainActivity.SendData_Byte(bytes);//��������
    	}
    	};
    	
    protected void onDestroy(){
		if (send_timer != null) //ע����ʱ��
		{
			send_timer.cancel();
			send_timer = null;
		}
		super.onDestroy();
		}
    
    
    //�Զ���ͼ����ת����
    private void mRotate_yaw(){
    	    	
    	mBitmap = ((BitmapDrawable)(getResources().getDrawable(R.drawable.yaw2))).getBitmap();				
		mMatrix.setRotate(MainActivity.VAL_ANG_Z, mBitmap.getWidth() / 2, mBitmap.getHeight() / 2);//��ת�Ƕ�����
		paint = new Paint();
		//���ÿ����,��ֹ�����ʧ��
		paint.setAntiAlias(true);
		mBitmap = Bitmap.createBitmap(mBitmap, 0, 0, mBitmap.getWidth(), mBitmap.getHeight(), mMatrix, true);		
		mImageView_yaw.setImageBitmap(mBitmap);
		
    }
    	
    
    private void mRotate_rol(){

    	mBitmap = ((BitmapDrawable)(getResources().getDrawable(R.drawable.rol2))).getBitmap();				
		mMatrix.setRotate( MainActivity.VAL_ANG_X, mBitmap.getWidth() / 2, mBitmap.getHeight() / 2);//��ת�Ƕ�����
		paint = new Paint();
		//���ÿ����,��ֹ�����ʧ��
		paint.setAntiAlias(true);
		mBitmap = Bitmap.createBitmap(mBitmap, 0, 0, mBitmap.getWidth(), mBitmap.getHeight(), mMatrix, true);		
		mImageView_rol.setImageBitmap(mBitmap);
		
    }
    
    
    private void mRotate_pit(){
		
		mBitmap = ((BitmapDrawable)(getResources().getDrawable(R.drawable.pit2))).getBitmap();				
		mMatrix.setRotate(-MainActivity.VAL_ANG_Y, mBitmap.getWidth() / 2, mBitmap.getHeight() / 2);//��ת�Ƕ�����
		paint = new Paint();
		//���ÿ����,��ֹ�����ʧ��
		paint.setAntiAlias(true);
		mBitmap = Bitmap.createBitmap(mBitmap, 0, 0, mBitmap.getWidth(), mBitmap.getHeight(), mMatrix, true);		
		mImageView_pit.setImageBitmap(mBitmap);
		
    }
    
    private void mRotate_thr_up(){
		if(LOCK == 1){
		mBitmap = ((BitmapDrawable)(getResources().getDrawable(R.drawable.zhen))).getBitmap();				
    	mAngle_thr = (float)(VAL_THR-1000)*180/1000;
		mMatrix.setRotate(mAngle_thr, mBitmap.getWidth() / 2, mBitmap.getHeight() / 2);//��ת�Ƕ�����
		paint = new Paint();
		//���ÿ����,��ֹ�����ʧ��
		paint.setAntiAlias(true);
		mBitmap = Bitmap.createBitmap(mBitmap, 0, 0, mBitmap.getWidth(), mBitmap.getHeight(), mMatrix, true);		
		mImageView_thr.setImageBitmap(mBitmap);
		}
    }
   
    	
}  
	
