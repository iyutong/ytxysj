package com.mycompany.myapp2;

/**
武少编写
QQ2524479660
            */

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;

public class MainActivity extends ActionBarActivity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        //添加toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); //绑定工具栏ID
		toolbar.setLogo(R.mipmap.ic_launcher); // 设置apk图标
		toolbar.setTitle("主标题");  // 主标题
		toolbar.setSubtitle("副标题"); // 副标题
		setSupportActionBar(toolbar);//替换系统状态栏

		DrawerLayout drawer=(DrawerLayout) findViewById(R.id.drawerlayout);//绑定侧滑ID
		ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawer,toolbar,R.string.app_name,R.string.app_name){};
   	 	//标题栏左侧显示一个菜单按钮
		toggle.syncState();
   	 	//绑定侧滑监听器
		drawer.setDrawerListener(toggle);
    }
}
