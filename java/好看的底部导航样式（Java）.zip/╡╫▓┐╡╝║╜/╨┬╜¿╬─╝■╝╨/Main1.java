package com.example.testproject;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class Main1 extends AppCompatActivity implements View.OnClickListener {
    Toolbar toolbar;
    private FragmentManager fragmentManager;
    private ImageView image1,image2,image3,image4;
    private RelativeLayout firstlayout,secondlayout,thirdlayout,fourlayout;
    private ViewFragment2 view2;
    private ViewFragment3 view3;
    private ViewFragment4 view4;
    private ViewFragment5 view5;
    private FrameLayout frameLayout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main6);
        toolbar=findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);

        fragmentManager=getSupportFragmentManager();
        init();
        setChioceItem(0);
    }
    public void init(){

        image1=findViewById(R.id.first_image);
        image2=findViewById(R.id.second_image);
        image3=findViewById(R.id.third_image);
        image4=findViewById(R.id.fourth_image);
        firstlayout=findViewById(R.id.first_layout);
        secondlayout=findViewById(R.id.second_layout);
        thirdlayout=findViewById(R.id.third_layout);
        fourlayout=findViewById(R.id.fourth_layout);
        firstlayout.setOnClickListener(this);
        secondlayout.setOnClickListener(this);
        thirdlayout.setOnClickListener(this);
        fourlayout.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.first_layout:
                setChioceItem(0);
                break;
            case R.id.second_layout:
                setChioceItem(1);
                break;
            case R.id.third_layout:
                setChioceItem(2);
                break;
            case R.id.fourth_layout:
                setChioceItem(3);
                break;

        }
    }
    private void setChioceItem(int index){
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        clearChioce();//清空重置
        hideFragments(fragmentTransaction);
        switch(index){
            case 0:
               //image1.setImageResource(R.mipmap.e7);
                if(view2==null){
                    view2=new ViewFragment2();
                    fragmentTransaction.add(R.id.main_content,view2);
                }
                else{
                    fragmentTransaction.show(view2);
                }
                break;
            case 1:
                //image2.setImageResource(R.mipmap.e9);
                if(view3==null){
                    view3=new ViewFragment3();
                    fragmentTransaction.add(R.id.main_content,view3);
                }else{
                    fragmentTransaction.show(view3);
                }
                break;
            case 2:
               // image3.setImageResource(R.mipmap.b1);
                if(view4==null){
                    view4=new ViewFragment4();
                    fragmentTransaction.add(R.id.main_content,view4);
                }else{
                    fragmentTransaction.show(view4);
                }
                break;
            case 3:
                //image4.setImageResource(R.mipmap.a7);
                if(view5==null){
                    view5=new ViewFragment5();
                    fragmentTransaction.add(R.id.main_content,view5);
                }else{
                    fragmentTransaction.show(view5);
                }
                break;
        }
        fragmentTransaction.commit();
    }

    private void clearChioce(){

    }

    private void hideFragments(FragmentTransaction fragmentTransaction){
        if(view2!=null){
            fragmentTransaction.hide(view2);
        }
        if(view3!=null){
            fragmentTransaction.hide(view3);
        }
        if(view4!=null){
            fragmentTransaction.hide(view4);
        }
        if(view5!=null){
            fragmentTransaction.hide(view5);
        }
    }
}
