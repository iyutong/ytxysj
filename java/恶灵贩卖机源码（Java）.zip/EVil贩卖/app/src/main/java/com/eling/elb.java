package com.eling;

import cn.bmob.v3.*;

public class elb extends BmobObject
{private String hy=null;
    private String xii=null;
    private String jbhy=null;
    private String jb=null;
    public void setXinxi(String xii)
    {
        this.xii=xii;
    }
    public String getXinxi()
    {
        return xii;
    }
    public void sethy(String hy)
    {
        this.hy=hy;
    }
    public String gethy()
    {
        return hy;
    }
    public void setjbhy(String jbhy)
    {
        this.jbhy=jbhy;
    }
    public String getjbhy()
    {
        return jbhy;
    }
    public void setjb(String jb)
    {
        this.jb=jb;
    }
    public String getjb()
    {
        return jb;
    }


}


