package com.eling;

import android.app.Activity;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.SaveListener;
import com.eling.R;
import com.eling.ym1;
import java.util.ArrayList;
import java.util.List;


public class ym1 extends Activity 
{private ViewPager viewPager; // android-support-v4�еĻ������
    private List<ImageView> imageViews; // ������ͼƬ����
ListView li;
    private String[] titles; // ͼƬ����
    private int[] imageResId; // ͼƬID
    private List<View> dots; // ͼƬ�������ĵ���Щ��
Button q,e,zc;
EditText w,z;
    private TextView tv_title;
    private int currentItem = 0; // ��ǰͼƬ�������
    int   a,b,resuIt;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ym1);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); 
        li=(ListView) findViewById(R.id.ym1ListView1);
        
        li.setAdapter(
            new ArrayAdapter<String>
            (ym1.this,android.R.layout.simple_list_item_1,new String[]{"正在加载，请稍候……"}));

        BmobQuery<ymq> me=new BmobQuery<ymq>();
        me.findObjects(this, new FindListener<ymq>(){

                @Override
                public void onSuccess(List<ymq> p1)
                {
                    if(p1.size()==0)
                    {

                    }
                    else
                    {

                        ArrayList ar=new ArrayList();
                        for(ymq m:p1)
                        {
                            if(m.getIMEI()==null||m.getIMEI().length()<8)
                            {}
                            else
                            {
                                String pp="【"+m.getUser()+"】"+m.getXinxi();
                                ar.add(pp);
                            }
                        }
                        String[] st=new String[ar.size()];
                        int o=0;
                        for(int i=ar.size()-1;i>=0;i--)
                        {
                            st[i]=(String)ar.get(o);
                            ++o;
                        }
                        li.setAdapter(null);
                        li.setAdapter(
                            new ArrayAdapter<String>
                            (ym1.this,android.R.layout.simple_list_item_1,st));

                    }
                }

                @Override
                public void onError(int p1, String p2)
                {
                    li.setAdapter(null);
                    
                    li.setAdapter(
                        new ArrayAdapter<String>
                        (ym1.this,android.R.layout.simple_list_item_1,new String[]{
                             "【恶灵】加载失败了，你可以：",
                             "◇1.检查网络是否通畅，然后刷新！",
                             "◇2.关闭软件并重启。",
                             "◇3.向恶灵反馈信息。", }));

                }
            });
        

        imageResId = new int[] { R.drawable.a, R.drawable.b, R.drawable.c, R.drawable.d, R.drawable.e };
        titles = new String[imageResId.length];
        titles[0] = "官方介绍";
        titles[1] = "Evil~贩卖机";
        titles[2] = "开发者：恶灵";
        titles[3] = "QQ：1956871326";
        titles[4] = "反馈请加好友";
        imageViews = new ArrayList<ImageView>();
        for (int i = 0; i < imageResId.length; i++) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(imageResId[i]);
            imageView.setScaleType(ScaleType.CENTER_CROP);
            imageViews.add(imageView);
        }

        dots = new ArrayList<View>();
        dots.add(findViewById(R.id.v_dot0));
        dots.add(findViewById(R.id.v_dot1));
        dots.add(findViewById(R.id.v_dot2));
        dots.add(findViewById(R.id.v_dot3));
        dots.add(findViewById(R.id.v_dot4));


        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_title.setText(titles[0]);//

        viewPager = (ViewPager) findViewById(R.id.vp);
        viewPager.setAdapter(new MyAdapter());
        
        viewPager.setOnPageChangeListener(new MyPageChangeListener());

    }



    private class MyPageChangeListener implements OnPageChangeListener {
        private int oldPosition = 0;

        
        public void onPageSelected(int position) {
            currentItem = position;
            tv_title.setText(titles[position]);
            dots.get(oldPosition).setBackgroundResource(R.drawable.dot_normal);
            dots.get(position).setBackgroundResource(R.drawable.dot_focused);
            oldPosition = position;
        }

        public void onPageScrollStateChanged(int arg0) {

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }
    }

    private class MyAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return imageResId.length;
        }

        @Override
        public Object instantiateItem(View arg0, int arg1) {
            ((ViewPager) arg0).addView(imageViews.get(arg1));
            return imageViews.get(arg1);
        }

        @Override
        public void destroyItem(View arg0, int arg1, Object arg2) {
            ((ViewPager) arg0).removeView((View) arg2);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public void restoreState(Parcelable arg0, ClassLoader arg1) {

        }

        @Override
        public Parcelable saveState() {
            return null;
        }

        @Override
        public void startUpdate(View arg0) {

        }

        @Override
        public void finishUpdate(View arg0) {}
        
        }
        
        public void 发言(View view) {
            AlertDialog.Builder builder=new AlertDialog.Builder(ym1.this);
            builder.setTitle("发帖评论");

            LayoutInflater inflater=LayoutInflater.from(ym1.this);
            View vie=inflater.inflate(R.layout.hftz, null);
            builder.setView(vie);

            final AlertDialog dialog=builder.create();


            dialog.show();
            zc = (Button) vie.findViewById(R.id.ym1Button1);
            z = (EditText) vie.findViewById(R.id.ym1EditText1);
            zc.setOnClickListener(new View.OnClickListener(){

                    @Override
                    public void onClick(View p1)
                    {BmobUser bmobuser=BmobUser.getCurrentUser(ym1.this);
                                    if(bmobuser!=null){

                                        BmobUser user = BmobUser.getCurrentUser(ym1.this);
                                        BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                                        String id=user.getObjectId();
                                        query.getObject(ym1.this,id, new GetListener<MyUser>() 
                                            {

                                                @Override
                                                public void onFailure(int p1, String p2)
                                                {

                                                }

                                                @Override
                                                public void onSuccess(MyUser object) {
                                                    ymq me=new ymq();
                                                    String eed1=w.getText().toString();

                                                    me.setUser(object.getUsername());
                                                    me.setXinxi(eed1);

                                                    if(eed1.length()<=500&&eed1.length()>=5)
                                                    {
                                                        Toast.makeText(ym1.this,"正在提交…",Toast.LENGTH_LONG).show();
                                                        me.save(ym1.this, new SaveListener(){

                                                                @Override
                                                                public void onSuccess()
                                                                {
                                                                    Toast.makeText(ym1.this,"评论成功",Toast.LENGTH_LONG).show();

                                                                }

                                                                @Override
                                                                public void onFailure(int p1, String p2)
                                                                {
                                                                    Toast.makeText(ym1.this,"评论失败",Toast.LENGTH_LONG).show();
                                                                }
                                                            });
                                                    }
                                                    else if(eed1.equals(""))
                                                    {
                                                        Toast.makeText(ym1.this,"不能留空哟",Toast.LENGTH_LONG).show();
                                                    }
                                                    else if(eed1.length()>500||eed1.length()<5)
                                                    {
                                                        Toast.makeText(ym1.this,"不符合格式:\n内容字数不少于5个字并不超过500个字",Toast.LENGTH_LONG).show();
                                                    }}});

                                    }
                                    else{
                                        Toast.makeText(ym1.this,"请先登录",Toast.LENGTH_LONG).show();
                                    }

                                
            
            }});
        }}
