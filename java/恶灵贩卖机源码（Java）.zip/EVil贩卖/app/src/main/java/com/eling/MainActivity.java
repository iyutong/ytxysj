package com.eling;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.DeleteListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import com.eling.MainActivity;
import com.eling.MyUser;
import com.eling.R;
import com.gc.materialdesign.views.ButtonFloat;
import com.gc.materialdesign.views.ButtonRectangle;

    public class MainActivity extends AppCompatActivity 
    {TextView zh,el,ye;
        EditText sht,sh,z,m,cf,mi,cx2;
        Button jhpo,zc,k,qx,gm,qdsj,qxsj,cx;
        Toolbar mybar;
    int   a,b,resuIt;
    ButtonFloat bt;
    ButtonRectangle cz;
    
    
        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.main);
            Bmob.initialize(MainActivity.this,"bddeed807473f5ae397bcd0553c15f6e");
  
            mybar=(Toolbar) findViewById(R.id.toolbar);
            mybar.setTitle("   Evil~贩卖机");  // 主标题
            mybar.setSubtitle("   by~El"); // 副标题
            setSupportActionBar(mybar);
            final DrawerLayout mDrawerLayout = (DrawerLayout) findViewById ( R.id.drawer_layout );

            
            ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle  ( this, mDrawerLayout, mybar,
                                                                              R.string.drawer_open, R.string.drawer_close );
            mDrawerToggle.syncState();
            
            mDrawerLayout.setDrawerListener(mDrawerToggle);

            mDrawerLayout.setDrawerListener ( mDrawerToggle );


            NavigationView mNavigationView = (NavigationView) findViewById ( R.id.navigation_view );
            mNavigationView.setNavigationItemSelectedListener ( new NavigationView.OnNavigationItemSelectedListener ( ) {
                    @Override
                    public boolean onNavigationItemSelected ( MenuItem menuItem )
                    {
                        switch ( menuItem.getItemId ( ) )
                        {
                                
                            case R.id.tc:
                                Dialog dialong = new AlertDialog.Builder(MainActivity.this).
                                    setTitle("温馨提示").
                                    setMessage("是否退出登录?").

                                    setPositiveButton("确定",new DialogInterface.OnClickListener()
                                    {   @Override
                                        public void onClick(DialogInterface p1, int p2)
                                        {BmobUser bmobuser=BmobUser.getCurrentUser(MainActivity.this);
                                            if(bmobuser!=null){
                                                BmobUser.logOut(MainActivity.this);
                                                Toast.makeText(MainActivity.this,"退出登录成功",1).show();
                                            }
                                            else{
                                                Toast.makeText(MainActivity.this,"系统检测到你未登录",1).show();
                                            }
                                        }
                                    }).
                                    setNegativeButton("取消",new DialogInterface.OnClickListener()
                                    {  
                                        @Override
                                        public void onClick(DialogInterface p1, int p2)
                                        {
                                        }

                                    }).
                                    create();
                                dialong.show();
                                
                                
                                break;
                            case R.id.jl:

                                Intent poi = new Intent(MainActivity.this,ym1.class);
                                poi.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(poi);
                                
                                break;

                            
                    case R.id.ye:

                                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                                builder.setTitle("查询余额");

                                LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
                                View vie=inflater.inflate(R.layout.kmye, null);
                                builder.setView(vie);

                                final AlertDialog dialog=builder.create();


                                dialog.show();
                                ye = (TextView) vie.findViewById(R.id.cxsj);
                                cx = (Button) vie.findViewById(R.id.kmyeButton1);
                                cx2 = (EditText) vie.findViewById(R.id.kmyeEditText1);
                                cx.setOnClickListener(new View.OnClickListener(){

                                        @Override
                                        public void onClick(View p1)
                                        {
                                            String p=cx2.getText().toString().trim();
                                            BmobQuery<elb> bmobQuery = new BmobQuery<elb>();
                                            bmobQuery.getObject(MainActivity.this, p, new GetListener<elb>() {

                                                    @Override
                                                    public void onFailure(int p1, String p2)
                                                    {

                                                    }

                                                    @Override
                                                    public void onSuccess(elb object) {
                                                        ye.setText("该卡密有"+object.getXinxi()+"恶灵币");
                                                    }});
                                        }});

                        break;
                    }

                        mDrawerLayout.closeDrawers ( );
                        return true;
                    }
                } );      
                cz=(ButtonRectangle)findViewById(R.id.czi);
                cz.setOnClickListener(new OnClickListener(){

                        @Override
                        public void onClick(View p1)
                        {
                            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("卡密充值");
                            LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
                            View vie=inflater.inflate(R.layout.km, null);
                            builder.setView(vie);
                            
                            final AlertDialog dialog=builder.create();
                            dialog.setCanceledOnTouchOutside(false);
                            dialog.show();
                            k = (Button) vie.findViewById(R.id.kma);
                            mi = (EditText) vie.findViewById(R.id.kmb);
                            qx = (Button) vie.findViewById(R.id.kmc);
                            gm = (Button) vie.findViewById(R.id.kmd);
                            k.setOnClickListener(new View.OnClickListener(){

                                    @Override
                                    public void onClick(View p1)
                                    {String mp=mi.getText().toString().trim();
                                        BmobQuery<elb> bmobQuery = new BmobQuery<elb>();
                                        bmobQuery.getObject(MainActivity.this, mp, new GetListener<elb>() {
                                                @Override
                                                public void onSuccess(elb object) {
                                                    a=Integer.parseInt(object.getXinxi());
                                                    
                                                    BmobUser user = BmobUser.getCurrentUser(MainActivity.this);
                                                    BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                                                    String id=user.getObjectId();
                                                    query.getObject(MainActivity.this,id, new GetListener<MyUser>() 
                                                        {
                                                            @Override
                                                            public void onSuccess(MyUser object) {
                                                                b=Integer.parseInt(object.getye());
                                                                
                                                                final MyUser p2 = new MyUser();
                                                                resuIt=a+b;
                                                                p2.setye(resuIt+"");
                                                                p2.update(MainActivity.this,object.getObjectId(), new UpdateListener() {
                                                                        @Override
                                                                        public void onSuccess() {
                                                                            Toast.makeText(MainActivity.this,"充值成功",1).show();
                                                                            String mp=mi.getText().toString().trim();
                                                                            elb p2 = new elb();
                                                                            p2.setObjectId(mp);
                                                                            p2.delete(MainActivity.this, new DeleteListener() {
                                                                                    @Override
                                                                                    public void onSuccess() {
                                                                                        Toast.makeText(MainActivity.this,"充值成功",1).show();
                                                                                    }

                                                                                    @Override
                                                                                    public void onFailure(int p1,String msg) {
                                                                                   
                                                                                    }
                                                                                });
                                                                        }

                                                                        @Override
                                                                        public void onFailure(int p1 ,String msg) {
                                                                            Toast.makeText(MainActivity.this,"充值失败，请稍后重试!",1).show();
                                                                        }
                                                                    });                     }
                                                            @Override
                                                            public void onFailure(int p1, String p2)
                                                            {
                                                                Toast.makeText(MainActivity.this,"卡密错误或无效!",1).show();

                                                                
                                                            }
                                                            
                                                                
                                                                });
                                                    
                                                }

                                                @Override
                                                public void onFailure(int p1,String msg) {
                                                    Toast.makeText(MainActivity.this,"卡密错误或无效!",1).show();
                                                }
                                            });
           
                            }});
                            qx.setOnClickListener(new View.OnClickListener(){

                                    @Override
                                    public void onClick(View p1)
                                    {
                                        dialog.dismiss();
                                    }});
                            gm.setOnClickListener(new View.OnClickListener(){

                                    @Override
                                    public void onClick(View p1)
                                    {
                                        Intent intent = new Intent();
                                        intent.setData(Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=1956871326"));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);

                                    }});
                        }
                    });
            BmobUser bmobuser=BmobUser.getCurrentUser(MainActivity.this);
            if(bmobuser!=null){
                BmobUser user = BmobUser.getCurrentUser(MainActivity.this);
                BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                String id=user.getObjectId();
                query.getObject(MainActivity.this,id, new GetListener<MyUser>() 
                    {
                        @Override
                        public void onSuccess(MyUser object) {
                            el=(TextView) findViewById(R.id.elq);
                            zh=(TextView) findViewById(R.id.zhq);
                            el.setText(object.getye());
                            zh.setText(object.getUsername());
                        }
                        @Override
                        public void onFailure(int p1, String p2)
                        {
                            // TODO: Implement this method

                        }});
            }else{{}}
            bt=(ButtonFloat)findViewById(R.id.恶灵);
            bt.setOnClickListener(new OnClickListener(){

                    @Override
                    public void onClick(View p1)
                    {        Bmob.initialize(MainActivity.this,"bddeed807473f5ae397bcd0553c15f6e");

                        BmobUser bmobuser=BmobUser.getCurrentUser(MainActivity.this);
                        if(bmobuser!=null){
                            Toast.makeText(MainActivity.this,"您已登录!",1).show();
                            
                        }else{
                            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("登录");

                            LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
                            View vie=inflater.inflate(R.layout.dl, null);
                            builder.setView(vie);

                            final AlertDialog dialog=builder.create();


                            dialog.show();
                            jhpo = (Button) vie.findViewById(R.id.denglul);
                            sh = (EditText) vie.findViewById(R.id.dluu);
                            sht = (EditText) vie.findViewById(R.id.dluuu);
                            jhpo.setOnClickListener(new View.OnClickListener(){

                                    @Override
                                    public void onClick(View p1)
                                    {if (sh.getText().toString().trim().isEmpty()||sh.getText().toString().trim().length()<5)
                                        {
                                            Toast.makeText(MainActivity.this,"账号长度有误请重试",Toast.LENGTH_LONG).show();
                                        }
                                        else{
                                            if (sht.getText().toString().trim().trim().isEmpty()||sht.getText().toString().length()<5)
                                            {

                                                Toast.makeText(MainActivity.this,"密码长度有误请重试",1000).show();

                                            }
                                            else{



                                                final ProgressDialog dialo = new ProgressDialog(MainActivity.this);
                                                dialo.setMessage("正在登录...");
                                                dialo.setCanceledOnTouchOutside(false);
                                                dialo.show();
                                                new Handler().postDelayed(new Runnable() {

                                                        @Override
                                                        public void run()
                                                        {
                                                            String e_user = sh.getText().toString().trim();
                                                            String e_pass= sht.getText().toString().trim();

                                                            MyUser user=new MyUser();
                                                            user.setUsername(e_user);
                                                            user.setPassword(e_pass);
                                                            user.login(MainActivity.this, new SaveListener(){

                                                                    @Override
                                                                    public void onSuccess()
                                                                    {
                                                                        Toast.makeText(MainActivity.this,"登陆成功",Toast.LENGTH_LONG).show();
                                                                        dialog .dismiss();
                                                                        dialo.dismiss();
                                                                    }

                                                                    @Override
                                                                    public void onFailure(int p1, String p2)
                                                                    {


                                                                        if(p2.equals("username or password incorrect."))
                                                                        {
                                                                            Toast.makeText(MainActivity.this,"账号或密码不正确",Toast.LENGTH_LONG).show();
                                                                        }
                                                                        else{
                                                                            if(p2.equals("The network is not available,please check your network!"))
                                                                            {
                                                                                Toast.makeText(MainActivity.this,"网络不可用，请检查您的网络！",Toast.LENGTH_LONG).show();
                                                                            }
                                                                            else{
                                                                                if(p2.equals("login data required."))
                                                                                {
                                                                                    Toast.makeText(MainActivity.this,"请检查账号或密码",Toast.LENGTH_LONG).show();
                                                                                }
                                                                                else{
                                                                                    Toast.makeText(MainActivity.this,"登陆失败",Toast.LENGTH_LONG).show();
                                                                                }
                                                                            }
                                                                        }


                                                                        dialo.dismiss();
                                                                    }
                                                                });}},1500);
                                            }}
                                    }
                                });
                        // TODO: Implement this method
                    }}
                });
            
      

                
        }
    public void 注册(View view) {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("注册");

        LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
        View vie=inflater.inflate(R.layout.zc, null);
        builder.setView(vie);

        final AlertDialog dialog=builder.create();


        dialog.show();
        zc = (Button) vie.findViewById(R.id.zhuc);
        z = (EditText) vie.findViewById(R.id.z);
        m = (EditText) vie.findViewById(R.id.m);
        cf = (EditText) vie.findViewById(R.id.cf);
        zc.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {if (z.getText().toString().trim().isEmpty()||z.getText().toString().trim().length()<5)
                    {
                        Toast.makeText(MainActivity.this,"账号长度有误请重试",Toast.LENGTH_LONG).show();
                        
                        return;
                    }
                    if (m.getText().toString().trim().isEmpty()||m.getText().toString().trim().length()<5)
                    {
                        Toast.makeText(MainActivity.this,"密码长度有误请重试",Toast.LENGTH_LONG).show();
                        
                        return;
                    }
                    if (cf.getText().toString().isEmpty()||cf.getText().toString().length()<5||!cf.getText().toString().equals(m.getText().toString()))
                    {
                        Toast.makeText(MainActivity.this,"重复密码不匹配请重试",Toast.LENGTH_LONG).show();
                        m.setText("");
                        return;
                    }
                    else{
                        final ProgressDialog dialg = new ProgressDialog(MainActivity.this);
                        dialg.setMessage("正在注册...");
                        dialg.setCanceledOnTouchOutside(false);
                        dialg.show();
                        new Handler().postDelayed(new Runnable() {

                                @Override
                                public void run()
                                {

                                    String e_user = z.getText().toString().trim();
                                    String e_pass=m.getText().toString().trim();

                                    MyUser user=new MyUser();
                                    user.setUsername(e_user);
                                    user.setPassword(e_pass);
                                    user.setye("10");
                                    user.signUp(MainActivity.this, new SaveListener(){

                                            @Override
                                            public void onFailure(int p1, String p2)
                                            {String r = z.getText().toString().trim();

                                                if(p2.equals("username '"+r+"' already taken."))
                                                {
                                                    Toast.makeText(MainActivity.this,"已有该账号",Toast.LENGTH_LONG).show();
                                                }
                                                else{

                                                }

                                                dialg.dismiss();

                                            }
                                            @Override
                                            public void onSuccess()
                                            {
                                                MyUser myuser=BmobUser.getCurrentUser(MainActivity.this,MyUser.class);
                                                myuser.update(MainActivity.this, new UpdateListener(){

                                                        @Override
                                                        public void onSuccess()
                                                        {dialog.dismiss();
                                                            Toast.makeText(MainActivity.this,"注册成功",Toast.LENGTH_LONG).show();
                                                            BmobUser.logOut(MainActivity.this);
                                                            dialg.dismiss();
                                                            dialog.dismiss();
                                                        }

                                                        @Override
                                                        public void onFailure(int p1, String p2)
                                                        {
                                                            String r = z.getText().toString().trim();

                                                            if(p2.equals("username '"+r+"' already taken."))
                                                            {
                                                                Toast.makeText(MainActivity.this,"已有该账号",Toast.LENGTH_LONG).show();
                                                            }
                                                            else{

                                                            }

                                                            dialg.dismiss();

                                                        }
                                                    });}});}},1500);}
        
        }});
        }
    public void 找回密码(View view) {
        Toast.makeText(MainActivity.this,"请联系开发者",1).show();
    
                    
                    }
                                        
    public void ym1(View view) {
        
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("");
        LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
        View vie=inflater.inflate(R.layout.q, null);
        builder.setView(vie);
        final AlertDialog dialog=builder.create();
        dialog.show();
        qdsj= (Button) vie.findViewById(R.id.qdsj);
        qxsj = (Button) vie.findViewById(R.id.qxsj);
        qdsj.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {BmobUser bmobuser=BmobUser.getCurrentUser(MainActivity.this);
                    if(bmobuser!=null){
                        BmobUser user = BmobUser.getCurrentUser(MainActivity.this);
                        BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                        String id=user.getObjectId();
                        query.getObject(MainActivity.this,id, new GetListener<MyUser>() 
                            {
                                @Override
                                public void onSuccess(MyUser object) {

                                    if(Integer.parseInt(object.getye())<Integer.parseInt("100")){
                                        Toast.makeText(MainActivity.this,"系统检测到你的余额不足",1).show();

                                    }
                                    else{

                                        BmobQuery<elym> bmobQuery = new BmobQuery<elym>();
                                        bmobQuery.getObject(MainActivity.this, ("MdI0SSSm"), new GetListener<elym>() {

                                                @Override
                                                public void onFailure(int p1, String p2)
                                                {

                                                }

                                                @Override
                                                public void onSuccess(elym object) {
                                                    ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                                                    manager.setText(object.getq());

                                                    BmobUser user = BmobUser.getCurrentUser(MainActivity.this);
                                                    BmobQuery<MyUser> query = new BmobQuery<MyUser>();
                                                    String id=user.getObjectId();
                                                    query.getObject(MainActivity.this,id, new GetListener<MyUser>() 
                                                        {

                                                            @Override
                                                            public void onSuccess(MyUser object) {
                                                                b=Integer.parseInt(object.getye());
                                                                a=Integer.parseInt("100");


                                                                final MyUser p2 = new MyUser();
                                                                resuIt=b-a;
                                                                p2.setye(resuIt+"");
                                                                p2.update(MainActivity.this,object.getObjectId() , new UpdateListener() {
                                                                        @Override
                                                                        public void onSuccess() {
                                                                            Toast.makeText(MainActivity.this,"购买成功",1).show();
                                                                            Dialog dialong = new AlertDialog.Builder(MainActivity.this).
                                                                                setTitle("温馨提示").
                                                                                setCancelable(false).
                                                                                setMessage("下载源码的链接已反正到剪切板，请去浏览器下载。").

                                                                                setPositiveButton("确定",new DialogInterface.OnClickListener()
                                                                                {   @Override
                                                                                    public void onClick(DialogInterface p1, int p2)
                                                                                    {
                                                                                    }
                                                                                }).
                                                                                setNegativeButton("取消",new DialogInterface.OnClickListener()
                                                                                {  
                                                                                    @Override
                                                                                    public void onClick(DialogInterface p1, int p2)
                                                                                    {
                                                                                    }

                                                                                }).
                                                                                create();
                                                                            dialong.show();
                                                                            
                                                                        }

                                                                        @Override
                                                                        public void onFailure(int p1,String msg) {

                                                                        }
                                                                    });
                                                            }

                                                            @Override
                                                            public void onFailure(int p1,String msg) {

                                                            }
                                                        });
                                                }});}}
                                @Override
                                public void onFailure(int p1, String p2)
                                {


                                }});
                    }else{
                        Toast.makeText(MainActivity.this,"请先登录",1).show();
                    }

                }});
        qxsj.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {dialog.dismiss();
                }});

        
        }}
