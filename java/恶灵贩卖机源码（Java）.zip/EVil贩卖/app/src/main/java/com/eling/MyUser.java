package com.eling;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobDate;

public class MyUser extends BmobUser
{
    //获取数据库信息
	
    private String nickName,xyh;
    private Boolean sex;
    private String nick,ye;
    private Integer age;
    private Boolean Pro;
    private String Id;
    private BmobDate Time;
    private BmobDate Timeout;
    private Boolean Is;

    public String getNickName() {
        return nickName;
    }
    public void setNickName(String nickName) {
		this.nickName = nickName;}
	
	public BmobDate getTime() {
        return Time;
    }

    public void setTime(BmobDate time) {
        Time = time;
    }

    public BmobDate getTimeout() {
        return Timeout;
    }

    public void setTimeout(BmobDate timeout) {
        Timeout = timeout;
    }

    public void setIs(Boolean is) {
        this.Is = is;
    }

    public Boolean getIs() {
        return Is;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        this.Id = id;
    }

    public void setPro(Boolean pro) {
        this.Pro = pro;
    }

    public Boolean getPro() {
        return Pro;
    }

    public boolean getSex() {
        return this.sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public String getNick() {
        return this.nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
		
		
    }
	public String getye() {
        return this.ye;
    }



	public void setye(String ye) {
        this.ye = ye;
    }
	
	public String getxyh() {
        return this.xyh;
    }



	public void setxyh(String xyh) {
        this.xyh = xyh;
    }

	
	
	
}

