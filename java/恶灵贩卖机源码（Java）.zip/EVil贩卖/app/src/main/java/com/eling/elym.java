package com.eling;

import cn.bmob.v3.*;

public class elym extends BmobObject
{private String q=null;
    private String xii=null;
    private String jbhy=null;
    private String jb=null;
    public void setXinxi(String xii)
    {
        this.xii=xii;
    }
    public String getXinxi()
    {
        return xii;
    }
    public void setq(String q)
    {
        this.q=q;
    }
    public String getq()
    {
        return q;
    }
    public void setjbhy(String jbhy)
    {
        this.jbhy=jbhy;
    }
    public String getjbhy()
    {
        return jbhy;
    }
    public void setjb(String jb)
    {
        this.jb=jb;
    }
    public String getjb()
    {
        return jb;
    }


}


