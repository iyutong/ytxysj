package com.eling;

import cn.bmob.v3.*;

public class ymq extends BmobObject
{
    private String user=null;
    private String xinxi=null;
    private String IMEI=null;
    public void setXinxi(String xinxi)
    {
        this.xinxi=xinxi;
    }
    public void setIMEI(String i)
    {
        this.IMEI=i;
    }

    public void setUser(String user)
    {
        this.user=user;
    }
    public String getXinxi()
    {
        return xinxi;
    }

    public String getUser()
    {
        return user;
    }
    public String getIMEI()
    {
        return IMEI;
    }
}

