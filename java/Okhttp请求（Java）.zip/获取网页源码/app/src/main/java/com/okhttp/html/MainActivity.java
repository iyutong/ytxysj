package com.okhttp.html;

import android.app.*;
import android.os.*;
import okhttp3.*;
import android.widget.*;
import android.os.Handler;
import android.view.View.*;
import android.view.*;
import android.text.*;
public class MainActivity extends Activity 
{
	/*
	第1个开源作品
	蛋壳作品2019-4-14 17:00
	QQ:1970284668(有疑问加QQ)
	测试环境:酷安搜索Aide
	采用类库:Okhttp3
	GitHub地址:https://square.github.io/okhttp/
	*/
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		LinearLayout lin=(LinearLayout)findViewById(R.id.Action);
		Window window=this.getWindow();
		window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.height = (int) (egg.getActionHeight(window.getContext()));
		lin.setLayoutParams(layoutParams);
		ViewGroup decorViewGroup = (ViewGroup) window.getDecorView();
        View statusBarView = new View(window.getContext());
        int statusBarHeight = egg.getActionHeight(window.getContext());
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, statusBarHeight);
        params.gravity = Gravity.TOP;
        statusBarView.setLayoutParams(params);
        statusBarView.setBackgroundColor(0xff2196f3);
        decorViewGroup.addView(statusBarView);
		Button send=findViewById(R.id.sendSussess);
		final EditText lickCon=findViewById(R.id.editLink);
		send.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					EditText sussess=findViewById(R.id.sussess);
					String s = lickCon.getText().toString().trim();
					if(TextUtils.isEmpty(s)){
						Toast.makeText(getApplicationContext(),"不能为空",Toast.LENGTH_LONG).show();
					}
					else
					{
					sussess.setText("加载中...");
					new Thread(new Runnable(){

							@Override
							public void run()
							{
								// TODO: Implement this method
								Message msg=requestHandler.obtainMessage();

								try{
									OkHttpClient client=new OkHttpClient();
									String Link=lickCon.getText()+"";
									Request request=new Request.Builder().url(Link).build();
									Response response=client.newCall(request).execute();
									if(response.isSuccessful())
									{
										msg.what=0;
										msg.obj=response.body().string();
									}
								}catch(Exception e){
									msg.what=0;
									msg.obj=e;
									
								}finally {
									msg.sendToTarget();
								}
							}

						}).start();
					}
				}
		});
    }

	private Handler requestHandler=new Handler(){

		@Override
		public void handleMessage(Message msg)
		{
			switch(msg.what){
				case 0:
					String Mess=msg.obj+"";
				EditText sussess=findViewById(R.id.sussess);
				sussess.setText(Mess);
					break;
				default:
					super.handleMessage(msg);
			}
		}
	};
}

