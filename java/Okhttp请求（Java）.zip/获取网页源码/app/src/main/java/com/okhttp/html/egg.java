package com.okhttp.html;
import android.view.*;
import android.os.*;
import android.app.*;
import android.widget.*;
import android.widget.ActionMenuView.*;
import android.content.*;
import android.content.res.*;

public class egg
{
	public static void setWindowStatusBarColor(Activity activity, int colorResId) {  
        try {  
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {  
                Window window = activity.getWindow();  
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);  
                window.setStatusBarColor(activity.getResources().getColor(colorResId));  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
	
	public static LinearLayout.LayoutParams getLayoutParams(View id)
	{
		LinearLayout.LayoutParams Params=(LinearLayout.LayoutParams)id.getLayoutParams();
		return Params;
	}
	
	public static RelativeLayout.LayoutParams getRelativeLayout(View id)
	{
		RelativeLayout.LayoutParams Params=(RelativeLayout.LayoutParams)id.getLayoutParams();
		return Params;
	}
	
	public static int getActionHeight(Context context)
	{
		int statusBarHeight = 0;
        Resources res = context.getResources();
        int resourceId = res.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            statusBarHeight = res.getDimensionPixelSize(resourceId);
        }
        return statusBarHeight;
	}
}
