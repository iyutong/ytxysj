package com.william.logging.service;

import org.springframework.stereotype.Service;

/**
 * Created by sungang on 2017/11/16.
 */
@Service
public class UserService {
}
