package com.cking.crashhandler;

import android.app.*;
import android.os.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		//异常捕获初始化
		CrashHandler.getInstance().init(this);
    }
}
