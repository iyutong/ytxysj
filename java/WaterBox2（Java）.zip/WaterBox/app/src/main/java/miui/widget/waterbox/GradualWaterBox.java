package miui.widget.waterbox;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.RelativeLayout;
import com.s1243808733.waterbox.animation.Folme;
import com.s1243808733.waterbox.animation.base.AnimConfig;
import com.s1243808733.waterbox.animation.utils.EaseManager;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class GradualWaterBox extends RelativeLayout implements SensorEventListener {
    public static final int MaxAngle = 35;
    public static final float MaxValue = 1.0f;
    public static final float MinValue = 0.0f;
    public static final int PointNum = 5;
    private static final int SensorAccValueDimens = 3;
    private static final int SensorBufferCount = 2;
    public static final String TAG = "Memory";
    private WaterData data = new WaterData();
    private AnimConfig edgeRotAnimConfig;
    private PointF endPoint;
    private float finalValue;
    private boolean initialized;
    private float[] mAccValues;
    private float[][] mAccValuesForAverage = new float[2][];
    private int mAccValuesForAverageIndex = 0;
    private Sensor mAccelerometer;
    private int mColor = Color.parseColor("#330084FF");
    private float mCornerRadius = 48.0f;
    private boolean mDebug = new File(Environment.getExternalStorageDirectory(), "water_box").exists();
    private final Paint mDebugPaint = new Paint();
    private boolean mIsValueSet;
    private boolean mIsVisible;
    private RectF mRectF = new RectF();
    private float mSensorLastAngle;
    private long mSensorLastChangedTime = Long.MAX_VALUE;
    private SensorManager mSensorManager;
    private boolean mSensorRegistered = false;
    private float mValue = 1.0f;
    private final Paint mWaterPaint = new Paint();
    private final List<AnimConfig> pointAnimConfigs = new ArrayList();
    private final List<PointF> points = new ArrayList();
    private float preAngle = this.data.getRot();
    private PointF realEndPoint;
    private PointF realStartPoint;
    private AnimConfig rotAnimConfig;
    private PointF startPoint;
    private AnimConfig valueAnimConfig;
    private boolean varInitialized;
    private AnimConfig waterAlphaAnimConfig;

    private final float getPointPer(int i) {
        return ((float) i) / 4.0f;
    }

    private final float getWaterAlphaByValue(float f) {
        return f == 0.0f ? 0.0f : 1.0f;
    }

    private final float normalizeValue(float f) {
        if (f < 0.0f) {
            f = 0.0f;
        }
        if (f > 1.0f) {
            f = 1.0f;
        }
        double d = (double) f;
        if (d >= 0.0d && d <= 0.01d) {
            f = 0.0f;
        }
        double d2 = (double) f;
        if (d2 > 0.01d && d2 < 0.03d) {
            f = 0.03f;
        }
        double d3 = (double) f;
        if (d3 > 0.97d && d3 < 0.99d) {
            f = 0.97f;
        }
        double d4 = (double) f;
        if (d4 < 0.99d || d4 > 1.0d) {
            return f;
        }
        return 1.0f;
    }

    private final float valFromPer(float f, float f2, float f3) {
        return ((1.0f - f) * f2) + (f * f3);
    }

    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    public GradualWaterBox(Context context) {
        super(context);
        onCreate();
    }

    public GradualWaterBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        onCreate();
    }

    public GradualWaterBox(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        onCreate();
    }

    private void onCreate() {
        setWillNotDraw(false);
        Object systemService = getContext().getSystemService("sensor");
        if (systemService != null) {
            this.mSensorManager = (SensorManager) systemService;
            this.mAccelerometer = this.mSensorManager.getDefaultSensor(1);
            checkInitVars();
        }
    }

    private void checkInitVars() {
        if (!this.varInitialized) {
            this.varInitialized = true;
            this.edgeRotAnimConfig = new AnimConfig().setEase(EaseManager.getStyle(-2, new float[]{1.0f, 0.9f}));
            this.rotAnimConfig = new AnimConfig().setEase(EaseManager.getStyle(-2, new float[]{0.2f, 1.0f}));
            this.waterAlphaAnimConfig = new AnimConfig().setEase(EaseManager.getStyle(-2, new float[]{1.0f, 1.0f}));
            this.valueAnimConfig = new AnimConfig().setEase(EaseManager.getStyle(-2, new float[]{0.9f, 1.0f}));
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        init();
    }

    private final void beginEnterAnim() {
        if (this.mIsValueSet) {
            setValue(this.mValue);
        }
    }

    private final void init() {
        if (!this.initialized) {
            this.initialized = true;
            this.mDebugPaint.setStrokeWidth(2.0f);
            this.mDebugPaint.setTextSize(40.0f);
            this.mDebugPaint.setColor(-65536);
            this.mDebugPaint.setTextAlign(Paint.Align.LEFT);
            this.mDebugPaint.setAntiAlias(true);
            this.data.setWaterAlpha(getWaterAlphaByValue(this.mValue));
            updateWaterPaintColorAndAlpha();
            this.mWaterPaint.setAntiAlias(true);
            this.realStartPoint = new PointF();
            PointF pointF = this.realStartPoint;
            pointF.x = 0.0f;
            pointF.y = ((float) getHeight()) - (((float) getHeight()) * this.data.getValue());
            this.realEndPoint = new PointF();
            this.realEndPoint.x = (float) getWidth();
            this.realEndPoint.y = ((float) getHeight()) - (((float) getHeight()) * this.data.getValue());
            for (int i = 0; i < 5; i++) {
                float pointPer = getPointPer(i);
                this.points.add(new PointF(((float) getWidth()) * pointPer, ((float) getHeight()) - (((float) getHeight()) * this.data.getValue())));
                double d = (double) pointPer;
                Double.isNaN(d);
                AnimConfig animConfig = new AnimConfig();
                Double.isNaN(d);
                this.pointAnimConfigs.add(animConfig.setEase(EaseManager.getStyle(-2, new float[]{0.8f - (((float) Math.sin(d * 3.141592653589793d)) * 0.6f), 1.0f})));
            }
            this.startPoint = new PointF();
            PointF pointF2 = this.startPoint;
            pointF2.x = 0.0f;
            pointF2.y = ((float) getHeight()) - (((float) getHeight()) * this.data.getValue());
            this.endPoint = new PointF();
            this.endPoint.x = (float) getWidth();
            this.endPoint.y = ((float) getHeight()) - (((float) getHeight()) * this.data.getValue());
        }
    }

    private final void updateWaterPaintColorAndAlpha() {
        PointF pointF = this.startPoint;
        if (pointF != null && this.endPoint != null) {
            this.mWaterPaint.setShader(new LinearGradient(pointF.x, this.startPoint.y, 0.0f, (float) getHeight(), Color.parseColor("#85B6FF"), Color.parseColor("#3FD4F4"), Shader.TileMode.CLAMP));
        }
    }

    private final void followRot() {
        final LineEndPoints lineEnd = this.getLineEnd(this.data.getValue(), this.data.getRot());
        this.realStartPoint.x = lineEnd.getStartPoint().x;
        this.realStartPoint.y = lineEnd.getStartPoint().y;
        this.realEndPoint.x = lineEnd.getEndPoint().x;
        this.realEndPoint.y = lineEnd.getEndPoint().y;
        Folme.useValue(new Object[] { this.data }).to(new Object[] { "edgeRot", this.data.getRot(), this.edgeRotAnimConfig });
        final Iterator<PointF> iterator = this.points.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final PointF pointF = iterator.next();
            final float pointPer = this.getPointPer(n);
            final AnimConfig animConfig = this.pointAnimConfigs.get(n);
            Folme.useValue(new Object[] { pointF }).to(new Object[] { "x", this.valFromPer(pointPer, this.realStartPoint.x, this.realEndPoint.x), animConfig });
            Folme.useValue(new Object[] { pointF }).to(new Object[] { "y", this.valFromPer(pointPer, this.realStartPoint.y, this.realEndPoint.y), animConfig });
            ++n;
        }
        final LineEndPoints lineEnd2 = this.getLineEnd(this.data.getValue(), this.data.getEdgeRot());
        this.startPoint.x = lineEnd2.getStartPoint().x;
        this.startPoint.y = lineEnd2.getStartPoint().y;
        this.endPoint.x = lineEnd2.getEndPoint().x;
        this.endPoint.y = lineEnd2.getEndPoint().y;
    }

    private final LineEndPoints getLineEnd(float f, float f2) {
        PointF linePoint = getLinePoint(f, f2, -1);
        PointF linePoint2 = getLinePoint(f, f2, 1);
        float f3 = f2 % 360.0f;
        if (f3 < 0.0f) {
            f3 += 360.0f;
        }
        if (f3 > 180.0f) {
            linePoint = linePoint2;
        }
        return new LineEndPoints(linePoint, linePoint2);
    }

    private final PointF getLinePoint(float f, float f2, int i) {
        PointF pointF = new PointF();
        float height = (0.5f - f) * ((float) getHeight());
        pointF.x = (((float) getWidth()) / 2.0f) + (((float) Math.cos((double) toRad(f2))) * height);
        pointF.y = (((float) getHeight()) / 2.0f) + (((float) Math.sin((double) toRad(f2))) * height);
        PointF pointF2 = new PointF();
        pointF2.x = (((float) getWidth()) / 2.0f) + (((float) (getWidth() * i)) / 2.0f);
        float f3 = f2 - ((float) (i * 90));
        pointF2.y = getLineEndFunc(pointF, f3, pointF2.x, Float.NaN).y;
        if (Math.abs(this.data.getRot()) != 90.0f) {
            pointF2.y = Math.max(pointF2.y, (((float) getHeight()) / 2.0f) - ((float) (getHeight() / 2)));
            pointF2.y = Math.min(pointF2.y, (((float) getHeight()) / 2.0f) + ((float) (getHeight() / 2)));
            pointF2.x = getLineEndFunc(pointF, f3, Float.NaN, pointF2.y).x;
        }
        return pointF2;
    }

    private final PointF getLineEndFunc(PointF pointF, float f, float f2, float f3) {
        PointF pointF2 = new PointF(pointF.x + (((float) Math.cos((double) toRad(f))) * 35.0f), pointF.y + (((float) Math.sin((double) toRad(f))) * 35.0f));
        float f4 = pointF2.y - pointF.y;
        float f5 = pointF.x - pointF2.x;
        float f6 = -((pointF2.x * pointF.y) - (pointF.x * pointF2.y));
        return new PointF((f6 - (f3 * f5)) / f4, (f6 - (f4 * f2)) / f5);
    }

    private final float toRad(float f) {
        double d = (double) f;
        Double.isNaN(d);
        Double.isNaN(d);
        Double.isNaN(180.0d);
        return (float) ((d * 3.141592653589793d) / 180.0d);
    }

    private final void onVisible() {
        this.mSensorLastChangedTime = Long.MAX_VALUE;
        registerSensorListener();
        beginEnterAnim();
    }

    private final void onInvisible() {
        unregisterSensorListener();
    }

    public final void registerSensorListener() {
        Sensor sensor = this.mAccelerometer;
        if (sensor != null && !this.mSensorRegistered) {
            SensorManager sensorManager = this.mSensorManager;
            this.mSensorRegistered = true;
            sensorManager.registerListener(this, sensor, 2);
            Log.d("Memory", "registerListener");
        }
    }

    public final void unregisterSensorListener() {
        if (this.mAccelerometer != null && this.mSensorRegistered) {
            SensorManager sensorManager = this.mSensorManager;
            this.mSensorRegistered = false;
            sensorManager.unregisterListener(this);
            Log.d("Memory", "unregisterListener");
        }
    }

    public void onDraw(Canvas canvas) {
        followRot();
        drawWater(canvas);
        if (this.mDebug) {
            drawDebug(canvas);
        }
        if (!isSensorNotChangedForAWhile()) {
            invalidate();
        } else if (this.data.value != this.finalValue || shouldInvalidate()) {
            invalidate();
        }
        super.onDraw(canvas);
    }

    private boolean shouldInvalidate() {
        for (int i = 0; i < this.points.size(); i++) {
            if (this.points.get(i).y != valFromPer(getPointPer(i), this.realStartPoint.y, this.realEndPoint.y)) {
                return true;
            }
        }
        return false;
    }

    private final void drawWater(Canvas canvas) {
        List<PointF> list;
        PointF pointF = new PointF(0.0f, 0.0f);
        PointF pointF2 = new PointF(0.0f, (float) getHeight());
        PointF pointF3 = new PointF((float) getWidth(), (float) getHeight());
        PointF pointF4 = new PointF((float) getWidth(), 0.0f);
        PointF pointF5 = this.startPoint;
        PointF pointF6 = this.endPoint;
        int edge = getEdge(pointF5);
        int edge2 = getEdge(pointF6);
        if (edge == 1 && edge2 == 1) {
            list = Arrays.asList(new PointF[]{pointF, pointF2, pointF3, pointF4});
        } else if (edge == 1 && edge2 == 2) {
            list = Arrays.asList(new PointF[]{pointF});
        } else if (edge == 1 && edge2 == 3) {
            list = Arrays.asList(new PointF[]{pointF, pointF2});
        } else if (edge == 1 && edge2 == 4) {
            list = Arrays.asList(new PointF[]{pointF, pointF2, pointF3});
        } else if (edge == 2 && edge2 == 2) {
            list = Arrays.asList(new PointF[]{pointF2, pointF3, pointF4, pointF});
        } else if (edge == 2 && edge2 == 3) {
            list = Arrays.asList(new PointF[]{pointF2});
        } else if (edge == 2 && edge2 == 4) {
            list = Arrays.asList(new PointF[]{pointF2, pointF3});
        } else if (edge == 2 && edge2 == 1) {
            list = Arrays.asList(new PointF[]{pointF2, pointF3, pointF4});
        } else if (edge == 3 && edge2 == 3) {
            list = Arrays.asList(new PointF[]{pointF2, pointF3});
        } else if (edge == 3 && edge2 == 4) {
            list = Arrays.asList(new PointF[]{pointF3});
        } else if (edge == 3 && edge2 == 1) {
            list = Arrays.asList(new PointF[]{pointF3, pointF4});
        } else if (edge == 3 && edge2 == 2) {
            list = Arrays.asList(new PointF[]{pointF3, pointF4, pointF});
        } else if (edge == 4 && edge2 == 4) {
            list = Arrays.asList(new PointF[]{pointF4, pointF, pointF2, pointF3});
        } else if (edge == 4 && edge2 == 1) {
            list = Arrays.asList(new PointF[]{pointF4});
        } else if (edge == 4 && edge2 == 2) {
            list = Arrays.asList(new PointF[]{pointF4, pointF});
        } else if (edge == 4 && edge2 == 3) {
            list = Arrays.asList(new PointF[]{pointF4, pointF, pointF2});
        } else {
            throw new IllegalStateException();
        }
        Collections.reverse(list);
        Path path = new Path();
        if (Float.isNaN(pointF6.x) || Float.isInfinite(pointF6.x)) {
            Log.w("Memory", "endP.x error");
            pointF6.x = (float) getWidth();
        }
        if (Float.isNaN(pointF5.x) || Float.isInfinite(pointF5.x)) {
            Log.w("Memory", "startP.x error");
            pointF5.x = 0.0f;
        }
        path.moveTo(pointF6.x, pointF6.y);
        for (PointF pointF7 : list) {
            path.lineTo(pointF7.x, pointF7.y);
        }
        path.lineTo(pointF5.x, pointF5.y);
        ArrayList arrayList = new ArrayList();
        arrayList.add(pointF5);
        arrayList.addAll(this.points);
        arrayList.add(pointF6);
        PointF avgPoints = avgPoints((PointF) arrayList.get(0), (PointF) arrayList.get(1));
        path.lineTo(avgPoints.x, avgPoints.y);
        int size = arrayList.size();
        for (int i = 2; i < size; i++) {
            int i2 = i - 1;
            PointF avgPoints2 = avgPoints((PointF) arrayList.get(i2), (PointF) arrayList.get(i));
            path.quadTo(((PointF) arrayList.get(i2)).x, ((PointF) arrayList.get(i2)).y, avgPoints2.x, avgPoints2.y);
        }
        path.lineTo(pointF6.x, pointF6.y);
        updateWaterPaintColorAndAlpha();
        for (int i3 = 0; i3 < this.points.size(); i3++) {
            PointF pointF8 = this.points.get(i3);
            if (pointF8.y <= 0.0f || pointF8.y >= ((float) getHeight())) {
                Log.i("Memory", "point " + i3 + " : " + this.points.get(i3).toString());
            }
        }
        canvas.drawPath(path, this.mWaterPaint);
    }

    private final PointF avgPoints(PointF pointF, PointF pointF2) {
        return new PointF((pointF.x + pointF2.x) / 2.0f, (pointF.y + pointF2.y) / 2.0f);
    }

    private final void drawDebug(Canvas canvas) {
        double value = (double) this.data.getValue();
        Double.isNaN(value);
        Double.isNaN(value);
        double abs = Math.abs(value - 0.5d);
        this.mDebugPaint.setStyle(Paint.Style.STROKE);
        double height = (double) getHeight();
        Double.isNaN(height);
        Double.isNaN(height);
        canvas.drawCircle((float) (getWidth() / 2), (float) (getHeight() / 2), (float) (height * abs), this.mDebugPaint);
        this.mDebugPaint.setStyle(Paint.Style.FILL);
        this.mDebugPaint.setColor(-16711936);
        for (PointF next : this.points) {
            canvas.drawCircle(next.x, next.y, 8.0f, this.mDebugPaint);
        }
        this.mDebugPaint.setColor(-65536);
        canvas.drawCircle(this.startPoint.x, this.startPoint.y, 8.0f, this.mDebugPaint);
        canvas.drawCircle(this.endPoint.x, this.endPoint.y, 8.0f, this.mDebugPaint);
        this.mDebugPaint.setColor(-7829368);
        canvas.drawLine(this.realStartPoint.x, this.realStartPoint.y, this.realEndPoint.x, this.realEndPoint.y, this.mDebugPaint);
        this.mDebugPaint.setColor(-65536);
        canvas.drawLine(this.startPoint.x, this.startPoint.y, this.endPoint.x, this.endPoint.y, this.mDebugPaint);
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent != null) {
            float[] fArr = sensorEvent.values;
            float[][] fArr2 = this.mAccValuesForAverage;
            int i = this.mAccValuesForAverageIndex;
            fArr2[i] = fArr;
            this.mAccValuesForAverageIndex = i + 1;
            if (this.mAccValuesForAverageIndex == 2) {
                this.mAccValuesForAverageIndex = 0;
                float[] fArr3 = new float[3];
                for (int i2 = 0; i2 < 3; i2++) {
                    for (int i3 = 0; i3 < 2; i3++) {
                        fArr3[i2] = fArr3[i2] + fArr2[i3][i2];
                    }
                }
                for (int i4 = 0; i4 < 3; i4++) {
                    fArr3[i4] = fArr3[i4] / 2.0f;
                }
                handleNewSensorAverageValue(fArr3);
            }
        }
    }

    private void handleNewSensorAverageValue(float[] fArr) {
        this.mAccValues = fArr;
        float[] fArr2 = this.mAccValues;
        float f = fArr2[2] / 10.0f;
        float angle = toAngle(-((float) Math.atan2((double) (-(fArr2[1] / 10.0f)), (double) (-(fArr[0] / 10.0f)))));
        if (angle < 0.0f) {
            angle += 360.0f;
        }
        boolean z = !isSensorNotChangedForAWhile();
        boolean isSensorAngleChanged = isSensorAngleChanged(angle);
        if (z || isSensorAngleChanged) {
            if (isSensorAngleChanged) {
                this.mSensorLastChangedTime = System.currentTimeMillis();
                this.mSensorLastAngle = angle;
            }
            rotToAngle(angle);
            Folme.useValue(new Object[]{this.data}).to(new Object[]{"effectPer", Float.valueOf(1.0f - Math.abs(f))});
            invalidate();
        }
    }

    private boolean isSensorNotChangedForAWhile() {
        return System.currentTimeMillis() - this.mSensorLastChangedTime > 2000;
    }

    private boolean isSensorAngleChanged(float f) {
        return Math.abs(this.mSensorLastAngle - f) > 9.0f;
    }

    private final void rotToAngle(float f) {
        float f2 = f - ((float) (f > 270.0f ? 450 : 90));
        if (this.data.getValue() == 1.0f) {
            this.data.setEffectPer(0.0f);
        }
        float min = Math.min(this.data.getEffectPer() * 35.0f, Math.max(this.data.getEffectPer() * -35.0f, f2)) + 90.0f;
        while (min > this.preAngle + 180.0f) {
            min -= 360.0f;
        }
        while (min < this.preAngle - 180.0f) {
            min += 360.0f;
        }
        Folme.useValue(new Object[]{this.data}).to(new Object[]{"rot", Float.valueOf(min), this.rotAnimConfig});
    }

    private final float toAngle(float f) {
        double d = (double) (f * 180.0f);
        Double.isNaN(d);
        Double.isNaN(d);
        return (float) (d / 3.141592653589793d);
    }

    public final void setValue(float f) {
        Log.i("Memory", "setValue : " + f);
        this.finalValue = f;
        this.mIsValueSet = true;
        checkInitVars();
        float normalizeValue = normalizeValue(f);
        this.mValue = normalizeValue;
        Folme.useValue(new Object[]{this.data}).to(new Object[]{"value", Float.valueOf(normalizeValue), this.valueAnimConfig});
        invalidate();
    }

    public void end() {
        Folme.end(new WaterData[]{this.data});
        if (this.points != null && !points.isEmpty()) {
            for (PointF pointF : this.points) {
                Folme.end(new PointF[]{pointF});
            }
        }
    }

    public final void setColor(int i) {
        this.mColor = i;
        updateWaterPaintColorAndAlpha();
    }

    public final void setCornerRadius(float f) {
        this.mCornerRadius = f;
    }

    private final boolean near(float f, float f2) {
        return ((double) Math.abs(f - f2)) < 5.0d;
    }

    private final int getEdge(PointF pointF) {
        if (near(pointF.x, 0.0f)) {
            return 2;
        }
        if (near(pointF.x, (float) getWidth())) {
            return 4;
        }
        return (near(pointF.y, 0.0f) || !near(pointF.y, (float) getHeight())) ? 1 : 3;
    }

    public final void setDebug(boolean z) {
        this.mDebug = z;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.mRectF = new RectF(0.0f, 0.0f, (float) i, (float) i2);
    }

    public void reset() {
        this.data = new WaterData();
        this.data.value= 0.0f;
        this.initialized = false;
        this.points.clear();
        this.pointAnimConfigs.clear();
        init();
    }



    public final class LineEndPoints {
        private final PointF endPoint;
        private final PointF startPoint;

        public final PointF component1() {
            return this.startPoint;
        }

        public final PointF component2() {
            return this.endPoint;
        }

        public int hashCode() {
            PointF pointF = this.startPoint;
            int i = 0;
            int hashCode = (pointF != null ? pointF.hashCode() : 0) * 31;
            PointF pointF2 = this.endPoint;
            if (pointF2 != null) {
                i = pointF2.hashCode();
            }
            return hashCode + i;
        }

        public String toString() {
            return "LineEndPoints(startPoint=" + this.startPoint + ", endPoint=" + this.endPoint + ")";
        }

        public LineEndPoints(PointF pointF, PointF pointF2) {
            this.startPoint = pointF;
            this.endPoint = pointF2;
        }

        public final PointF getEndPoint() {
            return this.endPoint;
        }

        public final PointF getStartPoint() {
            return this.startPoint;
        }
    }


    public final class WaterData {
        private float edgeRot = 90.0F;

        private float effectPer;

        private float rot = 90.0F;

        private float value = 1.0F;

        private float waterAlpha = 1.0F;

        public final float getEdgeRot() {
            return this.edgeRot;
        }

        public final float getEffectPer() {
            return this.effectPer;
        }

        public final float getRot() {
            return this.rot;
        }

        public final float getValue() {
            return this.value;
        }

        public final float getWaterAlpha() {
            return this.waterAlpha;
        }

        public final void setEdgeRot(float paramFloat) {
            this.edgeRot = paramFloat;
        }

        public final void setEffectPer(float paramFloat) {
            this.effectPer = paramFloat;
        }

        public final void setRot(float paramFloat) {
            this.rot = paramFloat;
        }

        public final void setValue(float paramFloat) {
            this.value = paramFloat;
        }

        public final void setWaterAlpha(float paramFloat) {
            float f = paramFloat;
            if (paramFloat < 0.0F)
                f = 0.0F; 
            this.waterAlpha = f;
        }
    }


}

