package miui.widget.waterbox;

import android.app.Activity;
import android.os.Bundle;
import android.view.SearchEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;
import com.s1243808733.waterbox.WaterBox;

public class MainActivity extends Activity {

    private WaterBox waterBox;

    private GradualWaterBox gradualWaterBox; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        waterBox = (WaterBox)findViewById(R.id.waterBox);
        waterBox.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    Toast.makeText(MainActivity.this, view.toString(), Toast.LENGTH_LONG).show();
                }
            });

        //waterBox.setPressedAnimation(false);//如果不需要按压效果
            
        gradualWaterBox=(GradualWaterBox)findViewById(R.id.gradualWaterBox);
        gradualWaterBox.setCornerRadius(30);
        gradualWaterBox.setValue(0.5f);
        gradualWaterBox.registerSensorListener();
        
        
        SeekBar seekbar=findViewById(R.id.seekBar);
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

                @Override
                public void onProgressChanged(SeekBar p1, int p2, boolean p3) {
                    waterBox.setPercent(p2);
                    gradualWaterBox.setValue((float)p2/100);
                    
                }

                @Override
                public void onStartTrackingTouch(SeekBar p1) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar p1) {

                }
            });
        

    }

    @Override
    public boolean onSearchRequested(SearchEvent searchEvent) {
        return super.onSearchRequested(searchEvent);
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onStop() {
        super.onStop();
    }





} 
