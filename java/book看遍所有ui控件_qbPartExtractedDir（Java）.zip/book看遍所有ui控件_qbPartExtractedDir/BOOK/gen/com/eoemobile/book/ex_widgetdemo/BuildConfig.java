/** Automatically generated file. DO NOT MODIFY */
package com.eoemobile.book.ex_widgetdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}