package com.example.mydrawcircleprogress;

import com.example.mydrawcircleprogress.views.MyCircleProgress;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class MainActivity extends Activity {
	private MyCircleProgress myp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		myp = (MyCircleProgress) findViewById(R.id.MyCircleProgress);
		new ProgressAnimation().execute();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	class ProgressAnimation extends AsyncTask<Void, Integer, Void> {

		@Override
		protected Void doInBackground(Void... params) {
			for (int i = 0; i < 360; i++) {
				try {
					publishProgress(i);
					Thread.sleep(250);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			myp.n = values[0];
			myp.invalidate();
			super.onProgressUpdate(values);
		}
	}

}
