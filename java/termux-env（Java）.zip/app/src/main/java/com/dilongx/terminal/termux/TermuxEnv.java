package com.dilongx.terminal.termux;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.Nullable;

import com.termux.terminal.EmulatorDebug;
import com.termux.terminal.TerminalColors;
import com.termux.terminal.TerminalSession;
import com.termux.terminal.TextStyle;
import com.termux.view.TerminalView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author DilongX
 * @version 1.0.0
 * @date 2020/8/16
 * @description null
 */
public class TermuxEnv {
    /**
     * Note that this is a symlink on the Android M preview.
     */
    @SuppressLint("SdCardPath")
    public static final String FILES_PATH = "/data/data/com.termux/files";
    public static final String PREFIX_PATH = FILES_PATH + "/usr";
    public static final String HOME_PATH = FILES_PATH + "/home";

    private int MIN_FONTSIZE;
    private static final int MAX_FONTSIZE = 256;
    private static final String FONTSIZE_KEY = "fontsize";
    private int mFontSize;

    TerminalView mTerminalView;
    Activity mContext;

    public TermuxEnv(Activity context, TerminalView terminalView) {
        this.mContext = context;
        this.mTerminalView = terminalView;
        initialize();

        checkForFontAndColors();
    }

    /**
     * If value is not in the range [min, max], set it to either min or max.
     */
    static int clamp(int value, int min, int max) {
        return Math.min(Math.max(value, min), max);
    }

    public void changeFontSize(boolean increase) {
        mFontSize += (increase ? 1 : -1) * 2;
        mFontSize = Math.max(MIN_FONTSIZE, mFontSize);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        prefs.edit().putString(FONTSIZE_KEY, Integer.toString(mFontSize)).apply();

        mTerminalView.setTextSize(mFontSize);
    }

    private void checkForFontAndColors() {
        try {
            @SuppressLint("SdCardPath") File fontFile = new File("/data/data/com.termux/files/home/.termux/font.ttf");
            @SuppressLint("SdCardPath") File colorsFile = new File("/data/data/com.termux/files/home/.termux/colors.properties");

            final Properties props = new Properties();
            if (colorsFile.isFile()) {
                try (InputStream in = new FileInputStream(colorsFile)) {
                    props.load(in);
                }
            }

            TerminalColors.COLOR_SCHEME.updateWith(props);
            TerminalSession session = getCurrentTermSession();
            if (session != null && session.getEmulator() != null) {
                session.getEmulator().mColors.reset();
            }
            updateBackgroundColor();

            final Typeface newTypeface = (fontFile.exists() && fontFile.length() > 0) ? Typeface.createFromFile(fontFile) : Typeface.MONOSPACE;
            mTerminalView.setTypeface(newTypeface);
        } catch (Exception e) {
            Log.e(EmulatorDebug.LOG_TAG, "Error in checkForFontAndColors()", e);
        }
    }

    private void updateBackgroundColor() {
        TerminalSession session = getCurrentTermSession();
        if (session != null && session.getEmulator() != null) {
            mContext.getWindow().getDecorView().setBackgroundColor(session.getEmulator().mColors.mCurrentColors[TextStyle.COLOR_INDEX_BACKGROUND]);
        }
    }

    @Nullable
    private TerminalSession getCurrentTermSession() {
        return mTerminalView.getCurrentSession();
    }

    private void initialize() {
        float dipInPixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, mContext.getResources().getDisplayMetrics());

        // This is a bit arbitrary and sub-optimal. We want to give a sensible default for minimum font size
        // to prevent invisible text due to zoom be mistake:
        MIN_FONTSIZE = (int) (4f * dipInPixels);

        // http://www.google.com/design/spec/style/typography.html#typography-line-height
        int defaultFontSize = Math.round(12 * dipInPixels);
        // Make it divisible by 2 since that is the minimal adjustment step:
        if (defaultFontSize % 2 == 1) defaultFontSize--;

        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        try {
            mFontSize = Integer.parseInt(prefs.getString(FONTSIZE_KEY, Integer.toString(defaultFontSize)));
        } catch (NumberFormatException | ClassCastException e) {
            mFontSize = defaultFontSize;
        }

        mTerminalView.setOnKeyListener(new TermuxViewClient(this));
        mFontSize = clamp(mFontSize, MIN_FONTSIZE, MAX_FONTSIZE);
        mTerminalView.setTextSize(mFontSize);

        TerminalSession session = createTermSession();
        mTerminalView.attachSession(session);
    }

    @SuppressLint("SdCardPath")
    private TerminalSession createTermSession() {
        new File(HOME_PATH).mkdirs();

        final String termEnv = "TERM=xterm-256color";
        final String homeEnv = "HOME=" + TermuxEnv.HOME_PATH;
        final String prefixEnv = "PREFIX=" + TermuxEnv.PREFIX_PATH;
        final String androidRootEnv = "ANDROID_ROOT=" + System.getenv("ANDROID_ROOT");
        final String androidDataEnv = "ANDROID_DATA=" + System.getenv("ANDROID_DATA");
        // EXTERNAL_STORAGE is needed for /system/bin/am to work on at least
        // Samsung S7 - see https://plus.google.com/110070148244138185604/posts/gp8Lk3aCGp3.
        final String externalStorageEnv = "EXTERNAL_STORAGE=" + System.getenv("EXTERNAL_STORAGE");
        final String ps1Env = "PS1=$ ";
        final String ldEnv = "LD_LIBRARY_PATH=" + TermuxEnv.PREFIX_PATH + "/lib";
        final String langEnv = "LANG=en_US.UTF-8";
        final String pathEnv = "PATH=" + TermuxEnv.PREFIX_PATH + "/bin:" + TermuxEnv.PREFIX_PATH + "/bin/applets";
        String[] env = new String[]{termEnv, homeEnv, prefixEnv, ps1Env, ldEnv, langEnv, pathEnv, androidRootEnv, androidDataEnv, externalStorageEnv};

        String executablePath = null;
        String[] args;
        String shellName = null;

        for (String shellBinary : new String[]{"login", "bash", "zsh"}) {
            File shellFile = new File(PREFIX_PATH + "/bin/" + shellBinary);
            if (shellFile.canExecute()) {
                executablePath = shellFile.getAbsolutePath();
                shellName = "-" + shellBinary;
                break;
            }
        }

        if (executablePath == null) {
            // Fall back to system shell as last resort:
            executablePath = "/system/bin/sh";
            shellName = "-sh";
        }

        args = new String[]{shellName};

        return new TerminalSession(executablePath, HOME_PATH, args, env, new TerminalSession.SessionChangedCallback() {
            @Override
            public void onTitleChanged(TerminalSession changedSession) {
                // Ignore for now.
            }

            @Override
            public void onTextChanged(TerminalSession changedSession) {
                mTerminalView.onScreenUpdated();
            }

            @Override
            public void onSessionFinished(TerminalSession finishedSession) {

            }

            @Override
            public void onClipboardText(TerminalSession pastingSession, String text) {
                ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(new ClipData(null, new String[]{"text/plain"}, new ClipData.Item(text)));
            }

            @Override
            public void onBell(TerminalSession riningSession) {
                ((Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(50);
            }

            @Override
            public void onColorsChanged(TerminalSession session) {
            }
        });
    }
}
