package com.dilongx.terminal.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.dilongx.terminal.R;
import com.dilongx.terminal.termux.TermuxEnv;
import com.termux.view.TerminalView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TerminalView terminalView = findViewById(R.id.terminal_view);
        new TermuxEnv(this, terminalView);
    }
}