package com.example.testproject;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.net.PasswordAuthentication;

import de.hdodenhof.circleimageview.CircleImageView;

public class Mian6 extends AppCompatActivity {
    ImageView image1,image2,image4,image5;
     CircleImageView image3;
    EditText edit1,edit2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main11);
        //getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        image1=findViewById(R.id.main11image2);
        image2=findViewById(R.id.main11image0);//密码显示
        image3=findViewById(R.id.main11image1);//头像
        image4=findViewById(R.id.main11image3);//清除密码
        image5=findViewById(R.id.main11image4);//清除账号
        edit1=findViewById(R.id.main11edit1);
        edit2=findViewById(R.id.main11edit2);



        edit1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    edit1.setHint("");
                }else{
                    edit1.setHint("QQ号/手机号/邮箱");
                }
            }
        });

        edit2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    edit2.setHint("");
                    image2.setVisibility(View.VISIBLE);
                    //image2.setImageResource(R.mipmap.a2);
                }else{
                    edit2.setHint("输入密码");
                    if(TextUtils.isEmpty(edit2.getText().toString())){
                        image2.setVisibility(View.INVISIBLE);
                    }else{
                        image2.setVisibility(View.VISIBLE);
                    }

                }
            }
        });


        edit1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!TextUtils.isEmpty(s)){

                    image5.setVisibility(View.VISIBLE);
                    //image3.setVisibility(View.VISIBLE);
                    if(TextUtils.equals(s,"2783335126")){

                        image3.setVisibility(View.VISIBLE);
                    }else{
                        image3.setVisibility(View.INVISIBLE);
                    }

                }else{
                    image3.setVisibility(View.INVISIBLE);
                    image5.setVisibility(View.INVISIBLE);
                }



            }

            @Override
            public void afterTextChanged(Editable s) {
                if(TextUtils.equals(s,"2783335126")){

                    image3.setVisibility(View.VISIBLE);
                }else{
                    image3.setVisibility(View.INVISIBLE);
                }
                panduan();
            }
        });


        edit2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!TextUtils.isEmpty(s)){
                    image4.setVisibility(View.VISIBLE);

                }else{
                    image4.setVisibility(View.INVISIBLE);

                }


            }

            @Override
            public void afterTextChanged(Editable s) {
                panduan();
            }
        });

        image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit2.setText("");
            }
        });
        image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit1.setText("");
            }
        });

        image2.setOnClickListener(new View.OnClickListener() {
            Boolean hide=true;
            @Override
            public void onClick(View v) {
                if(hide){
                   hide=false;
                   image2.setImageResource(R.mipmap.a1);
                   edit2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    hide=true;
                    image2.setImageResource(R.mipmap.a2);
                    edit2.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

    }
    public void panduan(){
        if(!TextUtils.isEmpty(edit1.getText().toString())&&!TextUtils.isEmpty(edit2.getText().toString())){
            image1.setBackgroundResource(R.drawable.long_button_gradient);
            AnimationDrawable animationDrawable = (AnimationDrawable) image1.getBackground();
            animationDrawable.setExitFadeDuration(2000);
            animationDrawable.start();
        }else{
            image1.setBackgroundResource(R.drawable.yuanjiao3);
        }
    }

}
