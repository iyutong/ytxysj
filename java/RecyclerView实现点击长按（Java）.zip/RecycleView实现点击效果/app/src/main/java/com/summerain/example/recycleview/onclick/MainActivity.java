package com.summerain.example.recycleview.onclick;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.v7.widget.LinearLayoutManager;
import android.widget.Toast;

public class MainActivity extends Activity 
{
	private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		mRecyclerView = findViewById(R.id.recycler_view);
		mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
		// 实例化自定义适配器
        MyAdapter myAdapter = new MyAdapter();
		// 把适配器添加到RecycleView中
		mRecyclerView.setAdapter(myAdapter);
		// 添加监听
		mRecyclerView.addOnItemTouchListener(new RecycleViewClickListener(
												 MainActivity.this,
												 mRecyclerView,
												 new RecycleViewClickListener.OnItem2ClickListener(){

													 @Override
													 public void onItemClick(View view, int position)
													 {
														 // 点击事件
														 Toast.makeText(MainActivity.this,position+"我被点击了",Toast.LENGTH_SHORT).show();
													 }

													 @Override
													 public void onItemLongClick(View view, int position)
													 {
														 // 长按事件
														 Toast.makeText(MainActivity.this,position+"被长按了",Toast.LENGTH_SHORT).show();
													 }


												 }
											 ));

    }

	class MyAdapter extends RecyclerView.Adapter
	{

        // 在适配器当中自定义内部类，其中的子对象用于呈现数据
        class Myholder extends RecyclerView.ViewHolder
		{

            TextView t;

            public Myholder(View view)
			{
                super(view);

				// 实例化自定义对象
                t = (TextView) view;

            }


        }

//        以下是系统自动生成的三个方法

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
		{

            Myholder myholder = new Myholder(new TextView(parent.getContext()));

            return myholder;
        }

        //        对控件赋值
        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position)
		{

            Myholder mm = (Myholder) holder;

            mm.t.setText("item" + position);

        }

        @Override
        public int getItemCount()
		{
            return 200;
        }

    }


}
