package com.ying.gjh;
 
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class a extends Activity
{
	EditText zha1;
	EditText ma1;
	Button bg;
	String zhahao=zha1.getText().toString();
	String mima=ma1.getText().toString();
    @Override
	public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
	    setContentView(R.layout.a); 
		bg=findViewById(R.id.dg);
		bg.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(zhahao=="wpgzs"){
				    if(mima=="wp666"){
						Toast.makeText(a.this,"登录成功",Toast.LENGTH_SHORT).show();
						Toast.makeText(a.this,"正在进入中，请稍候",Toast.LENGTH_SHORT).show();
					}else{
						Toast.makeText(a.this,"密码错误",Toast.LENGTH_SHORT).show();
					}}
					else{
						Toast.makeText(a.this,"账号不存在或密码不匹配此账号",Toast.LENGTH_SHORT).show();
					}
					
					}
			});
		
	}
}
