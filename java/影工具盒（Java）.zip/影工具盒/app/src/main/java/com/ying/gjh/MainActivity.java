package com.ying.gjh;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.*;

public class MainActivity extends Activity {
	
Button but;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		but=findViewById(R.id.but);
		but.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent a=new Intent();
					a.setClass(MainActivity.this,a.class);
					startActivity(a);
				}
			});
    }
    
}
