import java.util.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import java.io.IOException;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Main {
	
	public static void main(String[] args) {
        try {
            Document doc = Jsoup.connect("https://h5.qzone.qq.com/ugc/share/7FEEFF7D562C2C2AF81623FFBCCA3E74?uw=3522592468&ticket=&subtype=0&srctype=62&sid=&blog_photo=0&appid=311&ciphertext=7FEEFF7D562C2C2AF81623FFBCCA3E74&g_f=5758&_wv=1")//qq空间的动态连接
                .data("query", "Java")//请求参数  
                .userAgent("Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)")//设置urer-agent  get();
                .timeout(5000)
                .get();
            //账号
            Elements datas = doc.select("span");
            String data = datas.attr("data-params");
            //名字
            Elements usernames = doc.getElementsByClass("username");
            Document username = Jsoup.parse(usernames.get(0).toString());
            //内容
            Elements txts = doc.getElementsByClass("txt");
            Document txt = Jsoup.parse(txts.get(2).toString());
            //时间
            Elements times = doc.getElementsByClass("time");
            Document time = Jsoup.parse(times.get(0).toString());
            
            System.out.println(SpecialStringTFM("帖子账号:"+data+"\n"+
                               "帖子名字:"+username.text()+"\n"+
                               "帖子内容:"+txt.text()+"\n"+
                               "帖子时间:"+time.text()+"\n"+
                               "帖子标题:"+doc.title()));
            
        } catch (IOException e) {}
		
        
        
    }
    
    private static String SpecialStringTFM(String msgs) {
        if (msgs.contains("{br}")) {
            Matcher m = Pattern.compile("\\{br\\}").matcher(msgs);
            while (m.find()) {
                msgs = msgs.replace(m.group(), "\n");
            }
        }
        
        if (msgs.contains("{sp}")) {
            Matcher m = Pattern.compile("\\{sp\\}").matcher(msgs);
            while (m.find()) {
                msgs = msgs.replace(m.group(), "\t");
            }
        }
        return msgs;
    }
    
}
