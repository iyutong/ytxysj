package com.s1243808733.waterbox;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import com.s1243808733.waterbox.BaseWaterBox;
import com.s1243808733.waterbox.animation.Folme;
import com.s1243808733.waterbox.animation.IFolme;
import com.s1243808733.waterbox.animation.base.AnimConfig;

public class WaterBox extends BaseWaterBox {

    public WaterBox(Context context) {
        this(context, null);
    }

    public WaterBox(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a=context.obtainStyledAttributes(attrs, R.styleable.WaterBox);

        if (!a.hasValue(R.styleable.WaterBox_android_background)) {
            final TypedArray aa = getContext().obtainStyledAttributes(new int[]{android.R.attr.colorBackground});
            final int themeColorBackground = aa.getColor(0, 0);
            aa.recycle();

            // If the theme colorBackground is light, use our own light color, otherwise dark
            final float[] hsv = new float[3];
            Color.colorToHSV(themeColorBackground, hsv);
            int backgroundColor = (hsv[2] > 0.5f
                ? getResources().getColor(R.color.water_box_light_background)
                : getResources().getColor(R.color.water_box_dark_background));

            setBackgroundColor(backgroundColor);
        }

        setColor(a.getColor(R.styleable.WaterBox_color, getResources().getColor(R.color.water_box_color)));

        setCornerRadius(a.getDimensionPixelSize(R.styleable.WaterBox_radius, getResources().getDimensionPixelSize(R.dimen.water_box_radius)));

        setPercent(a.getInt(R.styleable.WaterBox_value, 0));

        setPressedAnimation(a.getBoolean(R.styleable.WaterBox_pressedAnimation, getResources().getBoolean(R.bool.water_box_pressed_animation)));

        a.recycle();

        setDebug(false);

    }

    public void setPressedAnimation(boolean pressedAnimation) {
        IFolme useAt = Folme.useAt(new View[]{this});
        if (pressedAnimation) {
            useAt.touch().handleTouchOf(this, new AnimConfig[0]);
        } else {
            useAt.touch().ignoreTouchOf(this);
        }
    }

    public void setPercent(int progress) {
        if (progress < 0) {
            progress = 0;
        } else if (progress > 100) {
            progress = 100;
        }
        setValue((float)progress / 100);
    }

    @Override
    public void setColor(int color) {
        super.setColor(color);
    }

    @Override
    public void setCornerRadius(float radius) {
        super.setCornerRadius(radius);
    }

    @Override
    public void setBackgroundColor(int color) {
        super.setBackgroundColor(color);
    }

    @Override
    public void setValue(float progress) {
        super.setValue(progress);
    }

}

