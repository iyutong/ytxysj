/** Automatically generated file. DO NOT MODIFY */
package com.hrw.android.player;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}