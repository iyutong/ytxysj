package com.xiaoheng.xialasuaxin;

import android.app.*;
import android.os.*;
import android.support.v4.widget.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private TextView text;
	private SwipeRefreshLayout sw;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaohenglayout);
		
		text=(TextView)findViewById(R.id.xiaohenglayoutTextView1);

		sw=(SwipeRefreshLayout)findViewById(R.id.xiaohenglayoutSwipeRefreshLayout1);

		sw.setColorSchemeResources(android.R.color.holo_blue_light,android.R.color.holo_red_light,android.R.color.holo_green_light);
		
		sw.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener()
			{
				@Override
				public void onRefresh()
				{
					// TODO: Implement this method

					text.setText("正在刷新");

					new Handler().postDelayed(new Runnable(){

							@Override
							public void run()
							{
								// TODO: Implement this method

								text.setText("刷新完成");
								sw.setRefreshing(false);
								Toast.makeText(MainActivity.this,"刷新成功",Toast.LENGTH_SHORT).show();
								
							}
						},3000);


				}
			});
		
		
    }
}



    /****************************************
	 *      2017.9.17                       *
	 *                                      *
	 *      微信号：heng1919196455           *
	 *      小亨QQ：1919196455               *
	 *      QQ群聊：234257176                *
	 *                                      *
	 ****************************************/
