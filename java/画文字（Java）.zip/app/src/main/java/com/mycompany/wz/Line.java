package com.mycompany.wz;

public class Line
{
	private Float s_X;
	private Float s_Y;
	private Float e_X;
	private Float e_Y;
	Line(Float s_X,Float s_Y,Float e_X,Float e_Y){
		this.s_X=s_X;
		this.s_Y=s_Y;
		this.e_X=e_X;
		this.e_Y=e_Y;
	}
	float gets_X(){
		return s_X;
	}
	float gets_Y(){
		return s_Y;
	}
	float gete_X(){
		return e_X;
	}
	float gete_Y(){
		return e_Y;
	}
}
