package com.mycompany.wz;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity 
{
	private TextView tvStart;
	private TextView tvShow;
	private TextView tvEnd;
	private LinearLayout touch;
	private ImageView iv_canvas;
	private Bitmap baseBitmap;
	private Canvas canvas;
	private Paint paint;
	private Button clean;
	private Button copy;
	private List<Line> list;
	private Handler mHandler;
	private Message msg;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		/*
		by 城岚
		如若有bug请联系
		QQ2695035910
		*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		tvStart = findViewById(R.id.start);
		tvShow = findViewById(R.id.show);
		tvEnd = findViewById(R.id.end);
		touch = findViewById(R.id.touch);
		iv_canvas = findViewById(R.id.iv_canvas);
		clean = findViewById(R.id.clean);
		copy = findViewById(R.id.copy);
		paint = new Paint();
		paint.setStrokeWidth(5);
		paint.setColor(Color.RED);
		list = new ArrayList<>();
	    mHandler = new Handler() {  
			@Override  
			public void handleMessage(Message msg)
			{  
				//操作界面  
				switch (msg.what)
				{
					case 0:
						touch.setVisibility(View.VISIBLE);
						break;
						case 1:
						iv_canvas.setImageBitmap(baseBitmap);
						break;
				}	
				super.handleMessage(msg);  
			}  
		};
		touch.setOnTouchListener(new View.OnTouchListener() {
				float startX ;
				float startY ;
				@Override
				public boolean onTouch(View v, MotionEvent event)
				{

					switch (event.getAction())
					{
							/**
							 * 点击的开始位置
							 */
						case MotionEvent.ACTION_DOWN:
							// 第一次绘图初始化内存图片，指定背景为白色
							if (baseBitmap == null)
							{
								baseBitmap = Bitmap.createBitmap(iv_canvas.getWidth(),
																 iv_canvas.getHeight(), Bitmap.Config.ARGB_8888);
								canvas = new Canvas(baseBitmap);
								//	canvas.drawColor(Color.WHITE);
								// 记录开始触摸的点的坐标

							}
							startX = event.getX();
							startY = event.getY();
							tvStart.setText("起始位置：(" + event.getX() + "," + event.getY());
							break;
							/**
							 * 触屏实时位置
							 */
						case MotionEvent.ACTION_MOVE:
							tvShow.setText("实时位置：(" + event.getX() + "," + event.getY());
							// 记录移动位置的点的坐标
							float stopX = event.getX();
							float stopY = event.getY();

							//根据两点坐标，绘制连线
							canvas.drawLine(startX, startY, stopX, stopY, paint);

							//将线储存起来
							list.add(new Line(startX, startY, stopX, stopY));

							// 更新开始点的位置
							startX = event.getX();
							startY = event.getY();

							// 把图片展示到ImageView中
							iv_canvas.setImageBitmap(baseBitmap);
							break;
							/**
							 * 离开屏幕的位置
							 */
						case MotionEvent.ACTION_UP:
							tvEnd.setText("结束位置：(" + event.getX() + "," + event.getY());


							break;
						default:
							break;
					}
					/**
					 *  注意返回值
					 *  true：view继续响应Touch操作；
					 *  false：view不再响应Touch操作，故此处若为false，只能显示起始位置，不能显示实时位置和结束位置
					 */
					return true;
				}
			});
		clean.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					clean();		
					list.clear();
				}
			});
		copy.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if (list.size() == 0)
					{
						Toast.makeText(MainActivity.this, "还没有画图呢", 0).show();
					}
					else
					{
						touch.setVisibility(View.GONE);
						clean();
						MyThread t=new MyThread();
						t.start();

					}
				}
			});
	}
	private void clean()
	{
		// 手动清除画板的绘图，重新创建一个画板
		if (baseBitmap != null)
		{
			baseBitmap = Bitmap.createBitmap(iv_canvas.getWidth(),
											 iv_canvas.getHeight(), Bitmap.Config.ARGB_8888);
			canvas = new Canvas(baseBitmap);

			iv_canvas.setImageBitmap(baseBitmap);

		}
	}
	public class MyThread extends Thread
	{  
		public void run()
		{
			for (int i = 0 ; i < list.size() ; i++) 
			{
				Line l = list.get(i);
				canvas.drawLine(l.gets_X(), l.gets_Y(), l.gete_X(), l.gete_Y(), paint);
				try
				{
					Thread.sleep(80);
				}
				catch (InterruptedException e)
				{}
				msg = new Message();  
				msg.what = 1;
				mHandler.sendMessage(msg);//向Handler发送消息，
			}
			msg.what = 0;
			mHandler.sendMessage(msg);//向Handler发送消息，
		}}

}

