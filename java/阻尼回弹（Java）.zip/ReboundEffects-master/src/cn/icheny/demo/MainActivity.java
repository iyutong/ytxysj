package cn.icheny.demo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Demo
 * @author www.icheny.cn
 * @date 2016-12-23
 */
public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}
