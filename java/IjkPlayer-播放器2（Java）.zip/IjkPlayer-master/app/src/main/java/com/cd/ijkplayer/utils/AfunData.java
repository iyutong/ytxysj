package com.cd.ijkplayer.utils;

/**
 * Created by long on 2016/12/22.
 */

public class AfunData {

    /**
     * c : 0,16777215,1,25,196050,1364468342
     * m : 。。。。。。。。。。。。。。。。。。。。。。
     */

    private String c;
    private String m;

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }
}
