<?php
function Test(){
echo "Hello World!";
}
Test();
?>