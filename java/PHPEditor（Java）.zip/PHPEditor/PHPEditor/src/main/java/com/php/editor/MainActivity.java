package com.php.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.hz.android.fileselector.FileExtendFilter;
import com.hz.android.fileselector.FileSelectorView;
import com.php.editor.util.Func;
import com.php.editor.widget.CodePane;
import com.php.editor.widget.PreformEdit;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import android.view.View.OnClickListener;
import android.view.View;

public class MainActivity extends Activity 
{
	private File strFile = Environment.getExternalStorageDirectory();
	private final String editorPath = strFile.getAbsolutePath() + "/PHPEditor";
	private PreformEdit preformEdit;
	private FileSelectorView fsv;
	private CodePane codePane;
	private LinearLayout ps_bar;
	private String currentPath = editorPath + "/new.php";
	private SharedPreferences sp;
	private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		codePane = findViewById(R.id.codePane);
		ps_bar = findViewById(R.id.ps_bar);
        //String source = "function a(){\n}";
        preformEdit = new PreformEdit(codePane.getCodeText());
        //preformEdit.setDefaultText(source);
		init();

		sp = getSharedPreferences("path", MODE_PRIVATE);
		if (!sp.contains("path"))
		{
			editor = sp.edit();
			editor.putString("path", currentPath);
			editor.commit();
        }
		try
		{
			currentPath = sp.getString("path", currentPath);
			preformEdit.setDefaultText(new String(read(currentPath)));
			File newFile = new File(currentPath);
			getActionBar().setSubtitle(newFile.getName());
			if (!newFile.getParent().equals(editorPath))
			{
				getActionBar().setTitle(newFile.getParentFile().getName());
				Toast.makeText(this, "打开工程: " + newFile.getParentFile().getName(), Toast.LENGTH_SHORT).show();
			}
		}
		catch (Exception e)
		{
			File newFile = new File(editorPath + "/new.php");
			preformEdit.setDefaultText(new String(read(newFile.getAbsolutePath())));
			getActionBar().setSubtitle(newFile.getName());
			getActionBar().setTitle("PHPEditor");
		}
		
		addButton();
    }

	private void init()
	{
		if (!Func.isFolderExists(editorPath))
		{
			new File(editorPath).mkdir();
			Func.WriteTxt(editorPath + "/new.php", Func.readAssets(this, "new.php"));
		}
		if (!Func.isFolderExists(editorPath + "/new.php"))
		{
			Func.WriteTxt(editorPath + "/new.php", Func.readAssets(this, "new.php"));
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.undo:
				preformEdit.undo();
				break;
			case R.id.redo:
				preformEdit.redo();
				break;
			case R.id.open:
				showFileDialog();
				break;
			case R.id.save:
				save(currentPath);
				Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
				break;
			case R.id.run:
				run();
				break;
			case R.id.project:
				createProject();
				break;
			case R.id.file:
				createFile();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void showFileDialog()
	{
		fsv = new FileSelectorView(this);
		fsv.setCurrentDirectory(new File(currentPath).getParentFile());
		fsv.setFileFilter(new FileExtendFilter(Arrays.asList("php"))); // 设置过滤规则
        //fsv.setFileFilter(new FileContainsFieldsFilter(Arrays.asList("php")));

		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("选择文件");
		dialog.setCancelable(false);
		dialog.setView(fsv);
		dialog.setPositiveButton("取消", null);
		final AlertDialog ad = dialog.create();
		ad.show();
		fsv.setOnFileSelectedListener(new FileSelectorView.OnFileSelectedListener(){
				@Override
				public void onSelected(File selectedFile)
				{
					String path = selectedFile.getAbsolutePath();
					String txt = new String(read(path));
					preformEdit.setDefaultText(txt);
					ad.dismiss();
					currentPath = path;
					File f1 = new File(currentPath);
					getActionBar().setSubtitle(f1.getName());
					editor = sp.edit();
					editor.putString("path", currentPath);
					editor.commit();
					if (!f1.getParent().equals(editorPath))
					{
						getActionBar().setTitle(f1.getParentFile().getName());
						Toast.makeText(MainActivity.this, "打开工程: " + f1.getParentFile().getName(), Toast.LENGTH_SHORT).show();
					}
					else
					{
						getActionBar().setTitle("PHPEditor");
					}
				}
				@Override
				public void onFilePathChanged(File file)
				{
				}
			});
	}

	private byte[] read(String str)
	{
        byte[] buffer = null;
        if (!new File(str).exists())
		{
            return null;
        }
        try
		{
            FileInputStream fin = new FileInputStream(str);
            buffer = new byte[fin.available()];
            fin.read(buffer);
            fin.close();
            return buffer;
        }
		catch (Exception e)
		{
            e.printStackTrace();
            return buffer;
        }
    }

	@Override
	protected void onStop()
	{
		save(currentPath);
		super.onStop();
	}

	private void save(String path)
	{
		Func.WriteTxt(path, codePane.getText().toString());
	}

	private void createProject()
	{
		final EditText ed = new EditText(this);
		ed.setHint("输入工程名");
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("创建工程");
		dialog.setCancelable(false);
		dialog.setView(ed);
		dialog.setPositiveButton("确定", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					String projectPath = editorPath + File.separator + ed.getText().toString();
					new File(projectPath).mkdir();
					String newPath = projectPath + "/index.php";
					Func.WriteTxt(newPath, Func.readAssets(MainActivity.this, "index.php"));
					String txt = new String(read(newPath));
					preformEdit.setDefaultText(txt);
					currentPath = newPath;
					File f2 = new File(currentPath);
					getActionBar().setSubtitle(f2.getName());
					getActionBar().setTitle(f2.getParentFile().getName());
					editor = sp.edit();
					editor.putString("path", currentPath);
					editor.commit();
				}
			});
		dialog.setNegativeButton("取消", null);
		final AlertDialog ad = dialog.create();
		ad.show();
	}
	private void createFile()
	{
		final EditText ed2 = new EditText(this);
		ed2.setHint("输入文件名");
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("新建文件");
		dialog.setCancelable(false);
		dialog.setView(ed2);
		dialog.setPositiveButton(".php", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					String newPath = new File(currentPath).getParentFile().getAbsolutePath();
					newPath = newPath + File.separator + ed2.getText().toString() + ".php";
					Func.WriteTxt(newPath, "//新建文件");
					String txt = new String(read(newPath));
					preformEdit.setDefaultText(txt);
					currentPath = newPath;
					File f3 = new File(currentPath);
					getActionBar().setSubtitle(f3.getName());
					editor = sp.edit();
					editor.putString("path", currentPath);
					editor.commit();
				}
			});
		dialog.setNegativeButton("取消", null);
		final AlertDialog ad = dialog.create();
		ad.show();
	}

	private void run()
	{
		if (Func.isAppInstalled(this, "ru.kslabs.ksweb"))
		{
			PackageManager packageManager = getPackageManager();
			String packageName = "ru.kslabs.ksweb";
			Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(packageName);
			startActivity(launchIntentForPackage);
		}else{
			new AlertDialog.Builder(this)
			.setTitle("您未安装ksweb")
			.setMessage("运行需要ksweb的支持，您是否下载？")
				.setPositiveButton("下载", new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						Func.openUrl(MainActivity.this,"https://pan.baidu.com/s/1W5EAQnfVeLeddswx-EohrQ");
					}
				})
			.setNegativeButton("取消",null)
			.create().show();
		}
	}
	
	private TextView newButton(final String text){
		StateListDrawable sd = new StateListDrawable();
		sd.addState(new int[]{android.R.attr.state_pressed},new ColorDrawable(0x60000000));
		sd.addState(new int[]{0},new ColorDrawable(0x00ffffff));
		TextView btn = new TextView(this);
		btn.setText(text);
		btn.setTextSize(20);
		int pd = (int)btn.getTextSize()/2;
		btn.setPadding(pd,pd/2,pd,pd/4);
		btn.setBackgroundDrawable(sd);
		btn.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					switch(text){
						case "func":
							insert("function (){}");
							int index3 = codePane.getSelectionStart();
							codePane.setSelectionStart(index3-1);
							break;
						case "class":
							insert("class T{}");
							int index4 = codePane.getSelectionStart();
							codePane.setSelectionStart(index4-1);
							break;
						case "(":
							insert("()");
							int index = codePane.getSelectionStart();
							codePane.setSelectionStart(index-1);
							break;
						case "{":
							insert("{}");
							int index2 = codePane.getSelectionStart();
							codePane.setSelectionStart(index2-1);
							break;
						default:
						insert(text);
						break;
					}
				}
			});
		return btn;
	}
	private void addButton(){
		String[] ps={"func","class","(",")","{","}","\"",".",",","$",";","=","_","+","-","/","*","\\","%","#","^","?","&","|","<",">","~","'"};
		for(int i=0;i<ps.length;i++){
			ps_bar.addView(newButton(ps[i]));
		}
	}
	private void insert(String text){
		int index = codePane.getSelectionStart();
		Editable editable = codePane.getText();
		editable.insert(index,text);
	}
}
