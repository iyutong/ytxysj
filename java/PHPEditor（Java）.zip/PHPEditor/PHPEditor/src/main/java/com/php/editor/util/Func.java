package com.php.editor.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Func
{
	//读取Assets文本
	public static String readAssets(Context context, String fileName) {
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer, "utf-8");
			return text;
        }
		catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
	//文件是否存在
	public static boolean isFolderExists(String strFolder)
    {
        File file = new File(strFolder);

        if (!file.exists())
        {
             return false;
        }else{
        return true;
		}
    }
	//写入文本
	public static boolean WriteTxt(String path, String txt)
	{
		byte[] sourceByte = txt.getBytes();
		if (null != sourceByte)
		{
			try
			{
				File file = new File(path);	
				if (!file.exists())
				{	
					File dir = new File(file.getParent());
					dir.mkdirs();
					file.createNewFile();
				}
				FileOutputStream outStream = new FileOutputStream(file);
				outStream.write(sourceByte);
				outStream.close();	
				return true;
			}
			catch (Exception e)
			{
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	public static boolean isAppInstalled(Context context,String packagename)
	{
		PackageInfo packageInfo;        
		try {
            packageInfo = context.getPackageManager().getPackageInfo(packagename, 0);
		}catch (Exception e) {
            packageInfo = null;
            e.printStackTrace();
		}
		if(packageInfo ==null){
            //System.out.println("没有安装");
            return false;
		}else{
            //System.out.println("已经安装");
            return true;
        }
	}
	public static void openUrl(Context context,String url){
		Intent intent = new Intent();        
		intent.setAction("android.intent.action.VIEW");    
		Uri urls = Uri.parse(url);   
		intent.setData(urls);  
		context.startActivity(intent);
	}
}
