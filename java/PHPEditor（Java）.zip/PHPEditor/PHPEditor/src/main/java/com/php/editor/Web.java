package com.php.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ProgressBar;

public class Web extends Activity
{
	private WebView wv;
	private ProgressBar mProgressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web);
		wv = findViewById(R.id.wv);
		mProgressBar = findViewById(R.id.pb);
		setProgressBarColor("#000000");

		WebSettings webSettings = wv.getSettings();
        webSettings.setJavaScriptEnabled(true);
		webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setUseWideViewPort(true); 
        webSettings.setAllowFileAccess(true); 
        webSettings.setDomStorageEnabled(true);
        webSettings.setPluginState(WebSettings.PluginState.ON);
        webSettings.setSupportZoom(true); 
		webSettings.setBuiltInZoomControls(true);
		webSettings.setDisplayZoomControls(false);
        webSettings.setLoadWithOverviewMode(true);
		webSettings.setAppCacheEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); 
		webSettings.setBlockNetworkImage(false);
		webSettings.setLoadsImagesAutomatically(true);
		webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

		try
		{
			Intent intent = getIntent();  
			Uri uri=intent.getData();  
			if (uri != null)
			{  
				String url = intent.getDataString();
				wv.loadUrl(url);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		wv.setWebViewClient(new WebViewClient(){
				@Override
                public boolean  shouldOverrideUrlLoading(WebView v,String url){
                    if (!url.startsWith("http")) {
						toIntent(url);
                        return true;
                    }
					return super.shouldOverrideUrlLoading(v,url);
                }
            });
		wv.setWebChromeClient(new WebChromeClient(){
			@Override
				public void onProgressChanged(WebView v,int p){
					mProgressBar.setProgress(p);
					if(p==100){
						mProgressBar.setVisibility(View.GONE);
					}else{
						mProgressBar.setVisibility(View.VISIBLE);
					}
				}
				@Override
				public void onReceivedTitle(WebView view,String title){
					setTitle(title);
				}
			});
			
		getActionBar().setDisplayHomeAsUpEnabled(true);
	}


	public void toIntent(String url)
	{
        try
		{
			//Toast.makeText(activity,"尝试打开外部应用",500).show();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        }
		catch (Exception e)
		{
            //Toast.makeText(activity,"您还未安装客户端",1000).show();
        }
    }

	public void setProgressBarColor(String color)
	{
		mProgressBar.getProgressDrawable().setColorFilter(
			new PorterDuffColorFilter(Color.parseColor(color), PorterDuff.Mode.SRC_ATOP));
	}

	private int dip2px(float dpValue)
	{  
        final float scale = getResources().getDisplayMetrics().density;  
        return (int) (dpValue * scale + 0.5f);  
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add("访问").setIcon(R.drawable.add).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getTitle().toString()){
			case "访问":
				add();
				break;
		}
		return super.onOptionsItemSelected(item);
	}  
	private void add()
	{
		final EditText ed = new EditText(this);
		ed.setText(wv.getUrl());
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("访问");
		dialog.setCancelable(false);
		dialog.setView(ed);
		dialog.setPositiveButton("访问", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					wv.loadUrl(ed.getText().toString());
				}
			});
		dialog.setNegativeButton("取消", null);
		final AlertDialog ad = dialog.create();
		ad.show();
	}
	
}
