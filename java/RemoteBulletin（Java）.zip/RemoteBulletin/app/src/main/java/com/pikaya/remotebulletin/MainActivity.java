package com.pikaya.remotebulletin;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.regex.*;
public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		String url="https://share.weiyun.com/8e0bf64243564d204a7eeb4756db2088";
		myThread T1 = new myThread("one",url);
		T1.start();
		
		
		
		}

	
}

class set{
	private String gg;
set(String s){
gg=s;
TextView textView = (TextView)findViewById(R.id.txt1);
	textView.setText(gg);
	}
	
	
}

class myThread extends Thread{
	private String threadName;
	private String url;
	private Thread t;
	myThread(String name,String u){
		threadName=name;
		url=u;
	}
	public void run() {
		try {
			while(true){
				Thread.sleep(60000);
				Webpage page=new Webpage();
				page.setPageUrl(url);
				String code=page.getPageSourceWithoutHtml();
				set set=new set(code);
				
				}
		}catch (Exception e) {
			System.out.println("Thread " +  threadName + " interrupted.");
		}
		System.out.println("Thread " +  threadName + " exiting.");
	}
	public void start () {
		if (t == null) {
			t = new Thread (this,threadName);
			t.start ();
		}
	}


}


	
	/**
	 * @author winddack
	 *
	 */
	 class Webpage {
		private String pageUrl;//定义需要操作的网页地址
		private String pageEncode="UTF8";//定义需要操作的网页的编码
		public String getPageUrl() {
			return pageUrl;
		}
		public void setPageUrl(String pageUrl) {
			this.pageUrl = pageUrl;
		}
		public String getPageEncode() {
			return pageEncode;
		}
		public void setPageEncode(String pageEncode) {
			this.pageEncode = pageEncode;
		}
		//定义取源码的方法
		public String getPageSource()
		{
			StringBuffer sb = new StringBuffer();
			try {
				//构建一URL对象
				URL url = new URL(pageUrl);
				//使用openStream得到一输入流并由此构造一个BufferedReader对象
				BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), pageEncode));
				String line;
				//读取www资源
				while ((line = in.readLine()) != null)
				{
					sb.append(line);
				}
				in.close();
			}
			catch (Exception ex)
			{
				System.err.println(ex);
			}
			return sb.toString();
		}
		//定义一个把HTML标签删除过的源码的方法
		public String getPageSourceWithoutHtml()
		{
			final String regEx_script = "<script[^>]*?>[\\s\\S]*?<\\/script>"; // 定义script的正则表达式
			final String regEx_style = "<style[^>]*?>[\\s\\S]*?<\\/style>"; // 定义style的正则表达式
			final String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式
			final String regEx_space = "\\s*|\t|\r|\n";//定义空格回车换行符
			String htmlStr = getPageSource();//获取未处理过的源码
			Pattern p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);
			Matcher m_script = p_script.matcher(htmlStr);
			htmlStr = m_script.replaceAll(""); // 过滤script标签
			Pattern p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);
			Matcher m_style = p_style.matcher(htmlStr);
			htmlStr = m_style.replaceAll(""); // 过滤style标签
			Pattern p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
			Matcher m_html = p_html.matcher(htmlStr);
			htmlStr = m_html.replaceAll(""); // 过滤html标签
			Pattern p_space = Pattern.compile(regEx_space, Pattern.CASE_INSENSITIVE);
			Matcher m_space = p_space.matcher(htmlStr);
			htmlStr = m_space.replaceAll(""); // 过滤空格回车标签
			htmlStr = htmlStr.trim(); // 返回文本字符串
			htmlStr = htmlStr.replaceAll(" ", "");
			htmlStr = htmlStr.substring(0, htmlStr.indexOf("。")+1);
			return htmlStr;
		}
	}
