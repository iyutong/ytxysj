package com.looper.catchcrashlogtool;

/**
 * Created by looper on 2016/7/27.
 */
public interface HookHandler {
    public void hookHandler();
}
