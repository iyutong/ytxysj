package com.biliman.app;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.biliman.app.adapter.NewsAdapter;
import com.biliman.app.model.News;
import com.biliman.app.utils.HttpUtils;
import com.biliman.app.*;
import android.widget.*;
import android.graphics.*;
import java.util.*;

public class MainActivity extends Activity implements OnItemClickListener{
	
	
	
	private ListView lvNews;
	private NewsAdapter adapter;
	private List<News> newsList;
	
	//此处需要修改为自己的服务器地址：也就是具体的服务器地址:这里不要写你的localhost或者127.0.0.1因为这是要在手机上运行的！
	public static final String GET_NEWS_URL = "http://94.191.47.108/NewsDemo/getNewsJSON.php";
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		getActionBar().hide();
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		TextView a=(TextView)findViewById(R.id.bxtima);
		a.setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(),"UKIJKu.ttf"));
		
		
		lvNews = (ListView) findViewById(R.id.lvNews); //一条一条的消息展示消息
		newsList = new ArrayList<News>(); //初始化
		adapter = new NewsAdapter(this, newsList); //也是初始化，会在后期执行getNewsJSON()方法之后更新

		lvNews.setAdapter(adapter); //设置构造器
		lvNews.setOnItemClickListener(this);

		//这里执行了网络的的请求操作
		HttpUtils.getNewsJSON(GET_NEWS_URL, getNewsHandler);  //传入的一个handler对象
	}

	// 这里是访问网络数据的时候，返回的handler
	private Handler getNewsHandler = new Handler(){

		/**
		 * 这个方法是Handler自带的方法，用于接受返回的数据
		 */
		public void handleMessage(android.os.Message msg) {
			String jsonData = (String) msg.obj;
			System.out.println(jsonData);
			try {

				//下边是解析json
				JSONArray jsonArray = new JSONArray(jsonData);
				for (int i=0;i<jsonArray.length();i++){
					JSONObject object = jsonArray.getJSONObject(i);
					String title = object.getString("title");
					String desc = object.getString("desc");
					String time = object.getString("time");
					String content_url = object.getString("content_url");
					String pic_url = object.getString("pic_url");
					newsList.add(new News(title, desc, time, content_url, pic_url));
				}
				adapter.notifyDataSetChanged();//通知适配器数据发生变化
			} catch (Exception e) {
				e.printStackTrace();
			}
		};
	};

	/**
	 * 每一个条目的点击事件
	 */
	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long arg3) {

		//获取被点击的对象
		News news = newsList.get(position); 
		Intent intent = new Intent(this, BrowseNewsActivity.class);
		intent.putExtra("content_url", news.getContent_url()); //根据被点击的对象，获取其url
		startActivity(intent);
	}

	}
		
		
		
	
