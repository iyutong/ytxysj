package com.biliman.app;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.widget.*;
import com.biliman.app.*;
import java.util.*;

/**
 * 这里是每一个具体消息的展示
 * 
 * @author xuliugen
 * 
 */
public class baxbat extends Activity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		
		ListView mainListView=(ListView)findViewById(R.id.lvNews);
		String[]planets=new String[]{ "I love you Full And Otmix"};
		final ArrayList<String>Listitem=new ArrayList<String>();
		Listitem.addAll(Arrays.asList(planets));
		ArrayAdapter<String> mazmun1=new ArrayAdapter<String>(this, R.layout.kur);

		mazmun1.add("ئۇيغۇر");
		mazmun1.add("Uyghur");
		mainListView.setAdapter(mazmun1);
		
		
		
		
		}}
