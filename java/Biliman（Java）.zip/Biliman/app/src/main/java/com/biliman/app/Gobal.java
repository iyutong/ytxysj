package com.biliman.app;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;

public class Gobal {
    static Typeface mTypeface = null;

    public static Typeface getUyTypeface(Context context) {
        if (mTypeface == null) {
            mTypeface = Typeface.createFromAsset(context.getAssets(), "UKIJKu.ttf");
        }
        return mTypeface;
    }
}
