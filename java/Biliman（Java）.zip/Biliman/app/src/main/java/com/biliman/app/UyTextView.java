package com.biliman.app;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;
import com.biliman.app.Gobal;


public class UyTextView
extends TextView {
    public UyTextView(Context context) {
        super(context);
        this.loadTypeFace(context);
    }

    public UyTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.loadTypeFace(context);
    }

    public UyTextView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.loadTypeFace(context);
    }

    private void loadTypeFace(Context context) {
        this.setTypeface(Gobal.getUyTypeface(context));
    }

}
