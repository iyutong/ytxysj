package xiaoheng.toolbarfanhui;

import android.graphics.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
				
				
				Toolbar toolbar = (Toolbar) findViewById(R.id.listtextviewToolbar1);
				//设置toolbar颜色
				toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
				//添加toolbar
				setSupportActionBar(toolbar);
				//toolbar添加返回按钮
				getSupportActionBar().setDisplayHomeAsUpEnabled(true);
				//返回按钮点击事件
				toolbar.setNavigationOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View view)
								{
										//退出
										Toast.makeText(MainActivity.this,"你点击了返回键",Toast.LENGTH_SHORT).show();
										//finish();
								}
						});
				
    }
}
