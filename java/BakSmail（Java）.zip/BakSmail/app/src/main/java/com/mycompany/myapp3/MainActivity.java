package com.mycompany.myapp3;

import android.app.*;
import android.os.*;
import android.widget.*;
import com.google.common.collect.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.jf.baksmali.*;
import org.jf.baksmali.Adaptors.*;
import org.jf.dexlib2.*;
import org.jf.dexlib2.analysis.*;
import org.jf.dexlib2.dexbacked.*;
import org.jf.dexlib2.dexbacked.reference.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.writer.builder.*;
import org.jf.dexlib2.writer.io.*;
import org.jf.smali.*;
import org.jf.util.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		try
		{
			run();
		}
		catch (Exception e)
		{
			Toast.makeText(this, e.getMessage(), 500).show();
		}
    }
    private void run() throws Exception
	{
	 
	    /*
		dex合并
		*/
		//---------------+
		//第一个dex
		DexBackedDexFile dex1 = 
		DexBackedDexFile.fromInputStream(
		Opcodes.getDefault(), 
	  new BufferedInputStream(new FileInputStream("sdcard/classes1.dex")));
		
		
		//第二个dex
		DexBackedDexFile dex2 = 
		DexBackedDexFile.fromInputStream(
		Opcodes.getDefault(), 
		new BufferedInputStream(new FileInputStream("sdcard/classes2.dex")));
		
		
		//dex编译器
		DexBuilder builder=new DexBuilder(Opcodes.getDefault());
		
		
		//___________merge______________
		//合并所有class 支持重复class
		Set<? extends org.jf.dexlib2.dexbacked.DexBackedClassDef> list=new HashSet<>();
		list.addAll(dex1.getClasses());
		list.addAll(dex2.getClasses());
		for(DexBackedClassDef cl:list)
		{
			builder.internClassDef(cl);
		}
		//输出字节流
		/*MemoryDataStore store = new MemoryDataStore();
		builder.writeTo(store);
		byte[] buff=Arrays.copyOf(store.getBufferData(),store.getSize());*/
		
		
		//输出文件
		FileDataStore out=new FileDataStore(new File("sdcard/meage.dex"));
		builder.writeTo(out);
	   //--------合并-------+
		
		
		
		
		
		//___________samli______________
		//反编译到smali
		//操作dex1
		ClassPath p=
		new ClassPath(Lists.newArrayList(
		new DexClassProvider(dex1)),
		false, 
		dex1.getClasses().size());
		
		//反编译指定class
		DexBackedClassDef c= 
		(DexBackedClassDef) p.getClassDef("Lcom/php/Main;");
		
		//输出string
		StringWriter stringWriter = new StringWriter();
		IndentingWriter writer = new IndentingWriter(stringWriter);
		ClassDefinition classDefinition = new ClassDefinition(new BaksmaliOptions(), c);
		classDefinition.writeTo(writer);
		writer.close();
	    //stringWriter.toString() 就可以看到class反编译出来的smali
		System.out.println("Smali_String:"+stringWriter.toString());
		
		
		//假设已经修改 回编译到dex编译器里面去
		Smali.assembleSmaliFile(stringWriter.toString(), builder, new SmaliOptions());
		
		//输出文件
		FileDataStore Test2=new FileDataStore(new File("sdcard/Smali.dex"));
		builder.writeTo(Test2);
		//___________samli______________
		
		
		
		
		/*Iterator<DexBackedMethod> kk=(Iterator<DexBackedMethod>) c.getMethods().iterator();
		List<DexBackedMethod> l= Lists.newArrayList(kk);
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l.get(i).getName());
			StringBuffer type=new StringBuffer();
			for(String o:l.get(i).getParameterTypes())
			{
				type.append(o);
			}
			System.out.println("("+type.toString()+")"+l.get(i).getReturnType());
			System.out.println("");
		}*/
		/*System.out.println(c.getSuperclass());
		for(DexBackedMethod op:c.getMethods())
		{
			System.out.println(op.getName());
			StringBuffer type=new StringBuffer();
			for(String o:op.getParameterTypes())
			{
				type.append(o);
			}
			System.out.println("("+type.toString()+")"+op.getReturnType());
			System.out.println("");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		for(DexBackedMethod op:c.getVirtualMethods())
		{
			System.out.println(op.getName());
			StringBuffer type=new StringBuffer();
			for(String o:op.getParameterTypes())
			{
				type.append(o);
			}
			System.out.println("("+type.toString()+")"+op.getReturnType());
			System.out.println("");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		for(DexBackedMethod op:c.getDirectMethods())
		{
			System.out.println(op.getName());
			StringBuffer type=new StringBuffer();
			for(String o:op.getParameterTypes())
			{
				type.append(o);
			}
			System.out.println("("+type.toString()+")"+op.getReturnType());
			System.out.println("");
		}
		System.out.println("");
		System.out.println("");
		System.out.println("");
		for(DexBackedMethod op:c.getFields())
		{
			System.out.println(op.getName());
			StringBuffer type=new StringBuffer();
			for(String o:op.getParameterTypes())
			{
				type.append(o);
			}
			System.out.println("("+type.toString()+")"+op.getReturnType());
			System.out.println("");
		}*/
		
		
		
		/*Set<? extends org.jf.dexlib2.dexbacked.DexBackedClassDef> list=new HashSet<>();
		list.addAll(dex.getClasses());
		list.addAll(dex2.getClasses());
		for(DexBackedClassDef cl:list)
		{
			builder.internClassDef(cl);
		}*/
		
		
		
		
		/*for(DexBackedClassDef cl:dex.getClasses())
		{
			String className=cl.getType();
			String smaliPath = String.format("%s%s%s.smali", "sdcard/测试baksmali", File.separatorChar,
											 className.substring(1, className.length() - 1));
			StringWriter stringWriter = new StringWriter();
			IndentingWriter writer = new IndentingWriter(stringWriter);
			ClassDefinition classDefinition = new ClassDefinition(new BaksmaliOptions(), cl);
			classDefinition.writeTo(writer);
			writer.close();
			File o=new File(smaliPath);
			if(!o.getParentFile().exists())
			{
				o.getParentFile().mkdirs();
			}
			FileOutputStream out=new FileOutputStream(o);
			out.write(stringWriter.toString().getBytes());
			out.close();
			builder.internClassDef(cl);
		}*/
		
		/*MemoryDataStore store = new MemoryDataStore();
		builder.writeTo(store);
		FileOutputStream file=new FileOutputStream("sdcard/classes2.dex");
		file.write(Arrays.copyOf(store.getBufferData(), store.getSize()));
		file.close();*/
		//builder.writeTo(new FileDataStore(new File("sdcard/22.dex")));
	}
	private static byte[] processDex(DexBackedDexFile dex) throws Exception
	{
		DexBuilder dexBuilder = new DexBuilder(Opcodes.getDefault());
		ClassDef classDef = Smali.assembleSmaliFile(readTextFromSDcard(new FileInputStream("sdcard/1.smali")), dexBuilder, new SmaliOptions());
		if (classDef == null)
			throw new Exception("Parse smali failed");
		
		for(DexBackedStringReference a: dex.getStrings())
		{
			if(a.getString().equals("http://localhost:8003/jihuo.php"))
			{
				dexBuilder.internStringReference("测试");
			}
			System.out.println("字符串常量池  "+a.getString());
		}
		for (DexBackedClassDef dexBackedClassDef : dex.getClasses())
		{
			System.out.println("路径  "+ dexBackedClassDef.getType());
			for( DexBackedField f: dexBackedClassDef.getFields())
			{
				System.out.println("Field名称  "+f.getName());
				System.out.println("FieldType  ("+f.getType()+")");
			}
			for( DexBackedMethod m:dexBackedClassDef.getMethods())
			{
				System.out.println("method名称  "+m.getName());
				for(String a:m.getParameterTypes())
				{
					System.out.println("methodType  ("+a+")");
				}
				System.out.println("method返回值  "+m.getReturnType());
			}
			if(dexBackedClassDef.getSourceFile().equals("Type.java")){
				//http://localhost:8003/jihuo.php
				StringWriter stringWriter = new StringWriter();
				IndentingWriter writer = new IndentingWriter(stringWriter);
				ClassDefinition classDefinition = new ClassDefinition(new BaksmaliOptions(), dexBackedClassDef);
				classDefinition.writeTo(writer);
				writer.close();
			    Smali.assembleSmaliFile(stringWriter.toString().replace("http://localhost:8003/jihuo.php","测试"), dexBuilder, new SmaliOptions());
				//dexBuilder.internStringReference("测试");
			}else
			{
				dexBuilder.internClassDef(dexBackedClassDef);
			}
		}
		MemoryDataStore store = new MemoryDataStore();
		dexBuilder.writeTo(store);
		return Arrays.copyOf(store.getBufferData(), store.getSize());
	}
	private static String readTextFromSDcard(InputStream is) throws Exception
	{
		InputStreamReader reader = new InputStreamReader(is);
		BufferedReader bufferedReader = new BufferedReader(reader);
		StringBuffer buffer = new StringBuffer("");
		String str;
		while ((str = bufferedReader.readLine()) != null)
		{
			buffer.append(str);
			buffer.append("\n");
		}
		return buffer.toString();
	}

}
