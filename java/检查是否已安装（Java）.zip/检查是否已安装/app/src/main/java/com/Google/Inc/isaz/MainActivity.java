package com.Google.Inc.isaz;

import android.app.*;
import android.os.*;
import android.content.*;
import java.util.*;
import android.content.pm.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Boolean isaz = isAvilible(this,"com.tencent.mobileqq");
		if (isaz=true){
			Toast.makeText(this,"已安装",5000).show();
		}
		else{
			Toast.makeText(this,"未安装",5000).show();
		}
    }
	
	public static boolean isAvilible(Context context, String packageName) {
		final PackageManager packageManager = context.getPackageManager();
		List<PackageInfo> packageInfos = packageManager.getInstalledPackages(0);
		List<String> packageNames = new ArrayList<String>();

		if (packageInfos != null) {
			for (int i = 0; i < packageInfos.size(); i++) {
				String packName = packageInfos.get(i).packageName;
				packageNames.add(packName);
			}
		}
		// 判断packageNames中是否有目标程序的包名，有TRUE，没有FALSE
		return packageNames.contains(packageName);
	}
	
}
