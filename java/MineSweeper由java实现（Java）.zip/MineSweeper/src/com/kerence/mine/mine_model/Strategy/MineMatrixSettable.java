package com.kerence.mine.mine_model.Strategy;

// @download:http://www.codefans.net
import com.kerence.mine.data_structure.MineMatrix;

public interface MineMatrixSettable
{
	void setMineMatrix(MineMatrix m);
}
