package dz.xm.qqq;
import android.accessibilityservice.*;
import android.view.accessibility.*;
import java.util.*;

public class service extends AccessibilityService
{

	@Override
	public void onAccessibilityEvent(AccessibilityEvent event)
	{
		// TODO: Implement this method
		switch(event.getEventType()){
			case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
				findText("赞");
				break;
				case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
				findText("赞");
				break;
		}
	}

	
	
	private void findText(String text) {
        AccessibilityNodeInfo nodeInfo = getRootInActiveWindow();
		if (nodeInfo != null) {
            List<AccessibilityNodeInfo> list = nodeInfo.findAccessibilityNodeInfosByText(text);
			if(!list.isEmpty()){
				for(AccessibilityNodeInfo lists:list)
				{
					for(int i=0;i<10;i++){
					lists.performAction(AccessibilityNodeInfo.ACTION_CLICK);
				}
	     		}
			}
        }
    }
	
	@Override
	public void onInterrupt()
	{
		// TODO: Implement this method
	}

	
}
