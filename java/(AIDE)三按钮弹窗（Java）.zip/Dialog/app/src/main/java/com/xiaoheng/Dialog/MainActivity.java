package com.xiaoheng.Dialog;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button button=(Button)findViewById(R.id.mainButton);
		button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					
					
					AlertDialog.Builder a=new AlertDialog.Builder(MainActivity.this);
					a.setIcon(R.drawable.ic_launcher);//图标
					a.setCancelable(false);//点击界面其他地方弹窗不会消失
					a.setTitle("弹窗测试");//标题
					a.setMessage("小亨QQ1919196455\n欢迎加入⃟小⃟亨⃟分⃟享⃟群234257176");//弹窗内容
					a.setPositiveButton("小亨分享群", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								joinQQGroup("Miow_lT2ccTyvxNShCd33miSMDb90jeP");
							}

							public boolean joinQQGroup(String key)
							{
								Intent intent = new Intent();
								intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
								try
								{
									startActivity(intent);
									return true;
								}
								catch (Exception e)
								{
									return false;
								}
							}

						});
					a.setNegativeButton("联系小亨",new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								String heng="mqqwpa://im/chat?chat_type=wpa&uin=1919196455";
								startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(heng)));
								//p1.dismiss();
							}
						});
					a.setNeutralButton("加好友", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
							}
						});
					a.show();
					
				}
			});
    }
	
}
/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/