# ShareButton
A share button with smooth animation

## Demo
![Demo](https://github.com/kayan1990/ShareButton/blob/master/ShareButton/gif/sharebutton.gif)
