package com.example.testproject;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityOpenAnim extends AppCompatActivity {
    boolean isOpen = false;
    private ImageView img1,img2,img3,img4;
    private LinearLayout layout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout5);


        img1=findViewById(R.id.boss);
        img2=findViewById(R.id.anim1);
        img3=findViewById(R.id.anim2);
        img4=findViewById(R.id.anim3);
        layout=findViewById(R.id.clickOut);

        //进入页面等300ms之后再进行动画
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(280);//子线程中睡300ms是为了Acticity的布局初始化完毕才触发动画,否则动画会出现卡顿
                    img1.setClickable(false);//禁用点击，防止快速点击的时候动画未完成就再次开始
                    //EventBus.getDefault().post(new OpenBean());//使用EventBus发送消息到主线程的订阅事件开启动画,使用handler也可以
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isOpen) {
                                isOpen = !isOpen;//禁止快速点击
                                animRun(img2,img3,img4,img1);
                            }
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }).start();

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isOpen) {
                    isOpen = !isOpen;
                    animRunBack(img2,img3,img4,img1);//关闭时开启收回动画
                }
            }
        });

        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    //菜单展开的动画
    public void animRun(final View view1, final View view2, final View view3,final View view4) {
        //获取屏幕宽度
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        final int screenWidth = dm.widthPixels;

        ObjectAnimator animatorf=ObjectAnimator.ofFloat(view4,"translationX",screenWidth,0).setDuration(300);
        ObjectAnimator animatorff=ObjectAnimator.ofFloat(view4,"rotation",0,720).setDuration(300);
        AnimatorSet bouncer=new AnimatorSet();
        bouncer.playTogether(animatorf,animatorff);
        bouncer.start();
        //animatorf.setDuration(300);
        //animatorf.start();
        //左边控件的动画
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(view1, "translationY",
                0.0F, -screenWidth / 3f).setDuration(300);//Y方向移动距离
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(view1, "translationX",
                0.0F, -screenWidth / 4f).setDuration(300);//X方向移动距离
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(view1, "scaleX", 1.0f, 1.5f).setDuration(300);//X方向放大
        ObjectAnimator animator4 = ObjectAnimator.ofFloat(view1, "scaleY", 1.0f, 1.5f).setDuration(300);//Y方向放大
        ObjectAnimator animatora = ObjectAnimator.ofFloat(view1, "alpha", 0f, 1f).setDuration(300);
        AnimatorSet animSet1 = new AnimatorSet();
        animSet1.setInterpolator(new OvershootInterpolator());//到达指定位置后继续向前移动一定的距离然后弹回指定位置,达到颤动的特效
        animSet1.playTogether(animator1, animator2, animator3, animator4,animatora);//四个动画同时执行

        //中间控件的动画,因需要设置监听所以与
        final ObjectAnimator animator5 = ObjectAnimator.ofFloat(view2, "translationY",
                0.0F, -screenWidth / 2f).setDuration(300);
        ObjectAnimator animator6 = ObjectAnimator.ofFloat(view2, "scaleX", 1.0f, 1.5f).setDuration(300);
        ObjectAnimator animator7 = ObjectAnimator.ofFloat(view2, "scaleY", 1.0f, 1.5f).setDuration(300);
        ObjectAnimator animatorb = ObjectAnimator.ofFloat(view2, "alpha", 0f, 1f).setDuration(300);
        final AnimatorSet animatorSet2 = new AnimatorSet();
        animatorSet2.setInterpolator(new OvershootInterpolator());
        animatorSet2.playTogether(animator5, animator6, animator7,animatorb);
        animatorSet2.setStartDelay(50);//监听第一个动画开始之后50ms开启第二个动画,达到相继弹出的效果

        //右侧控件的动画
        ObjectAnimator animator8 = ObjectAnimator.ofFloat(view3, "translationY",
                0.0F, -screenWidth / 3).setDuration(300);
        ObjectAnimator animator9 = ObjectAnimator.ofFloat(view3, "translationX",
                0.0F, screenWidth / 4f).setDuration(300);
        ObjectAnimator animator10 = ObjectAnimator.ofFloat(view3, "scaleX", 1.0f, 1.5f).setDuration(300);
        ObjectAnimator animator11 = ObjectAnimator.ofFloat(view3, "scaleY", 1.0f, 1.5f).setDuration(300);
        ObjectAnimator animatorc = ObjectAnimator.ofFloat(view3, "alpha", 0f, 1f).setDuration(300);
        final AnimatorSet animatorSet3 = new AnimatorSet();
        animatorSet3.setInterpolator(new OvershootInterpolator());
        animatorSet3.playTogether(animator8, animator9, animator10, animator11,animatorc);
        animatorSet3.setStartDelay(50);


        //三个动画结束之后设置boss按键可点击,点击即收回动画
        animatorSet3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
               img1.setClickable(true);
            }
        });

        //第二个开始之后再开启第三个
        animator3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                animatorSet3.start();
            }

        });

        //第一个动画开始之后再开启第二个
        animSet1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                animatorSet2.start();
            }
        });

        animSet1.start();//放在最后是为了初始化完毕所有的动画之后才触发第一个控件的动画
    }


    //收回动画,相当于反向执行展开动画,此处不做更详细的注释
    public void animRunBack(final View view1, final View view2, final View view3,final  View view4) {
        //获取屏幕宽度
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        final int screenWidth = dm.widthPixels;

        ObjectAnimator animatorf=ObjectAnimator.ofFloat(view4,"translationX",0,screenWidth).setDuration(300);
        ObjectAnimator animatorff=ObjectAnimator.ofFloat(view4,"rotation",720,0).setDuration(300);
        AnimatorSet bouncer=new AnimatorSet();
        bouncer.playTogether(animatorf,animatorff);
        bouncer.start();

        //第一个收回动画
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(view1, "translationY",
                -screenWidth / 3f, 0.0F).setDuration(300);
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(view1, "translationX",
                -screenWidth / 4f, 0.0F).setDuration(300);
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(view1, "scaleX", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animator4 = ObjectAnimator.ofFloat(view1, "scaleY", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animatora = ObjectAnimator.ofFloat(view1, "alpha", 1f, 0f).setDuration(300);
        AnimatorSet animSet = new AnimatorSet();
        animSet.setInterpolator(new DecelerateInterpolator());
        animSet.playTogether(animator1, animator2, animator3, animator4,animatora);

        //第二个收回动画
        final ObjectAnimator animator5 = ObjectAnimator.ofFloat(view2, "translationY",
                -screenWidth / 2f, 0.0F).setDuration(300);
        ObjectAnimator animator6 = ObjectAnimator.ofFloat(view2, "scaleX", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animator7 = ObjectAnimator.ofFloat(view2, "scaleY", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animatorb = ObjectAnimator.ofFloat(view2, "alpha", 1f, 0f).setDuration(300);
        //                animator3.setInterpolator(new OvershootInterpolator());
        final AnimatorSet animatorSet2 = new AnimatorSet();
        animatorSet2.setInterpolator(new DecelerateInterpolator());
        animatorSet2.playTogether(animator5, animator6, animator7,animatorb);
        animatorSet2.setStartDelay(50);

        //第三个收回动画
        ObjectAnimator animator8 = ObjectAnimator.ofFloat(view3, "translationY",
                -screenWidth / 3, 0.0F).setDuration(300);
        ObjectAnimator animator9 = ObjectAnimator.ofFloat(view3, "translationX",
                screenWidth / 4f, 0.0F).setDuration(300);
        ObjectAnimator animator10 = ObjectAnimator.ofFloat(view3, "scaleX", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animator11 = ObjectAnimator.ofFloat(view3, "scaleY", 1.5f, 1.0f).setDuration(300);
        ObjectAnimator animatorc = ObjectAnimator.ofFloat(view3, "alpha", 1f, 0f).setDuration(300);
        final AnimatorSet animatorSet3 = new AnimatorSet();
        animatorSet3.setInterpolator(new DecelerateInterpolator());
        //四个动画同时执行
        animatorSet3.playTogether(animator8, animator9, animator10, animator11,animatorc);
        animatorSet3.setStartDelay(50);

        animator3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {

                animatorSet3.start();
                animatorSet3.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        finish();//收回动画结束后finish此页面
                    }
                });
            }

        });

        animSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                animatorSet2.start();
            }
        });

        animSet.start();
    }

    //优化返回键的点击事件
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && isOpen) {
            isOpen = !isOpen;
            img1.setClickable(false);
            animRunBack(img2,img3,img4,img1);
        }
        return false;
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.activity_out,R.anim.activity_in);
    }
}
