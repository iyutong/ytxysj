package com.example.testproject;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Slide;
import android.transition.TransitionInflater;
import android.view.View;
import android.view.Window;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import static android.view.View.LAYER_TYPE_SOFTWARE;

public class Main14 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
      
        super.onCreate(savedInstanceState);
       
        setContentView(R.layout.layout4);

        findViewById(R.id.boss1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ActivityOpenAnim.class);
                startActivity(intent);
                overridePendingTransition(R.anim.activity_out,R.anim.activity_in);
            }
        });
       
    
    }
    }
