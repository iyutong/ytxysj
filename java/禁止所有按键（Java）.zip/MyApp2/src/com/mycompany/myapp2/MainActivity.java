package com.mycompany.myapp2;

import android.app.*;
import android.os.*;
import android.view.*;
import java.lang.reflect.*;

public class MainActivity extends Activity
{
	public static final int 
	FLAG_HOMEKEY_DISPATCHED = 0x80000000;
    /** Called when the activity is first created. */
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		try {

			Object service = getSystemService("statusbar");
			Class<?> statusbarManager = Class.forName("android.app.StatusBarManager");
			Method test = statusbarManager.getMethod("collapse");
			test.invoke(service);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//关键代码
        setContentView(R.layout.main);
    }
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
			case KeyEvent.KEYCODE_BACK:
				switch (keyCode) {
					case KeyEvent.KEYCODE_HOME:
					return true;
					case KeyEvent.KEYCODE_BACK:
						return true;
						case KeyEvent.KEYCODE_CALL:
							return true;
							case KeyEvent.KEYCODE_SYM:
						return true;
					 case KeyEvent.KEYCODE_VOLUME_DOWN:
						 return true;
					 case KeyEvent.KEYCODE_VOLUME_UP:
					 return true;
					case KeyEvent.KEYCODE_STAR:
						 return true;	
			}	return true;
		}return true;
	}}
	
	
