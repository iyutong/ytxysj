package com.panda.filchoice;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends Activity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
 
        Intent intent=getIntent();
        String path = intent.getStringExtra("path");
        if(path!=null) Toast.makeText(getApplication(),"当前选中文件中返回:"+path , Toast.LENGTH_SHORT).show();
        //这3行为选择文件后回调执行的代码，其他文件我需跟该，设置图片那想改就改
		
		findViewById(R.id.Start).setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(getApplication(), FileListActivity.class));
                }
        });
	}
    
    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
    
} 
