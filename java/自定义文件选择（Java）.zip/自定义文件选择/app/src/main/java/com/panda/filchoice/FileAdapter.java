package com.panda.filchoice;

import android.widget.ArrayAdapter;
import android.content.Context;
import java.util.List;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;

public class FileAdapter extends ArrayAdapter<FileInfo>{
    private int resourceId;
    public FileAdapter(Context context,int textViewResourceId,List<FileInfo> object){
		super(context,textViewResourceId,object);
		resourceId=textViewResourceId;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent){
		FileInfo fileInfo = getItem(position);
		View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
		ImageView Image = view.findViewById(R.id.image1);
		TextView Name = view.findViewById(R.id.text_theme);
		TextView  Content= view.findViewById(R.id.text_content);
		TextView  Path= view.findViewById(R.id.file_path);
		Image.setImageResource(fileInfo.getImageId());
		Name.setText(fileInfo.getName());
		Content.setText(fileInfo.getContent());
		Path.setText(fileInfo.getContent());
		return view;
	}
    
}
