package com.panda.filchoice;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import android.content.Intent;
import android.widget.TextView;
import android.view.Window;

public class FileListActivity extends Activity {

	private List<FileInfo> fileList = new ArrayList<>();
	
	private ListView listview;
	
	private FileAdapter adapter;
	
	private String TotalPath;
	
	private static String FilePath;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.file_list);
		
		adapter = new FileAdapter(this,R.layout.list_view,fileList);
		listview = findViewById(R.id.listview);
		listview.setAdapter(adapter);
		RefreshFileList("/storage/emulated/0/");//设置主目录
        FilePath=TotalPath;
		listview.setOnItemClickListener(new AdapterView.OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> parent,View view,int position,long id) {
					FileInfo info = fileList.get(position);
					if (info.getType()==1) {
						if(!new File(info.getPath()).canExecute()){
                            Toast.makeText(getApplication(), "打开失败", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            FilePath = info.getPath();
                            RefreshFileList(info.getPath());
                        }
					}
					if (info.getType()==-1) {
						FilePath = info.getPath();
                        Intent intent = new Intent(getApplication(), MainActivity.class);
                        intent.putExtra("path", info.getPath());
                        startActivity(intent);
					}
					if(info.getType()==0){
						ReturnUp(TotalPath);
					}
				}
		});
        
        
        findViewById(R.id.list_ok).setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplication(), MainActivity.class);
                    intent.putExtra("path", FilePath);
                    startActivity(intent);
                }
        });
	}
    
    
	
	public void RefreshFileList(String f){
		TotalPath = f;
        TextView tv = findViewById(R.id.file_path);
        tv.setText(f);
		fileList.clear();
        File[] files = new File(f).listFiles();
		fileList.add(new FileInfo("..",null,R.drawable.folder,TotalPath,0));
        LinkedList<FileInfo> list = new LinkedList<>();
        for (File file : files) {
			list.add(new FileInfo(file.getName(), file.getPath() , file.isFile() ? -1 : 0));
        }
        Collections.sort(list);
        for (FileInfo info : list) {
			String path = info.getPath();
			String name = info.getName();
			fileList.add(new FileInfo(
									name,
									new FileTools().infos(path),
									info.setImage(path,name),
									path,
									getFileTypes(path)
									));
        }
		adapter.notifyDataSetChanged();
	}

	public int getFileTypes(String path){
		File file = new File(path);
		if(file.isFile()){
			return -1;
		}
		if(file.isDirectory()){
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public void ReturnUp(String path){
		File file = new File(path);
		if(TotalPath.equals("/")){
			Toast.makeText(getApplication(),"已经是根目录啦", Toast.LENGTH_SHORT).show();
		}
		else{
			TotalPath = file.getParent()+"/";
			RefreshFileList(file.getParent()+"/");
		}
		if(TotalPath.equals("//")){
			RefreshFileList("/");
		}
	}
		
	@Override
	public void onBackPressed() {
        if(!TotalPath.equals("/")){
			ReturnUp(TotalPath);
		}
		else{
			finish();
		}
    }
} 
