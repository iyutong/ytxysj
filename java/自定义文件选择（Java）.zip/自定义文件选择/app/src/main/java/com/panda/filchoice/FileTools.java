package com.panda.filchoice;

import java.text.DecimalFormat;
import java.io.File;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.util.Log;

public class FileTools {
	
	public FileTools(){
	}
	
	
    public long getFileSize(File file) {
        if (file.isFile()){
            return file.length();
		}
        final File[] children = file.listFiles();
        long total = 0;
        if (children != null){
            for (File child : children){
                total += getFileSize(child);
			}
		}
        return total;
    }
	
	public String FileSize(long file) {
		DecimalFormat df = new DecimalFormat("#.00");
		String FileSize;
		if (file < 1024) {
			FileSize = file + " B";
		} else if (file < 1048576) {
			FileSize = df.format((double) file / 1024) + " K";
		} else if (file < 1073741824) {
			FileSize = df.format((double) file / 1048576) + " M";
		} else {
			FileSize = df.format((double) file / 1073741824) + " G";
		}
		return FileSize;
	}
	
	public String FileModifyTime(File file){             
        Calendar cal = Calendar.getInstance();  
        long time = file.lastModified();  
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");         
        cal.setTimeInMillis(time);    
        return formatter.format(cal.getTime());
    }
	
	public String infos(String path){
		File file = new File(path);
		if(file.isDirectory()){
			return FileModifyTime(file);
		}
		else{
			return FileModifyTime(file)+" "+FileSize(getFileSize(file));
		}
	}
}
