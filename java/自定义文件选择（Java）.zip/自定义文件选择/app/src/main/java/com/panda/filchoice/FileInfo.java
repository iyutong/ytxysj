package com.panda.filchoice;

import java.io.File;
import android.widget.Toolbar;
import android.widget.Toast;
import android.util.Log;

public class FileInfo implements Comparable<FileInfo>{
    
    private String name;
	
	private String content;
	
	private int imageId;
	
	private String path;
	
	private int type;
	
	private long size;
	
	 @Override
    public int compareTo(FileInfo example01) {
        if (type == example01.type) {
            return this.path.compareTo(example01.path);
        }
        return type == 0 ? -1 : 1;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("");
        sb.append(path);
        return sb.toString();
    }
	
	public FileInfo(String name,String content,int imageId,String path,int type){
		this.name=name;
		this.content=content;
		this.imageId=imageId;
		this.path=path;
		this.type=type;
	}
	
	public FileInfo(String name, String path,int type){
		this.name=name;
		this.path=path;
		this.type=type;
	}
	
	public FileInfo(){
		
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getContent(){
		return this.content;
	}
	
	public int getImageId(){
		return this.imageId;
	}
	
	public String getPath(){
		return this.path;
	}
	
	public int getType(){
		return this.type;
	}
	
	public int setImage(String path,String name){
		File file = new File(path);
		String end = name.substring(name.lastIndexOf(".") + 1, name.length()).toLowerCase();
		Log.d("阿巴",end);
		if(file.isDirectory()){
			return R.drawable.folder;
        } else {
            if(name.endsWith(".java")||name.endsWith(".class")||name.endsWith(".rc")||name.endsWith(".sh")||name.endsWith(".xml")||name.endsWith(".css")||name.endsWith(".js")||name.endsWith(".html"))
				return R.drawable.file_type_java;
			else if(name.endsWith(".zip")||name.endsWith(".rar")||name.endsWith(".7z")||name.endsWith(".jar"))
				return R.drawable.file_type_zip;
			else if(name.endsWith(".png")||name.endsWith(".jpg"))
				return R.drawable.file_type_png;
			else if(name.endsWith(".gif"))
				return R.drawable.file_type_gif;
			else if(name.endsWith(".txt"))
				return R.drawable.file_type_txt;
			else if(name.endsWith(".mp3"))
				return R.drawable.file_type_mp3;
			else if(name.endsWith(".mp4"))
				return R.drawable.file_type_mp4;
			else if(name.endsWith(".apk"))
				return R.drawable.apk;
			else
				return R.drawable.file_type_end;
        }
	}
	
	
	
    
}

