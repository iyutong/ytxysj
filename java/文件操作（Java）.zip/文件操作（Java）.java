package com.s4droid.runtime;

import java.io.*;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class 文件操作
{
	static BufferedReader br = null;
    static BufferedWriter bw = null;
    static FileInputStream fin = null;
    static FileOutputStream fout = null;
    static InputStreamReader isr = null;
    static String line = "";
    static OutputStreamWriter osw = null;
	
	
	private static void zipFileOrDirectory(ZipOutputStream zipOutputStream, File file, String str) throws IOException {
        IOException ex;
        FileInputStream in = null;
        try {
            if (file.isDirectory()) {
                File[] entries = file.listFiles();
                if (entries.length <= 0) {
                    zipOutputStream.putNextEntry(new ZipEntry(str + file.getName() + "/"));
                    zipOutputStream.closeEntry();
                } else {
                    for (File zipFileOrDirectory : entries) {
                        zipFileOrDirectory(zipOutputStream, zipFileOrDirectory, str + file.getName() + "/");
                    }
                }
            } else {
                byte[] buffer = new byte[4096];
                FileInputStream in2 = new FileInputStream(file);
                try {
                    zipOutputStream.putNextEntry(new ZipEntry(str + file.getName()));
                    while (true) {
                        int bytes_read = in2.read(buffer);
                        if (bytes_read == -1) {
                            break;
                        }
                        zipOutputStream.write(buffer, 0, bytes_read);
                    }
                    zipOutputStream.closeEntry();
                    in = in2;
                } catch (IOException e) {
                    ex = e;
                    in = in2;
                    try {
                        ex.printStackTrace();
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException ex2) {
                                ex2.printStackTrace();
                                return;
                            }
                        }
                    } catch (Throwable th2) {
                        //th = th2;
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException ex22) {
                                ex22.printStackTrace();
                            }
                        }
                    }
                } catch (Throwable th3) {
                    //th = th3;
                    in = in2;
                    if (in != null) {
                        in.close();
                    }
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ex222) {
                    ex222.printStackTrace();
                }
            }
        } catch (IOException e2) {
            if (in != null) {
                in.close();
            }
        }
    }
	
	
	private static boolean deleteDir(File file) {
        if (file.isDirectory()) {
            String[] children = file.list();
            for (String file2 : children) {
                if (!deleteDir(new File(file, file2))) {
                    return false;
                }
            }
        }
        return file.delete();
    }

    private static Intent getAllIntent(String str) {
        Intent intent = new Intent();
        intent.addFlags(268435456);
        intent.setAction("android.intent.action.VIEW");
        intent.setDataAndType(Uri.fromFile(new File(str)), "*/*");
        return intent;
    }

    private static Intent getApkFileIntent(String str) {
        Intent intent = new Intent();
        intent.addFlags(268435456);
        intent.setAction("android.intent.action.VIEW");
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/vnd.android.package-archive");
        return intent;
    }

    private static Intent getAudioFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(67108864);
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        intent.setDataAndType(Uri.fromFile(new File(str)), "audio/*");
        return intent;
    }

    private static Intent getChmFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/x-chm");
        return intent;
    }

    private static Intent getExcelFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/vnd.ms-excel");
        return intent;
    }

    private static long getFileSize(File file) throws Exception {
        if (file.exists()) {
            return (long) new FileInputStream(file).available();
        }
        file.createNewFile();
        return 0;
    }

    private static long getFileSizes(File file) throws Exception {
        long size = 0;
        File[] flist = file.listFiles();
        for (int i = 0; i < flist.length; i++) {
            size = flist[i].isDirectory() ? size + getFileSizes(flist[i]) : size + getFileSize(flist[i]);
        }
        return size;
    }

    private static Intent getHtmlFileIntent(String str) {
        Uri uri = Uri.parse(str).buildUpon().encodedAuthority("com.android.htmlfileprovider").scheme("content").encodedPath(str).build();
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(uri, "text/html");
        return intent;
    }

    private static Intent getImageFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "image/*");
        return intent;
    }

    private static Intent getPdfFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/pdf");
        return intent;
    }

    private static Intent getPptFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/vnd.ms-powerpoint");
        return intent;
    }

    private static Intent getTextFileIntent(String str, boolean z) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        if (z) {
            intent.setDataAndType(Uri.parse(str), "text/plain");
        } else {
            intent.setDataAndType(Uri.fromFile(new File(str)), "text/plain");
        }
        return intent;
    }

    private static Intent getVideoFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(67108864);
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        intent.setDataAndType(Uri.fromFile(new File(str)), "video/*");
        return intent;
    }

    private static Intent getWordFileIntent(String str) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");
        intent.addFlags(268435456);
        intent.setDataAndType(Uri.fromFile(new File(str)), "application/msword");
        return intent;
    }

    private static Intent openFile(String str) {
        File file = new File(str);
        if (file == null || !file.exists() || file.isDirectory()) {
            return null;
        }
        String end = file.getName().substring(file.getName().lastIndexOf(".") + 1, file.getName().length()).toLowerCase();
        return (end.equals("m4a") || end.equals("mp3") || end.equals("mid") || end.equals("xmf") || end.equals("ogg") || end.equals("wav")) ? getAudioFileIntent(str) : (end.equals("3gp") || end.equals("mp4")) ? getVideoFileIntent(str) : (end.equals("jpg") || end.equals("gif") || end.equals("png") || end.equals("jpeg") || end.equals("bmp")) ? getImageFileIntent(str) : end.equals("apk") ? getApkFileIntent(str) : end.equals("ppt") ? getPptFileIntent(str) : end.equals("xls") ? getExcelFileIntent(str) : end.equals("doc") ? getWordFileIntent(str) : end.equals("pdf") ? getPdfFileIntent(str) : end.equals("chm") ? getChmFileIntent(str) : end.equals("txt") ? getTextFileIntent(str, false) : getAllIntent(str);
    }

    private static boolean writeStreamToFile(InputStream inputStream, File file) throws IOException {
        Exception e1;
        Throwable th;
        OutputStream outputStream = null;
        try {
            OutputStream output = new FileOutputStream(file);
            try {
                byte[] buffer = new byte[1024];
                while (true) {
                    int read = inputStream.read(buffer);
                    if (read != -1) {
                        output.write(buffer, 0, read);
                    } else {
                        output.flush();
                        try {
                            output.close();
                            inputStream.close();
                            outputStream = output;
                            return true;
                        } catch (IOException e) {
                            e.printStackTrace();
                            outputStream = output;
                            return false;
                        }
                    }
                }
            } catch (Exception e2) {
                e1 = e2;
                outputStream = output;
                try {
                    e1.printStackTrace();
                    try {
                        outputStream.close();
                        inputStream.close();
                        return false;
                    } catch (IOException e3) {
                        e3.printStackTrace();
                        return false;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        outputStream.close();
                        inputStream.close();
                    } catch (IOException e32) {
                        e32.printStackTrace();
                        return false;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                outputStream = output;
                outputStream.close();
                inputStream.close();
            }
        } catch (Exception e4) {
            e1 = e4;
            e1.printStackTrace();
            outputStream.close();
            inputStream.close();
            return false;
        }
		return false;
	}

    
    public static boolean 修改文件名(String str, String str2) {
        if (str2.equals(str)) {
            return true;
        }
        File oldfile = new File(str);
        if (!oldfile.exists()) {
            return false;
        }
        File newfile = new File(str2);
        return newfile.exists() ? false : oldfile.renameTo(newfile);
    }

    
    public static boolean 关闭写() {
        try {
            bw.close();
            fout.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public static boolean 关闭读() {
        try {
            br.close();
            fin.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public static boolean 写一行(String str) {
        try {
            bw.newLine();
            bw.write(str);
            bw.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public static boolean 写出字节文件(String str, byte[] bArr) {
        try {
            FileOutputStream fout = new FileOutputStream(str);
            fout.write(bArr);
            fout.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public static boolean 写出文本文件(String str, String str2, String str3) {
        try {
            FileOutputStream fout = new FileOutputStream(str);
            fout.write(str2.getBytes(str3));
            fout.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean 创建文件(String str) {
        boolean result = false;
        File f = new File(str);
        if (f.exists()) {
            return true;
        }
        try {
            return f.createNewFile();
        } catch (IOException e) {
            return result;
        }
    }

    public static boolean 创建目录(String str) {
        String[] dir = str.split("/");
        String dist = dir[0];
        boolean result = true;
        if (dir.length <= 0) {
            return false;
        }
        for (int i = 1; i < dir.length; i++) {
            dist = dist + "/" + dir[i];
            File mkdir = new File(dist);
            if (!mkdir.exists()) {
                result = mkdir.mkdir();
            }
        }
        return result;
    }

    public static boolean 删除文件(String str) {
        File file = new File(str);
        return file.exists() && !file.isDirectory() && file.delete();
    }

    public static boolean 删除目录(String str) {
        File dir = new File(str);
        return !dir.exists() ? false : deleteDir(dir);
    }

    public static String 取子目录(String str) {
        String pa = "";
        File[] ff = new File(str).listFiles();
        for (int i = 0; i < ff.length; i++) {
            if (ff[i].isDirectory()) {
                pa = pa + ff[i].getAbsolutePath() + "|";
            }
        }
        return pa;
    }

    public static String 取文件修改时间(String str) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(new File(str).lastModified()));
    }

    public static long 取文件尺寸(String str) {
        File file = new File(str);
        try {
            return file.isDirectory() ? getFileSizes(file) : getFileSize(file);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static String 取文件编码(String str) {
        String charset = "";
        try {
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(new File(str)));
            in.mark(4);
            byte[] first3bytes = new byte[3];
            in.read(first3bytes);
            in.reset();
            return (first3bytes[0] == (byte) -17 && first3bytes[1] == (byte) -69 && first3bytes[2] == (byte) -65) ? "utf-8" : (first3bytes[0] == (byte) -1 && first3bytes[1] == (byte) -2) ? "unicode" : (first3bytes[0] == (byte) -2 && first3bytes[1] == (byte) -1) ? "utf-16be" : (first3bytes[0] == (byte) -1 && first3bytes[1] == (byte) -1) ? "utf-16le" : "GBK";
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return charset;
        } catch (IOException e2) {
            e2.printStackTrace();
            return charset;
        }
    }

    public static boolean 复制文件(String str, String str2) {
        if (!new File(str).exists()) {
            return false;
        }
        int bytesum = 0;
        try {
            InputStream inStream = new FileInputStream(str);
            FileOutputStream fs = new FileOutputStream(str2);
            byte[] buffer = new byte[1444];
            while (true) {
                int byteread = inStream.read(buffer);
                if (byteread != -1) {
                    bytesum += byteread;
                    fs.write(buffer, 0, byteread);
                } else {
                    inStream.close();
                    fs.close();
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String 寻找文件关键词(String str, String str2) {
        String result = "";
        for (File f : new File(str).listFiles()) {
            if (f.getName().indexOf(str2) >= 0) {
                result = f.getPath() + "\n" + result;
            }
        }
        return result;
    }

    public static String 寻找文件后缀名(String str, String str2) {
        String result = "";
        for (File f : new File(str).listFiles()) {
            if (f.getPath().substring(f.getPath().length() - str2.length()).equals(str2) && !f.isDirectory()) {
                result = f.getPath() + "\n" + result;
            }
        }
        return result;
    }

    public static void 打开文件(Context mCOntext,String str) {
        mCOntext.startActivity(openFile(str));
    }

    public static boolean 打开文本文件_写(String str, String str2) {
        if (!new File(str).exists()) {
            return false;
        }
        try {
            fout = new FileOutputStream(str);
            osw = new OutputStreamWriter(fout, str2);
            bw = new BufferedWriter(osw);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean 打开文本文件_读(String str, String str2) {
        if (!new File(str).exists()) {
            return false;
        }
        try {
            fin = new FileInputStream(str);
            isr = new InputStreamReader(fin, str2);
            br = new BufferedReader(isr);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean 文件是否存在(String str) {
        return new File(str).exists();
    }

    public static boolean 是否为目录(String str) {
        File file = new File(str);
        return file.exists() && file.isDirectory();
    }

    public static boolean 是否为隐藏文件(String str) {
        File file = new File(str);
        return file.exists() ? file.isHidden() : false;
    }

    public static String 读一行() {
        try {
            String readLine = br.readLine();
            line = readLine;
            if (readLine != null) {
                return line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static byte[] 读取字节文件(String str) {
        byte[] buffer = null;
        if (!new File(str).exists()) {
            return null;
        }
        try {
            FileInputStream fin = new FileInputStream(str);
            buffer = new byte[fin.available()];
            fin.read(buffer);
            fin.close();
            return buffer;
        } catch (Exception e) {
            e.printStackTrace();
            return buffer;
        }
    }

    public static String 读取文件(String str, String str2) {
        Exception e;
        String res = "";
        if (!new File(str).exists()) {
            return res;
        }
        try {
            FileInputStream fin = new FileInputStream(str);
            int length = fin.available();
            byte[] buffer = new byte[length];
            fin.read(buffer);
            String res2 = new String(buffer, 0, length, str2);
            try {
                fin.close();
                return res2;
            } catch (Exception e2) {
                e = e2;
                res = res2;
                e.printStackTrace();
                return res;
            }
        } catch (Exception e3) {
            e = e3;
            e.printStackTrace();
            return res;
        }
    }

    public static String 读取资源文件(Context mContext,String str, String str2) {
        Exception e;
        String str3 = "";
        try {
            InputStream inputstream = mContext.getAssets().open(str);
            if (inputstream == null) {
                return "";
            }
            int length = inputstream.available();
            byte[] buffer = new byte[length];
            inputstream.read(buffer);
            String res = new String(buffer, 0, length, str2);
            try {
                inputstream.close();
                str3 = res;
                return res;
            } catch (Exception e2) {
                e = e2;
                str3 = res;
                e.printStackTrace();
                return "";
            }
        } catch (Exception e3) {
            e = e3;
            e.printStackTrace();
            return "";
        }
    }

    public static byte[] 读入资源文件2(Context mContext,String str) {
        byte[] buffer = null;
        try {
            InputStream inputstream = mContext.getAssets().open(str);
            if (inputstream != null) {
                buffer = new byte[inputstream.available()];
                inputstream.read(buffer);
                inputstream.close();
            }
            return buffer;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
	
	public static boolean zip压缩(String str, String str2) throws IOException {
        IOException ex;
        Throwable th;
        ZipOutputStream out = null;
        try {
            File outFile = new File(str2);
            File fileOrDirectory = new File(str);
            ZipOutputStream out2 = new ZipOutputStream(new FileOutputStream(outFile));
            try {
                if (fileOrDirectory.isFile()) {
                    zipFileOrDirectory(out2, fileOrDirectory, "");
                } else {
                    File[] entries = fileOrDirectory.listFiles();
                    for (File zipFileOrDirectory : entries) {
                        zipFileOrDirectory(out2, zipFileOrDirectory, "");
                    }
                }
                if (out2 != null) {
                    try {
                        out2.close();
                        out = out2;
                        return true;
                    } catch (IOException ex2) {
                        ex2.printStackTrace();
                        out = out2;
                        return false;
                    }
                }
                return true;
            } catch (IOException e) {
                out = out2;
                try {
                    e.printStackTrace();
                    if (out != null) {
                        return false;
                    }
                    try {
                        out.close();
                        return false;
                    } catch (IOException ex22) {
                        ex22.printStackTrace();
                        return false;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException ex222) {
                            ex222.printStackTrace();
                        }
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                if (out != null) {
                    out.close();
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
            if (out != null) {
                return false;
            }
            out.close();
            return false;
        }
		return false;
	}

    public static boolean zip解压(String str, String str2) throws IOException {
        FileOutputStream out;
        IOException ex;
        boolean flag = false;
        ZipFile zipFile = null;
        try {
            ZipFile zipFile2 = new ZipFile(str);
            Throwable th;
            try {
                InputStream in;
                Enumeration e = zipFile2.entries();
                new File(str2).mkdirs();
                while (e.hasMoreElements()) {
                    ZipEntry zipEntry = (ZipEntry) e.nextElement();
                    String entryName = zipEntry.getName();
                    in = null;
                    out = null;
                    try {
                        if (zipEntry.isDirectory()) {
                            String name = zipEntry.getName();
                            new File(str2 + File.separator + name.substring(0, name.length() - 1)).mkdirs();
                            flag = true;
                        } else {
                            int index = entryName.lastIndexOf("\\");
                            if (index != -1) {
                                new File(str2 + File.separator + entryName.substring(0, index)).mkdirs();
                            }
                            index = entryName.lastIndexOf("/");
                            if (index != -1) {
                                new File(str2 + File.separator + entryName.substring(0, index)).mkdirs();
                            }
                            File f = new File(str2 + File.separator + zipEntry.getName());
                            in = zipFile2.getInputStream(zipEntry);
                            FileOutputStream out2 = new FileOutputStream(f);
                            try {
                                byte[] by = new byte[1024];
                                while (true) {
                                    int c = in.read(by);
                                    if (c == -1) {
                                        break;
                                    }
                                    out2.write(by, 0, c);
                                }
                                out2.flush();
                                flag = true;
                                out = out2;
                            } catch (IOException e2) {
                                ex = e2;
                                out = out2;
                                try {
                                    ex.printStackTrace();
                                    flag = false;
                                    if (in != null) {
                                        in.close();
                                    }
                                    if (out == null) {
                                        out.close();
                                    } else {
                                        continue;
                                    }
                                } catch (Throwable th2) {
                                    th = th2;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                out = out2;
                            }
                        }
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException e3) {
                                flag = false;
                            } catch (Throwable th4) {
                                th = th4;
                                zipFile = zipFile2;
                            }
                        }
                        if (out != null) {
                            out.close();
                        } else {
                            continue;
                        }
                    } catch (IOException e4) {
                        ex = e4;
                        ex.printStackTrace();
                        flag = false;
                        if (in != null) {
                            in.close();
                        }
                        if (out == null) {
                            continue;
                        } else {
                            out.close();
                        }
                    }
                }
                if (zipFile2 != null) {
                    try {
                        zipFile2.close();
                        zipFile = zipFile2;
                        return flag;
                    } catch (IOException e5) {
                        zipFile = zipFile2;
                        return false;
                    }
                }
                zipFile = zipFile2;
                return flag;
                
                
            } catch (IOException e6) {
                ex = e6;
                zipFile = zipFile2;
                try {
                    ex.printStackTrace();
                    if (zipFile != null) {
                        return false;
                    }
                    try {
                        zipFile.close();
                        return false;
                    } catch (IOException e7) {
                        return false;
                    }
                } catch (Throwable th5) {
                    th = th5;
                    if (zipFile != null) {
                        try {
                            zipFile.close();
                        } catch (IOException e8) {
                        }
                    }
                }
            } catch (Throwable th42) {
                th = th42;
                zipFile = zipFile2;
            }
        } catch (IOException e9) {
            ex = e9;
            ex.printStackTrace();
            if (zipFile != null) {
                return false;
            }
            zipFile.close();
            return false;
        }
		return false;
	}
}
