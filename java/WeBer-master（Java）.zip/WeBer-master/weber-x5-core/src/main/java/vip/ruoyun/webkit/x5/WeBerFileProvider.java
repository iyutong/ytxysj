package vip.ruoyun.webkit.x5;

import android.support.v4.content.FileProvider;

/**
 * Created by ruoyun on 2019-09-19.
 * Author:若云
 * Mail:zyhdvlp@gmail.com
 * Depiction:
 */
public class WeBerFileProvider extends FileProvider {

}
