
# WeBer jsBridge

## H5开发体验

h5 的使用方法和  ios 的 [WebViewJavascriptBridge](https://github.com/marcuswestin/WebViewJavascriptBridge) 库的一致，h5 在开发中只要实现一套代码就可以和 ios android 进行通信。

## 使用

```groovy
implementation 'vip.ruoyun.webkit:weber-x5-jsbridge:1.0.2'
```





