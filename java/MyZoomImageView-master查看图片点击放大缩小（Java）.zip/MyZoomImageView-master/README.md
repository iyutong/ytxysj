# MyZoomImageView
多点触控，放大缩小平移的ImageView
![这里写图片描述](http://img.blog.csdn.net/20160215154643898)
