package com.mycompany.myapp;
/*
/*本源码仅供测试参考，如有问题欢迎咨询

 欢迎加入IAPP专修技术群，群聊号码：596834623

*/
import android.app.*;
import android.os.*;
import android.content.Context;
import android.widget.*;
import android.graphics.PixelFormat;
import android.view.View.*;
import android.view.*;
import android.content.*;
//import com.tencent.smtt.sdk.TbsVideo;
public class MainActivity extends Activity 
{
	private Button btn_tbs_videoPlay;
    private String videoUrl;
	private EditText edit;
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        btn_tbs_videoPlay = (Button)findViewById(R.id.mainButton1);
		edit = (EditText)findViewById(R.id.mainEditText1);
        btn_tbs_videoPlay.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					videoUrl=edit.getText().toString();
					Intent intent=new Intent(getApplicationContext(),VideoPlay.class);
					intent.putExtra("videoUrl",videoUrl);
					startActivity(intent);
					// TODO: Implement this method
				}
			});
    }

    /**
     * 直接调用播放视频
     * @param videoUrl 视频地址
     */
}
