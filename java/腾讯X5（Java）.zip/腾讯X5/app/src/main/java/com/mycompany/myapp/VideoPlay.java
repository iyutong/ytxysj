package com.mycompany.myapp;
import android.app.Activity;
import com.mycompany.myapp.tools.X5WebView;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.graphics.PixelFormat;
import android.view.View;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.TbsVideo;
import android.widget.*;

public class VideoPlay extends Activity
{
	private String videoUrl;
    private X5WebView x5webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);
       videoUrl=  getIntentData();
       x5webView= initView();
        startPlay(videoUrl);
    }

    /**
     * 跳转至此页面
     *
     * @param context
     * @param videoUrl 视频地址
     */

    /**
     * 获取上个页面传过来的数据
     */
    private String getIntentData() {
        Intent intent = getIntent();
       return videoUrl = intent.getStringExtra("videoUrl");
    }

    private X5WebView initView() {
      return  x5webView = (X5WebView)findViewById(R.id.mainX5WebView1);
    }

    /**
     * 使用自定义webview播放视频
     * @param vedioUrl 视频地址
     */
   /*private void startPlay(String vedioUrl) {
        x5webView.loadUrl(vedioUrl);
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        x5webView.getView().setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        x5webView.setWebChromeClient(new WebChromeClient());
    }*/
	private void startPlay(String videoUrl)
	{
        //判断当前是否可用
        if (TbsVideo.canUseTbsPlayer(getApplicationContext()))
		{
            //播放视频
            TbsVideo.openVideo(getApplicationContext(), videoUrl);
        }
		else
		{
            Toast.makeText(this, "视频播放器未准备好", Toast.LENGTH_SHORT).show();
        }
    }
}
