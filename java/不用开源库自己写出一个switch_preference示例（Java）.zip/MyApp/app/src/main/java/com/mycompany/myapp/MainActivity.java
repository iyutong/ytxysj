package com.mycompany.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.view.LayoutInflater;
import java.util.zip.Inflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Switch;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		LinearLayout linear = (LinearLayout)findViewById(R.id.main_linear);
		LayoutInflater inflater = LayoutInflater.from(this);
		
		View switch_preference1 = inflater.inflate(R.layout.switch_preference,null);//创建第一个switch_preference对象
		TextView title1 = (TextView)switch_preference1.findViewById(R.id.switch_preference_title);
		TextView subtitle1 = (TextView)switch_preference1.findViewById(R.id.switch_preference_subtitle);
		title1.setText("设置项1");
		subtitle1.setText("设置项1副标题");
		listenSwitch(switch_preference1);//为设置项1加上点击监听
		
		View switch_preference2 = inflater.inflate(R.layout.switch_preference,null);//创建第二个switch_preference对象
		TextView title2 = (TextView)switch_preference2.findViewById(R.id.switch_preference_title);
		TextView subtitle2 = (TextView)switch_preference2.findViewById(R.id.switch_preference_subtitle);
		title2.setText("设置项2");
		subtitle2.setText("设置项2副标题");
		listenSwitch(switch_preference2);//为设置项2加上点击监听
		
		View switch_preference3 = inflater.inflate(R.layout.switch_preference,null);//创建第二个switch_preference对象
		TextView title3 = (TextView)switch_preference3.findViewById(R.id.switch_preference_title);
		TextView subtitle3 = (TextView)switch_preference3.findViewById(R.id.switch_preference_subtitle);
		title3.setText("设置项3");
		subtitle3.setText("设置项3副标题");
		listenSwitch(switch_preference3);//为设置项3加上点击监听
		
		View switch_preferencex = inflater.inflate(R.layout.switch_preference,null);//创建第二个switch_preference对象
		TextView titlex = (TextView)switch_preferencex.findViewById(R.id.switch_preference_title);
		TextView subtitlex = (TextView)switch_preferencex.findViewById(R.id.switch_preference_subtitle);
		titlex.setText("设置项X");
		subtitlex.setText("设置项X副标题");
		listenSwitch(switch_preferencex);//为设置项X加上点击监听
		
		linear.addView(switch_preference1);//添加第一个switch_preference布局
		linear.addView(switch_preference2);//添加第二个switch_preference布局
		linear.addView(switch_preference3);//添加第三个switch_preference布局
		linear.addView(switch_preferencex);//添加第X个switch_preference布局
		
    }
    public void listenSwitch(View v1){
		v1.setOnClickListener(new OnClickListener(){
			public void onClick(View v2){
				Switch s1 = (Switch)v2.findViewById(R.id.switch_preference_switch);
				switch(s1.getTag().toString()){
					case "0":
						s1.setChecked(true);
						s1.setTag("1");
						break;
					case "1":
						s1.setChecked(false);
						s1.setTag("0");
						break;
					default:
						Toast.makeText(MainActivity.this,"开启状态有误,目前开关状态码:"+s1.getTag().toString(),Toast.LENGTH_LONG).show();
						break;
				}
			}
		});
	}
}
