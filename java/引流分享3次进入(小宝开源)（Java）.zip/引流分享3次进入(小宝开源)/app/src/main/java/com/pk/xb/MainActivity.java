package com.pk.xb;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{

	private TextView cs;

	private Button fx;

	private static final int PICK_CONTACT_REQUEST = 0;

	private int c;

//本源码由小宝开源研究，内容可能不怎么完整，可以用来引流！
	//目前有个BUG，就是分享直接按返回键可以计数，这个方法希望各位能修改！
	//欢迎加入Poetic Dream网络交流，群聊号码：735344201
	//有任何问题不明白的可以私聊我，加群获取更多我的教程源码
	//小宝QQ：892167508--813094866
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		//你们可以自己写记录次数，这个我就不重复了，谢谢支持！
		cs = (TextView)findViewById(R.id.cs);
		fx = (Button)findViewById(R.id.fx);
		fx.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent Intent = new Intent();
					Intent.setAction(Intent.ACTION_SEND);
					Intent.putExtra(Intent.EXTRA_TEXT, "欢迎加入Poetic Dream网络交流，群聊号码：735344201");//分享的内容
					Intent.setType("text/plain");
					Intent.setComponent(new ComponentName("com.tencent.mobileqq", "com.tencent.mobileqq.activity.JumpActivity"));//应用默认QQ
					startActivityForResult(Intent, PICK_CONTACT_REQUEST);
				}
			});

    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// Check which request we're responding to
		if (requestCode == PICK_CONTACT_REQUEST)
		{
			if (c++ >= 2)//从0开始计到第三次！
			{
				Toast.makeText(MainActivity.this, "成功" , 1000).show();

				//成功的处理方法这里写！
			}
			else
			{
				cs.setText("已分享" + c + "次");

			}
			// TODO: Implement this method

		}
    }
}
