package com.xm.luaeditor;

import android.text.*;
import java.util.*;
import android.widget.*;

public class OperationManager implements TextWatcher
 {
	EditText editText;
	int[] change=new int[2];
	TextChangeListener tcl;
	 
    private EditOperation opt;

    //启用开关，用于过滤撤销/重做时的编辑操作
    private boolean enable = true;

	public OperationManager(EditText et){
		editText=et;
	}
	
    OperationManager disable() {
        enable = false;
        return this;
    }

    OperationManager enable() {
        enable = true;
        return this;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        //if (count > 0) {
            int end = start + count;
            if (enable) {
                if (opt == null) {
                    opt = new EditOperation();
                }
                //记录原始内容
                opt.setSrc(s.subSequence(start, end), start, end);
            }
        //}
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        //if (count > 0) {
            int end = start + count;
			change[0]=start;
			change[1]=end;
			if(tcl!=null)tcl.onTextChange(s,start,end);
            if (enable) {
                if (opt == null) {
                    opt = new EditOperation();
                }
                //记录目标内容
                opt.setDst(s.subSequence(start, end), start, end);
            }
        //}
    }

    @Override
    public void afterTextChanged(Editable s) {
        if (enable && opt != null) {
            if (!redoOpts.isEmpty()) {//重做栈不空时用户又编辑了文本，视为抛弃重做栈
                redoOpts.clear();
            }
            //将操作入栈
            undoOpts.push(opt);
        }
        opt = null;
    }

	public boolean undo() {
        if (canUndo()) {
            EditOperation undoOpt = undoOpts.pop();

            //屏蔽撤销产生的事件
            disable();
            undoOpt.undo(editText);
            enable();

            //填入重做栈
            redoOpts.push(undoOpt);
            return true;
        }
        return false;
    }

    public boolean redo() {
        if (canRedo()) {
            EditOperation redoOpt = redoOpts.pop();

            //屏蔽重做产生的事件
            disable();
            redoOpt.redo(editText);
            enable();

            //填入撤销
            undoOpts.push(redoOpt);
            return true;
        }
        return false;
    }
	public boolean canUndo() {
        return !undoOpts.isEmpty();
    }

    public boolean canRedo() {
        return !redoOpts.isEmpty();
    }
	public int[] getChangeIndex(){
		return change;
	}
	public void setTextChangeListener(TextChangeListener tcl){
		this.tcl=tcl;
	}
	
    //使用LinkedList代替栈
    private final LinkedList<EditOperation> undoOpts = new LinkedList<>();
    private final LinkedList<EditOperation> redoOpts = new LinkedList<>();

	public interface TextChangeListener{
		void onTextChange(CharSequence s, int start, int end);
	}
	
}
