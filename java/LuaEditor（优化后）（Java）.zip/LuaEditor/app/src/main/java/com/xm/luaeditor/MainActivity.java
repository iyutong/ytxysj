package com.xm.luaeditor;

import android.app.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.widget.*;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity
{
/*
作者：炫明， 7eu7d7
QQ：3510088586，228218809
QQ群：241449466
*/
    private LuaEditor mLuaEditor;
	private ScrollView mScrollView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		mLuaEditor=new LuaEditor(this);
		mLuaEditor.setText("require \"import\"\nimport \"android.app.*\"");
        mScrollView=(ScrollView) findViewById(R.id.activitymainScrollView1);
		mScrollView.addView(mLuaEditor);
    }



}
