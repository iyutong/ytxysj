package com.xm.luaeditor;
import android.content.*;
import android.graphics.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.widget.*;
import java.util.*;
import android.view.*;

public class LuaEditor extends EditText
{
	HashMap<String,Integer> mLight = new HashMap<String,Integer>();
	HashMap<String,Integer> mLight_symbol = new HashMap<String,Integer>();
	OperationManager om;
	
	public LuaEditor(Context context)
	{
		super(context);
		setBackgroundColor(0xfffafafa);
		
		String[] keyWord="and,or,break,else,if,false,in,true,for,function,goto,then,local,nil,while,not,until,end,do".split(",");
        for (String v : keyWord)
			mLight.put(v, 0xffff4081);
		String[] keyLight = "__add|__band|__bnot|__bor|__bxor|__call|__concat|__div|__eq|__idiv|__index|__le|__len|__lt|__mod|__mul|__newindex|__pow|__shl|__shr|__sub|__tostring|__unm|_ENV|_G|assert|collectgarbage|dofile|error|findtable|getmetatable|ipairs|load|loadfile|loadstring|module|next|pairs|pcall|print|rawequal|rawget|rawlen|rawset|require|select|self|setmetatable|tointeger|tonumber|tostring|type|unpack|xpcall|activity|call|compile|dump|each|enum|import|loadbitmap|loadlayout|loadmenu|service|set|task|thread|timer|coroutine|debug|io|luajava|math|os|package|string|table|utf8".split("\\|");
		for (String v : keyLight)
			mLight.put(v, 0xff3f51b5);
        
		String[] symbol="( ) [ ] { }".split(" ");
        for (String v : symbol)
			mLight_symbol.put(v, 0xffbdbdbd);
			
		om=new OperationManager(this);
		om.setTextChangeListener(new OperationManager.TextChangeListener(){
				@Override
				public void onTextChange(CharSequence s, int start, int end)
				{
					if(mLight!=null){
						refreshHightLight(start,end);
					}
				}
			});
		addTextChangedListener(om);
	}

	@Override
	protected void onDraw(Canvas canvas)
	{
		// TODO: Implement this method
		Paint p=new Paint();
		int w=0,h=getLineHeight();
		p.setStrokeWidth(2);
		p.setStyle(Paint.Style.FILL);
		p.setColor(0xffeeeeee);
		
		int y=(getLayout().getLineForOffset(getSelectionStart())+1);
		//if (getCurrentCursorLine() != -1)
		canvas.drawRect(0, (y-1) * h, getWidth(), y * h + 5, p);
		p.setColor(0xffbdbdbd);
		p.setTextSize(h - 10);
		for (int i=0;i < getLineCount();i++)
		{
			w += 1;
			int Y=(i + 1) * h;
			canvas.drawText(i + 1 + "", 0, Y, p);
		}
		int width=(int) p.measureText(w + "") + 8;
		canvas.save();
		canvas.translate(0,getScrollY());
		canvas.drawLine(width, 0, width, getLineCount()*getLineHeight(), p);
		canvas.restore();
		setPadding(width + 5, 0, 0, 0);
		
		super.onDraw(canvas);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode==KeyEvent.KEYCODE_VOLUME_DOWN){
			om.undo();
			return true;
		}
		if(keyCode==KeyEvent.KEYCODE_VOLUME_UP){
			om.redo();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	

	public void refreshHightLight(int start_find,int end_find)
	{
		long timestart=System.currentTimeMillis();
        //关键字高亮
        Editable mSpannable =getText();
        String code = mSpannable.toString();
		//截取区间
		start_find=code.lastIndexOf("\n",start_find)+1;
		int temp=code.indexOf("\n",end_find);
		end_find=(temp==-1?code.length():temp);
		//while(start_find>0&&!isWhitespace(code.charAt(start_find-1)))start_find--;
		//while(end_find<code.length()&&!isWhitespace(code.charAt(end_find)))end_find++;
		if(start_find>end_find)return;
        mSpannable.setSpan(new ForegroundColorSpan(0xff000000), start_find, end_find, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        for (String str:mLight.keySet())
		{
            int start=start_find;
            int len=str.length();
            while ((start = code.indexOf(str, start)) != -1&&(start+len)<=end_find)
			{
                if (start != 0 && isNun_or_Abc(code.charAt(start - 1)))
				{start += len; continue;}
                if (start + len < code.length() && isNun_or_Abc(code.charAt(start + len)))
				{start += len; continue;}
                mSpannable.setSpan(new ForegroundColorSpan(mLight.get(str)), start, start + len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                start += len;
            }
        }

		for (int i=0;i < 9;i++)
		{
			int start=start_find;
			int len=1;
			while ((start = code.indexOf(i + "", start)) != -1&&(start+len)<=end_find)
			{
				if (start != 0 && isAbc(code.charAt(start - 1)))
				{start += len; continue;}
				if (start + len < code.length() && isAbc(code.charAt(start + len)))
				{start += len; continue;}
				mSpannable.setSpan(new ForegroundColorSpan(0xffFF4081), start, start + len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				start += len;
			}
		}
		
		for (String str:mLight_symbol.keySet())
		{
			int start=start_find;
			while ((start = code.indexOf(str, start)) != -1&&(start+1)<=end_find)
			{
				mSpannable.setSpan(new ForegroundColorSpan(mLight_symbol.get(str)), start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				start ++;
			}
		}

		int start = start_find;
		while (true)
		{		
			start = code.indexOf("\"", start);
			int end=code.indexOf("\"", start + 1);
			//start=
			//Log.i("前",start+"");
			//Log.i("后",end+"");
			if (start == -1)break;
			if (end != -1)
			{
				mSpannable.setSpan(new ForegroundColorSpan(0xffff0000), start, end + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				start = end + 1;
			}
			else
			{
				end = code.indexOf("\n", start);
				if (end != -1)
				{
					mSpannable.setSpan(new ForegroundColorSpan(0xffff4081), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				else
				{
					end = code.length();
					mSpannable.setSpan(new ForegroundColorSpan(0xffff4081), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				start = end + 1;
			}
			if(end+1>=end_find)break;
		}
		System.out.println(System.currentTimeMillis()-timestart);
    }
	
	public boolean isNun_or_Abc(char c)
	{
        return (c > 'a' && c < 'z') || (c > 'A' && c < 'Z') || (c > '0' && c < '9');
    }

	public boolean isAbc(char c)
	{
		return (c > 'a' && c < 'z') || (c > 'A' && c < 'Z');
	}

}
