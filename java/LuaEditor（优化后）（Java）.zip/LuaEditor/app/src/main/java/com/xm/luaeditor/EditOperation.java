package com.xm.luaeditor;

import android.os.*;
import android.text.*;
import android.widget.*;
import java.io.*;

class EditOperation
 {
    //原始内容，通常是被删除的部分
    private String src;
    private int srcStart;
    private int srcEnd;

    //目标内容，通常是输入的部分
    private String dst;
    private int dstStart;
    private int dstEnd;

    EditOperation setSrc(CharSequence src, int srcStart, int srcEnd) {
        this.src = src != null ? src.toString() : "";
        this.srcStart = srcStart;
        this.srcEnd = srcEnd;
        return this;
    }

    EditOperation setDst(CharSequence dst, int dstStart, int dstEnd) {
        this.dst = dst != null ? dst.toString() : "";
        this.dstStart = dstStart;
        this.dstEnd = dstEnd;
        return this;
    }

    void undo(EditText text) {
        Editable editable = text.getText();

        int idx = -1;
        if (dstEnd > 0) {//删除目标内容
            editable.delete(dstStart, dstEnd);

            if (src == null) {
                idx = dstStart;
            }
        }
        if (src != null) {//插入原始内容
            editable.insert(srcStart, src);
            idx = srcStart + src.length();
        }
        if (idx >= 0) {//恢复光标位置
            text.setSelection(idx);
        }
    }

    void redo(EditText text) {
        Editable editable = text.getText();

        int idx = -1;
        if (srcEnd > 0) {//删除原始内容
            editable.delete(srcStart, srcEnd);
            if (dst == null) {
                idx = srcStart;
            }
        }
        if (dst != null) {//插入目标内容
            editable.insert(dstStart, dst);
            idx = dstStart + dst.length();
        }
        if (idx >= 0) {//恢复光标位置
            text.setSelection(idx);
        }
    }
}     
