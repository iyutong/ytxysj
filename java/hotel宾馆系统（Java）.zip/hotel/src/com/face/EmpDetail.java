/**
 * ��ʾԱ������ϸ��Ϣ
 */
package com.face;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;

public class EmpDetail extends JDialog implements ActionListener
{

	public void actionPerformed(ActionEvent arg0)
	{

	}

}
