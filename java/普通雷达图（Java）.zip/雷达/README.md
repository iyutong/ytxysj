# Android-RadarView

------

##介绍

雷达图，类似支付宝芝麻分解读，王者荣耀对战资料图。

##效果图

<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/1.jpg" width="240px" height="427px" />
<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/2.jpg" width="240px" height="427px" />
<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/3.jpg" width="240px" height="427px" />

<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/4.jpg" width="240px" height="427px" />
<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/5.jpg" width="240px" height="427px" />
<img src="https://github.com/jeanboydev/Android-RadarView/blob/master/resources/6.jpg" width="240px" height="427px" />



## 关于我

* Mail: jeanboy@foxmail.com

## License

    Copyright 2015 jeanboy

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.


 [1]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/1.jpg
 [2]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/2.jpg
 [3]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/3.jpg
 [4]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/4.jpg
 [5]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/5.jpg
 [6]:https://github.com/jeanboydev/Android-RadarView/blob/master/resources/6.jpg


