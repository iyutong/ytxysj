package com.mycompany.myapp6;

import android.app.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	TextView 测试;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
 测试=(TextView) findViewById(R.id.测试);
		测试.setText(h("/110110101001011/1000101111010101",2));}//进制数为2
	public static String h(String r4_String, int r5i)
	{
		String r1_String = "";
		String[] r2_String_A = r4_String.split("/");
		int r0i = 1;
		while (r0i < r2_String_A.length)
		{
			r1_String = new StringBuffer().append(r1_String).append((char) Integer.parseInt(r2_String_A[r0i], r5i)).toString();
			r0i++;
		}
		return r1_String;
	}//调用进制方法
}


