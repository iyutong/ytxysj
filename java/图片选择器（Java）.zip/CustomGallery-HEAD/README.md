# CustomGallery

图片选择器的demo

参考博客链接http://blog.csdn.net/lmj623565791/article/details/39943731
