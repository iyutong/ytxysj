package com.example.testproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<bean>beans=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        init();//初始化；
        ListAdapter listAdapter=new ListAdapter(MainActivity.this,R.layout.item,beans);
        Mylistview mylistview=findViewById(R.id.list);
        mylistview.setAdapter(listAdapter);


    }
    public void init(){
        for(int i=0;i<15;i++){
            bean item1=new bean("UI客栈聊天群","欢迎你的加入",R.mipmap.ic_launcher);
            beans.add(item1);
        }
    }
    class ListAdapter extends ArrayAdapter<bean>{
        private int resid;

        public ListAdapter(@NonNull Context context, int resource,List<bean>objects) {
            super(context, resource,objects);
            resid=resource;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            bean beans=getItem(position);
            View view= LayoutInflater.from(getContext()).inflate(resid,parent,false);
            ImageView imageView=view.findViewById(R.id.image);
            TextView textView=view.findViewById(R.id.text11);
            TextView textView1=view.findViewById(R.id.text22);
            imageView.setImageResource(beans.getImageId());
            textView.setText(beans.getName());
            textView1.setText(beans.getContent());
            return view;

        }
    }
}