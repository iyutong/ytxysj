package xp.xm.hookbilibili;
import android.content.*;
import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.*;
import android.view.*;

public class HookBiliBili implements IXposedHookLoadPackage
{

	@Override
	public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable
	{
		// TODO: Implement this method
		if (lpparam.packageName.equals("tv.danmaku.bili")||lpparam.packageName.equals("com.bilibili.app.in"))
		{
			XposedBridge.log("开始Hook 哔哩哔哩");
			XposedHelpers.findAndHookMethod(lpparam.classLoader.loadClass("bl.bbp"), "e", "com.bilibili.bangumi.api.uniform.BangumiUniformSeason", new XC_MethodHook(){
					@Override
					protected void beforeHookedMethod(MethodHookParam param)
					{
						param.setResult(true);
					}
					@Override
					protected void afterHookedMethod(MethodHookParam param)
					{

					}
				});

			XposedHelpers.findAndHookMethod(lpparam.classLoader.loadClass("bl.bbp"), "b", Context.class, "com.bilibili.bangumi.api.uniform.BangumiUniformSeason", new XC_MethodHook(){
					@Override
					protected void beforeHookedMethod(MethodHookParam param)
					{
				 		param.setResult(true);
					}
					@Override
					protected void afterHookedMethod(MethodHookParam param)
					{

					}
				});
				
				
			XposedHelpers.findAndHookMethod(lpparam.classLoader.loadClass("bl.bco"), "a", "tv.danmaku.videoplayer.basic.context.PlayerParams", int.class,boolean.class, new XC_MethodHook(){
					@Override
					protected void beforeHookedMethod(MethodHookParam param)
					{
				 		param.args[2]=true;
					}
					@Override
					protected void afterHookedMethod(MethodHookParam param)
					{

					}
				});
				
		}	
	}

}
