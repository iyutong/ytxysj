package com.myxu;

import android.os.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.appcompat.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;

import android.support.v7.appcompat.R;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

	private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		toolbar = (Toolbar) findViewById(R.id.toolbar);
		toolbar.setTitle("哈哈哈哈");
		setSupportActionBar(toolbar);

		final DrawerLayout mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close);
        mDrawerToggle.syncState();//初始化状态
        mDrawerLayout.setDrawerListener(mDrawerToggle);


		NavigationView mNavigationView = (NavigationView) findViewById(R.id.nav_view);
        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
				@Override
				public boolean onNavigationItemSelected(MenuItem menuItem) {
					switch (menuItem.getItemId()) {
						case R.id.a:
							Toast.makeText(MainActivity.this,"毒皇",0).show();
							break;
					}
					mDrawerLayout.closeDrawers();//关闭抽屉
					return true;
				}
			});
	}
	
}


