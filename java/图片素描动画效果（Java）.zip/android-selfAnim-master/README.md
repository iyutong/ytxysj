# android-selfAnim

实现android素描动画效果，不是我写滴，是参考：<a href="http://blog.csdn.net/huachao1001/article/details/51518322">Android自动手绘，圆你儿时画家梦！</a>，做了一些优化和改动

![image](https://github.com/yipianfengye/android-selfAnim/blob/master/images/mygif.gif)
