package com.xiaoheng.activitydonghua;

import android.app.*;
import android.os.*;
import android.view.*;

public class xiaohengactivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// 待办事项：实现这个方法
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaohengbuju);
	}
	
}
