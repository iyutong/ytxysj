package com.xiaoheng.activitydonghua;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		/*说明
		overridePendingTransition(R.anim.xiaoheng1,R.anim.xiaoheng5);
		xiaoheng1是进入界面动画
		xiaoheng5是结束界面动画
		即前面的是进入动画，后面的是截取动画*/
		
		final EditText edittext1=(EditText)findViewById(R.id.mainEditText1);
		final EditText edittext2=(EditText)findViewById(R.id.mainEditText2);
		Button button=(Button)findViewById(R.id.mainButton1);
		
		button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// 待办事项：实现这个方法
					String et1=edittext1.getText().toString();
					String et2=edittext2.getText().toString();
					String a=("xiaoheng"+et1);
					String b=("xiaoheng"+et2);
					//Toast.makeText(MainActivity.this,a,Toast.LENGTH_SHORT).show();
					overridePendingTransition(R.anim.xiaoheng18,R.anim.xiaoheng12);
				}
			});
		
		
    }
}


/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/