/*
 * Copyright (c) 2013 Tah Wei Hoon.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Apache License Version 2.0,
 * with full text available at http://www.apache.org/licenses/LICENSE-2.0.html
 *
 * This software is provided "as is". Use at your own risk.
 */

package com.myopicmobile.textwarrior.common;


/**
 * Off-black on off-white background color scheme
 */
import android.graphics.*;

public class ColorSchemeLight extends ColorScheme
 {

	public ColorSchemeLight(){
		setColor(Colorable.FOREGROUND, Color.parseColor("#218868"));
		setColor(Colorable.BACKGROUND, OFF_BLACK);
		setColor(Colorable.SELECTION_FOREGROUND, OFF_WHITE);
		setColor(Colorable.CARET_FOREGROUND, OFF_WHITE);
		setColor(Colorable.KEYWORD,Color.RED);
	}

	private static final int OFF_WHITE = 0xFFF0F0ED;
	private static final int OFF_BLACK = 0xFF333333;
	private static final int Mine=0xff809c4f;
	@Override
	public boolean isDark() {
		return false;
	}
}
