


package com.mycompany.myapp;

import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import com.kingsatuo.view.*;
import com.myopicmobile.textwarrior.android.*;

import android.support.v7.widget.Toolbar;


public class JsEditorAc extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener
{
private FreeScrollingTextField b;
private JSEditor js;

	@Override
	public boolean onNavigationItemSelected(MenuItem p1)
	{
		// TODO: Implement this method
		return false;
	}
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.js_editor);
		getWindow().setStatusBarColor(Color.parseColor("#218868"));
js=(JSEditor) findViewById(R.id.jseditor);
//部分源码来自LingSaTuo(已授权)
//设置编辑器载入时的文字
//编辑器提示的东西(var ,变量什么的)在Editor/app/src/main/java/com/myopicmobile/textwarrior/common/ThemeLanguage.java里。
js.setText("var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();"+"\n"+"\n");

		//设置编辑器是否为黑夜模式(注意，这个编辑器黑夜和白天弄反了，所以填false设置为黑夜，填true设置为白日。其实两种模式唯一不一样的地方，就是背景色不一样(滑稽))
		 js.setDark(false);
		 
		Toolbar toolbar=(Toolbar) findViewById(R.id.toolbarss);
		toolbar.setTitle ("编辑器");
		//设置toolbar颜色
		toolbar.setTitleTextColor (Color.parseColor ("#ffffff"));
		//添加toolbar
		setSupportActionBar(toolbar);
		
		//toolbar添加返回按钮
		getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
		//返回按钮点击事件
		toolbar.setNavigationOnClickListener (new View.OnClickListener () {
				@Override
				public void onClick (View view)
				{
					//退出
					finish ();
				}
			});
		
		 
		
		
		
	}

	
	private Activity activity;

		
		
		
	
		}
		
