package com.myopicmobile.textwarrior.common;

/**
 * Created by Administrator on 2017/12/1.
 */

public class ThemeLanguage extends Language {
    private static Language _theOne = null;
    /*private final String DEFAULT = "SNS.H";
    private final String KEYWORDS = "BREAK|CASE|CATCH|CLASS|CONST|CONTINUE|DEBUGGER|DEFAULT|DELETE|DO|ELSE|EXPORT|EXTEDNS|FINALLY|" +
            "FOR|FUNCTION|IF|IMPORT|IN|INSTANCEOF|NEW|RETURN|SUPER|SWITCH|THIS|THROW|TRY|TYPEOF|VAR|VOID|WHILE|LET|WITH|YIELD|LIBS_INTHIS|" +
            "TRUE|FALSE|NULL|UNDEFINED";
    private final String PARENTHESES = "LPAREN|RPAREN|LBRACE|RBRACE|LBRACK|RBRACK|SEMICOLON|COMMA|DOT|EQ|SPACE|DIV|GT|" +
            "LT|NOT|COMP|QUESTION|AT|COLON|PLUS|MINUS|MULT|DIV|AND|OR|XOR|MOD";

    private final String OTHER = "INTEGER_LITERAL|FLOATING_POINT_LITERAL|COMMENTS|STRING_LITERAL|IDENTIFIER|EOF|VARNAME|FUNCTIONNAME";
    private final String EDITOR = "CARET_DISABLED|CARET_BACKGROUND|CARET_FOREGROUND|SELECT_BACKGROUND|SELECT_TEXT|INPUT_LINE|LINE_NUMBER|BACKGROUND|DEFAULT_TEXT";*/
    private final String[] KEY = {"SNS.H",
            "Block","Item",".2018-GoodYear-China","Thanks King、ST","print","Android",
             "break","case","catch","class","const",
            "continue","debugger","default","delete","do",
            "else","export","extends","finally","for",
            "function","if","import","in","instanceof",
            "new","return","final","in","float",
            "for","super","switch","this",
            "throw","try","typeof","var","void",
            "while","let","with","yield",
            "true","false","null","undefined",
			"EMM","HOME","com.mojang.minecraftpe.MainActivity.currentMainActivity.get();"};
    public static Language getInstance(){
        if(_theOne == null){
            _theOne = new ThemeLanguage();
        }
        return _theOne;
    }
    private ThemeLanguage(){
        setKeywords(new String[]{});
        super.setNames(KEY);
	   }

    public boolean isLineAStart(char c){
        return false;
    }
}
