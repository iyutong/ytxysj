package com.myopicmobile.textwarrior.common;

/**
 * Created by Administrator on 2017/12/2.
 */

public interface To {
    boolean T(Object obj);
}
