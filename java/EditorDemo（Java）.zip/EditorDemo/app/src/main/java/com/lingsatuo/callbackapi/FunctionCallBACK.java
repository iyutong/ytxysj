package com.lingsatuo.callbackapi;

/**
 * Created by Administrator on 2017/11/17.
 */

public interface FunctionCallBACK {
    void T(Object object);
}
