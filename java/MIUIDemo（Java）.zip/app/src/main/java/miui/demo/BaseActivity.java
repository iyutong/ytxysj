package miui.demo;
import android.os.Bundle;
import miui.app.Activity;

public class BaseActivity extends Activity {

    @Override
    protected void onCreate(Bundle p1) {
        MiuiUtil.setMiuiTheme(this,R.style.Empty);
        super.onCreate(p1);
    }
    
}
