package miui.demo;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import miui.os.SystemProperties;

public class MiuiUtil {

    public static boolean isMiuiSystem() {
        try {
            Class.forName("miui.os.Build");
            return true;
        } catch (ClassNotFoundException e) {    
            return false;
        }
    }

    public static void setMiuiTheme(Activity act, int overrideTheme) {
        setMiuiTheme(act, overrideTheme, false);
    }

    public static void setMiuiTheme(Activity act, int overrideTheme, boolean noBackground) {
        int themeResId = 0;
        try { themeResId = act.getResources().getIdentifier("Theme.DayNight", "style", "miui"); } catch (Throwable t) {}
        if (themeResId == 0) themeResId = act.getResources().getIdentifier(isNightMode(act) ? "Theme.Dark" : "Theme.Light", "style", "miui");
        act.setTheme(themeResId);
        //if (!Helpers.is11()) act.getTheme().applyStyle(R.style.ActivityAnimation10, true);
        act.getTheme().applyStyle(overrideTheme, true);
        act.getWindow().setBackgroundDrawable(noBackground ? null : new ColorDrawable(getSystemBackgroundColor(act)));
    }

    public static int getSystemBackgroundColor(Context context) {
        int black = Color.BLACK;
        int white = Color.WHITE;
        try {
            black = context.getResources().getColor(context.getResources().getIdentifier("black", "color", "miui"), context.getTheme());
            white = context.getResources().getColor(context.getResources().getIdentifier("white", "color", "miui"), context.getTheme());
        } catch (Throwable ignore) {}
        return isNightMode(context) ? black : white;
    }


    public static boolean is11() {
        return SystemProperties.getInt("ro.miui.ui.version.code", 8) >= 9;
    }

    public static boolean isNightMode(Context context) {
        return (context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

}

