package miui.demo;
 
//import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import miui.app.Activity;
import miui.app.AlertDialog;

public class MainActivity extends BaseActivity { 
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showDialog();
    }

    private void showDialog() {
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("标题")
            .setMessage("内容")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dia, int which) {

                }
            })
            .setNegativeButton("取消", null)
            .create();
        dialog.show();
    }
	
} 
