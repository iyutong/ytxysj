package com.mycompany.myvideo.adap;

public interface OnBottomListener {
    public void onBottom();
}
