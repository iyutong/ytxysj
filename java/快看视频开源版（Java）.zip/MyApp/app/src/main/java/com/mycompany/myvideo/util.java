package com.mycompany.myvideo;
import android.net.Uri;

public class util
{
	public static String id;
}
