/** Automatically generated file. DO NOT MODIFY */
package com.example.zz_doctor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}