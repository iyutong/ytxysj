/** Automatically generated file. DO NOT MODIFY */
package efan.zz.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}