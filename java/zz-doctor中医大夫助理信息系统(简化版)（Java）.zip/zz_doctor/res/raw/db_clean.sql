drop table if exists MAP_RX_RECIPE_MEDICINE;
drop table if exists MAP_MEDICINE_SYNERGIST;
drop table if exists MEDICINE;
drop table if exists RX_RECIPE;
drop table if exists MAP_SYNDROME_DISEASE;
drop table if exists DISEASE;
drop table if exists SYNDROME_SUBJECT;
