/*
 * Copyright 2009 eFANsoftware
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package efan.zz.android.common.android;

import efan.zz.android.ZZ;
import android.content.Context;
import android.widget.AutoCompleteTextView;

/**
 * Tricky class to bypass AutoCompleteTextView combine ArrayAdapter not sharable
 * bug/problem
 */

//�Զ�ƥ���ʶ����Ϣ
public class IdentifiedAutoCompleteTextView extends AutoCompleteTextView
{
	private int valueId;

	public IdentifiedAutoCompleteTextView(Context context)
	{
		super(context);
	}

	public int getValueId()
	{
		return valueId;
	}

	public void setValueId(int valueId)
	{
		this.valueId = valueId;
	}

	@Override
	public void showDropDown()
	{
		ZZ.inputMethodMgr.hideSoftInputFromWindow(this.getWindowToken(), 0);
		super.showDropDown();
	}
}
