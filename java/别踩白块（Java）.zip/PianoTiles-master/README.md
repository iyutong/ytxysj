# PianoTiles
don't touch white block  别踩方块儿游戏   基于SurfaceView

基于Android SurfaceView开发~跟原生的区别还是蛮大的，只是突发奇想练练手~
![](https://github.com/ZeeeeeeNo/PianoTiles/blob/master/pianoTiles.gif)
