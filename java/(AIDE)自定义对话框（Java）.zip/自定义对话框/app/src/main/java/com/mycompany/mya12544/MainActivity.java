package com.mycompany.mya12544;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button button=(Button)findViewById(R.id.mainButton);
		button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					MyDialog myDialog =new MyDialog(MainActivity. this,"我是自定义对话框");
					myDialog.show();
					
					
				}
			});
    }
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/