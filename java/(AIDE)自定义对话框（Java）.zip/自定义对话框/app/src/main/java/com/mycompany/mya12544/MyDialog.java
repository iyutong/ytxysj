package com.mycompany.mya12544;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MyDialog extends Dialog
{
	private String dialogName;
	private TextView tvMsg;
	private Button btnOK;
	private Button btnCancel;
	public MyDialog(Context context , String dialogName)
	{
		super(context);
		this.dialogName = dialogName;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		
		
		super .onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.my_dialog);//引入自定义对话框布局
		
		tvMsg=(TextView) findViewById(R.id.tv_msg);
		btnOK=(Button)findViewById(R.id.btn_ok);
		btnCancel=(Button)findViewById(R.id.btn_cancel);
		tvMsg.setText(dialogName);//设置自定义对话框显示内容
		
		btnOK.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View v)
				{
					//startMyDialog(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
					
				//Toast.makeText(getContext(),"你点击了确定",Toast.LENGTH_SHORT).show();
				
				}});
			
		btnCancel.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View v)
				{
					dismiss();
				}
			});
	}
	
}
