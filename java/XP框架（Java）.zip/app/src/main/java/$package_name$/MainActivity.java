package $package_name$;

import android.app.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity{
    
	
    @Override
	protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		if(激活()){
			setTitle("xposed模块:已激活");
		}else{
			setTitle("xposed模块:未激活");
		}Toast.makeText(MainActivity.this,变量(),Toast.LENGTH_SHORT).show();
		
		
	}

	private String 变量()
	{
		return "未被hook";
	}

	private boolean 激活()
	{
		return false;
	}
	
		
		}