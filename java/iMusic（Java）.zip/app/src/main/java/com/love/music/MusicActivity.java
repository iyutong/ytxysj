package com.love.music;
import android.support.v7.app.*;
import android.os.*;
import java.io.*;
import java.util.*;
import android.widget.*;
import android.media.*;
import android.view.*;
import android.view.KeyEvent.*;
import java.text.*;
import android.text.method.*;
import android.content.*;
import android.database.*;
import android.provider.*;
import android.app.*;

public class MusicActivity extends AppCompatActivity
{

	private ArrayList<String> mDatas;

	private ListView mListView;

	private MediaPlayer mMediaPlayer;
	
	private int currIndex;

	private SeekBar mSeekBar;

	private TextView currTime,totalTime;
	
	private static final int INTERNAL_TIME = 1000;//音乐进度间隔时间
	
	private Handler mHandler = new Handler(new Handler.Callback() {
		@Override
		public boolean handleMessage(Message msg) {
			//展示给进度条和当前时间
			int progress = mMediaPlayer.getCurrentPosition();
			mSeekBar.setProgress(progress);
			currTime.setText(parseTime(progress));
			//继续定时发送数据
			updateProgress();
			return true;
		}
	});

	private TextView mTextView;

	private long exitTime;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_music);
		mDatas = new ArrayList<String>();
		myMusic();
		//判断集合是否为空
		if (mDatas.isEmpty()) {//若集合为空，则加载另一个布局文件
			setContentView(R.layout.my_music_none);
		}
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(MusicActivity.this, android.R.layout.simple_list_item_1, mDatas);
		mListView = (ListView) findViewById(R.id.mListView);
		mListView.setAdapter(adapter);
		mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				currIndex = position;
				start();
			}
		});
		mMediaPlayer = new MediaPlayer();
		//播完监听
		mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer mMediaPlayer) {
				if (mDatas.size() > 0) {
					next();
				} else {
					Toast.makeText(MusicActivity.this, "播放列表为空", Toast.LENGTH_SHORT).show();
				}
			}
		});
		//错误监听
		mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
			public boolean onError(MediaPlayer mMediaPlayer, int what, int extra) {
				mMediaPlayer.reset();
				return false;
			}
		});
		mSeekBar = (SeekBar) findViewById(R.id.mSeekBar);
		mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				
			public void onProgressChanged(SeekBar mSeekBar, int progress, boolean fromUser) {

			}

			public void onStartTrackingTouch(SeekBar mSeekBar) {
				
			}

			public void onStopTrackingTouch(SeekBar mSeekBar) {
				int progress = mSeekBar.getProgress();
				mMediaPlayer.seekTo(progress);
			}
		});
		currTime = (TextView) findViewById(R.id.curr_time);
		totalTime = (TextView) findViewById(R.id.total_time);
		mTextView = (TextView) findViewById(R.id.mTextView);
	}
	private void myMusic() {
		//获取sdcard/Music目录
		File file = new File("/sdcard/Music");
		//创建过滤器对象
		FilenameFilter filter = new FilenameFilter() {
			//实现accept()方法
			public boolean accept(File dir,String name) {
				File currFile = new File(dir,name);
				//如果文件名以.mp3、.flac的结尾则返回true，否则返回false
				if (currFile.isFile() && name.endsWith(".mp3") || name.endsWith(".flac") || name.endsWith(".ape")) {
					return true;
				} else {
					return false;
				}
			}
		};
		if (file.exists()) {
			String[] lists = file.list(filter);
			for (String name: lists) {
				mDatas.add(name);
			}
		}
	}
	//开始播放
	private void start() {
		if (mDatas.size() > 0 && currIndex < mDatas.size()) {
			String path = mDatas.get(currIndex);
			mMediaPlayer.reset();
			try
			{
				mMediaPlayer.setDataSource("/sdcard/Music/" + path);
				mMediaPlayer.prepare();
				mMediaPlayer.start();
				seekbar();
				mTextView.setText(mDatas.get(currIndex));
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Toast.makeText(this, "列表为空！", Toast.LENGTH_SHORT).show();
		}
	}
	//下一首
	private void next() {
		if (currIndex + 1 < mDatas.size()) {
			currIndex ++;
			start();
		} else {
			Toast.makeText(this, "已经是最后一首了！", Toast.LENGTH_SHORT).show();
		}
	}
	//切歌时重置进度条并展示歌曲时长
	private void seekbar() {
		mSeekBar.setProgress(0);
		mSeekBar.setMax(mMediaPlayer.getDuration());
		totalTime.setText(parseTime(mMediaPlayer.getDuration()));
		updateProgress();
	}
	//每间隔1s通知更新进度
	private void updateProgress() {
		Message msg = Message.obtain();
		mHandler.sendMessageDelayed(msg, INTERNAL_TIME);
	}
	//解析时间
	private String parseTime(int oldTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");//时间格式
		String newTime = sdf.format(new Date(oldTime));
		return newTime;
	}
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
			mMediaPlayer.stop();
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
	}

	//再按一次返回键退出程序
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
			if (System.currentTimeMillis()-exitTime > 2000) {
				Toast.makeText(this, "再按一次返回键退出", Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				finish();
				System.exit(0);
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
