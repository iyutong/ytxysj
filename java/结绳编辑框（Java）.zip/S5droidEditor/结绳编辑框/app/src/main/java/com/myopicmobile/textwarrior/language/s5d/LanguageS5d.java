package com.myopicmobile.textwarrior.language.s5d;

import android.content.Context;

import com.myopicmobile.textwarrior.base.BaseCodeTree;
import com.myopicmobile.textwarrior.base.BaseLanguage;
import com.myopicmobile.textwarrior.base.BaseLexer;
import com.myopicmobile.textwarrior.bean.Navigation;
import com.myopicmobile.textwarrior.common.DocumentProvider;
import com.myopicmobile.textwarrior.language.sly.LexerSly;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LanguageS5d extends BaseLanguage {

    private static LanguageS5d mLanguage = null;
    private static LexerS5d mLexer = null;
    private BaseCodeTree mLocalVar = new BaseCodeTree();
    protected HashMap<String, String[]> mEventMap = new HashMap<>();

    //关键词
    private final static String[] keywords = {
            "变量", "常量", "定义", "为", "文本型", "整数型", "字节型", "字符型", "从", "引入",
            "逻辑型", "浮点数型", "双精度型", "长整数型", "对象", "静态", "创建", "返回",
            "结束", "事件", "方法", "循环", "判断", "分支", "如果", "则", "否则", "又如果",
            "步进", "步退", "容错处理", "俘获", "容错", "计次循环", "变量循环",
            "判断循环", "遍历循环", "且", "或", "至", "真", "假", "空", "从属于", "断言",
            "本对象", "跳出", "跳过", "类", "继承", "枚举", "构造方法", "属性读", "属性写",
            "属性", "接入", "定义事件", "挂接事件", "父对象", "原生", "布局",
            "静态处理", "处理", "虚拟方法", "覆写方法", "保留","私有"};

    //基本操作
    private final static String[] basicTools = {
            "应用操作", "文本操作", "文件操作", "上下文操作", "对话框", "进度对话框", "线程", "定时器", "时钟",
            "位运算", "媒体操作", "拼音操作", "数据库操作", "数组操作", "时间操作", "正则表达式", "算术运算", "字符操作",
            "音量操作", "颜色值操作", "像素单位操作", "加解密操作", "压缩操作", "存储卡操作", "系统操作", "反射操作",
            "转换操作", "共享数据", "哈希表", "集合", "网络操作", "组件容器", "事件监听器", "适配器", "JSON操作",
            "事件监听器", "R", "ROOT操作", "编码操作", "类型值_集合", "类型值_哈希表", "控制台", "后台服务",
            "广播"
    };

    //基本定义常量
    private final static String[] basicConstant = {
            "返回键", "HOME键", "回车键", "菜单键", "音量增键", "音量减键",
            "从左往右", "从右往左", "淡入淡出", "淡出淡入", "浅灰", "深灰",
            "灰色", "紫色", "品红", "红色", "绿色", "蓝色", "青绿", "黄色",
            "黑色", "白色", "无色", "中间", "顶部", "底部", "左边", "右边",
            "横屏", "竖屏", "文件排序_时间排序", "文件排序_名称排序",
            "文件排序_大小排序", "音量类型_媒体音量", "音量类型_闹钟音量",
            "音量类型_铃声音量", "音量类型_通话音量", "音量类型_通知音量",
            "音量类型_系统音量", "音量类型_双音多频音量", "滚动状态_结束滚动",
            "滚动状态_触摸滚动", "滚动状态_手指离开屏幕仍在滚动"
    };

    private final static char[] BASIC_S5d_OPERATORS = {
            '(', ')', '{', '}', '.', ',', ';', '=', '+', '-',
            '/', '*', '&', '!', '|', ':', '[', ']', '<', '>',
            '?', '~', '%', '^'
    };

    public void addBaseEvent(String name, String[] names) {
        addUserWord(name);
        updateUserWord();
        if (!mEventMap.containsKey(name)) {
            mEventMap.put(name, names);
        }
    }

    public final boolean hasBaseEvent(String s) {
        return mEventMap.containsKey(s);
    }

    public String[] getBaseEvent(String name) {
        return mEventMap.get(name);
    }

    @Override
    public String[] getKeywords() {
        return keywords;
    }

    @Override
    public LexerS5d getLexer() {
        return (LexerS5d) super.getLexer();
    }

    public static LanguageS5d getInstance() {
        if (mLanguage == null) {
            mLanguage = new LanguageS5d();
        }
        if (mLexer == null) {
            mLexer = new LexerS5d();
        }
        mLanguage.setLexer(mLexer);
        return mLanguage;
    }

    @Override
    public CharSequence format(CharSequence sequence) {
        CharSequence text = null;
        S5dFormatter formatter = new S5dFormatter(sequence.toString());
        try {
            formatter.format();
            String msg = formatter.getErrorMessage();
            if (msg.equals("无错误")) {
                text = formatter.getResult();
            } else {
                System.err.println(msg);
                text = sequence;
            }
        } catch (IOException e) {
            text = sequence;
            e.printStackTrace();
        }
        return text;
    }

    private LanguageS5d() {
        setOperators(BASIC_S5d_OPERATORS);
        for (int i = 0; i < keywords.length; i++) {
            keywords[i] = keywords[i] + "@[关键字]";
        }
        setKeywords(keywords);
        setNames(basicConstant);//先setNames才能addNames
        addNames(basicTools);
    }
}
