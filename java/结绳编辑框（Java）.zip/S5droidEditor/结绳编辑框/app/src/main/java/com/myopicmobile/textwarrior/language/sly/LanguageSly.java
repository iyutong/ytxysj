package com.myopicmobile.textwarrior.language.sly;

import com.myopicmobile.textwarrior.base.BaseLanguage;
import com.myopicmobile.textwarrior.language.java.LexerJava;
import com.myopicmobile.textwarrior.language.s5d.LanguageS5d;
import com.myopicmobile.textwarrior.language.s5d.LexerS5d;

public class LanguageSly extends BaseLanguage {

    private static LanguageSly mLanguage = null;
    private static LexerSly mLexer = null;

    private final static String[] keywords = {
		"id","名称"
    };

    private final static String[] basicNames = {
		"高度","宽度","内边距","外边距","左内边距","上内边距","右内边距",
		"下内边距","左外边距","上外边距","右外边距","下外边距","X坐标","Y坐标",
		"X偏移","Y偏移","可视","可用","可停留焦点"
    };

    private final static char[] BASIC_Java_OPERATORS = {
	    '{', '}', '.', ',', '=', '-'
    };
    public static LanguageSly getInstance() {
        if (mLanguage == null) {
            mLanguage = new LanguageSly();
        }
        if (mLexer == null) {
            mLexer = new LexerSly();
        }
        mLanguage.setLexer(mLexer);
        return mLanguage;
    }
    private LanguageSly() {
        setOperators(BASIC_Java_OPERATORS);
        setKeywords(keywords);
        setNames(basicNames);//先setName才能addName
    }
}
