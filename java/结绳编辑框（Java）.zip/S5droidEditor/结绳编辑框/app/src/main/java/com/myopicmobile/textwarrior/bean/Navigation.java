package com.myopicmobile.textwarrior.bean;

public class Navigation {

    public int line;

    public String text;

    public Navigation(int line, String text) {
        this.line = line;
        this.text = text;
    }

}
