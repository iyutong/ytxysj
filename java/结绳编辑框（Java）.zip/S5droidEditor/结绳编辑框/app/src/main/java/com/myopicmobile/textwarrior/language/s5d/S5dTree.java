package com.myopicmobile.textwarrior.language.s5d;

import com.myopicmobile.textwarrior.base.BaseCodeTree;

public class S5dTree extends BaseCodeTree {
}
