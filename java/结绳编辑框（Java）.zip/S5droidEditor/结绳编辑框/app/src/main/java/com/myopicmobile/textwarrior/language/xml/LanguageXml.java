package com.myopicmobile.textwarrior.language.xml;

import com.myopicmobile.textwarrior.base.BaseLanguage;
import com.myopicmobile.textwarrior.language.s5d.LanguageS5d;
import com.myopicmobile.textwarrior.language.s5d.LexerS5d;
import com.myopicmobile.textwarrior.language.sly.LexerSly;

public class LanguageXml extends BaseLanguage {

    private static LanguageXml mLanguage = null;
    private static LexerXml mLexer = null;

    private final static String[] keywords = {
		"activity","manifest","application"
    };

    private final static String[] basicNames = {
		"intent-filter","meta","style"
    };

    private final static char[] BASIC_Java_OPERATORS = {
	    '<', '/', '>', '=', '-'
    };
    public static LanguageXml getInstance() {
        if (mLanguage == null) {
            mLanguage = new LanguageXml();
        }
        if (mLexer == null) {
            mLexer = new LexerXml();
        }
        mLanguage.setLexer(mLexer);
        return mLanguage;
    }
    private LanguageXml() {
        setOperators(BASIC_Java_OPERATORS);
        setKeywords(keywords);
        setNames(basicNames);//先setName才能addName
    }
}
