package com.myopicmobile.textwarrior.interfaces;

public interface SelectionModeListener {
	
	public void onSelectionModeChanged(boolean active);
	
}
