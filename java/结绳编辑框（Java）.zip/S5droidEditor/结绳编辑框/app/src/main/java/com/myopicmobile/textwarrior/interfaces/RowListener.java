package com.myopicmobile.textwarrior.interfaces;

public interface RowListener {
	public void onRowChange(int newRowIndex);
}
