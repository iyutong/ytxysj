package com.myopicmobile.textwarrior.language.sly;

import android.graphics.Rect;

import com.myopicmobile.textwarrior.bean.BlockLine;
import com.myopicmobile.textwarrior.language.CharSeqReader;
import com.myopicmobile.textwarrior.common.DocumentProvider;
import com.myopicmobile.textwarrior.base.BaseLanguage;
import com.myopicmobile.textwarrior.common.Pair;
import com.myopicmobile.textwarrior.base.BaseLexer;
import com.myopicmobile.textwarrior.language.java.JavaLexer;
import com.myopicmobile.textwarrior.language.java.JavaType;
import com.myopicmobile.textwarrior.language.s5d.S5dType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LexerSly extends BaseLexer {

    public LexerSly() {
        super();
    }

    @Override
    protected List<Pair> requestTokenize() {
        DocumentProvider doc = getDocument();
        BaseLanguage lang = getLanguage();
        ArrayList<Pair> tokens = new ArrayList<>(8196);
        ArrayList<BlockLine> lines = new ArrayList<>(8196);
        ArrayList<BlockLine> lineStacks = new ArrayList<>(8196);
        if (!lang.isProgLang()) {
            tokens.add(new Pair(0, NORMAL));
            super.setBlockLines(lines);
            return tokens;
        }
        JavaLexer lexer = new JavaLexer(new CharSeqReader(doc));
        lang.clearUserWord();
        int idx = 0;
        String markedText = null;
        JavaType markedType = null;
        JavaType type = null;
        while (true) {
            try {
                type = lexer.yylex();
                if (type == JavaType.EOF) {
                    break;
                }
                switch (type) {
					case LBRACE:
                        lineStacks.add(new BlockLine(lexer.yyLine(), lexer.yyLine(), lexer.yychar(), lexer.yychar()));
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case RBRACE:
                        int size = lineStacks.size();
                        if (size > 0) {
                            BlockLine line = lineStacks.remove(size - 1);
                            line.endLine = lexer.yyLine();
                            line.endColumn = lexer.yychar();
                            if (line.endLine - line.startLine > 1) {
                                lines.add(line);
                            }
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
					case NULL_LITERAL:
                    case BOOLEAN_LITERAL:
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case STRING:
                    case CHARACTER_LITERAL:
                        addPairIfNeeded(new Pair(idx, SINGLE_SYMBOL_DELIMITED_A), tokens);
                        break;
                    case MINUS:
                    case INTEGER_LITERAL:
                    case FLOATING_POINT_LITERAL:
                        addPairIfNeeded(new Pair(idx, NUMBER), tokens);
                        break;
                    case IDENTIFIER:
						if (markedType == JavaType.LBRACE || markedType == JavaType.DOT || 
							lexer.yytext().equals("真") || lexer.yytext().equals("假")) {
							addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
						}
						break;
					case DOT:
						if (markedType == JavaType.IDENTIFIER)
							addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
						break;
					case RPAREN:
					case LBRACK://左中括号
					case RBRACK:
					case COMMA://逗号
					case EQ://等号
					case EQEQ:
                    case SEMICOLON:
					case PLUS:
					case MINUSMINUS:
					case PLUSPLUS:
					case DIV:
					case MULT:
					case GT:
					case LT:
					case QUESTION:
					case AND:
					case ANDAND:
					case OROR:
					case OR:
					case XOR:
					case MOD:
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    default:
                        addPairIfNeeded(new Pair(idx, NORMAL), tokens);
                }
                switch (type) {
                    case WHITESPACE:
                        break;
                    case IDENTIFIER:
                        markedType = type;
                        markedText = lexer.yytext();
                        break;
                    default:
                        markedType = type;
                        break;
                }
				idx += lexer.yytext().length();
            } catch (Exception e) {
                e.printStackTrace();
				idx++;
            }
        }
        lang.updateUserWord();
        super.setBlockLines(lines);
        return tokens;
    }

	@Override
	public int autoIndent(S5dType type) {
		// TODO: Implement this method
		return 0;
	}

    @Override
    public int autoIndent(CharSequence text) {
        JavaLexer lexer = new JavaLexer(new CharSeqReader(text));
        int indent = 0;
		int caseCount = 0;
        try {
            JavaType type = null;
            while (true) {
                type = lexer.yylex();
                if (type == JavaType.EOF) {
                    break;
                }
                switch (type) {
                    case LPAREN:
                    case LBRACE:
                        indent++;
                        break;
						/*case RPAREN:
						 case RBRACE:
						 indent--;
						 break;*/
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return indent * 3;
    }

    @Override
    public void onEnabled() {
        super.onEnabled();
        setLanguage(LanguageSly.getInstance());
    }
}
