package com.myopicmobile.textwarrior.language.s5d;

import android.graphics.Color;
import com.myopicmobile.textwarrior.base.BaseLexer;
import com.myopicmobile.textwarrior.bean.BlockLine;
import com.myopicmobile.textwarrior.bean.ColorLine;
import com.myopicmobile.textwarrior.bean.Navigation;
import com.myopicmobile.textwarrior.common.DocumentProvider;
import com.myopicmobile.textwarrior.common.Pair;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class LexerS5d extends BaseLexer {

    private int currentLine = 0;
    private int currentColumn = 0;
    private int currentLength = 0;
    private String currentText = "";

    public LexerS5d() {
        super();
    }

    @Override
    protected List<Pair> requestTokenize() {
        DocumentProvider hDoc = getDocument();
        LanguageS5d language = (LanguageS5d) getLanguage();
        List<Pair> tokens = new ArrayList<>();
        S5dTree tree = new S5dTree();
        TrieTree<S5dType> vars = new TrieTree<>();
        List<String> methods = new ArrayList<>();
        ArrayList<Navigation> navigations = new ArrayList<>();
        ArrayList<BlockLine> lines = new ArrayList<>(1536);
        ArrayList<BlockLine> lineStacks = new ArrayList<>(1536);
        ArrayList<BlockLine> lineStacks2 = new ArrayList<>(1536);
        ArrayList<BlockLine> lineStacks3 = new ArrayList<>(1536);
        ArrayList<ColorLine> colorLines = new ArrayList<>(128);
        ArrayList<String> includes = new ArrayList<>(128);
        if (!language.isProgLang()) {
            tokens.add(new Pair(0, NORMAL));
            super.setBlockLines(lines);
            return tokens;
        }
        String source = hDoc.toString();
        StringBuilder varType = new StringBuilder();
        StringReader stringReader = new StringReader(source);
        S5dLexer lexer = new S5dLexer(stringReader);
        S5dType type = null;
        S5dType markedType = null;
        String name = null;
        int varLine = 0;
        int state = 0;
        int markedSwitchLine = -1;
        int markedStaicColumn = -1;
        int idx = 0;
        language.clearUserWord();
        while (type != S5dType.EOF) {
            try {
                type = lexer.yylex();
                currentLine = lexer.yyLine();
                currentColumn = lexer.yychar();
                currentLength = lexer.yylength();
                currentText = lexer.yytext();
                switch (type) {
                    case IDENTIFIER://标识符
                        boolean add = false;
                        boolean countVar = false;
                        boolean foreachVar = false;
                        if (state == 1) {
                            state = 2;
                            name = source.substring(idx, idx + currentLength);
                        } else if (state == 3) {
                            state = 4;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 5) {
                            state = 4;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 7) {
                            state = 8;
                            add = true;
                            name = source.substring(idx, idx + currentLength);
                        } else if (state == 9) {
                            state = 10;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 11) {
                            state = 10;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 6) {
                            state = 16;
                        } else if (state == 12) {
                            state = 13;
                        } else if (state == 14) {
                            state = 15;
                        } else if (state == 17) {
                            state = 17;
                        } else if (state == 18) {
                            countVar = true;
                            tree.addVariant(currentLine, currentText, "整数型");
                        } else if (state == 19) {
                            foreachVar = true;
                            name = source.substring(idx, idx + currentLength);
                            String lineText = hDoc.getLine(currentLine);
                            tree.addVariant(currentLine, name,
                                    lineText.substring(lineText.indexOf("为") + 1,
                                            lineText.indexOf("从")).trim());
                        } else if (state == 20) {
                            state = 20;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 21) {
                            state = 21;
                        } else if (state == 22) {
                            includes.add(lexer.yytext());
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        int HIGHLIGHT_TYPE = NORMAL;
                        if (markedType == S5dType.AS) {
                            if (state != 21)
                                HIGHLIGHT_TYPE = CLASS;
                        } else if (markedType == S5dType.INSTANCEOF) {
                            HIGHLIGHT_TYPE = CLASS;
                            language.addName(lexer.yytext());
                        } else if (markedType == S5dType.CLAZZ) {
                            HIGHLIGHT_TYPE = CLASS;
                            language.addName(lexer.yytext());
                        } else if (markedType == S5dType.EXTENDZ) {
                            HIGHLIGHT_TYPE = CLASS;
                            language.addName(lexer.yytext());
                            parentClass = lexer.yytext();
                        } else if (markedType == S5dType.IMPLEMENTS) {
                            HIGHLIGHT_TYPE = CLASS;
                            language.addName(lexer.yytext());
                        } else if (markedType == S5dType.VARIANT || add || countVar || foreachVar) {
                            vars.put(source, idx, currentLength, S5dType.VARIANT);
                            HIGHLIGHT_TYPE = VARIANT;
                        } else if (vars.get(source, idx, lexer.yylength()) == S5dType.VARIANT) {
                            HIGHLIGHT_TYPE = VARIANT;
                        } else if (language.isName(lexer.yytext())) {
                            HIGHLIGHT_TYPE = CLASS;
                        }
                        addPairIfNeeded(new Pair(idx, HIGHLIGHT_TYPE), tokens);
                        break;
                    case PROPERTY_GET://属性读
                        String method = hDoc.getLine(currentLine).trim();
                        methods.add(method.substring(method.indexOf(' ') + 1).trim() + "@[属性读]");
                        navigations.add(new Navigation(currentLine, method));
                        state = 12;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case PROPERTY_SET://属性写
                        String method2 = hDoc.getLine(currentLine).trim();
                        methods.add(method2.substring(method2.indexOf(' ') + 1).trim() + "@[属性写]");
                        navigations.add(new Navigation(currentLine, method2));
                        state = 12;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case DEFINE_EVENT://定义事件
                        String method3 = hDoc.getLine(currentLine).trim();
                        methods.add(method3.substring(method3.indexOf(' ') + 1).trim() + "@[事件]");
                        navigations.add(new Navigation(currentLine, method3));
                        state = 12;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case CONSTRUCTOR://构造方法
                    case VIRTUALMETHOD://虚拟方法
                    case OVERRIDEMETHOD://覆写方法
                        String method4 = hDoc.getLine(currentLine).trim();
                        methods.add(method4.substring(method4.indexOf(' ') + 1).trim() + "@[方法]");
                        navigations.add(new Navigation(currentLine, method4));
                        state = 12;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case COUNTLOOP://计次循环
                        state = 17;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case FOREACH://遍历循环
                        state = 19;
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case FORLOOP://变量循环
                    case WHILELOOP://判断循环
                    case STATIC_DEAL://静态处理
                    case TRY://容错处理
                        state = 0;
                        varType.setLength(0);
                        tree.enterCodeBlock(currentLine);
                        lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case IF://如果
                    case SIMPLE_TRY://容错
                    case SWITCH://判断
                        state = 0;
                        varType.setLength(0);
                        if (markedType == S5dType.END) {
                            int size = lineStacks.size();
                            if (size > 0) {
                                BlockLine line = lineStacks.remove(size - 1);
                                line.endLine = currentLine;
                                line.endColumn = currentColumn;
                                line.type = BlockLine.TYPE_FLOW_DOWN;
                                if (line.endLine - line.startLine > 1) {
                                    lines.add(line);
                                }
                            }
                            if (type == S5dType.SWITCH) {
                                int size2 = lineStacks2.size();
                                if (size2 > 0) {
                                    BlockLine line = lineStacks2.remove(size2 - 1);
                                    line.endLine = currentLine;
                                    //line.endColumn = currentColumn;
                                    if (line.endLine - line.startLine > 1) {
                                        lines.add(line);
                                    }
                                }
                            }

                            List<S5dTree.Node> nodes = tree.exitCodeBlock(currentLine).children;
                            S5dTree.Node sub;
                            for (int i = 0; i < nodes.size(); i++) {
                                sub = nodes.get(i);
                                if (!sub.isBlock) {
                                    vars.put(sub.varName, null);
                                }
                            }
                        } else {
                            if (type == S5dType.IF || type == S5dType.SWITCH) {
                                tree.enterCodeBlock(currentLine);
                            }
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case LOOP://循环
                        state = 0;
                        if (markedType == S5dType.END) {
                            int size = lineStacks.size();
                            if (size > 0) {
                                BlockLine line = lineStacks.remove(size - 1);
                                line.endLine = currentLine;
                                line.endColumn = currentColumn;
                                line.type = BlockLine.TYPE_FLOW_UP;
                                if (line.endLine - line.startLine > 1) {
                                    lines.add(line);
                                }
                            }
                            List<S5dTree.Node> nodes = tree.exitCodeBlock(currentLine).children;
                            S5dTree.Node sub;
                            for (int i = 0; i < nodes.size(); i++) {
                                sub = nodes.get(i);
                                if (!sub.isBlock) {
                                    vars.put(sub.varName, null);
                                }
                            }
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case CLAZZ://类
                    case ENUMZ://枚举
                    case METHOD://方法
                    case EVENT://事件
                    case PROPERTY://属性
                    case DEAL://处理
                        if (markedType == S5dType.END) {
                            state = 0;
                            varType.setLength(0);
                            int size = lineStacks.size();
                            if (size > 0) {
                                BlockLine line = lineStacks.remove(size - 1);
                                line.endLine = currentLine;
                                line.endColumn = currentColumn;
                                if (line.endLine - line.startLine > 1) {
                                    lines.add(line);
                                }
                            }
                            
                            List<S5dTree.Node> nodes = tree.exitCodeBlock(currentLine).children;
                            S5dTree.Node sub;
                            for (int i = 0; i < nodes.size(); i++) {
                                sub = nodes.get(i);
                                if (!sub.isBlock) {
                                    vars.put(sub.varName, null);
                                }
                            }
                        } else {
                            if (type == S5dType.METHOD || type == S5dType.EVENT) {
                                String mE = hDoc.getLine(currentLine).trim();
                                if (type == S5dType.METHOD)
                                    methods.add(mE.substring(mE.indexOf("方法 ") + 3).trim() + "@[方法]");
                                navigations.add(new Navigation(currentLine, mE.trim()));
                                state = type == S5dType.EVENT ? 6 : 12;
                            } else {
                                state = 0;
                                varType.setLength(0);
                            }
                            tree.enterCodeBlock(currentLine);
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case ELSEIF://又如果
                    case ELSE://否则
                    case CATCH://捕捉
                        int size = lineStacks.size();
                        if (size > 0) {
                            BlockLine line = lineStacks.remove(size - 1);
                            line.endLine = currentLine;
                            line.endColumn = currentColumn;
                            line.type = BlockLine.TYPE_FLOW_DOWN;
                            if (line.endLine - line.startLine > 1) {
                                lines.add(line);
                            }
                            lineStacks.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case LBRACE:// { 到 } 的普通区块划线
                        lineStacks3.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case RBRACE://}
                        int size3 = lineStacks3.size();
                        if (size3 > 0) {
                            BlockLine line = lineStacks3.remove(size3 - 1);
                            line.endLine = currentLine;
                            line.endColumn = currentColumn;
                            line.type = BlockLine.TYPE_NORMAL;
                            if (line.endLine - line.startLine > 1) {
                                lines.add(line);
                            }
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case CASE://分支
                        int size2 = lineStacks2.size();
                        int num = currentLine;
                        if (size2 > 0 && markedSwitchLine != -1 && num - markedSwitchLine != 1) {
                            BlockLine line = lineStacks2.remove(size2 - 1);
                            line.endLine = num;
                            line.endColumn = currentColumn;
                            if (line.endLine - line.startLine > 1) {
                                lines.add(line);
                            }
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case BYTEV://字节型
                    case CHARV://字符型
                    case LONGV://长整数型
                    case DOUBLEV://双精度型
                    case FLOATV://浮点数型
                    case BOOLEANV://逻辑型
                    case INTV://整数型
                    case STRINGV://文本型
                    case OBJECT://对象
                        if (state == 3) {
                            state = 4;
                            varType.append(source, idx, idx + currentLength);
                        } else if (state == 9) {
                            state = 10;
                            varType.append(source, idx, idx + currentLength);
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, CLASS), tokens);
                        break;
                    case VARIANT://变量
                        state = 1;
                        varLine = currentLine;
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case AS://为
                        if (state == 2) {
                            state = 3;
                        } else if (state == 8) {
                            state = 9;
                        } else if (state == 20) {
                            state = 21;
                            tree.addVariant(currentLine, varType.toString(), "[宏定义]");
                            varType.setLength(0);
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case DEFINE://定义
                        state = 20;
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case IMPORTZ://引入
                        state = 22;
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case LAYOUT:
                        String mText = hDoc.getLine(currentLine);
                        if (mText.contains("=")) {
                            mText = mText.substring(mText.indexOf("布局") + 2, mText.indexOf("=")).trim();
                            methods.add(mText + " 为 组件容器@[方法]");
                        }
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case KEEP://保留
                    case STATIC://静态
                    case END://结束
                    case RETURN://返回
                    case NEW://创建
                    case NULL://空
                    case FALSE://假
                    case TRUE://真
                    case TO://至
                    case IN://从
                    case THEN://则
                    case ANDK://与
                    case ORK://或
                    case FORWARD://步进
                    case BACK://步退
                    case THIS://本对象
                    case INSTANCEOF://从属于
                    case ASSERT://断言
                    case BREAK://跳出
                    case CONTINUE://跳过
                    case EXTENDZ://继承
                    case PRIVATEZ://私有
                    case IMPLEMENTS:
                    case DISPATCH_EVENT:
                    case SUPER:
                    case NATIVE:
                    case CONST:
                        state = 0;
                        varType.setLength(0);
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case J_IF:
                    case J_DO:
                    case J_TRY:
                    case J_NEW:
                    case J_INT:
                    case J_FOR:
                    case J_BYTE:
                    case J_TRUE:
                    case J_THIS:
                    case J_CASE:
                    case J_CHAR:
                    case J_ELSE:
                    case J_ENUM:
                    case J_LONG:
                    case J_NULL:
                    case J_GOTO:
                    case J_VOID:
                    case J_BREAK:
                    case J_SHORT:
                    case J_SUPER:
                    case J_THROW:
                    case J_CATCH:
                    case J_CONST:
                    case J_CLASS:
                    case J_FALSE:
                    case J_FLOAT:
                    case J_FINAL:
                    case J_WHILE:
                    case J_ASSERT:
                    case J_STATIC:
                    case J_SWITCH:
                    case J_THROWS:
                    case J_RETURN:
                    case J_NATIVE:
                    case J_IMPORT:
                    case J_DOUBLE:
                    case J_PUBLIC:
                    case J_BOOLEAN:
                    case J_EXTENDS:
                    case J_DEFAULT:
                    case J_FINALLY:
                    case J_PACKAGE:
                    case J_PRIVATE:
                    case J_ABSTRACT:
                    case J_STRICTFP:
                    case J_CONTINUE:
                    case J_VOLATILE:
                    case J_TRANSIENT:
                    case J_INTERFACE:
                    case J_PROTECTED:
                    case J_INSTANCEOF:
                    case J_IMPLEMENTS:
                    case J_SYNCHRONIZED:
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case JAVA_TAG_START:
                    case JAVA_TAG_END:
                        addPairIfNeeded(new Pair(idx, FUNCTION), tokens);
                        break;
                    case COMMENT://注释
                        String comment = currentText;
                        
                        addPairIfNeeded(new Pair(idx, DOUBLE_SYMBOL_DELIMITED_MULTILINE), tokens);
                        break;
                    case STRING://字符串，字符
                        String text = currentText;
                        text = text.substring(text.indexOf("\"") + 1, text.lastIndexOf("\""));
                        if (state == 22) {
                            includes.add(text);
                        }
                        state = 0;
                        varType.setLength(0);
                        if (checkHexColorForString(text)) {
                            try {
                                colorLines.add(new ColorLine(currentLine, currentColumn, currentColumn + currentLength, Color.parseColor(text)));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        
                        addPairIfNeeded(new Pair(idx, SINGLE_SYMBOL_DELIMITED_A), tokens);
                        break;
                    case LONG_STRING:
                    case FULL_ANGLE_STRING:
                    case CHARACTER_LITERAL:
                        state = 0;
                        varType.setLength(0);
                        addPairIfNeeded(new Pair(idx, SINGLE_SYMBOL_DELIMITED_A), tokens);
                        break;
                    case INTEGER_LITERAL://数字
                        if (state == 17) {
                            state = 17;
                        } else {
                            state = 0;
                        }
                        varType.setLength(0);
                        if (checkHexColor(currentText)) {
                            try {
                                String str = currentText.toLowerCase().replace("0x", "");
                                int color = Color.parseColor("#" + str);
                                colorLines.add(new ColorLine(currentLine, currentColumn, currentColumn + currentLength, color));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        addPairIfNeeded(new Pair(idx, NUMBER), tokens);
                        break;
                    case FLOATING_POINT_LITERAL://浮点数
                        state = 0;
                        varType.setLength(0);
                        addPairIfNeeded(new Pair(idx, NUMBER), tokens);
                        break;
                    //符号
                    case LBRACK://左中括号
                        if (state == 4 || state == 10) {
                            varType.append('[');
                        } else if (state == 17) {
                            state = 17;
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case RBRACK://右中括号
                        if (state == 4 || state == 10) {
                            varType.append(']');
                        } else if (state == 17) {
                            state = 17;
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case DOT://.
                        if (state == 4) {
                            state = 5;
                            varType.append('.');
                        } else if (state == 10) {
                            state = 11;
                            varType.append('.');
                        } else if (state == 17) {
                            state = 17;
                        } else {
                            state = 0;
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case COMMA://逗号
                        if (state == 10) {
                            state = 7;
                            if (varType.length() != 0) {
                                tree.addVariant(currentLine, name, varType.toString());
                                varType.setLength(0);
                            }
                        } else if (state == 17) {
                            state = 18;
                        } else {
                            state = 0;
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case LPAREN://左括号
                        if (state == 15 || state == 13) {
                            state = 7;
                        } else if (state == 17) {
                            state = 17;
                        } else if (state == 20) {
                            state = 20;
                            varType.append(source, idx, idx + currentLength);
                        } else {
                            state = 0;
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case RPAREN://右括号
                        if (state == 10) {
                            if (varType.length() != 0) {
                                tree.addVariant(currentLine, name, varType.toString());
                                varType.setLength(0);
                            }
                        } else if (state == 20) {
                            state = 20;
                            varType.append(source, idx, idx + currentLength);
                        } else {
                            state = 0;
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case COLON://冒号
                        if (state == 16) {
                            state = 14;
                        } else {
                            state = 0;
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case SEMICOLON:
                    case EQ://等号
                    case NEWLINE://换行
                        if (varType.length() != 0) {
                            String clazz = varType.toString();
                            tree.addVariant(currentLine, name, clazz);
                            language.addName(clazz.replace("[", "")
                                    .replace("]", ""));
                            varType.setLength(0);
                        }
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case LT://小于
                        state = 22;
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case GT://大于
                        state = 0;
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case NOT:
                    case ELLIPSIS:
                    case NOTEQ:
                    case EQEQ:
                    case MINUS:
                    case PLUS:
                    case MINUSMINUS:
                    case PLUSPLUS:
                    case DIV:
                    case MULT:
                    case QUESTION:
                    case AND:
                    case ANDAND:
                    case OROR:
                    case OR:
                    case XOR:
                    case MOD:
                    case GTEQ:
                    case LTEQ:
                        addPairIfNeeded(new Pair(idx, OPERATOR), tokens);
                        break;
                    case BAD_CHARACTER:
                        throw new RuntimeException(String.format("Bad Character: %d", currentText));
                    case WHITESPACE:
                        //假装空格和前面是同一个东西
                        break;
                    default:
                        addPairIfNeeded(new Pair(idx, NORMAL), tokens);
                }
                switch (type) {
                    case WHITESPACE:
                    case EOF:
                        //跳过空格
                        break;
                    case CLAZZ://类
                    case ENUMZ://枚举
                    case IF://如果
                    case METHOD://方法
                    case EVENT://事件
                    case SWITCH://判断
                        if (markedType != S5dType.END) {
                            if (type == S5dType.METHOD && markedType == S5dType.STATIC) {
                                lineStacks.add(new BlockLine(currentLine, currentLine,
                                        markedStaicColumn, markedStaicColumn));
                            } else {
                                lineStacks.add(new BlockLine(currentLine, currentLine,
                                        currentColumn, currentColumn));
                            }
                            if (type == S5dType.SWITCH) {
                                markedSwitchLine = currentLine;
                            }
                        }
                        markedType = type;
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        break;
                    case CASE://分支
                        lineStacks2.add(new BlockLine(currentLine, currentLine, currentColumn, currentColumn));
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        markedType = type;
                        break;
                    case STATIC:
                        addPairIfNeeded(new Pair(idx, KEYWORD), tokens);
                        markedType = type;
                        markedStaicColumn = currentColumn;
                        break;
                    default:
                        //记录上一个非空Type
                        markedType = type;
                }

                idx += currentLength;
            } catch (Exception e) {
                e.printStackTrace();
                idx++;//错误了，索引也要往后挪
            }
        }
        //不必检验tokens是否为空,在LexThread中已经检查
        //refreshComponentName(vars);
        language.updateUserWord();

        setNavigations(navigations);

        setCustomMethods(methods);

        setIncludes(includes);
        this.

                setTree(tree);
        super.

                setBlockLines(lines);
        super.

                setColorLines(colorLines);
        //super.setDeviderLines(deviderLines);
        return tokens;
    }

    private static boolean checkHexColorForString(String str) {
        int length = str.length();
        return (length == 9 || length == 7) && str.startsWith("#");
    }

    private static boolean checkHexColor(String str) {
        int length = str.length();
        return (length == 10 || length == 8) && str.toLowerCase().startsWith("0x");
    }

    private S5dTree tree;
    private String parentClass = "窗口";
    private List<Navigation> navigations;
    private List<String> customMethods = new ArrayList<>();
    private List<String> includes = new ArrayList<>();

    public String getParentClass() {
        return this.parentClass;
    }

    public List<String> getIncludes() {
        return this.includes;
    }

    public void setIncludes(List<String> includes) {
        this.includes = includes;
    }

    public List<String> getCustomMethods() {
        return this.customMethods;
    }

    public void setCustomMethods(List<String> methods) {
        this.customMethods = methods;
    }

    public List<Navigation> getNavigations() {
        return this.navigations;
    }

    public void setNavigations(List<Navigation> navigations) {
        this.navigations = navigations;
    }

    public S5dTree getTree() {
        return this.tree;
    }

    public void setTree(S5dTree tree) {
        this.tree = tree;
    }

    @Override
    public int autoIndent(S5dType type) {
        int indent = 0;
        int caseCount = 0;
        switch (type) {
            case LBRACE:
            case FORLOOP:
            case WHILELOOP:
            case FOREACH:
            case CLAZZ:
            case ENUMZ:
            case TRY:
            case CATCH:
            case CONSTRUCTOR:
            case PROPERTY_GET:
            case PROPERTY_SET:
            case DEFINE_EVENT:
            case STATIC_DEAL:
            case COUNTLOOP:
            case VIRTUALMETHOD:
            case OVERRIDEMETHOD:
                indent++;
                break;
            case EVENT:
            case METHOD:
            case SWITCH:
                indent++;
                break;
            case THEN:
            case ELSE:
                //用THEN代替IF参与自动插入
                indent++;
                break;
            case END:
            case RBRACE:
                indent--;
                break;
            case CASE:
                caseCount++;
                break;
            case COLON:
                if (caseCount > 0) {
                    indent++;
                    caseCount = Integer.MIN_VALUE;
                }
                break;
        }

        return indent * 3;
    }

    @Override
    public int autoIndent(CharSequence text) {
        S5dLexer lexer = new S5dLexer(text);
        int indent = 0;
        int caseCount = 0;
        try {
            S5dType type = null;
            S5dType lastType = null;
            label:
            while (true) {
                type = lexer.yylex();
                switch (type) {
                    case EOF:
                        //达到字符串末尾,结束循环
                        break label;
                    case LBRACE:
                    case FORLOOP:
                    case WHILELOOP:
                    case FOREACH:
                    case CLAZZ:
                    case ENUMZ:
                    case TRY:
                    case CATCH:
                    case CONSTRUCTOR:
                    case PROPERTY_GET:
                    case PROPERTY_SET:
                    case DEFINE_EVENT:
                    case STATIC_DEAL:
                    case COUNTLOOP:
                    case VIRTUALMETHOD:
                    case OVERRIDEMETHOD:
                        indent++;
                        break;
                    case EVENT:
                    case METHOD:
                    case SWITCH:
                        if (lastType == S5dType.END) {
                            //忽略,这是表示语句块的结束,不应该被识别
                        } else {
                            indent++;
                        }
                        break;
                    case THEN:
                    case ELSE:
                        //用THEN代替IF参与自动插入
                        indent++;
                        break;
                    case END:
                    case RBRACE:
                        indent--;
                        break;
                    case CASE:
                        caseCount++;
                        break;
                    case COLON:
                        if (caseCount > 0) {
                            indent++;
                            caseCount = Integer.MIN_VALUE;
                        }
                        break;
                }
                if (type != S5dType.WHITESPACE) {
                    lastType = type;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return indent * 3;
    }


    @Override
    public void onEnabled() {
        super.onEnabled();
        setLanguage(LanguageS5d.getInstance());
    }

}
