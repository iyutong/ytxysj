package com.myopicmobile.textwarrior.language.sly;

import com.myopicmobile.textwarrior.language.CharSeqReader;
import com.myopicmobile.textwarrior.language.java.JavaLexer;
import com.myopicmobile.textwarrior.language.java.JavaType;

import java.io.IOException;
import java.io.Reader;

public final class SlyLexer {

    private JavaLexer lexer;

    public SlyLexer(CharSequence input) {
        this(new CharSeqReader(input));
    }

    public SlyLexer(Reader r) {
        lexer = new JavaLexer(r);
        content = null;
        sign = false;
		under = false;
    }

    private JavaType cache;
    private String content;
    private boolean sign;
	private boolean under;
	
	public SlyToken nextToken() throws IOException{
		SlyToken ori = nextToken_();
		if(getContent().equals("真")||getContent().equals("假")){
			return SlyToken.BOOL;
		}else{
			return ori;
		}
	}

    public SlyToken nextToken_() throws IOException {
        JavaType type = null;
        if(sign){
            sign = false;
            type = cache;
            cache = null;
        }else{
            type = lexer.yylex();
        }
		if(type == null){
			type = lexer.yylex();
		}
        switch (type) {
            case EQ:
                return SlyToken.EQ;
            case LBRACE:
                return SlyToken.LBRACE;
            case RBRACE:
                return SlyToken.RBRACE;
            case COMMA:
                return SlyToken.COMMA;
            case BOOLEAN_LITERAL:
                return SlyToken.BOOL;
            case INTEGER_LITERAL:
                if (lexer.yytext().matches("[0-9]+")) {
					if(under){
						under = false;
						sign = true;
						cache = null;
						content = "-" + lexer.yytext();
					}
                    return SlyToken.INTEGER;
                } else {
                    throw new IllegalArgumentException("Number format not supported:" + lexer.yytext() + " at" + getPosition());
                }
            case STRING:{
                StringBuilder sb = new StringBuilder(lexer.yytext());
                while ((type = lexer.yylex()) == JavaType.STRING) {
                    sb.append(lexer.yytext());
                }
                cache = type;
                sign = true;
                content = sb.toString();
                return SlyToken.STRING;
			}
            case IDENTIFIER:{
				StringBuilder sb = new StringBuilder(lexer.yytext());
				while((type = lexer.yylex()) != JavaType.EOF){
					if(type == JavaType.IDENTIFIER || type == JavaType.DOT){
						sb.append(lexer.yytext());
					}else{
						break;
					}
				}
				cache = type;
				sign = true;
				content = sb.toString();
				return SlyToken.IDENTIFIER;
			}
            case NEWLINE:
            case WHITESPACE:
                return nextToken();
            case EOF:
                return SlyToken.EOF;
			case MINUS:
				if(!under){
					under = true;
				}else{
					throw new IllegalArgumentException("unexpected '-'");
				}
				return nextToken();
            default:
                throw new IllegalArgumentException("unexpected token " + type + " at" + getPosition());
        }
    }

    public String getContent(){
        if(sign){
            return content;
        }else {
            return lexer.yytext();
        }
    }

    public String getPosition() {
        return " line " + getLine() + " column " + getColumn();
    }

    int getLine() {
        return lexer.yyLine();
    }

    int getColumn() {
        return lexer.yyColumn();
    }

    public enum SlyToken {
        LBRACE,
        RBRACE,
        COMMA,
        IDENTIFIER,
        EQ,
        INTEGER,
        BOOL,
        STRING,
        EOF
    }

}
