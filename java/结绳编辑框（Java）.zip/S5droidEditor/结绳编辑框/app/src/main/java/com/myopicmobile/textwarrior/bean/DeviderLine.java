package com.myopicmobile.textwarrior.bean;

public class DeviderLine {

    public DeviderLine(int line) {
        this.line = line;
    }

    public int line;

}
