package com.myopicmobile.textwarrior.language.s5d;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;
import com.jiesheng.editor.R;
import com.myopicmobile.textwarrior.android.FreeScrollingTextField;
import com.myopicmobile.textwarrior.base.BasePanel;
import com.myopicmobile.textwarrior.bean.ListItem;
import com.myopicmobile.textwarrior.bean.Navigation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class S5dAutoCompletePanel extends BasePanel {

    private final int mPadding = 20;
    public final int TYPE_METHOD = 0;
    public final int TYPE_EVENT = 1;
    public int markedType;
    public CharSequence mText;
    public String markedText = "";
    private Filter mFilter;
    private S5dPanelAdapter adapter;
    private int mHeight = 0;

    public S5dAutoCompletePanel(FreeScrollingTextField field) {
        super(field);
        adapter = new S5dPanelAdapter(field.getContext());
        setAdapter(adapter);
    }

    public S5dAutoCompletePanel(Context context) {
        super(context);
    }

    public S5dAutoCompletePanel(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public S5dAutoCompletePanel(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public S5dAutoCompletePanel(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    public S5dPanelAdapter getAdapter() {
        return (S5dPanelAdapter) super.getAdapter();
    }

    @Override
    public void setHeight(int height) {
        if (mHeight != height) {
            mHeight = height;
            super.setHeight(height);
        }
    }


    @Override
    public void select(int pos) {
        FreeScrollingTextField field = getTextField();
        S5dPanelAdapter adapter = getAdapter();
        View view = adapter.getView(pos, null, null);
        TextView textView = (TextView) view.findViewById(R.id.auto_panel_text);
        String text = textView.getText().toString();
        String commitText = null;
        boolean isFunc = text.contains("(");
            /*if (text.equals("变量循环")) {
                commitText = "变量循环 " + mardedLoopVar + "= 0 至 10\n结束 循环";
                needFormat = true;
                markedText = commitText;
                field.replaceText(field.getCaretPosition() -
                                _constraint.length() -
                                mardedLoopVar.length() - 1,
                        _constraint.length() +
                                mardedLoopVar.length() + 1, commitText);
                _adapter.abort();
                dismiss();
                field.format();
                return;
            } else if (text.equals("遍历循环")) {
                commitText = "遍历循环 变量名 为 " +
                        markedVarType.replace("[", "")
                                .replace("]", "") + " 从 " + mardedLoopVar + "\n结束 循环";
                needFormat = true;
                markedText = commitText;
                field.replaceText(field.getCaretPosition() -
                                _constraint.length() -
                                mardedLoopVar.length() - 1,
                        _constraint.length() +
                                mardedLoopVar.length() + 1, commitText);
                _adapter.abort();
                dismiss();
                field.format();
                return;
            } else {*/
        if (text.contains("=")) {
            commitText = text.substring(0, text.indexOf('=') + 1) + " ";
        } else if (text.contains(" : ")) {
            if (isFunc) {
                commitText = text.substring(0, text.indexOf('(')) + "(";
            } else {
                commitText = text.substring(0, text.indexOf(" : "));
            }
        } else if (isFunc) {
            if (markedType == TYPE_METHOD) {
                if (text.substring(text.indexOf("(") + 1, text.indexOf(")"))
                        .replace(" ", "").equals(""))
                    commitText = text.substring(0, text.indexOf('(')) + "()";
                else
                    commitText = text.substring(0, text.indexOf('(')) + "(";
            } else {
                commitText = text;
            }
        } else {
            commitText = text;
        }
        markedText = commitText;
        field.replaceText(field.getCaretPosition() - mText.length(), mText.length(), commitText);
        adapter.abort();
        dismiss();
    }

    /**
     * 获取主要文字颜色
     */
    public int myGetTextPrimaryColor(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(android.R.attr.textColorPrimary, typedValue, true);
        return typedValue.data;
    }

    class S5dPanelAdapter extends BasePanelAdapter {

        private Context context;

        public S5dPanelAdapter(Context context) {
            super(context);
            this.context = context;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = null;
            if (convertView == null) {
                @SuppressLint("InflateParams") View rootView = LayoutInflater.from(context).inflate(R.layout.auto_panel_item, null);
                view = rootView;
            } else {
                view = convertView;
            }
            TextView textView = view.findViewById(R.id.auto_panel_text);
            ImageView imageView = view.findViewById(R.id.auto_panel_icon);
            try {
                String text = getItem(position).getText();
                SpannableString spannableString = null;
                ForegroundColorSpan foregroundColorSpan = null;
                if (text.contains("=")) {
                    spannableString = new SpannableString(text);
                    foregroundColorSpan = new ForegroundColorSpan(0xffa6a6a6);
                    spannableString.setSpan(foregroundColorSpan,
                            text.indexOf("=") + 1, text.length(),
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else if (text.contains(" : ")) {
                    spannableString = new SpannableString(text);
                    foregroundColorSpan = new ForegroundColorSpan(0xffa6a6a6);
                    spannableString.setSpan(foregroundColorSpan,
                            text.indexOf(" : "), text.length(),
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else if (text.contains("(")) {
                    spannableString = new SpannableString(text);
                    foregroundColorSpan = new ForegroundColorSpan(0xffa6a6a6);
                    spannableString.setSpan(foregroundColorSpan,
                            text.indexOf('('), text.length(),
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else if (text.endsWith("@[关键字]")) {
                    foregroundColorSpan = new ForegroundColorSpan(0XFF2196F3);
                    int idx = text.indexOf("@[关键字]");
                    text = text.substring(0, idx);
                    spannableString = new SpannableString(text);
                    spannableString.setSpan(foregroundColorSpan, 0, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else {
                    spannableString = new SpannableString(text);
                    foregroundColorSpan = new ForegroundColorSpan(myGetTextPrimaryColor(context));
                    spannableString.setSpan(foregroundColorSpan, 0, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                textView.setText(spannableString);
                imageView.setImageBitmap(getItem(position).getBitmap());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return view;
        }

        @Override
        public Filter getFilter() {
            mFilter = new Filter() {
                /**
                 * 本方法在后台线程执行，定义过滤算法
                 */
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    // 此处实现过滤
                    // 过滤后利用FilterResults将过滤结果返回
                    LanguageS5d language = (LanguageS5d) getLanguage();
                    LexerS5d lexer = language.getLexer();
                    S5dTree tree = lexer.getTree();
                    List<Navigation> navigations = lexer.getNavigations();
                    ArrayList<String> buf = new ArrayList<>();
                    ArrayList<String> fields = new ArrayList<>();
                    //代码提示算法写在这里
                    FilterResults filterResults = new FilterResults();
                    filterResults.values = buf;   // results是上面的过滤结果
                    filterResults.count = buf.size();  // 结果数量
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    if (results != null && results.count > 0 && !isSet()) {
                        // 有过滤结果，显示自动完成列表
                        clearResults();   // 清空旧列表
                        ArrayList<String> stringArrayList = (ArrayList<String>) results.values;
                        for (int i = 0; i < stringArrayList.size(); i++) {
                            String itemText = stringArrayList.get(i);
                            if (itemText.endsWith("@[变量]")) {
                                addResult(new ListItem(getVarBitmap(), subString(itemText, "@[变量]")));
                            } else if (itemText.endsWith("@[方法]")) {
                                addResult(new ListItem(getMethodBitmap(), subString(itemText, "@[方法]")
                                        .replace("为 Activity", "为 窗口")));
                            } else if (itemText.endsWith("@[事件]")) {
                                addResult(new ListItem(getEventBitmap(), subString(itemText, "@[事件]")));
                            } else if (itemText.endsWith("@[属性写]")) {
                                addResult(new ListItem(getPropertySetBitmap(), subString(itemText, "@[属性写]")));
                            } else if (itemText.endsWith("@[属性读]")) {
                                addResult(new ListItem(getPropertyGetBitmap(), subString(itemText, "@[属性读]")));
                            } else if (itemText.endsWith("@[调用属性写]")) {
                                addResult(new ListItem(getPropertySetBitmap(),
                                        subString(itemText, "@[调用属性写]").replace(")", "")
                                                .replace("(", " = ").replace("为", ":")));
                            } else if (itemText.endsWith("@[调用属性读]")) {
                                addResult(new ListItem(getPropertyGetBitmap(), subString(itemText, "@[调用属性读]")
                                        .replace("()", "").replace("为", ":")));
                            } else {
                                addResult(new ListItem(null, itemText));
                            }
                        }
                        int y = getTextField().getCaretY() + getTextField().rowHeight() / 2 - getTextField().getScrollY();
                        setHeight(getItemHeight() * Math.min(4, results.count));
                        setHorizontalOffset(mPadding);
                        setWidth(getTextField().getWidth() - mPadding * 2);
                        setVerticalOffset(y - getTextField().getHeight());
                        //_textField.getCaretY()-_textField.getScrollY()-_textField.getHeight());
                        notifyDataSetChanged();
                        show();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return mFilter;
        }
    }

    private String subString(String text, String identifier) {
        return text.substring(0, text.lastIndexOf(identifier));
    }

    private boolean whetherAdd(String a, String b) {
        b = b.toLowerCase();
        a = a.toLowerCase();
        return (b.toLowerCase().contains(a) || PinyinTool.getFirstPinyinForWords(b).contains(a) || PinyinTool.getPinyinForWords(b).contains(a));
    }

    private void findAll(S5dTree.Node node, final S5dTree.Node root, int line, HashMap<String, String> tips) {
        if (!node.isBlock) {
            tips.put(node.varName, node.varType);
            return;
        }
        if (node.startLine > line || node.endLine < line) {
            return;
        }
        for (int i = 0; i < node.children.size(); i++) {
            S5dTree.Node sub = node.children.get(i);
            findAll(sub, root, line, tips);
        }
    }

    private void findForPrefix(String match, S5dTree.Node node, final S5dTree.Node root, int line, List<String> tips) {
        if (!node.isBlock) {
            tips.clear();
            if (whetherAdd(match, node.varName.toLowerCase()) && (node.parent == root || node.startLine < line)) {
                tips.add(node.varName + " : " + node.varType + "@[变量]");
            }
            return;
        }
        if (node.startLine > line || node.endLine < line) {
            return;
        }
        for (int i = 0; i < node.children.size(); i++) {
            S5dTree.Node sub = node.children.get(i);
            findForPrefix(match, sub, root, line, tips);
        }
    }

    private final static String[] NO_RESULT = new String[]{null, null};

    private String[] find(String match, S5dTree.Node node, S5dTree.Node root, int line) {
        for (int i = 0; i < node.children.size(); i++) {
            S5dTree.Node sub = node.children.get(i);
            if (sub.isBlock) {
                if (sub.startLine <= line && sub.endLine >= line) {
                    String[] res = find(match, sub, root, line);
                    if (res != NO_RESULT) {
                        return res;
                    }
                }
            } else {
                if (node == root || (sub.startLine < line)) {
                    if (sub.varName.toLowerCase().equals(match)) {
                        return new String[]{sub.varName, sub.varType};
                    }
                }
            }
        }
        return NO_RESULT;
    }
}
