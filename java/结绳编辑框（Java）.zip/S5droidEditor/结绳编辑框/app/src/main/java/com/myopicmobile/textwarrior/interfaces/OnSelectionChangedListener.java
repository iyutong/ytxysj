package com.myopicmobile.textwarrior.interfaces;

public interface OnSelectionChangedListener {
	
	public void onSelectionChanged(boolean active, int selStart, int selEnd);

}
