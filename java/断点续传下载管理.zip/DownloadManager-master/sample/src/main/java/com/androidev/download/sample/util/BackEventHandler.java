package com.androidev.download.sample.util;

/**
 * Created by 4ndroidev on 16/10/20.
 */
public interface BackEventHandler {

    boolean onBackPressed();

}
