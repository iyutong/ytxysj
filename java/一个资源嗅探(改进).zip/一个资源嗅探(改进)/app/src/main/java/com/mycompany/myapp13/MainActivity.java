package com.mycompany.myapp13;
 
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/*源码from QQ群AIDE高级设置 号码 537756994 
   改进者 qq : 3474006766 若生
*/

public class MainActivity extends Activity {
	public ArrayList<Map<String,String>> URLArrayList = new ArrayList<>();
	public SimpleAdapter simpleAdapter;
	public WebView wv;
	public long pte;
    public EditText ed;
    private int n=0;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		wv = findViewById(R.id.mainWebView1);
		ListView list =findViewById(R.id.mainListView1);
        ed=findViewById(R.id.activitymainEditText1);
		list.setAdapter(simpleAdapter = new SimpleAdapter(this,URLArrayList,R.layout.item,new String[]{"url"},new int[]{R.id.itemTextView1}));
		wv.setWebViewClient(new MyWebViewClient());
		wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
		wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
		wv.getSettings().setSupportMultipleWindows(true);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
           wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
    }
    public void go_(View v){
        URLArrayList.clear();
        
        wv.loadUrl(TextUtils.isEmpty(ed.getText())?"http://www.baidu.com":ed.getText().toString());
    }
	//复制
	public void copyURL(View view){
		if(view instanceof TextView)
			((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Label",((TextView)view).getText()));
		Toast.makeText(this,"复制成功",0).show();
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event){
		// TODO: Implement this method
		if(keyCode==KeyEvent.KEYCODE_BACK && wv.canGoBack())
			wv.goBack();
		else if(keyCode==KeyEvent.KEYCODE_BACK && (pte+500)>=(pte=System.currentTimeMillis()))
			this.finish();
		else
			Toast.makeText(this,"在按一次退出",Toast.LENGTH_SHORT).show();
		return true;
	}


	//重写webviewclicent
	class MyWebViewClient extends WebViewClient{

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url){
			//跳转界面清空数据
			if(!url.startsWith("http"))
				return super.shouldOverrideUrlLoading(view,url);
                
                
            view.getSettings().setJavaScriptEnabled(true);
			view.loadUrl(url);
			return true;
		}
        
       @Override
		public void onLoadResource(WebView view, String url){
			HashMap<String,String> kv = new HashMap<>();
			//if(url.contains("index.m3u8"){
				//判断类型自己写
           if(url.indexOf("css")==-1&&url.indexOf("gif")==-1&&url.indexOf("log")==-1){
             kv.put("url",url);
			URLArrayList.add(0,kv);
               if(url.indexOf("m4a")!=-1||url.indexOf("mp4")!=-1||url.indexOf("mp3")!=-1||url.indexOf("mkv")!=-1||url.indexOf("m3u8")!=-1||url.indexOf("png")!=-1||url.indexOf("jpg")!=-1){
                   dowloadthis("my_"+n+".file",url);
                   n++;
               }
            }
			simpleAdapter.notifyDataSetInvalidated();
		}
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();//即可忽略SSL证书错误，继续加载页面。这个地方是我没有https的证书，只能选择绕过，如果你用的是http交互的话请注释这行
        }
    
	}
    
public class PlayerActivity extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
//here
    }
    }
    
    
    public boolean dowloadthis(String n,String addars){

//创建下载任务,downloadUrl就是下载链接
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(addars));
//指定下载路径和下载文件名
        request.setDestinationInExternalPublicDir("/Music/", n);
//获取下载管理器
        DownloadManager downloadManager= (DownloadManager)this.getSystemService(Context.DOWNLOAD_SERVICE);
//将下载任务加入下载队列，否则不会进行下载
        downloadManager.enqueue(request);

        return true;
    }
}
