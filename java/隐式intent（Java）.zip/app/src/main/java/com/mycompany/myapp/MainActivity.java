package com.mycompany.myapp;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button button1= (Button)findViewById(R.id.mainButton1);
		button1.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					Intent intent= new Intent("com.ex.intent.action.SECOND");
					startActivity(intent);

				
    }
	});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		getMenuInflater().inflate(R.menu.main,menu);
return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()){
			case R.id.item:
				Toast.makeText(this,"呵",Toast.LENGTH_SHORT).show();
				break;
				default:
		}
		return true;
		}
		
		
}
