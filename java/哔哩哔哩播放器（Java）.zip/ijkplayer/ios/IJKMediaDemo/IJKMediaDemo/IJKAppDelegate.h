//
//  IJKAppDelegate.h
//  IJKMediaDemo
//
//  Created by ZhangRui on 13-9-19.
//  Copyright (c) 2013年 bilibili. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IJKVideoViewController;

@interface IJKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) IJKVideoViewController *viewController;

@end
