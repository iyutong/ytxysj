#! /usr/bin/env bash

git push origin --all --follow-tags
git push gitcafe --all --follow-tags
git push oschina --all --follow-tags
git push csdn --all --follow-tags

