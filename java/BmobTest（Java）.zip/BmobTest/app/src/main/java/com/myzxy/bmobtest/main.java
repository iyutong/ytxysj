package com.myzxy.bmobtest;

import android.os.*;
import android.support.v7.app.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import android.content.*;

public class main extends AppCompatActivity 
	{

		private EditText users;

		private EditText password;

		private Button ok;

		private TextView vip;

		private Button dl;

		@Override
		protected void onCreate ( Bundle savedInstanceState )
			{
				super.onCreate ( savedInstanceState );
				setContentView ( R.layout.mainn );
				Bmob.initialize ( this, "4793b8d68365a9679c9b34775441358a" );
				users = (EditText) findViewById ( R.id.users );
				password = (EditText) findViewById ( R.id.passw );
				vip = (TextView)findViewById ( R.id.vip );
				dl = (Button) findViewById ( R.id.dl );
				getuser ( );
				ok = (Button) findViewById ( R.id.ok );
				dl.setOnClickListener ( new OnClickListener ( ){

							@Override
							public void onClick ( View p1 )
								{

									SetUser ( );
									// TODO: Implement this method
								}
						} );
				ok.setOnClickListener ( new OnClickListener ( ){

							private Context thzz=main.this;

							@Override
							public void onClick ( View p1 )
								{User bu = new User ( );
									bu.setUsername ( users.getText ( ).toString ( ) );
									bu.setPassword ( password.getText ( ).toString ( ) );
									bu.setvip ( false );
									bu.signUp ( thzz, new SaveListener ( ) {
												@Override
												public void onSuccess ( )
													{
														toast ( "注册成功" );
														/* SharedPreferences sp = thzz.getSharedPreferences("SJ", MODE_PRIVATE);
														 SharedPreferences.Editor editor = sp.edit();
														 editor.putString("user",users.getText().toString());
														 editor.putString("pass",password.getText().toString());
														 editor.commit();*/




														//通过BmobUser.getCurrentUser(context)方法获取登录成功后的本地用户信息
													}
												@Override
												public void onFailure ( int code, String msg )
													{
														// TODO Auto-generated method stub
														toast ( "注册失败:" + msg + code );


														// TODO: Implement this method
													}
											} );

									// TODO: Implement this method
								}
						} );

			}
		public void toast ( String aa )
			{


				Toast.makeText ( main.this, aa, 3000 ).show ( );
			}
		public  void SetUser ( )
			{

				BmobUser userss = new BmobUser ( );
				userss.setUsername ( users.getText ( ).toString ( ) );
				userss.setPassword ( password.getText ( ).toString ( ) );
				userss.login ( this, new SaveListener ( ) {

							@Override
							public void onSuccess ( )
								{
									// TODO Auto-generated method stub

									toast ( "登录成功" );
								    getuser ( );
								}

							@Override
							public void onFailure ( int arg0, String arg1 )
								{
									// TODO Auto-generated method stub
									toast ( "登陆失败：" + arg1 );
								}
						} );}
		public void getuser ( )
			{

				BmobQuery<User> query = new BmobQuery<User> ( );

				BmobUser user = BmobUser.getCurrentUser ( this );

				String id=user.getObjectId ( );

				query.getObject ( this, id, new GetListener<User> ( ) 
						{



							@Override
							public void onSuccess ( User object )
								{





									if ( object.getvip ( ) )
										{
											vip.setText ( "是" );

										}
									else
										{

											vip.setText ( "否" );

										}
								}

							@Override
							public void onFailure ( int code, String arg0 )
								{
									// TODO Auto-generated method stub
									//   toast("查询失败："+arg0);
								}



						} );



			}

	}
