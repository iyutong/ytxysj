package com.myzxy.bmobtest;

import android.content.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.telephony.*;
import android.widget.*;
import android.view.*;
import android.view.View.*;

public class MainActivity extends AppCompatActivity 
{
	Button btn;
	TextView tv;
	EditText edt;

	
		@Override
		protected void onCreate ( Bundle savedInstanceState )
			{
				super.onCreate ( savedInstanceState );
				setContentView ( R.layout.main );
				tv = (TextView) findViewById ( R.id.id );
		edt=(EditText) findViewById(R.id.edt);
		btn=(Button) findViewById(R.id.btn);
		TelephonyManager tm = (TelephonyManager) 
		this.getSystemService(TELEPHONY_SERVICE); 
		String m=tm.getDeviceId();
		double e= Double.parseDouble(m);
		java.text.DecimalFormat   df   =new java.text.DecimalFormat("#");  
	  	final String re= df.format(e);
		tv.setText(re);
				btn.setOnClickListener ( new OnClickListener ( ){

							@Override
							public void onClick ( View p1 )
								{
									String edi=edt.getText().toString();
									if(edi .equals(re+1))//在激活码后面加一，而不是整体加一，我居然犯了这个错误😂
										{
											Intent intent=new Intent();
											intent.setClass(MainActivity.this,main.class);
											startActivity(intent);
										}else{
											Snackbar.make(p1, "验证失败", Snackbar.LENGTH_LONG).setAction("Action", null).show();

										}
									// TODO: Implement this method
								}
						} );
		
    }
}
