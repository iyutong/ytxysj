package com.example.testproject;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;

public class Main4 extends AppCompatActivity {
    private ViewPager2 viewpager;
    private ArrayList<Fragment> fragments;
    private ArrayList<String> titles;
    private ViewFragment4 fragment5;
    private ViewFragment5 fragment6;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main9);

        init();


        MyFragmentStateAdapter myFragmentStateAdapter = new MyFragmentStateAdapter(this, fragments);
        viewpager.setAdapter(myFragmentStateAdapter);

        viewpager.setCurrentItem(1);


        viewpager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                //Log.d("amy",position+"");
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }
        });

    }
    public void init(){

        viewpager=findViewById(R.id.viewpager2);

        fragments = new ArrayList<>();
        fragment5 = new ViewFragment4();
        fragment6 = new ViewFragment5();

        fragments.add(fragment5);
        fragments.add(fragment6);





    }

class MyFragmentStateAdapter extends FragmentStateAdapter {

    private ArrayList<Fragment> fragments;

    public MyFragmentStateAdapter(@NonNull FragmentActivity fragmentActivity, ArrayList<Fragment> fragments) {
        super(fragmentActivity);
        this.fragments = fragments;
    }

    @Override
    public int getItemCount() {
        return fragments.size();
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return fragments.get(position);
    }
}
}
