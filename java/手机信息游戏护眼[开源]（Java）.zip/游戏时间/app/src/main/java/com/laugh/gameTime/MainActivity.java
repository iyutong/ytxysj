package com.laugh.gameTime;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.*;
import android.widget.*;
import android.view.*;
import android.graphics.*;
import java.text.*;

public class MainActivity extends Activity
{
    @Override
    protected void onCreate(Bundle bundle)
	{
        super.onCreate(bundle);
        setContentView(R.layout.main);
		if(!isServiceRunning(this, FloatService.class.getCanonicalName()))
		{
			startService(new Intent(this, FloatService.class));
		}
    }
	public static boolean isServiceRunning(Context context, String serviceName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> runningServiceInfos = am.getRunningServices(200);
        if (runningServiceInfos.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningServiceInfo serviceInfo : runningServiceInfos) {
            if (serviceInfo.service.getClassName().equals(serviceName)) {
                return true;
            }
        }
        return false;
    }
}
