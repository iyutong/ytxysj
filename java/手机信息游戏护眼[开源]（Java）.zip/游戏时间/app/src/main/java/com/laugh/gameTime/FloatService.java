package com.laugh.gameTime;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import java.util.*;
import java.text.*;
import java.io.*;

public class FloatService extends Service
{
	private TextView date;
    private TextView electricity;
    private View floatView;
    private TextView time;
    private TextView week;
    private WindowManager windowManager;
	private WindowManager.LayoutParams params;
	Handler handler = new Handler();

	private TextView memory;

	private ActivityManager mActivityManager;

	private TextView cpu;
	@Override
	public IBinder onBind(Intent p1)
	{
		return null;
	}

	@Override
	public void onCreate()
	{
		super.onCreate();
		WindowFloat();
	}

	private void WindowFloat()
	{
		windowManager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		params = new WindowManager.LayoutParams();
        params.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        params.format = PixelFormat.TRANSLUCENT;
        params.width = WindowManager.LayoutParams.FILL_PARENT;
        params.height = WindowManager.LayoutParams.FILL_PARENT;
        params.gravity = Gravity.CENTER;
        params.x = 0;
        params.y = 0;
        floatView = View.inflate(getApplication(), R.layout.floatview, null);
        week = (TextView) floatView.findViewById(R.id.week);
        date = (TextView) floatView.findViewById(R.id.date);
        time = (TextView) floatView.findViewById(R.id.time);
        electricity = (TextView) floatView.findViewById(R.id.electricity);
		memory = (TextView) floatView.findViewById(R.id.memory);
		cpu = (TextView) floatView.findViewById(R.id.cpu);
		windowManager.addView(floatView, params);
		new Timer().scheduleAtFixedRate(new FloatWindowTimer(), 0, 1000);
    }

	public String getWeek()
	{
        Calendar instance = Calendar.getInstance();
        Calendar calendar = instance;
        Date date = new Date(System.currentTimeMillis());
        calendar.setTime(date);
		String[] week = getResources().getStringArray(R.array.week);
		return week[instance.get(7)-1];
    }
	class FloatWindowTimer extends TimerTask
	{
		@Override
        public void run()
		{
			handler.post(new Runnable(){
					@Override
					public void run()
					{
						final String Week = getWeek();
						final SimpleDateFormat Date = new SimpleDateFormat("yyyy-MM-dd");
						final SimpleDateFormat Time = new SimpleDateFormat("HH:mm:ss");
						final IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
						final Intent intent = registerReceiver(null, filter);
						final int current = intent.getExtras().getInt("level");// 获得当前电量
						final int total = intent.getExtras().getInt("scale");// 获得总电量
						final int percent = current * 100 / total;
						date.setText(Date.format(new Date()));
						time.setText(Time.format(new Date()));
						week.setText(Week);
						electricity.setText(percent + "%");
						memory.setText(DeviceInfoManager.getUsedPercentValue(getApplication()));
						cpu.setText(((int)DeviceInfoManager.getTotalCpuRate())+"%");
						windowManager.updateViewLayout(floatView, params);
					}
				});
		}
    }
	
}
