package com.xiaoheng.QQgengxin;

import android.app.*;
import android.os.*;
import android.view.*;

public class xiaohengactivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaohenglayout1);
	}
	
}
