package com.mycompany.jtqsxdj;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		Button aa=(Button)findViewById(R.id.mainButton);
		Button bb=(Button)findViewById((R.id.mainButton1));
		
		
		
		aa.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View p1)
				{
					Toast.makeText(MainActivity.this,"你已按下短按按钮",Toast.LENGTH_LONG).show();
					
				}
			});
			
			
			bb.setOnLongClickListener(new OnLongClickListener()
			{

				@Override
				public boolean onLongClick(View p1)
				{
					Toast.makeText(MainActivity.this,"你已按下长按按钮",Toast.LENGTH_LONG).show();
					
					return true;
					//true是长按是会震动  改成false长按是不会震动
				}
			});
		
		
		
    }
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/