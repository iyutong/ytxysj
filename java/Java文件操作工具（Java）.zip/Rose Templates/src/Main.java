import com.rose.templates.FileUtils;
import java.io.File;

public class Main
{
	public static void main(String[] args) throws Exception
	{
        //System.out.println(Long.toHexString(Long.MAX_VALUE));
        System.out.println(FileUtils.getSHA1(new File("/sdcard/last_log")).length());
    }
}
