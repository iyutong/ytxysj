package com.rose.templates.interfaces;

import java.io.File;

/**
 * This is a interface of method deleteFile() in class FileUtils
 * @author Rose
 */
public interface DeleteFileMonitor
{
    
    /**
     * This method is to notify you that the process is going to start finding files
     * to be deleted.
     */
    void onStartDetecting();
    
    /**
     * This method can let you select whether the file detected should be deleted
     * Note that if you have returned 'false' to one of the files,it will affect its parent
     * directory's deleting process.So when a file is canceled,its parent directory will be canceled as well.
     * 
     * @param file The file detected by the process
     * @return Whether the given file should be deleted soon
     */
    boolean onFileDetected(File file);
    
    /**
     * When we are finding files,we will try to update 
     * the file count to be deleted and notify you.
     * If the changed count is under the size you return,it will not call onFileCountUpdated()
     *
     * @return the min changed size you want to receive
     */
    int getMinUpdateSize();
    
    /**
     * This method is to notify you that the count of files
     * to be deleted is updated greatly since last call to this method.
     *
     * @param fileCount The new count of files to be deleted
     */
    void onFileCountUpdated(int fileCount);
    
    /**
     * This method is to notify you that we have finished the process
     * of finding files to be deleted and we try to send the count of 
     * files to you.
     * The size of getMinUpdateSize() is ignored.
     * It will may be under the size last sended by onFileCountUpdated()
     * because the parent files of the canceled files are removed this time.
     *
     * @param fileCount The count of files to be deleted
     */
    void onFinishDetecting(int fileCount);
    
    /**
     * This method is alike onFileCountUpdated().
     * This method is to notify you that the count of deleted files has updated
     *
     * @param deletedCount The count of deleted files
     */
    void onDeletedCountUpdated(int deletedCount);
    
    /**
     * This method is to notify you that we are failed to.delete the given file
     * Return true to continue and return false to stop
     *
     * @return Whether to continue
     */
    boolean onDeleteFailed(File file);
    
    /**
     * This method is to notify you that we have finished all the work of this process
     *
     * @param allDeleted Whether we are successful
     * @param deletedCount the count of files we actually deleted
     * @param supposedCount the count of files we should delete
     */
    void onDeleteFinished(boolean allDeleted,int deletedCount,int supposedCount);
    
}
