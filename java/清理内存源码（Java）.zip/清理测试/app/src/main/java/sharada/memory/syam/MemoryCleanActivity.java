package sharada.memory.syam;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MemoryCleanActivity extends Activity {
    long mem = 0;
    int myid = 0;
    int sk = 0;
    MemoryInfo syamu = new MemoryInfo();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
       hida();
        syamu();
        hida_ammachi();
        finish();
    }

    public void hida() {
        ActivityManager servMng = (ActivityManager) getSystemService("activity");
        List<RunningAppProcessInfo> list = servMng.getRunningAppProcesses();
        String[] values = new String[list.size()];
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                String his = ((RunningAppProcessInfo) list.get(i)).processName;
                String his3 = his + "-" + (((RunningAppProcessInfo) list.get(i)).pid);
                if (his.contains("sharada.tm.syam")) {
                    this.myid = ((RunningAppProcessInfo) list.get(i)).pid;
                } else {
                    servMng.restartPackage(((RunningAppProcessInfo) list.get(i)).processName);
                }
                if (!his.contains("com.android")) {
                    this.sk++;
                }
                values[i] = his3;
                servMng.getMemoryInfo(this.syamu);
                this.mem = this.syamu.availMem / 1048576;
            }
            ((ListView) findViewById(R.id.mylist)).setAdapter(new ArrayAdapter(this, 17367043, 16908308, values));
        }
    }

    public void hida_ammachi() {
        ActivityManager servMng = (ActivityManager) getSystemService("activity");
        List<RunningAppProcessInfo> list = servMng.getRunningAppProcesses();
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                servMng.restartPackage(((RunningAppProcessInfo) list.get(i)).processName);
            }
        }
    }

    private void syamu() {
        View layout = getLayoutInflater().inflate(R.layout.toast_layout, (ViewGroup) findViewById(R.id.toast_layout_root));
        ((ImageView) layout.findViewById(R.id.toast)).setImageResource(R.drawable.ic_launcher);
        ((TextView) layout.findViewById(R.id.text)).setText("\n" + this.sk + " Applications Closed" + "\nAvailable Free Memory : " + this.mem + " MB");
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(16, 0, 0);
        toast.setDuration(1);
        toast.setView(layout);
        toast.show();
    }
}
