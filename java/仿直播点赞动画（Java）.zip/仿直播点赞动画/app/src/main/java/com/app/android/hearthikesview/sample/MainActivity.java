package com.app.android.hearthikesview.sample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;

import com.app.android.hearthikesview.HeartLikeSurfaceView;
import com.app.android.hearthikesview.HeartLikeView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

   // private HeartLikeView mLikeView;
    //private java.util.Timer mTimer = new java.util.Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        android.widget.LinearLayout xx=(android.widget.LinearLayout)findViewById(R.id.xx);
        final com.app.android.hearthikesview.HeartLikeView mLikeView=new com.app.android.hearthikesview.HeartLikeView(this);
        xx.addView(mLikeView);

        java.util.Timer mTimer = new java.util.Timer();
        mTimer.scheduleAtFixedRate(new java.util.TimerTask() {
                @Override
                public void run() {
                    mLikeView.post(new Runnable() {
                            @Override
                            public void run() {
                                mLikeView.showHeartView();
                            }
                        });
                }
            }, 100, 100);
    }


}
