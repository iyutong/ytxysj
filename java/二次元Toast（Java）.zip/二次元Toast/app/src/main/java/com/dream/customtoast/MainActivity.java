package com.dream.customtoast;

import android.app.*;
import android.os.*;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		MyToast.show(this, "雪儿最可爱(๑• . •๑)");
	}
}
