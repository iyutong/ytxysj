package com.dream.customtoast;
import android.animation.*;
import android.content.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;

public class MyToast extends Toast {
	/**
     * Toast单例
     */
    private static MyToast toast;

    /**
     * Toast容器
     */
    private static TextView tv;

    /**
     * 构造
     *
     * @param context
     */
    public MyToast(Context context) {
        super(context);
    }

    /**
     * 显示Toast
     *
     * @param context   上下文
     * @param text      显示的文本
     */
    public static void show(Context context, CharSequence text) {
        if (text != null || !"".equals(text)) {
			// 初始化一个新的Toast对象
			initToast(context, text);
			toast.setDuration(text.length() < 15 ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
			tv.setPivotY(0);
			tv.setScaleY(0f);
			ObjectAnimator anim = ObjectAnimator.ofFloat(tv, "scaleY", 0, 1);
			anim.setStartDelay(200);
			anim.setDuration(800);
			anim.setInterpolator(new BounceInterpolator());
			anim.start();
			// 显示Toast
			toast.show();
		}
    }

    /**
     * 初始化Toast
     *
     * @param context   上下文
     * @param text      显示的文本
     */
    private static void initToast(Context context, CharSequence text) {
        try {
            cancelToast();
            toast = new MyToast(context);
            tv = new TextView(context);
			tv.setBackgroundResource(R.drawable.toast_frame);
			tv.setTextColor(context.getResources().getColor(android.R.color.white));
			tv.setText(text);
            toast.setView(tv);
            toast.setGravity(Gravity.CENTER, 0, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 隐藏当前Toast
     */
    public static void cancelToast() {
        if (toast != null) {
            toast.cancel();
        }
    }
}
