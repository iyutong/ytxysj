package com.open.lua.util;

import android.content.Context;
import android.widget.Toast;
import com.androlua.LuaApplication;

public class LuaToast {

   public Context mContext = LuaApplication.mApp.getApplicationContext();
    
    
    public LuaToast(Object o) {
        
        Toast.makeText(mContext, o.toString(), 1).show();
        
    }
    
    
    
    
}
