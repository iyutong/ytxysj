package com.open.lua.widget;

import android.content.*;
import com.caverock.androidsvg.*;


public class SvgView extends SVGImageView
{
	public SvgView(Context c){
		super(c);
	}
}
