
----------------------------------------------
--AppDarkTheme/黑色主题
----------------------------------------------


状态栏背景色 = 0xFF363636
标题栏背景色 = 状态栏背景色
侧滑栏背景色 = 0xFF303030
标题文字颜色 = 0xFFFFFFFF
副标题文字颜色 = 0xFF888888
图标着色 = 0xFF888888

空文件夹矢量图 = activity.getLuaDir().."/svgs/file_empty_dark.svg"

BasewordColor=0xFF81C784
--关键字
KeywordColor=0xFFFFB74D
--注释
CommentColor=0x5FFFFFFF
--变量
UserwordColor=0xFF536DFE
--字符串
StringColor=0xFFE57373


return android.R.style.Theme_Material_NoActionBar
