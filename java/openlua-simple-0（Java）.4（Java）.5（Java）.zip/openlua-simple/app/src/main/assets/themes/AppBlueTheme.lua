

----------------------------------------------
--AppBlueTheme/蓝色主题
----------------------------------------------


状态栏背景色 = 0xFF3F51B5
标题栏背景色 = 状态栏背景色
侧滑栏背景色 = 0xFFFAFAFA
标题文字颜色 = 0xFF303030
副标题文字颜色 = 0xFF888888
图标着色 = 0xAf0038e2


空文件夹矢量图 = activity.getLuaDir().."/svgs/file_empty_blue.svg"
          

BasewordColor=0xff008400
--关键字
KeywordColor=0xffb4002d
--注释
CommentColor=0x5F000000
--变量
UserwordColor=状态栏背景色
--字符串
StringColor=0xFFE57373


return android.R.style.Theme_Material_Light_NoActionBar
 