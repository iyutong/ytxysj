package com.sx.zy;

public class MyArray
{
	private int[] myarray=new int[]
	{0,0,0,
	0,0,0,
	0,0,0};
	
	public int[] array(int[] ary)
	{
		myarray[0]=ary[0];
		myarray[1]=ary[1];
		myarray[2]=ary[2];
		myarray[3]=ary[3];
		myarray[4]=ary[4];
		myarray[5]=ary[5];
		myarray[6]=ary[6];
		myarray[7]=ary[7];
		myarray[8]=ary[8];
		return myarray;
	}
}
