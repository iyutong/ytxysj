package com.sx.zy;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;


/**
 *My QQ:1543728366
 *
 */
public class JingView extends AppWidgetProvider
{
    private static RemoteViews remoteViews = null ;
	private static int[] z=new int[]{0,0,0,0,0,0,0,0,0};
	private static String[] sintent=new String[]{"com.jing.m1","com.jing.m2","com.jing.m3","com.jing.m4","com.jing.m5","com.jing.m6","com.jing.m7","com.jing.m8","com.jing.m9","com.jing.text"};
	private static int[] id=new int[]{R.id.m1,R.id.m2,R.id.m3,R.id.m4,R.id.m5,R.id.m6,R.id.m7,R.id.m8,R.id.m9,R.id.mainButton1};
    @Override
    public void onDeleted(Context context, int[] appWidgetIds)
    {
        super.onDeleted(context, appWidgetIds);
    }
    @Override
    public void onDisabled(Context context)
    {
        super.onDisabled(context);
    }
    @Override
    public void onEnabled(Context context)
    {
        super.onEnabled(context);
    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        super.onReceive(context, intent);
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
		if(intent.getAction().equals(sintent[9]))
		{
			for(int i=0;i<sintent.length-1;i++)
			{
				z=new int[]{0,0,0,0,0,0,0,0,0};
				remoteViews.setImageViewResource(id[i],R.drawable.n);
				appWidgetManager.updateAppWidget(new ComponentName(context,JingView.class),remoteViews);
			}
			
			
		}
		for(int i=0;i<sintent.length-1;i++)
		{
			if(z[i]==0)
			{
				
		if(intent.getAction().equals(sintent[i]))
		{
			z[i]=1;
			int luozi;
			try{
				luozi=new LuoZi().down(z);
			}catch(Exception e){
				luozi=-1;
			}
			if(luozi==-1)
			{
				for(int ii=0;ii<sintent.length-1;ii++)
				{
					z=new int[]{2,2,2,2,2,2,2,2,2};
					remoteViews.setImageViewResource(id[ii],R.drawable.n);
					remoteViews.setImageViewResource(id[4],R.drawable.over);
					appWidgetManager.updateAppWidget(new ComponentName(context,JingView.class),remoteViews);
				}
				break;
			}
			//if(z[i]==0){
			remoteViews.setImageViewResource(id[i],R.drawable.o);
			appWidgetManager.updateAppWidget(new ComponentName(context,JingView.class),remoteViews);
			if(luozi!=100)
				{
				z[luozi]=2;
				remoteViews.setImageViewResource(id[luozi],R.drawable.x);
				appWidgetManager.updateAppWidget(new ComponentName(context,JingView.class),remoteViews);
			}else if(luozi==100){
				for(int ii=0;ii<sintent.length-1;ii++)
				{
					z=new int[]{2,2,2,2,2,2,2,2,2};
					remoteViews.setImageViewResource(id[ii],R.drawable.n);
					remoteViews.setImageViewResource(id[3],R.drawable.over);
					remoteViews.setImageViewResource(id[4],R.drawable.x);
					remoteViews.setImageViewResource(id[5],R.drawable.win);
					appWidgetManager.updateAppWidget(new ComponentName(context,JingView.class),remoteViews);
				}
				break;
			}
			
			break;
		}
		}
		}
	}
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds)
    {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        RemoteViews remoteViews1= updateWidgetView(context);
        int N = appWidgetIds.length;
        for(int i = 0 ; i < N ; i++){
            appWidgetManager.updateAppWidget(appWidgetIds[i], remoteViews1);
        }
    }

    private RemoteViews updateWidgetView(Context context){

    	if(remoteViews == null)
		{
    	    remoteViews = new RemoteViews(context.getPackageName() , R.layout.main);
		}
		for(int i=0;i<sintent.length;i++)
		{
			remoteViews.setOnClickPendingIntent(id[i],PendingIntent.getBroadcast(context,0,new Intent(sintent[i]),0));
		}
        return remoteViews ;
    }

}
