package com.sx.zy;

public class LuoZi
{
	private int ma;
	private final int CORNERS=0,SIDES=10;
	public int down(int[] ia)
	{
		
		if(ia[4]==0)
		{
			ma=4;
			return ma;
		}
		int win=ll(ia);
		if(win!=-1)
		{
			if(win==100){
				return 100;
			}
			ma=win;
			return ma;
		}
		int mta=math(CORNERS,ia);
		if(mta!=-1)
		{
			ma=mta;
			return ma;
		}
		int mtb=math(SIDES,ia);
		
		if(mtb!=-1)
		{
			ma=mtb;
			return ma;
		}
		
		return -1;
	}
	
	private int ll(int[] in)
	{
		int li=100;
		if(in[0]!=0&&in[0]==in[1]&&in[1]==in[2]){return li;}else 
		if(in[3]!=0&&in[3]==in[4]&&in[4]==in[5]){return li;}else 
		if(in[6]!=0&&in[6]==in[7]&&in[7]==in[8]){return li;}else
		
		if(in[0]!=0&&in[0]==in[3]&&in[3]==in[6]){return li;}else 
		if(in[1]!=0&&in[1]==in[4]&&in[4]==in[7]){return li;}else 
		if(in[2]!=0&&in[2]==in[5]&&in[5]==in[8]){return li;}else 
		
		if(in[0]!=0&&in[0]==in[4]&&in[4]==in[8]){return li;}else 
		if(in[2]!=0&&in[2]==in[4]&&in[4]==in[6]){return li;}else 
		/*++++++++++*/
		
		if(in[0]!=0&&in[0]==in[1]&&in[2]==0){li=2;return li;}else 
		if(in[0]!=0&&in[0]==in[2]&&in[1]==0){li=1;return li;}else 
		if(in[2]!=0&&in[2]==in[1]&&in[0]==0){li=0;return li;}else 
		
		if(in[3]!=0&&in[3]==in[4]&&in[5]==0){li=5;return li;}else 
		if(in[5]!=0&&in[5]==in[4]&&in[3]==0){li=3;return li;}else 
		
		if(in[6]!=0&&in[6]==in[7]&&in[8]==0){li=8;return li;}else 
		if(in[6]!=0&&in[6]==in[8]&&in[7]==0){li=7;return li;}else 
		if(in[8]!=0&&in[8]==in[7]&&in[6]==0){li=6;return li;}else 
		/*++++++++++*/
		if(in[0]!=0&&in[0]==in[3]&&in[6]==0){li=6;return li;}else 
		if(in[0]!=0&&in[0]==in[6]&&in[3]==0){li=3;return li;}else 
		if(in[6]!=0&&in[6]==in[3]&&in[0]==0){li=0;return li;}else 
		
		if(in[1]!=0&&in[1]==in[4]&&in[7]==0){li=7;return li;}else 
		if(in[7]!=0&&in[7]==in[4]&&in[1]==0){li=1;return li;}else 
		
		if(in[2]!=0&&in[2]==in[5]&&in[8]==0){li=8;return li;}else 
		if(in[2]!=0&&in[2]==in[8]&&in[5]==0){li=5;return li;}else 
		if(in[8]!=0&&in[8]==in[5]&&in[2]==0){li=2;return li;}else 
		/*++++++++++*/
		if(in[0]!=0&&in[0]==in[4]&&in[8]==0){li=8;return li;}else 
		if(in[8]!=0&&in[8]==in[4]&&in[0]==0){li=0;return li;}else 
		
		if(in[2]!=0&&in[2]==in[4]&&in[6]==0){li=6;return li;}else 
		if(in[6]!=0&&in[6]==in[4]&&in[2]==0){li=2;return li;}
		
		
		
		
		
		return -1;
	}
	
	
	private int math(int jf,int[] in)
	{
		int ma=-1;
		int r=4;
		for(int i=1;i<=3000;i++)
		{
		int mran=((int)(Math.random()*r))+jf;/*四个角或者四方随机添加*/
		if(mran==0&&in[0]==0)
		{
			ma=0;
			break;
		}else if(mran==1)
		{
			if(in[2]==0){
				ma=2;
				break;
				}
			if(r==2){
				r--;
			}
		}else if(mran==2)
		{
			if(in[6]==0){
				ma=6;
				break;
				}
			if(r==3){
				r--;
			}
		}else if(mran==3)
		{
			if(in[8]==0){
				ma=8;
				break;
				}
			r--;
		}else if(mran==10&&in[1]==0)
		{
			ma=1;
			break;
		}else if(mran==11)
		{
			if(in[3]==0){
				ma=3;
				break;
				}
			if(r==2){
				r--;
			}
		}else if(mran==12)
		{
			if(in[5]==0){
				ma=5;
				break;
				}
			if(r==3){
				r--;
			}
		}else if(mran==13&&in[7]==0)
		{
			if(in[7]==0){
				ma=7;
				break;
				}
			r--;
		}else if(r==1){
			ma=-1;
			break;
		}
		}
		return ma;
	}
}
