package com.example.testproject;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.drawable.DrawableCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;


import jp.wasabeef.glide.transformations.BlurTransformation;

import static com.bumptech.glide.request.RequestOptions.bitmapTransform;

public class Main01 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout01);

        ImageView imageView=findViewById(R.id.i2);

        Glide.with(Main01.this).load(R.mipmap.zj)
                .apply(RequestOptions.bitmapTransform(new BlurTransformation(30,3)))
                //.apply(RequestOptions.bitmapTransform(BlurTransformation(25, 3)))
                .into(imageView);
    }
}
