package com.tiandog.note;
 
import android.app.Activity;
import android.os.Bundle;
import java.io.IOException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.widget.TextView;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import okhttp3.Call;
import okhttp3.Callback;

public class MainActivity extends Activity { 

    protected TextView note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		this.getActionBar().setSubtitle("舔狗舔狗，舔到最后，一无所有");
		
		note = findViewById(R.id.note);
		Button getNote = findViewById(R.id.get);
		
		getNote.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					note.setText("加载中");
					get("http://test.isiyuan.net/tiangou/tg.php");
				}
			});
    }
	
	String result;
	
	public void get(String url) {
		OkHttpClient client = new OkHttpClient();
		Request request = new Request.Builder().url(url).build();
		Call call = client.newCall(request);
		call.enqueue(new Callback() {
				@Override
				public void onFailure(Call call, IOException e) {
					//错误
				}

				@Override
				public void onResponse(Call call, Response response) throws IOException {
					if(response.isSuccessful()){
						result = response.body().string();
						runOnUiThread(new Runnable(){

								@Override
								public void run() {
									note.setText(result);
								}
							});
					}
				}
			});
	}
} 
