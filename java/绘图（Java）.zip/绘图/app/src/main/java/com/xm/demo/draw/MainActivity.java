package com.xm.demo.draw;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.*;
import android.view.*;

public class MainActivity extends Activity 
{
	private ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //QQ群241449466
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		img = findViewById(R.id.mainImageView1);
		draw();
    }
	
	public void draw(){
		Display dis=getWindowManager().getDefaultDisplay();
		int w=dis.getWidth(),h=dis.getHeight();
		Bitmap bitmap=Bitmap.createBitmap(dis.getWidth(),dis.getHeight(),Bitmap.Config.ARGB_8888);
		Canvas c=new Canvas(bitmap);
		Paint p=new Paint();
		Path pa=new Path();
		int l=w/3-(w/3/2),t=h/2-70,r=w/2+(w/3/2),b=h/2+70;
		int rw=r-l;
		int rh=b-t;
		p.setColor(0xff2196F3);
		pa.addCircle(l+(rw-rw/3/2)+80,t+rh/2,70,Path.Direction.CCW);
		c.save();
		c.clipPath(pa,Region.Op.XOR);
		c.drawRect(l,t,r,b,p);
		c.restore();
		c.drawCircle(l+(rw-rw/3/2)+95,t+rh/2,70,p);
		img.setImageBitmap(bitmap);
	}
}
