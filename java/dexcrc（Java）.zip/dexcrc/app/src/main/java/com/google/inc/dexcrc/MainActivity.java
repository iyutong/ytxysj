package com.google.inc.dexcrc;

import android.app.*;
import android.os.*;
import android.content.*;
import java.io.*;
import android.widget.*;
import javax.xml.transform.*;
import java.util.zip.*;
import java.util.concurrent.atomic.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		dexjy(this);
	}
	
	public static void dexjy(Context con){
		String dexcrc = assetcrc(con);
		try{
		String apkpath= (con.getPackageCodePath());
		ZipFile apkfile = new ZipFile(apkpath);
		ZipEntry dexentry = apkfile.getEntry("classes2.dex");
		Long dexcrc3 = dexentry.getCrc();
		String dexcrc4 = Long.toHexString(dexcrc3).toUpperCase().toString();
		if(dexcrc4.equals(dexcrc)){
			return;
		}else{
			System.exit(0);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static String assetcrc(Context con){
		String result = null;
		InputStream fis = null;
		try {
			fis =  con.getAssets().open("a.txt");
			byte[] buffer = new byte[1024];
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			int len = 0;
			while ((len = fis.read(buffer)) != -1) {
				outputStream.write(buffer, 0, len);
			}
			result = outputStream.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
}
