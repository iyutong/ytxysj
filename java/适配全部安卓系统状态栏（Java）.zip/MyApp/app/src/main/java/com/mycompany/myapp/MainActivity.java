package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import com.mycompany.myapp.utils.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
    
    StatusBarUtil.StatusBarLightMode(MainActivity.this);
    }
    }
}
