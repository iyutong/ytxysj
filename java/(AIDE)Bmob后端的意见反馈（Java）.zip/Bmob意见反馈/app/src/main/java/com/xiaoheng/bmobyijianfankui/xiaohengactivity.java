package com.xiaoheng.bmobyijianfankui;

import cn.bmob.v3.*;

class yijianfankui extends BmobObject
{
	private String fankuineirong;
    private String lianxiQQ;

    public String getName() {
        return fankuineirong;
    }
    public void setName(String name) {
        this.fankuineirong= name;
    }
    public String getAddress() {
        return lianxiQQ;
    }
    public void setAddress(String address) {
        this.lianxiQQ= address;
    }
}
