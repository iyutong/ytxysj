package com.xiaoheng.bmobyijianfankui;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Bmob.initialize(this,"7b5d0a519fb0015a6ffc739aa196abfc");
		//直接改为自己的Application ID就能用了，其他代码不用改，Bmob也不用管，提交成功后自动生成表，列和行。
		
		
    }
	
	public void xiaohengonclick(View view)
	{
		final EditText edittext1=(EditText)findViewById(R.id.mainEditText1);
		final EditText edittext2=(EditText)findViewById(R.id.mainEditText2);
		
		String edit1=edittext1.getText().toString();
		String edit2=edittext2.getText().toString();
		
		int textlong=edittext1.length();
		
		if(edit1.equals("")||edit2.equals(""))
		{
			Toast.makeText(MainActivity.this,"不可以留空哦！",Toast.LENGTH_SHORT).show();
		}
		else if(textlong<15)
		{
			Toast.makeText(MainActivity.this,"不能少于15字哦！",Toast.LENGTH_SHORT).show();
		}
		else
		{
			yijianfankui xiaoheng=new yijianfankui();
			
			xiaoheng.setName(edit1);
			xiaoheng.setAddress(edit2);
			xiaoheng.save(MainActivity.this, new SaveListener(){

					@Override
					public void onSuccess()
					{
						// TODO: Implement this method
						Toast.makeText(MainActivity.this,"反馈成功",Toast.LENGTH_SHORT).show();
						edittext1.setText("");
						edittext2.setText("");
					}

					@Override
					public void onFailure(int p1, String p2)
					{
						// TODO: Implement this method
						Toast.makeText(MainActivity.this,"反馈失败\n请检查是否连接到网络",Toast.LENGTH_SHORT).show();
					}
				});
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.xiaohengmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
			case R.id.item:
				String 小亨QQ号= getResources().getString(R.string.小亨QQ);
				try{
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+小亨QQ号)));
				}catch(Exception xiaoheng){
					Toast.makeText(MainActivity.this,"转跳异常",Toast.LENGTH_LONG).show();
				}
		}
		return super.onOptionsItemSelected(item);
	}
	
}

/****************************************
 *      2017.8.22                       *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
