package com.example.viewInjector;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import com.example.viewInjector.base.BaseFragment;
import com.example.viewInjector.base.BaseViewHolder;
import java.util.ArrayList;
import java.util.List;
import org.view.annotation.ContentView;
import org.view.annotation.Event;
import org.view.annotation.ViewInject;

@ContentView(R.layout.page_example)
public class ExampleFragmentPage extends BaseFragment {

    private ViewHolder holder;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        holder = new ViewHolder(view);
        List<TextItem> items=new ArrayList<>();
        for (int i=0;i < 10;i++) {
            items.add(new TextItem("Item" + i));
        }
        ExampleAdapter adapter=new ExampleAdapter(getActivity(), items);
        holder.listView.setAdapter(adapter);
    }

    
    @Event(R.id.listView,type=AdapterView.OnItemClickListener.class)
    void onItemClick(AdapterView<?> parent, View view, int position, long itemId) {
        TextItem item=(TextItem)parent.getItemAtPosition(position);
        Toast.makeText(getActivity(),item.getText(), Toast.LENGTH_LONG).show();
    }

    public class ViewHolder extends BaseViewHolder {

        @ViewInject(R.id.listView)
        private ListView listView;

        public ViewHolder(View view) {
            super(view);
        }

    }

}
