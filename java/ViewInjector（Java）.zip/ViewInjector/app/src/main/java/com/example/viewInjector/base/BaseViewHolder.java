package com.example.viewInjector.base;
import android.view.View;
import org.view.ViewInjectorManager;

public class BaseViewHolder {

    public final View itemView;

    public BaseViewHolder(View itemView) {
        this.itemView = itemView;
        ViewInjectorManager.getViewInjector()
            .inject(this, itemView);
    }

}
