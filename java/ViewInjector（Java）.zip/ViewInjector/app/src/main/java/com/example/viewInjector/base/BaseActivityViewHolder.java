package com.example.viewInjector.base;
import android.app.Activity;
import org.view.ViewInjectorManager;

public class BaseActivityViewHolder {

    public final Activity activity;

    public BaseActivityViewHolder(Activity activity) {
        this.activity = activity;
        ViewInjectorManager.getViewInjector()
            .inject(this, activity);
    }

}
