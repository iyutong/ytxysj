package com.example.viewInjector;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.viewInjector.base.BaseAdapter;
import java.util.List;
import org.view.ViewInjectorManager;
import org.view.annotation.ViewInject;

public class ExampleAdapter extends BaseAdapter<TextItem,ExampleAdapter.MyViewHolder> {

    final Context context;
    List<TextItem> items;

    public ExampleAdapter(Context context, List<TextItem> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public ExampleAdapter.MyViewHolder onCreateViewHolder(LayoutInflater inflater, ViewGroup parent, int position) {
        ExampleAdapter.MyViewHolder holder=new MyViewHolder(inflater.inflate(R.layout.list_item_text, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(ExampleAdapter.MyViewHolder convertHolder, int position) {
        TextItem item=getItem(position);
        convertHolder.title.setText(item.getText());
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public TextItem getItem(int position) {
        return items.get(position);
    }

    public class MyViewHolder extends ViewHolder {
        
        @ViewInject(R.id.title)
        private TextView title;
        
        public MyViewHolder(View itemView) {
            super(itemView);
            ViewInjectorManager.getViewInjector()
                .inject(this, itemView);
        }
        
    }

}
