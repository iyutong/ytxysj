package com.example.viewInjector.base;

import android.app.ActionBar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.fragment.app.FragmentActivity;
import org.view.MenuItemListenerManager;
import org.view.ViewInjector;
import org.view.ViewInjectorManager;
import org.view.annotation.MenuItemEvent;

public class BaseActivity extends FragmentActivity {

    protected ViewInjector viewInjector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initActionBar();
        injectView();
    }

    /**
     * 注入视图
     */
    private void injectView() {
        viewInjector =  ViewInjectorManager.getViewInjector();
        if (useInjectView()) {
            viewInjector.inject(this);
        }
    }

    private void initActionBar() {
        ActionBar actionBar=getActionBar();
        if (actionBar != null) {
            if (canBack()) {
                actionBar.setDisplayHomeAsUpEnabled(true);
            }
        }
    }


    public boolean useInjectView() {
        return true;
    }

    public boolean canBack() {
        return false;
    }

}
