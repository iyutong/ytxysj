package com.example.viewInjector;

public class TextItem {
    
    private CharSequence text;

    public TextItem(CharSequence text) {
        this.text = text;
    }

    public void setText(CharSequence text) {
        this.text = text;
    }

    public CharSequence getText() {
        return text;
    }
    
}
