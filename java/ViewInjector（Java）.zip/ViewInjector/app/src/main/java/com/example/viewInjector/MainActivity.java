package com.example.viewInjector;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.example.viewInjector.R;
import com.example.viewInjector.base.BaseActivity;
import java.util.ArrayList;
import java.util.List;
import org.view.MenuItemListenerManager;
import org.view.annotation.ContentView;
import org.view.annotation.MenuItemEvent;
import org.view.annotation.OptionsMenu;
import org.view.annotation.ViewInject;
import org.view.common.util.Util;

@ContentView(R.layout.activity_main)
@OptionsMenu(R.menu.options_main)
public class MainActivity extends BaseActivity { 

    @ViewInject(R.id.viewPager)
    private ViewPager viewPager;

    private MenuItemListenerManager menuItemListenerManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewPager.setAdapter(new MyFragmentPagerAdapter());

    }

    /**
     * 设置多个MenuItem
     */
    @MenuItemEvent(values={R.id.item,R.id.item2})
    public boolean test(MenuItem item) {
        Toast.makeText(Util.getApp(), "title=" + item.getTitle(), Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public boolean canBack() {
        return true;
    }

    @Override
    public boolean useInjectView() {
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //开始注入Menu
        menuItemListenerManager 
            = viewInjector.inject(this, menu, getMenuInflater());

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Toast.makeText(Util.getApp(), "onOptionsItemSelected#title=" + item.getTitle(), Toast.LENGTH_SHORT).show();

        //因为获取不到 android.R.id.home 的MenuItem，所以用此方法传入
        menuItemListenerManager.onOptionsItemSelected(item);

        return super.onOptionsItemSelected(item);
    }

    @MenuItemEvent(android.R.id.home)
    @Override
    public void finish() {
        super.finish();
    }

    class MyFragmentPagerAdapter extends FragmentPagerAdapter {

        List<Fragment> fragments=new ArrayList<>();

        public MyFragmentPagerAdapter() {
            super(getSupportFragmentManager());
            for (int i=0;i < 5;i++) {
                fragments.add(new ExampleFragmentPage());
            }
        }

        @Override
        public Fragment getItem(int p1) {
            return fragments.get(p1);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return "Page" + position;
        }

    }

} 
