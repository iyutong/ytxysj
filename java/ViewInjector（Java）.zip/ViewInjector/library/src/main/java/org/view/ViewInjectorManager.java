package org.view;

/**
 * author: s1243808733
 * date: 2020/08/08 22:52
 */
public class ViewInjectorManager {

    private static ViewInjectorManager sInstance;

    private ViewInjector viewInjector;

    private ViewInjectorManager() {
    }

    public static ViewInjector getViewInjector() {
        if (getInstance().viewInjector == null) {
            getInstance().viewInjector = ViewInjectorImpl.getInstance();
        }
        return getInstance().viewInjector;
    }
    
    public void setViewInjector(ViewInjector viewInjector) {
        this.viewInjector = viewInjector;
    }

    public static ViewInjectorManager getInstance() {
        if (sInstance == null) {
            sInstance = new ViewInjectorManager();
        }
        return sInstance;
    }

}
