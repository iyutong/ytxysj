package org.view;
import android.view.MenuItem;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.view.common.util.LogUtil;

public class MenuItemListenerManager  {

    private List<MenuItemClickListener> mMenuItemClickListeners=new ArrayList<>();

    public MenuItemListenerManager() {

    }

    public void addEventMethod(Object handler, Method method, MenuItem item, int itemId) {
        MenuItemClickListener listener = new MenuItemClickListener(handler, method, itemId);
        if (item != null) {
            listener.isSeted = true;
            item.setOnMenuItemClickListener(listener);
        }
        mMenuItemClickListeners.add(listener);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        for (MenuItemClickListener listener:mMenuItemClickListeners) {
            if (listener.itemId == item.getItemId()) {
                if (!listener.isSeted) {
                    return listener.onMenuItemClick(item);
                }
            }
        }
        return false;
    }

    private static class MenuItemClickListener implements MenuItem.OnMenuItemClickListener {

        private final Object handler;

        private final Method method;

        private final int itemId;

        private boolean isSeted;

        public MenuItemClickListener(Object handler, Method method, int itemId) {
            this.handler = handler;
            this.method = method;
            this.itemId = itemId;
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            Object returnValue=null;
            try {
                int parameterCount=method.getParameterCount();
                if (parameterCount == 0) {
                    returnValue = method.invoke(handler);
                } else if (parameterCount == 1) {
                    if (MenuItem.class == method.getParameterTypes()[0]) {
                        returnValue = method.invoke(handler, item == null ?null: item);
                    } 
                }
            } catch (IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
                LogUtil.e(e.getMessage(), e);
            }
            if (returnValue != null && Boolean.class == returnValue.getClass()) {
                return (boolean)returnValue;
            }
            return false;
        }

    }


}
