package com.php.editor;

import android.app.Activity;
import android.os.Bundle;
import com.php.editor.widget.CodePane;
import com.php.editor.widget.PreformEdit;

public class MainActivity extends Activity 
{

	private PreformEdit preformEdit;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		CodePane codePane = new CodePane(this);
        setContentView(codePane);
        String source = "function a(){\n}";
        preformEdit = new PreformEdit(codePane.getCodeText());
        preformEdit.setDefaultText(source);
    }
}
