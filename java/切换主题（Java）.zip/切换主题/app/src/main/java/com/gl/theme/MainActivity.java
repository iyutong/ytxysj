package com.gl.theme;

import android.graphics.drawable.*;
import android.os.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
	private Button bt;//声明弹出提示变量
	private Button bt2;//声明切换主题变量
	private int theme=R.style.PinkAppTheme;//将默认主题保存到theme变量
	private Toast toast;//声明Toast变量
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		//如果savedInstanseTate不为空
		if (savedInstanceState != null) {
			//获得theme数据放到theme变量
			theme = savedInstanceState.getInt("theme", R.style.PinkAppTheme);
			setTheme(theme);//设置主题
		}
		setContentView(R.layout.main);
		//实例化控件
		bt = findViewById(R.id.mainButton1);
		bt2 = findViewById(R.id.mainButton2);

		//如果theme等于默认主题
		if (theme == R.style.PinkAppTheme) {
			//设置相关参数
			myDrawable(bt);
			myDrawable(bt2);
		} else {
			myDrawable2(bt);
			myDrawable2(bt2);
		}
		bt2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					//如果theme等于默认主题
					if (theme == R.style.PinkAppTheme) {
						theme = R.style.GreenAppTheme;//将主题2赋值给theme
						recreate();//重新创建Activity
					} else {
						theme = R.style.PinkAppTheme;
						recreate();
					}
				}
			});
		bt.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					//如果theme等于默认主题
					if (theme == R.style.PinkAppTheme) {
						tw("青久");
					} else {
						tw2("青久");
					}
				}
			});
    }

	//保存Activity状态，当Activity生命周期结束前会调用该方法保存状态
	@Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("theme", theme);//保存theme数据
    }

	//设置控件圆角等属性
	public void myDrawable(View v) {
		//创建GradientDrawable对象，设置控件圆角等属性
		GradientDrawable drawable=new GradientDrawable();
		drawable.setSize(700, 100);//设置长宽
		drawable.setStroke(5, 0xfffb7299);//设置边框宽度/颜色
		drawable.setColor(0x77fb7299);//设置内部填充颜色
		drawable.setCornerRadius(45);//设置圆角半径
		v.setBackground(drawable);//将TextView背景设置为drawable
	}

	//设置控件圆角等属性2
	public void myDrawable2(View v) {
		//创建GradientDrawable对象，设置控件圆角等属性
		GradientDrawable drawable=new GradientDrawable();
		drawable.setSize(700, 100);//设置长宽
		drawable.setStroke(5, 0xfff649485);//设置边框宽度/颜色
		drawable.setColor(0x77f649485);//设置内部填充颜色
		drawable.setCornerRadius(45);//设置圆角半径
		v.setBackground(drawable);//将TextView背景设置为drawable
	}

	//自定义Toast
	public void tw(String msg) {
		//如果toast不为空
		if (toast != null) {
			toast.cancel();//防止Toast重复弹出
		}
		TextView tv=new TextView(this);//创建TextView对象
		tv.setText(msg);//设置文本内容
		tv.setTextSize(18);//设置文本大小
		tv.setTextColor(0xfffb7299);//设置文本颜色
		tv.setGravity(Gravity.CENTER);//设置文本位置
		tv.setPadding(5, 5, 5, 5);//设置文本内边距
		myDrawable(tv);
		toast = new Toast(this);//创建Toast对象
		toast.setView(tv);//设置视图
		toast.setDuration(Toast.LENGTH_LONG);//设置显示时长
		toast.setGravity(Gravity.BOTTOM, 0, 70);//设置位置
		toast.show();//将Toast显示出来
	}

	//自定义Toast
	public void tw2(String msg) {
		//如果toast不为空
		if (toast != null) {
			toast.cancel();//防止Toast重复弹出
		}
		TextView tv=new TextView(this);//创建TextView对象
		tv.setText(msg);//设置文本内容
		tv.setTextSize(18);//设置文本大小
		tv.setTextColor(0xfff649485);//设置文本颜色
		tv.setGravity(Gravity.CENTER);//设置文本位置
		tv.setPadding(5, 5, 5, 5);//设置文本内边距
		myDrawable2(tv);
		toast = new Toast(this);//创建Toast对象
		toast.setView(tv);//设置视图
		toast.setDuration(Toast.LENGTH_LONG);//设置显示时长
		toast.setGravity(Gravity.BOTTOM, 0, 70);//设置位置
		toast.show();//将Toast显示出来
	}
}
