package com.xiaoheng.yonghuzhuche;
import cn.bmob.v3.*;

class xiaohengzhuche extends BmobUser//让xiaohengzhuche继承BmobUser
{}
