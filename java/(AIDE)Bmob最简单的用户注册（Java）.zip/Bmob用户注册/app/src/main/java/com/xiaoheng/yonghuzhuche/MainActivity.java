package com.xiaoheng.yonghuzhuche;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;

/*这是最简单的实现Bmob注册实例

直接把Application ID换上自己的就可以用了，不会改不要乱改，以后我会出登陆的实例

请尊重原创

by.小亨
*/

public class MainActivity extends Activity 
{
	private EditText edittext1,edittext2;//创建编辑框变量
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaohenglayout);
		
		Bmob.initialize(this,"99a26b3b9e330afec9f24b690cadbe84");//初始化Bmob id
		//Application ID
		
		
		edittext1=(EditText)findViewById(R.id.xiaohenglayoutEditText1);//绑定用户名编辑框个id
		edittext2=(EditText)findViewById(R.id.xiaohenglayoutEditText2);//绑定密码编辑框id
    }
	
	
	public void xiaohenglayoutbutton(View view)
	{//注册按钮点击事件   开始
		
		String zhanghao=edittext1.getText().toString();//获取账号编辑框中的字符串
		String mima=edittext2.getText().toString();//获取密码编辑框中的字符串
		
		xiaohengzhuche zhuche=new xiaohengzhuche();//新建一个zhuche对象
		
		zhuche.setUsername(zhanghao);//把账号上传到Bmob，_User表中的username列中
		zhuche.setPassword(mima);//把密码上传到Bmob，_User表中的password列中
		
		zhuche.signUp(this, new SaveListener()
		{//回调事件  开始
		
				@Override
				public void onSuccess()
				{
					//注册成功后运行的事件
					Toast.makeText(MainActivity.this,"注册成功！",Toast.LENGTH_LONG).show();//弹出成功的提示
				}

				@Override
				public void onFailure(int p1, String p2)
				{
					//注册失败后运行的事件
					Toast.makeText(MainActivity.this,"注册失败\n"+p2,Toast.LENGTH_LONG).show();//弹出失败的提示
				}
			});//回调事件   结束
		
	}//注册按钮的点击事件  结束
	
	
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate main_menu.xml 
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.xiaohengmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{

		switch(item.getItemId())
		{
			case R.id.xiaohengitem3:
				String 小亨QQ号= getResources().getString(R.string.小亨QQ);
				try
				{
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+小亨QQ号)));
				}
				catch(Exception e)
				{
					Toast.makeText(MainActivity.this, "转跳失败，未安装手Q或当前版本不支持", 1000).show();
				}
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem2:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://fir.im/AIDElayout")));
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem1:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://pan.baidu.com/s/1slRXapB")));
		}

		return super.onOptionsItemSelected(item);
	}
	
	
	
}


/****************************************
 *      2017.9.2                        *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
