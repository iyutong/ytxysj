package com.kumu.Qrcode;


import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.bumptech.glide.*;
import java.io.*;

public class MainActivity extends Activity 
{
	
	TextView qq;
	
	EditText ed1;
	
	ImageView lmg;
	
	Button bt1,bt2,bt3,bt4;
	
	boolean flag=false;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		
        setContentView(R.layout.main);
		
		qq=(TextView) findViewById(R.id.qq);
		
		ed1=(EditText) findViewById(R.id.mainEditText1);
		
		lmg=(ImageView) findViewById(R.id.mainImageView1);
		
		bt1=(Button) findViewById(R.id.mainButton1);
		
		bt2=(Button) findViewById(R.id.mainButton2);
		
		bt3=(Button) findViewById(R.id.mainButton3);
		
		bt4=(Button) findViewById(R.id.mainButton4);
		
		qq.setText("作者QQ501845535");
		
		
		
		
		bt1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{					
				
				
					if(false==new NetworkDetector(). detect(MainActivity.this)){
						
							ts("网络不可用");
						
						flag=false;
					}else {
						
						
						
					
					String nr=ed1.getText().toString();
					
					
					if(nr.equals("")){
					
						ts("内容不能为空");
						
						flag=false;
				}else{
					
					
					Glide.with(MainActivity.this)
						
						.load("http://api.guaqb.cn/qzcode.php?url=" + nr)
						
						.crossFade(300)
						
						.skipMemoryCache(true)
						
						.into(lmg);
						
						flag=true;
				}	
				}}
			});
		
			
			
		bt2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{


					
					if(flag){
					
					String dir = Environment.getExternalStorageDirectory().getPath().toString();
					
					String contentString = ed1.getText().toString();
					
					lmg.buildDrawingCache(true);  
					lmg.buildDrawingCache();  
					
					Bitmap bitmap = lmg.getDrawingCache();  

					saveMyBitmap(bitmap,contentString);
					
					lmg.setDrawingCacheEnabled(false);
					
					ts("保存成功路径;"+dir +"/枯木_二维码生成器/"+ contentString + ".png");
						
						
					}else{
						
						ts("请先生成二维码");
						
					}
				}
			});
			
			
			
		bt3.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
			
		
		if(flag){
			
		
			lmg.buildDrawingCache(true);  
			lmg.buildDrawingCache();  
			
			Bitmap bitmap = lmg.getDrawingCache();  

			lmg.setDrawingCacheEnabled(false);
			
			Uri uri = Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, null,null));
			Intent intent = new Intent();
			
			intent.setAction(Intent.ACTION_SEND);
			
			intent.setType("image/*");
			intent.putExtra(Intent.EXTRA_STREAM, uri);
			intent = Intent.createChooser(intent, "分享");
			startActivity(intent);
			
		}else{
			
			
			ts("请先生成二维码");
		
				}}
			});
		
		bt4.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					
					ed1.setText("");
					
				}
			});
		
    }
	
	
	public static void saveMyBitmap(Bitmap mBitmap, String bitName) {
		
		String dir = Environment.getExternalStorageDirectory().getPath().toString();
		
		File f = new File(dir +"/枯木_二维码生成器/"+ bitName + ".png");
		if(!f.getParentFile().exists()){
			
			f.getParentFile().mkdir();
		}
		FileOutputStream fOut = null;
		try {
			fOut = new FileOutputStream(f);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		if(fOut==null){
			return ;
		}
		
		mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
		try {
			fOut.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fOut.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void ts(String p0)
	{
		Toast toast = Toast.makeText(MainActivity.this, p0, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 0,200);  
           toast.show();
	}
	
	
	
}

//枯木_AIDE
//QQ"501845535
/*
当前APP信息：
工程名：枯木_二维码生成
包名：com.kumu.Qrcode
*/
