package com.mobai.pd;

import android.app.*;
import android.os.*;

public class b extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.aa);
	}
}
