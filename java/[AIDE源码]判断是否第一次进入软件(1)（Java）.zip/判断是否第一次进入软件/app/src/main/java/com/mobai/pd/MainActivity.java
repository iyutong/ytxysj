package com.mobai.pd;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.content.SharedPreferences;//这两行记得添加
import android.content.SharedPreferences.Editor;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		
		if (isFristRun()) {
			// 如果是第一次启动程序则进入引导界面
			Intent intent = new Intent(MainActivity.this,a.class);
			startActivity(intent);
		} else {
			// 如果不是第一次启动则进入主页
			Intent intent = new Intent(MainActivity.this,b.class);
			startActivity(intent);
		}
		finish();
    }
	private boolean isFristRun() {
		//实例化SharedPreferences对象（第一步）
		SharedPreferences sharedPreferences = this.getSharedPreferences(
			"share", MODE_PRIVATE);
		//实例化SharedPreferences.Editor对象（第二步） 
		boolean isFirstRun = sharedPreferences.getBoolean("isFirstRun", true);
		Editor editor = sharedPreferences.edit();
		if (!isFirstRun) {
			return false;
		} else {
			//保存数据 （第三步）
			editor.putBoolean("isFirstRun", false);
			//提交当前数据 （第四步）
			editor.commit();
			return true;
		}
	}
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {

		}
		return true;
	}
}
