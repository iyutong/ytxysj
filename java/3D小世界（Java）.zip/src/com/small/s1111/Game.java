package com.small.s1111;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class Game extends Activity implements OnClickListener
{
	public static String txt;
	SharedPreferences sps;
	TextView text;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		requestWindowFeature(1);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
       	setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.game);
		ImageButton ibn=(ImageButton)findViewById(R.id.gameImageButton);
		text=(TextView)findViewById(R.id.gametext);
		ibn.setOnClickListener(this);
	}

	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	
	}
	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		sps=getSharedPreferences("save",MODE_WORLD_WRITEABLE);
		boolean mode=sps.getBoolean("TBtn",false);
		if(mode)
		{
			if(!Meun.mediaplayer.isPlaying())
				Meun.mediaplayer.start();
			else
				Meun.mediaplayer.pause();
		}
		else
			Meun.mediaplayer.pause();	
		super.onPause();
	}
}

