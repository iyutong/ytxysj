package com.small.s1111;
import javax.microedition.khronos.opengles.*;
import android.util.*;

public class Robot
{
	int al0,al1,i;
	int mode1,mode2;
	Ball antenna;
	CylinderSide antennaside;
	
	Ball head;
	Circle headcircle;
	
	CylinderSide cylinderside;
	
	Capsule arm;
	
	Capsule leg;
	
	float size=2;
	float ar=0.2f*size,al=1.0f*size;
	float hr=2.0f*size,hcl=1.0f;
	float cr=2.0f*size,cl=2.8f*size;
	float mr=0.5f*size,ml=1.6f*size;
	float lr=0.6f*size,ll=1.5f*size;
	public Robot()
	{
		//天线
		antenna=new Ball(ar,90,10,10,OpenglView.id[2]);
		antennaside=new CylinderSide(ar,ar,al,360,5,OpenglView.id[2]);
		//头
		head=new Ball(hr,90,10,30,OpenglView.id[3]);
		headcircle=new Circle(hr,360,50,OpenglView.id[2]);
		//身
		cylinderside=new CylinderSide(cr,cr,cl,360,50,OpenglView.id[2]);
		//手
		arm=new Capsule(mr,ml,10,20,OpenglView.id[2]);
		//腿
		leg=new Capsule(lr,ll,10,30,OpenglView.id[2]);
		
		OpenglView.Robotl=cl/2+ar*hcl+ll+lr*2+ar;
	}
	public void drawSelf(GL10 gl,int a,int b)
	{
		mode1=a;
		mode2=b;
		if(mode2<2&&mode1==1)
		{
			if(al0==-60)i=0;
			if(i==0)al0+=30;
			if(i==1)al0-=30;
			if(al0==60)i=1;
		}
		if((mode1==0||mode2>1)&&al0!=0)
			al0=0;
			
		if(mode2>1&&mode1==1)
		{
			if(al1==-30)i=0;
			if(i==0)al1+=15;
			if(i==1)al1-=15;
			if(al1==30)i=1;
		}
		if((mode1==0||mode2<2)&&al1!=0)
			al1=0;
			
		gl.glPushMatrix();
		gl.glRotatef(90,1,0,0);
		//左天线
		gl.glPushMatrix();
		gl.glTranslatef(-hr/2,cl/2+hr+ar*hcl+ar-al,0);
		gl.glRotatef(30,0,0,1);

		gl.glPushMatrix();
		gl.glTranslatef(0,al,0);
		gl.glRotatef(90,1,0,0);
		antenna.drawSelf(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glTranslatef(0,0,0);
		gl.glRotatef(0,0,0,0);
		antennaside.drawSelf(gl);
		gl.glPopMatrix();
		gl.glPopMatrix();
		//右天线
		gl.glPushMatrix();
		gl.glTranslatef(hr/2,cl/2+hr+ar*hcl+ar-al,0);
		gl.glRotatef(-30,0,0,1);

		gl.glPushMatrix();
		gl.glTranslatef(0,al,0);
		gl.glRotatef(90,1,0,0);
		antenna.drawSelf(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glTranslatef(0,0,0);
		gl.glRotatef(0,0,0,0);
		antennaside.drawSelf(gl);
		gl.glPopMatrix();
		gl.glPopMatrix();
		//头
		gl.glPushMatrix();
		gl.glTranslatef(0,cl/2+ar*hcl,0);
		gl.glRotatef(0,0,0,0);

		gl.glPushMatrix();
		gl.glTranslatef(0,0,0);
		gl.glRotatef(-90,0,1,0);
		head.drawSelf(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glTranslatef(0,0,0);
		gl.glRotatef(90,1,0,0);
		headcircle.drawSelf(gl);
		gl.glPopMatrix();
		gl.glPopMatrix();
		//身
		gl.glPushMatrix();
		gl.glTranslatef(0,0,0);
		gl.glRotatef(0,0,0,0);
		
		gl.glPushMatrix();
		gl.glTranslatef(0,cl/2,0);
		gl.glRotatef(-90,1,0,0);
		headcircle.drawSelf(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glTranslatef(0,-cl/2,0);
		gl.glRotatef(0,0,0,0);
		cylinderside.drawSelf(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glTranslatef(0,-cl/2,0);
		gl.glRotatef(90,1,0,0);
		headcircle.drawSelf(gl);
		gl.glPopMatrix();
		gl.glPopMatrix();
		//左手
		gl.glPushMatrix();
		gl.glTranslatef(-hr-ar*hcl-mr,cl/2-mr,0);
		gl.glRotatef(al0,1,0,0);
		arm.drawSelf(gl);
		gl.glPopMatrix();
		//右手
		gl.glPushMatrix();
		gl.glTranslatef(hr+ar*hcl+mr,cl/2-mr,0);
		gl.glRotatef(-al0,1,0,0);
		arm.drawSelf(gl);
		gl.glPopMatrix();
		//左腿
		gl.glPushMatrix();
		gl.glTranslatef(-hr/4-lr/2,-(cl/2+ar*hcl+lr),0);
		gl.glRotatef(-al0,1,0,0);
		gl.glRotatef(-al1,0,0,1);
		leg.drawSelf(gl);
		gl.glPopMatrix();
		//右腿
		gl.glPushMatrix();
		gl.glTranslatef(hr/4+lr/2,-(cl/2+ar*hcl+lr),0);
		gl.glRotatef(al0,1,0,0);
		gl.glRotatef(al1,0,0,1);
		leg.drawSelf(gl);
		gl.glPopMatrix();
		
		gl.glPopMatrix();
	}
}
