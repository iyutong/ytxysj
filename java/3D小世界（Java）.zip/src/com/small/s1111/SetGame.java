package com.small.s1111;

import android.app.*;
import android.content.pm.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import android.content.*;
import android.view.inputmethod.*;

public class SetGame extends Activity implements OnCheckedChangeListener
{
	SharedPreferences sps;
	boolean mode;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		requestWindowFeature(1);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
       	setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.set);
		sps=getSharedPreferences("save",MODE_WORLD_WRITEABLE);
		mode=sps.getBoolean("TBtn",false);
		ToggleButton TBtn=(ToggleButton)findViewById(R.id.setTbtn0);
		if(mode)
			TBtn.setChecked(true);
		else
			TBtn.setChecked(false);
		TBtn.setOnCheckedChangeListener(this);
	}
	public void onCheckedChanged(CompoundButton p1, boolean p2)
	{
		// TODO: Implement this method
		sps.edit().putBoolean("TBtn",p2).commit();
	}
}
