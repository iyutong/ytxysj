package com.small.s1111;
import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class Map3D
{
	FloatBuffer tex,ver,nor;
	int vCount,id;
	public Map3D(int w,int h,int n,float[][] array,int id)
	{
		this.id=id;
		vCount=w*h*6;
		float[] textures=new float[vCount*2];
		float[] vertices=new float[vCount*3];
		float[] normals =new float[vCount*3];
		int c=0,d=0,e=0;
		for(int a=0;a<w;a++)
		for(int b=0;b<h;b++)
		{
			
			int anext=a+1;
			int bnext=b+1;
			int an=a*n,anextn=anext*n;
			int bn=b*n,bnextn=bnext*n;
			
			float x0=an;
			float y0=bn;
			float z0=array[a][b];
			
			float x1=anextn;
			float y1=bn;
			float z1=array[anext][b];
			
			float x2=anextn;
			float y2=bnextn;
			float z2=array[anext][bnext];
			
			float x3=an;
			float y3=bnextn;
			float z3=array[a][bnext];
			
			vertices[c++]=x0;
			vertices[c++]=y0;
			vertices[c++]=z0;
			textures[d++]=x0/w;
			textures[d++]=y0/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
			
			vertices[c++]=x1;
			vertices[c++]=y1;
			vertices[c++]=z1;
			textures[d++]=x1/w;
			textures[d++]=y1/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
			
			vertices[c++]=x2;
			vertices[c++]=y2;
			vertices[c++]=z2;
			textures[d++]=x2/w;
			textures[d++]=y2/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
			
			vertices[c++]=x0;
			vertices[c++]=y0;
			vertices[c++]=z0;
			textures[d++]=x0/w;
			textures[d++]=y0/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
			
			vertices[c++]=x2;
			vertices[c++]=y2;
			vertices[c++]=z2;
			textures[d++]=x2/w;
			textures[d++]=y2/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
			
			vertices[c++]=x3;
			vertices[c++]=y3;
			vertices[c++]=z3;
			textures[d++]=x3/w;
			textures[d++]=y3/w;
			normals[e++]=0;
			normals[e++]=0;
			normals[e++]=1;
		}
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertices.length*4);
		vbb.order(ByteOrder.nativeOrder());
		ver=vbb.asFloatBuffer();
		ver.put(vertices);
		ver.position(0);

		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		tbb.order(ByteOrder.nativeOrder());
		tex=tbb.asFloatBuffer();
		tex.put(textures);
		tex.position(0);

		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		nor=nbb.asFloatBuffer();
		nor.put(normals);
		nor.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量

		gl.glVertexPointer(3,GL10.GL_FLOAT,0,ver);
		gl.glNormalPointer(GL10.GL_FLOAT,0,nor);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,tex);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,vCount);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
