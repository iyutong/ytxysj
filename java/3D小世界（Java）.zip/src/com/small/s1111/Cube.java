//矩形封装类
//A：矩形在X轴的长度
//B：矩形在Y轴的长度
//C：矩形在Z轴的长度
//中心坐标（0，0，0）
package com.small.s1111;
import javax.microedition.khronos.opengles.*;

public class Cube
{
	TextureRect[] drect= new TextureRect[6];
	public  Cube(GL10 gl,float a,float b,float c,int id)
	{
		drect[0]=new TextureRect(a,b,id);
		drect[1]=new TextureRect(a,b,id);
		drect[2]=new TextureRect(c,b,id);
		drect[3]=new TextureRect(c,b,id);
		drect[4]=new TextureRect(a,c,id);
		drect[5]=new TextureRect(a,c,id);
		//前
		gl.glPushMatrix();
		gl.glTranslatef(0,0,c);
		drect[0].drawSelf(gl);
		gl.glPopMatrix();
		//后
		gl.glPushMatrix();
		gl.glTranslatef(0,0,-c);
		gl.glRotatef(180,0,1,0);
		drect[1].drawSelf(gl);
		gl.glPopMatrix();
		//左
		gl.glPushMatrix();
		gl.glTranslatef(-a,0,0);
		gl.glRotatef(-90,0,1,0);
		drect[2].drawSelf(gl);
		gl.glPopMatrix();
		//右
		gl.glPushMatrix();
		gl.glTranslatef(a,0,0);
		gl.glRotatef(90,0,1,0);
		drect[3].drawSelf(gl);
		gl.glPopMatrix();
		//上
		gl.glPushMatrix();
		gl.glTranslatef(0,b,0);
		gl.glRotatef(-90,1,0,0);
		drect[4].drawSelf(gl);
		gl.glPopMatrix();
		//下
		gl.glPushMatrix();
		gl.glTranslatef(0,-b,0);
		gl.glRotatef(90,1,0,0);
		drect[5].drawSelf(gl);
		gl.glPopMatrix();
	}
}
