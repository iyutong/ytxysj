//圆柱面类
//R0：上圆半径；R1：底圆半径
//H：高度；N：圆柱边数
//angle:角度值，取值0-360;
//底圆圆心坐标：（0，0，0）
package com.small.s1111;
import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class CylinderSide
{
	FloatBuffer vex,tex,nex;
	int id,vCount;
	public CylinderSide(float r0,float r1,float h,float angle,int n,int id)
	{
		this.id=id;
		int a=0,b=0,f=0;
		float next=angle/n;
		vCount=n*6;
		float[] vertices=new float[vCount*3];
		float[] textures=new float[vCount*2];
		float[] normals=new float[vCount*3];
		for(float c=0;c<angle;c+=next)
		{
			double d=Math.toRadians(c);
			double e=Math.toRadians(c+next);
			float x0=(float)(r0*Math.sin(d));
			float y0=(float)h;
			float z0=(float)(r0*Math.cos(d));

			float x1=(float)(r1*Math.sin(d));
			float y1=(float)0;
			float z1=(float)(r1*Math.cos(d));

			float x2=(float)(r1*Math.sin(e));
			float y2=(float)0;
			float z2=(float)(r1*Math.cos(e));

			float x3=(float)(r0*Math.sin(e));
			float y3=(float)h;
			float z3=(float)(r0*Math.cos(e));

			vertices[a++]=-x0;
			vertices[a++]=y0;
			vertices[a++]=-z0;
			textures[b++]=(float)(c/angle);
			textures[b++]=0;
			normals[f++]=(float)Math.sin(d);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(d);

			vertices[a++]=-x1;
			vertices[a++]=y1;
			vertices[a++]=-z1;
			textures[b++]=(float)(c/angle);
			textures[b++]=1;
			normals[f++]=(float)Math.sin(d);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(d);
			
			vertices[a++]=-x2;
			vertices[a++]=y2;
			vertices[a++]=-z2;
			textures[b++]=(float)(c/angle);
			textures[b++]=1;
			normals[f++]=(float)Math.sin(e);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(e);

			vertices[a++]=-x0;
			vertices[a++]=y0;
			vertices[a++]=-z0;
			textures[b++]=(float)(c/angle);
			textures[b++]=0;
			normals[f++]=(float)Math.sin(d);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(d);
			
			vertices[a++]=-x2;
			vertices[a++]=y2;
			vertices[a++]=-z2;
			textures[b++]=(float)(c/angle);
			textures[b++]=1;
			normals[f++]=(float)Math.sin(e);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(e);
			
			vertices[a++]=-x3;
			vertices[a++]=y3;
			vertices[a++]=-z3;
			textures[b++]=(float)(c/angle);
			textures[b++]=0;
			normals[f++]=(float)Math.sin(e);
			normals[f++]=0;
			normals[f++]=(float)Math.cos(e);
		}
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertices.length*4);
		vbb.order(ByteOrder.nativeOrder());
		vex=vbb.asFloatBuffer();
		vex.put(vertices);
		vex.position(0);

		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		tbb.order(ByteOrder.nativeOrder());
		tex=tbb.asFloatBuffer();
		tex.put(textures);
		tex.position(0);
		
		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		nex=nbb.asFloatBuffer();
		nex.put(normals);
		nex.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量

		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vex);
		gl.glNormalPointer(GL10.GL_FLOAT,0,nex);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,tex);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,vCount);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
