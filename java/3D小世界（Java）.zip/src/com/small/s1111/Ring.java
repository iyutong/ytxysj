//椭圆环类
//R0、R1：圆环半径
//r：圆环圆半径
//RN：圆环边数；N：圆环切面圆边数
//RA：取值0-360，如：180则绘制半个圆环，360：则完整圆环
//注意：RA除以RN必须是整数
package com.small.s1111;

import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class Ring
{
	FloatBuffer vex,tex,nex;
	int vCount,id;
	public Ring(float R0,float R1,float r,int Rn,int rn,int Ra,int id)
	{
		this.id=id;
		float next0=Ra/Rn;
		double Ra0=Math.toRadians(Ra);
		float next1=360/rn;
		vCount=Rn*rn*6;
		float[] vertices=new float[vCount*3];
		float[] normals=new float[vCount*3];
		float[] textures=new float[vCount*2];
		int a=0,b=0,e=0;
		for(int c=0;c<Ra;c+=next0)
		{
			double c0=Math.toRadians(c);
			double c1=Math.toRadians(c+next0);
			for(int d=0;d<360;d+=next1)
			{
				double d0=Math.toRadians(d);
				double d1=Math.toRadians(d+next1);
				
				double tan0=Math.atan((r*Math.cos(d0))/(R0+r*Math.sin(d0)));
				double tan1=Math.atan((r*Math.cos(d1))/(R0+r*Math.sin(d1)));
				
				double Rr0=R0+r*Math.sin(d0);
				double Rr1=R0+r*Math.sin(d1);
				
				double r00=R1+r*Math.sin(d0);
				double r01=R1+r*Math.sin(d1);
				
				float x0=(float)(Rr0*Math.cos(c0));
				float y0=(float)(Rr0*Math.tan(tan0));
				float z0=(float)(r00*Math.cos(c0)*Math.tan(c0));
				
				float x1=(float)(Rr1*Math.cos(c0));
				float y1=(float)(Rr1*Math.tan(tan1));
				float z1=(float)(r01*Math.cos(c0)*Math.tan(c0));
	
				float x2=(float)(Rr1*Math.cos(c1));
				float y2=(float)(Rr1*Math.tan(tan1));
				float z2=(float)(r01*Math.cos(c1)*Math.tan(c1));
				
				float x3=(float)(Rr0*Math.cos(c1));
				float y3=(float)(Rr0*Math.tan(tan0));
				float z3=(float)(r00*Math.cos(c1)*Math.tan(c1));
				
				double nRr0=R0+Math.sin(d0);
				double nRr1=R0+Math.sin(d1);
				double nr00=R1+Math.sin(d0);
				double nr01=R1+Math.sin(d1);
				float nx0=(float)(nRr0*Math.cos(c0));
				float ny0=(float)(nRr0*Math.tan(tan0));
				float nz0=(float)(nr00*Math.cos(c0)*Math.tan(c0));
				float nx1=(float)(nRr1*Math.cos(c0));
				float ny1=(float)(nRr1*Math.tan(tan1));
				float nz1=(float)(nr01*Math.cos(c0)*Math.tan(c0));
				float nx2=(float)(nRr1*Math.cos(c1));
				float ny2=(float)(nRr1*Math.tan(tan1));
				float nz2=(float)(nr01*Math.cos(c1)*Math.tan(c1));
				float nx3=(float)(nRr0*Math.cos(c1));
				float ny3=(float)(nRr0*Math.tan(tan0));
				float nz3=(float)(nr00*Math.cos(c1)*Math.tan(c1));
				
				vertices[a++]=-x0;
				vertices[a++]=y0;
				vertices[a++]=-z0;
				textures[b++]=(float)(c0/Ra0);
				textures[b++]=(float)(d0/(Math.PI*2));
				normals[e++]=-nx0;
				normals[e++]=ny0;
				normals[e++]=-nz0;
				
				vertices[a++]=-x2;
				vertices[a++]=y2;
				vertices[a++]=-z2;
				textures[b++]=(float)(c1/Ra0);
				textures[b++]=(float)(d1/(Math.PI*2));
				normals[e++]=-nx2;
				normals[e++]=ny2;
				normals[e++]=-nz2;
				
				vertices[a++]=-x1;
				vertices[a++]=y1;
				vertices[a++]=-z1;
				textures[b++]=(float)(c0/Ra0);
				textures[b++]=(float)(d1/(Math.PI*2));
				normals[e++]=-nx1;
				normals[e++]=ny1;
				normals[e++]=-nz1;
				
				vertices[a++]=-x0;
				vertices[a++]=y0;
				vertices[a++]=-z0;
				textures[b++]=(float)(c0/Ra0);
				textures[b++]=(float)(d0/(Math.PI*2));
				normals[e++]=-nx0;
				normals[e++]=ny0;
				normals[e++]=-nz0;
				
				vertices[a++]=-x3;
				vertices[a++]=y3;
				vertices[a++]=-z3;
				textures[b++]=(float)(c1/Ra0);
				textures[b++]=(float)(d0/(Math.PI*2));
				normals[e++]=-nx3;
				normals[e++]=ny3;
				normals[e++]=-nz3;

				vertices[a++]=-x2;
				vertices[a++]=y2;
				vertices[a++]=-z2;
				textures[b++]=(float)(c1/Ra0);
				textures[b++]=(float)(d1/(Math.PI*2));
				normals[e++]=-nx2;
				normals[e++]=ny2;
				normals[e++]=-nz2;
			}
		}
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertices.length*4);
		vbb.order(ByteOrder.nativeOrder());
		vex=vbb.asFloatBuffer();
		vex.put(vertices);
		vex.position(0);

		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		tbb.order(ByteOrder.nativeOrder());
		tex=tbb.asFloatBuffer();
		tex.put(textures);
		tex.position(0);
		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		nex=nbb.asFloatBuffer();
		nex.put(normals);
		nex.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量

		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vex);
		gl.glNormalPointer(GL10.GL_FLOAT,0,nex);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,tex);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,vCount);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
