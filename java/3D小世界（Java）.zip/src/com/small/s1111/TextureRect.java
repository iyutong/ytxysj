//矩形类
//A：矩形在X轴的长度
//B：矩形在Y轴的长度
package com.small.s1111;
import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class TextureRect
{
	FloatBuffer vertexbuffer,texturebuffer,normalbuffer;
	int id;
	public TextureRect(float a,float b,int id)
	{
		this.id=id;
		float vertexs[]={
			-a,-b,0,a,b,0,-a,b,0,
			-a,-b,0,a,-b,0,a,b,0,
			};
		float textures[]={
			0,1,1,0,0,0,
			0,1,1,1,1,0,
		};
		float[] normals=
		{
			0,0,1,0,0,1,0,0,1,
			0,0,1,0,0,1,0,0,1,
		};
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertexs.length*4);//创建顶点数据缓冲
		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		vbb.order(ByteOrder.nativeOrder());//设置字节顺序
		tbb.order(ByteOrder.nativeOrder());
		vertexbuffer=vbb.asFloatBuffer();//转换成float
		texturebuffer=tbb.asFloatBuffer();
		vertexbuffer.put(vertexs);
		texturebuffer.put(textures);
		vertexbuffer.position(0);
		texturebuffer.position(0);
		
		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		normalbuffer=nbb.asFloatBuffer();
		normalbuffer.put(normals);
		normalbuffer.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量
		
		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vertexbuffer);
		gl.glNormalPointer(GL10.GL_FLOAT,0,normalbuffer);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,texturebuffer);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,6);
		
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
