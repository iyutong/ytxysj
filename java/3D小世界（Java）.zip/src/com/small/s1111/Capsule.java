package com.small.s1111;

import javax.microedition.khronos.opengles.*;

public class Capsule
{
	Ball ball;
	CylinderSide cylinderSide;
	int id;
	float l;
	public Capsule(float r,float l,int ln,int n,int id)
	{
		this.id=id;
		this.l=l;
		ball=new Ball(r,90,ln,n,id);
		cylinderSide=new CylinderSide(r,r,l,360,n,id);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		ball.drawSelf(gl);
		gl.glPopMatrix();
		
		gl.glPushMatrix();
		gl.glRotatef(180,1,0,0);
		cylinderSide.drawSelf(gl);
		gl.glPopMatrix();
		
		gl.glPushMatrix();
		gl.glTranslatef(0,-l,0);
		gl.glRotatef(180,1,0,0);
		ball.drawSelf(gl);
		gl.glPopMatrix();
	}
}
