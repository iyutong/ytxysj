package com.small.s1111;

import android.annotation.*;
import android.content.*;
import android.graphics.*;
import android.opengl.*;
import android.util.*;
import android.view.*;
import java.io.*;
import javax.microedition.khronos.egl.*;
import javax.microedition.khronos.opengles.*;
import javax.microedition.khronos.egl.EGLConfig;

public class OpenglView extends GLSurfaceView
{
	static int[] id=new int[6];
	AnitEllipsiod anit;
	TextureRect m;
	TextureRect water;
	float mx,my;
	Robot robot;
	int Rx,Ry;
	int mn;
	float robotx,roboty,robotz;
	float Robotx,Roboty,Robotz,Robotr;
	float Robotx1,Roboty1;
	int Nextx,Nexty,Nextx0,Nexty0;
	public static float Robotl;
	int W,H,bmpn=5;
	public OpenglView(Context context,AttributeSet attr)
	{
		super(context,attr);
		this.setRenderer(new GLRenderer());
	}
	class GLRenderer implements GLSurfaceView.Renderer
	{

		@Override
		public void onSurfaceCreated(GL10 gl, EGLConfig p2)
		{
			// TODO: Implement this method
			//gl.glDisable(GL10.GL_DITHER)//;//关闭抗抖动
			gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT,GL10.GL_FASTEST);//设置系统对视图修正
			gl.glEnable(GL10.GL_TEXTURE_2D);
			gl.glEnable(GL10.GL_DEPTH_TEST);//启用深度测试
			gl.glDepthFunc(GL10.GL_LEQUAL);
			gl.glShadeModel(GL10.GL_SMOOTH);
			id[0]=inittextures(gl,R.drawable.grass);
			id[1]=inittextures(gl,R.drawable.m);
			id[2]=inittextures(gl,R.drawable.robot_texid);
			id[3]=inittextures(gl,R.drawable.robot_head);
			id[4]=inittextures(gl,R.drawable.sky);
			id[5]=inittextures(gl,R.drawable.water);
			robot=new Robot();
			anit=new AnitEllipsiod(1500,1000,1500,100,10,90,id[4]);
			m=new TextureRect(0.15f,0.15f,OpenglView.id[1]);
			water=new TextureRect(1500,1500,id[5]);
			load();
		}

		@Override
		public void onSurfaceChanged(GL10 gl, int p2, int p3)
		{
			// TODO: Implement this method
			W=p2;H=p3;
			gl.glViewport(0,0,p2,p3);//设置视窗大小
			gl.glMatrixMode(GL10.GL_PROJECTION);//设置投影矩阵
			gl.glLoadIdentity();//初始化矩阵
			float ratio=(float)p2/p3;
			gl.glFrustumf(-ratio,ratio,-1,1,1.5f,3000);
		
		}
		int mi;
		@Override
		public void onDrawFrame(GL10 gl)
		{
			// TODO: Implement this method
			gl.glClearColor(0f,0f,0f,0);
			gl.glClear(GL10.GL_COLOR_BUFFER_BIT|GL10.GL_DEPTH_BUFFER_BIT);
			gl.glMatrixMode(GL10.GL_MODELVIEW);
			gl.glLoadIdentity();
			if(mn==1)
			{
				mi++;
				if(mi==1||mi>2)
					switch(ma)
					{
						case 0:
							Robotr=lookX;
							roboty=3f;
							break;
						case 1:
							Robotr=lookX;
							roboty=-3f;
							break;
						case 2:
							Robotr=lookX;
							robotx=-1.7f;
							break;
						case 3:
							Robotr=lookX;
							robotx=1.7f;
							break;
					}
			}
			else
				mi=0;
			if(ma<2)
			{
				Robotx+=(float)Math.sin(Math.toRadians(-lookX))*roboty;
				Roboty+=(float)Math.cos(Math.toRadians(-lookX))*roboty;
				Nextx0=(int)Robotx/bmpn;
				Nexty0=(int)Roboty/bmpn;
				Robotx1=Robotx+(float)Math.sin(Math.toRadians(-lookX))*roboty;
				Roboty1=Roboty+(float)Math.cos(Math.toRadians(-lookX))*roboty;
				Nextx=(int)Robotx1/bmpn;
				Nexty=(int)Roboty1/bmpn;
				if(bmpwh[Nextx+150][Nexty+150]>bmpwh[Nextx0+150][Nexty0+150]+Robotl)
				{
					Robotx-=(float)Math.sin(Math.toRadians(-lookX))*roboty;
					Roboty-=(float)Math.cos(Math.toRadians(-lookX))*roboty;
				}
			}
			if(ma>1)
			{
				Robotx+=(float)Math.cos(Math.toRadians(lookX))*robotx;
				Roboty+=(float)Math.sin(Math.toRadians(lookX))*robotx;
				Nextx0=(int)Robotx/bmpn;
				Nexty0=(int)Roboty/bmpn;
				Robotx1=Robotx+(float)Math.cos(Math.toRadians(lookX))*robotx;
				Roboty1=Roboty+(float)Math.sin(Math.toRadians(lookX))*robotx;
				Nextx=(int)Robotx1/bmpn;
				Nexty=(int)Roboty1/bmpn;
				if(bmpwh[Nextx+150][Nexty+150]>bmpwh[Nextx0+150][Nexty0+150]+Robotl*0.5f)
				{
					Robotx-=(float)Math.cos(Math.toRadians(lookX))*robotx;
					Roboty-=(float)Math.sin(Math.toRadians(lookX))*robotx;
				}
			}
			Rx=(int)Robotx/bmpn;
			Ry=(int)Roboty/bmpn;
			Robotz=bmpwh[Rx+150][Ry+150]+Robotl-100;
			robotx=roboty=0;
			
			gl.glPushMatrix();
			GLU.gluLookAt(gl,
						  80*(float)Math.sin(Math.toRadians(lookX))+Robotx,
						  -80*(float)Math.cos(Math.toRadians(lookX))+Roboty,
						  lookY+40+Robotz,
						  Robotx,
						  Roboty,
						  Robotz,
						  -(float)Math.sin(Math.toRadians(lookX)),
						  (float)Math.cos(Math.toRadians(lookX)),
						  0);

			gl.glPushMatrix();
			gl.glRotatef(90,1,0,0);
			anit.drawSelf(gl);
			gl.glPopMatrix();
			
			gl.glPushMatrix();
			gl.glTranslatef(Robotx,Roboty,Robotz);
			gl.glRotatef(Robotr,0,0,1);
			robot.drawSelf(gl,mn,ma);
			gl.glPopMatrix();
			
			gl.glPushMatrix();
			gl.glTranslatef(-bmpn*150,-bmpn*150,-100f);
			map3D.drawSelf(gl);
			gl.glPopMatrix();
			
			gl.glPushMatrix();
			gl.glTranslatef(0,0,-100f);
			water.drawSelf(gl);
			gl.glPopMatrix();
			
			gl.glPopMatrix();
			if(mn>0)
			{
			gl.glPushMatrix();
			gl.glTranslatef(mx-1.3f,my+0.3f,-1.5f);
			gl.glEnable(GL10.GL_BLEND);
			gl.glBlendFunc(GL10.GL_SRC_ALPHA,GL10.GL_ONE);
			m.drawSelf(gl);
			gl.glDisable(GL10.GL_BLEND);
			gl.glPopMatrix();
			}
		}
	}
	int bmpw,bmph;
	float[][] bmpwh;
	Map3D map3D;
	public void load()
	{
		Bitmap bmp=BitmapFactory.decodeResource(this.getResources(),R.drawable.bmp);
		bmpw=bmp.getWidth();
		bmph=bmp.getHeight();
		bmpwh=new float[bmpw+1][bmph+1];
		for(int bw=0;bw<bmpw;bw++)
			for(int bh=0;bh<bmph;bh++)
			{
				int color=bmp.getPixel(bw,bh);
				int r=Color.red(color);
				int g=Color.green(color);
				int b=Color.blue(color);
				int h=(r+g+b)/3;
				bmpwh[bw][bh]=h;
			}
		map3D=new Map3D(bmpw,bmph,bmpn,bmpwh,id[0]);
	}
	private int inittextures(GL10 gl,int bmpid)
	{
		int[] textures=new int[1];
		gl.glGenTextures(1,textures,0);
		int textureid=textures[0];
		gl.glBindTexture(GL10.GL_TEXTURE_2D,textureid);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D,GL10.GL_TEXTURE_MIN_FILTER,GL10.GL_LINEAR_MIPMAP_NEAREST);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D,GL10.GL_TEXTURE_MAG_FILTER,GL10.GL_LINEAR_MIPMAP_LINEAR);
		((GL11)gl).glTexParameterf(GL10.GL_TEXTURE_2D,GL11.GL_GENERATE_MIPMAP,GL10.GL_TRUE);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D,GL10.GL_CLAMP_TO_EDGE,GL10.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D,GL10.GL_CLAMP_TO_EDGE,GL10.GL_CLAMP_TO_EDGE);
		InputStream is=this.getResources().openRawResource(bmpid);
		Bitmap bitmap = null;
		try{
			bitmap=BitmapFactory.decodeStream(is);
		}
		finally
		{
			try
			{
				is.close();
			}
			catch (IOException e)
			{}
		}
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap, 0);
		bitmap.recycle();
		return textureid;
	}
	int ma;
	float x0,y0,x1,y1,x2,y2;
	float lookX,lookY;
	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		mn=0;
		// TODO: Implement this methou
		if(event.getX()>W/3)
		{
			if(event.getAction()==MotionEvent.ACTION_DOWN)
			{
				x0=event.getX();
				y0=event.getY();
			}
			if(event.getAction()==MotionEvent.ACTION_MOVE)
			{
				x1=x0-event.getX();
				y1=y0-event.getY();
				x0=event.getX();
				y0=event.getY();
				lookX+=x1/10f;
				lookY+=y1/-10f;
			}
			if(event.getAction()==MotionEvent.ACTION_UP)
			{
				x1=y1=x0=y0=0;
			}
		}
		if(event.getX()<W/3&&event.getY()>H/3)
		{
			mn=1;
			if(event.getAction()==MotionEvent.ACTION_DOWN)
			{
				x0=event.getX();
				y0=event.getY();
			}
			if(event.getAction()==MotionEvent.ACTION_MOVE)
			{
				x1=x0-event.getX();
				y1=y0-event.getY();
				if(x1*x1>y1*y1)
				{
					if(x1<0)ma=3;
					if(x1>0)ma=2;
						
				}
				if(y1*y1>x1*x1)
				{
					if(y1<0)ma=1;
					if(y1>0)ma=0;
				}
			}
			if(event.getAction()==MotionEvent.ACTION_UP)
			{
				x1=y1=mn=0;
			}
			mx=event.getX()/W;
			my=-event.getY()/H;
		}
		return true;
	}
	
}
