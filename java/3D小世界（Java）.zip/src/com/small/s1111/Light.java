package com.small.s1111;

import javax.microedition.khronos.opengles.*;

public class Light
{
	public Light(GL10 gl,float x,float y,float z)
	{
		gl.glEnable(GL10.GL_LIGHTING);
		gl.glEnable(GL10.GL_LIGHT0);
		gl.glEnable(GL10.GL_LIGHT1);
		//光
		float[] directionparam={x,y,z,0};
		gl.glLightfv(GL10.GL_LIGHT0,GL10.GL_POSITION,directionparam,0);
		
		float[] ambientParams={0.5f,0.5f,0.5f,1f};
		gl.glLightfv(GL10.GL_LIGHT0,GL10.GL_AMBIENT,ambientParams,0);
		float[] diffuseParams={1.0f,1.0f,1.0f,1f};
		gl.glLightfv(GL10.GL_LIGHT0,GL10.GL_DIFFUSE,diffuseParams,0);
		float[] specularParams={1f,1f,1f,1f};
		gl.glLightfv(GL10.GL_LIGHT0,GL10.GL_SPECULAR,specularParams,0);
		//光材质
		float[] ambientMaterial={0.5f,0.5f,0.5f,1f};
		gl.glMaterialfv(GL10.GL_FRONT_AND_BACK,GL10.GL_AMBIENT,ambientMaterial,0);
		float[] diffuseMaterial={0.8f,0.8f,0.8f,1f};
		gl.glMaterialfv(GL10.GL_FRONT_AND_BACK,GL10.GL_DIFFUSE,diffuseMaterial,0);
		float[] specularMaterial={1f,1f,1f,1f};
		gl.glMaterialfv(GL10.GL_FRONT_AND_BACK,GL10.GL_SPECULAR,specularMaterial,0);
		float[] shininessMaterial={1.5f};
		gl.glMaterialfv(GL10.GL_FRONT_AND_BACK,GL10.GL_SHININESS,shininessMaterial,0);
		
	}
}
