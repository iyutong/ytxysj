package com.small.s1111;

import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class AnitEllipsiod
{
	FloatBuffer vex,tex,nex;
	int id,vCount,h;
	public AnitEllipsiod(float rx,float ry,float rz,float angle,int hn,int n,int id)
	{
		double an=Math.toRadians(angle);
		this.id=id;
		int next0=360/n;
		float next1=angle/hn;
		vCount=(int)(n*hn*6);
		float[] vertices=new float[vCount*3];
		float[] textures=new float[vCount*2];
		float[] normals=new float[vCount*3];
		int c=0,d=0,g=0,tx=1,ty=2;
		for(float a=0;a<angle;a+=next1)
		{
			double t=Math.toRadians(a);
			double j=Math.toRadians(a+next1);
			for(int b=0;b<360;b+=next0)
			{
				double e=Math.toRadians(b);
				double f=Math.toRadians(b+next0);

				double rx0=rx*Math.sin(t);
				double rx1=rx*Math.sin(j);
				double ry0=ry*Math.cos(t);
				double ry1=ry*Math.cos(j);
				double rz0=rz*Math.sin(t);
				double rz1=rz*Math.sin(j);

				float x0=(float)(rx0*Math.sin(e));
				float y0=(float)ry0;
				float z0=(float)(rz0*Math.cos(e));

				float x1=(float)(rx1*Math.sin(e));
				float y1=(float)ry1;
				float z1=(float)(rz1*Math.cos(e));

				float x2=(float)(rx1*Math.sin(f));
				float y2=(float)ry1;
				float z2=(float)(rz1*Math.cos(f));

				float x3=(float)(rx0*Math.sin(f));
				float y3=(float)ry0;
				float z3=(float)(rz0*Math.cos(f));

				vertices[c++]=x0;
				vertices[c++]=y0;
				vertices[c++]=z0;
				textures[d++]=(float)(e/(2*Math.PI))*tx;
				textures[d++]=(float)(t/an)*ty;
				normals[g++]=-(float)(Math.sin(t)*Math.sin(e));
				normals[g++]=-(float)(Math.cos(t));
				normals[g++]=-(float)(Math.sin(t)*Math.cos(e));

				vertices[c++]=x2;
				vertices[c++]=y2;
				vertices[c++]=z2;
				textures[d++]=(float)(f/(2*Math.PI))*tx;
				textures[d++]=(float)(j/an)*ty;
				normals[g++]=-(float)(Math.sin(j)*Math.sin(f));
				normals[g++]=-(float)(Math.cos(j));
				normals[g++]=-(float)(Math.sin(j)*Math.cos(f));
				
				vertices[c++]=x1;
				vertices[c++]=y1;
				vertices[c++]=z1;
				textures[d++]=(float)(e/(2*Math.PI))*tx;
				textures[d++]=(float)(j/an)*ty;
				normals[g++]=-(float)(Math.sin(j)*Math.sin(e));
				normals[g++]=-(float)(Math.cos(j));
				normals[g++]=-(float)(Math.sin(j)*Math.cos(e));

				vertices[c++]=x0;
				vertices[c++]=y0;
				vertices[c++]=z0;
				textures[d++]=(float)(e/(2*Math.PI))*tx;
				textures[d++]=(float)(t/an)*ty;
				normals[g++]=-(float)(Math.sin(t)*Math.sin(e));
				normals[g++]=-(float)(Math.cos(t));
				normals[g++]=-(float)(Math.sin(t)*Math.cos(e));

				vertices[c++]=x3;
				vertices[c++]=y3;
				vertices[c++]=z3;
				textures[d++]=(float)(f/(2*Math.PI))*tx;
				textures[d++]=(float)(t/an)*ty;
				normals[g++]=-(float)(Math.sin(t)*Math.sin(f));
				normals[g++]=-(float)(Math.cos(t));
				normals[g++]=-(float)(Math.sin(t)*Math.cos(f));
				
				vertices[c++]=x2;
				vertices[c++]=y2;
				vertices[c++]=z2;
				textures[d++]=(float)(f/(2*Math.PI))*tx;
				textures[d++]=(float)(j/an)*ty;
				normals[g++]=-(float)(Math.sin(j)*Math.sin(f));
				normals[g++]=-(float)(Math.cos(j));
				normals[g++]=-(float)(Math.sin(j)*Math.cos(f));

			}
		}
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertices.length*4);
		vbb.order(ByteOrder.nativeOrder());
		vex=vbb.asFloatBuffer();
		vex.put(vertices);
		vex.position(0);

		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		tbb.order(ByteOrder.nativeOrder());
		tex=tbb.asFloatBuffer();
		tex.put(textures);
		tex.position(0);

		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		nex=nbb.asFloatBuffer();
		nex.put(normals);
		nex.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量

		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vex);
		gl.glNormalPointer(GL10.GL_FLOAT,0,nex);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,tex);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,vCount);

		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
