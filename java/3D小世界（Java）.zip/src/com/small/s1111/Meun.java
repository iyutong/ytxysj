package com.small.s1111;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.small.s1111.*;

public class Meun extends Activity implements OnClickListener
{
	static public MediaPlayer mediaplayer;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
		requestWindowFeature(1);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
       	setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meun);
		Button btn0=(Button)findViewById(R.id.menubutton0);
		Button btn1=(Button)findViewById(R.id.menubutton1);
		Button btn2=(Button)findViewById(R.id.menubutton2);
		Button btn3=(Button)findViewById(R.id.menubutton3);
		btn0.setOnClickListener(this);
		btn1.setOnClickListener(this);
		btn2.setOnClickListener(this);
		btn3.setOnClickListener(this);
		mediaplayer=MediaPlayer.create(this,R.raw.failbk);
		mediaplayer.setLooping(true);
    }

	@Override
	public void onClick(View p1)
	{
		Intent intent=new Intent();
		// TODO: Implement this method
		switch(p1.getId())
		{
			case R.id.menubutton0:
				intent.setClass(this,Game.class);
				startActivity(intent);
				break;
			case R.id.menubutton1:
				intent.setClass(this,SetGame.class);
				startActivity(intent);
				break;
			case R.id.menubutton2:
				intent.setClass(this,AboutGame.class);
				startActivity(intent);
				break;
			case R.id.menubutton3:
				mediaplayer.release();
				finish();
				System.exit(0);
				break;
				
		}
	}
	long systemtime;
	public void onBackPressed()
	{
		// TODO: Implement this method
		if(System.currentTimeMillis()-systemtime>2000)
		{
			systemtime=System.currentTimeMillis();
			Toast.makeText(this,"再按一次返回退出",0).show();
		}
		else
		{
			finish();
			System.exit(0);
		}
	}
}
