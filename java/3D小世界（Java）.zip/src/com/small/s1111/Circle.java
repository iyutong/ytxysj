//圆类
//R：圆半径
//ANGLE：取值范围0-360，如：如180则画半个圆；360则画完整的圆
//N：圆边数
//圆心坐标（0,0,0)
package com.small.s1111;
import java.nio.*;
import javax.microedition.khronos.opengles.*;

public class Circle
{
	int vCount,id;
	float next;
	FloatBuffer vex,tex,nex;
	public Circle(float r,float angle,int n,int id)
	{
		int a=0,b=0,c=0;
		this.id=id;
		vCount=n*3;
		next=angle/n;
		float[] vertexs=new float[vCount*3];
		float[] textures=new float[vCount*2];
		float[] normals=new float[vCount*3];
		if(r>0)
		for(float end=0;end<angle;end+=next)
		{
			double angrad=Math.toRadians(end);
			double x=r*Math.sin(angrad);
			double y=r*Math.cos(angrad);
			double angradnext=Math.toRadians(end+next);
			double xnext=r*Math.sin(angradnext);
			double ynext=r*Math.cos(angradnext);
			
			vertexs[a++]=0;
			vertexs[a++]=0;
			vertexs[a++]=0;
			textures[b++]=0.5f;
			textures[b++]=0.5f;
			normals[c++]=0;
			normals[c++]=0;
			normals[c++]=1;
			
			vertexs[a++]=(float)-x;
			vertexs[a++]=(float)y;
			vertexs[a++]=0;
			textures[b++]=(float)(0.5f-0.5f*x);
			textures[b++]=(float)(0.5f-0.5f*y);
			normals[c++]=0;
			normals[c++]=0;
			normals[c++]=1;
			
			vertexs[a++]=(float)-xnext;
			vertexs[a++]=(float)ynext;
			vertexs[a++]=0;
			textures[b++]=(float)(0.5f-0.5f*xnext);
			textures[b++]=(float)(0.5f-0.5f*ynext);
			normals[c++]=0;
			normals[c++]=0;
			normals[c++]=1;
		}
		ByteBuffer vbb=ByteBuffer.allocateDirect(vertexs.length*4);
		vbb.order(ByteOrder.nativeOrder());
		vex=vbb.asFloatBuffer();
		vex.put(vertexs);
		vex.position(0);
		
		ByteBuffer tbb=ByteBuffer.allocateDirect(textures.length*4);
		tbb.order(ByteOrder.nativeOrder());
		tex=tbb.asFloatBuffer();
		tex.put(textures);
		tex.position(0);
		
		ByteBuffer nbb=ByteBuffer.allocateDirect(normals.length*4);
		nbb.order(ByteOrder.nativeOrder());
		nex=nbb.asFloatBuffer();
		nex.put(normals);
		nex.position(0);
	}
	public void drawSelf(GL10 gl)
	{
		gl.glPushMatrix();
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);//启用顶点坐标
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);//启用纹理
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);//启用法向量
		
		gl.glVertexPointer(3,GL10.GL_FLOAT,0,vex);
		gl.glNormalPointer(GL10.GL_FLOAT,0,nex);
		gl.glTexCoordPointer(2,GL10.GL_FLOAT,0,tex);
		gl.glBindTexture(GL10.GL_TEXTURE_2D,id);
		gl.glDrawArrays(GL10.GL_TRIANGLES,0,vCount);
		
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		gl.glPopMatrix();
	}
}
