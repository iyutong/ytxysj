class Dome{
	public static void main(String[] agr){
		checktel("13419934872");//匹配电话号码
		checkqq("3510366586");//匹配QQ号码
		checkqqemail("8351008986@qq.com");//匹配QQ邮箱
		checkpassword("123456");//匹配银行卡密码
		check();//练习
	}
	
	public static void checktel(String tel){
		//13xxx 15xxx 18xxx 开头必须是1，第二个必须是3，5，8，手机号一共十个数字
		String reg="1[358]\\d{9}";
		System.out.println(tel.matches(reg));
	}
	
	public static void checkqq(String qq){
		//开头不能是0，不能超过十个数字，只能是数字
		String reg="[1-9]\\d{9}";
		System.out.println(qq.matches(reg));
	}
	
	public static void checkqqemail(String qqemail){
		//开头必须是1-9的数字不能为0，一共有10个数字，后缀必须是@qq.com
		String reg="[1-9]\\d{9}@qq.com";
		System.out.println(qqemail.matches(reg));
	}
	
	public static void checkpassword(String password){
		//只要是6位的纯数字就行了
		String reg="\\d{6}";
		System.out.println(password.matches(reg));
	}
	
	public static void check(){
		//前面必须是0-4的数字中间而且必须是3个数字必须有-在中间后面必须是5-9而且必须是3个数字
		String str="123-789",reg="[0-4]{3}-[5-9]{3}";
		System.out.println(str.matches(reg));
	}
	
}