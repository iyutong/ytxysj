import java.util.*;
import java.io.*;

public class Main
{
	
	public static void main(String[] args)
	{
		/*int one=0x78/2;
		int[] yfR=getyf(new int[]{0,LA, 0,XI, 1,DO, 0,LA, 1,RA, 1,DO, 0,XI, 1,DO, 0,LA, 1,RA, 1,MI, 1,FA, 1,RA});
		//int[] yfL=getyf(new int[]{0,12, 1,6, 1,12, 0,6, 1,1, 1,6, 0,8, 1,3, 1,8, 0,3, 0,6});
		int[] delayR={one*3,one,one*2,one*2,one*2,3*one/2,one/2,one*2,one*2,one,one,one*2,one*2};
		//int[] delayL={one,one,one*2,one,one,one*2,one,one,one*2,one,one};
		
		/*MidiFile mf=new MidiFile();
		mf.setTempo(155);
		mf.setKeySig(2);
		//mf.setKeySig(4);
		MidiChannel mc1=new MidiChannel();
		mc1.progChange(3);
		for(int i=0;i<yfR.length;i++)
		mc1.noteOnOffNow(delayR[i],yfR[i],100);
		mf.addChannel(mc1);
		MidiChannel mc2=new MidiChannel(2);
		mc2.progChange(3);
		for(int i=0;i<yfL.length;i++)
			mc2.noteOnOffNow(delayL[i],yfL[i],100);
		mc2.noteOnOffNow(one*2,getyf(new int[]{1,3, 1,6}),100);
		mf.addChannel(mc2);
		MidiFile mf=new MidiFile();//"/storage/emulated/0/7exfsz/test.mid");
		mf.setTempo(114);
		mf.setKeySig(0);
		MidiChannel mc1=new MidiChannel();
		mc1.progChange(3);
		for(int i=0;i<yfR.length;i++)
			mc1.noteOnOffNow(delayR[i],yfR[i],100);
		mf.addChannel(mc1);*/
		MIDIScript ms=new MIDIScript();
		ms.loadscript("/storage/emulated/0/钢琴脚本/花之舞.mids");
		try
		{
			ms.getMidi().writeToFile("/storage/emulated/0/钢琴脚本/花之舞.mid");
		}
		catch (IOException e)
		{}
		System.out.println("完成");
		
	}
	public static int[] getyf(int[] arr){
		int[] yf=new int[arr.length/2];
		for(int i=0;i<yf.length;i++){
			yf[i]=(arr[i*2]+5)*12+arr[i*2+1]-1;
		}
		return yf;
	}
}
