
import java.io.*;
import java.util.*;
public class MidiReader
{
	FileInputStream is;
	public MidiReader(String path){
		try
		{
			is = new FileInputStream(path);
		}
		catch (FileNotFoundException e)
		{}
	}
	public byte[] getbytearray(int size){
		byte[] bytearr=new byte[size];
		try
		{
			is.read(bytearr);
		}
		catch (IOException e)
		{}
		return bytearr;
	}
	public int getint(){
		return getint(4);
	}
	public int getint(int size){
		return byteToInt2(getbytearray(size));
	}
	public byte getbyte(){
		return getbytearray(1)[0];
	}
	public void seekTo(byte[] info){
		byte item=0;
		ss:while(true){
			for(int i=0;i<info.length;i++){
				if((item=getbyte())!=info[i]){
					continue ss;
				}
				if(i==info.length-1)return;
			}
		}
	}
	public byte[] getheader(){
		byte[] head={0x4d, 0x54, 0x68, 0x64};
		seekTo(head);
		byte[] size=getbytearray(4);
		return concatAll(head,size,getbytearray(byteToInt2(size)));
	}
	public byte[] getLeaderTrick(){
		byte[] trick=new byte[]{0x4d, 0x54, 0x72, 0x6B};
		seekTo(trick);
		int size=byteToInt2(getbytearray(4));
		return getbytearray(size);
	}
	public byte[] getmidiinfo(byte[] title,byte[] info){
		int index=indexof(info,title);
		int size=info[index+title.length];
		byte[] result=new byte[title.length+1+size];
		System.arraycopy(info,index,result,0,result.length);
		return result;
	}
	public byte[] getTempo(byte[] info){
		byte[] title=MidiFile.intArrayToByteArray(new int[]{0x00, 0xFF, 0x51});
		return getmidiinfo(title,info);
	}
	public byte[] getkeySig(byte[] info){
		byte[] title=MidiFile.intArrayToByteArray(new int[]{0x00, 0xFF, 0x59});
		return getmidiinfo(title,info);
	}
	public byte[] gettimeSig(byte[] info){
		byte[] title=MidiFile.intArrayToByteArray(new int[]{0x00, 0xFF, 0x58});
		return getmidiinfo(title,info);
	}
	public MidiChannel getnextTrick(){
		byte[] trick=new byte[]{0x4d, 0x54, 0x72, 0x6B};
		seekTo(trick);
		int size=byteToInt2(getbytearray(4));
		MidiChannel mc=new MidiChannel();
		byte[] info=getbytearray(size);
		for(int i=0;i<size-4;){
			if(info[i]==0x00&&((info[i+1]>>4)&0xF)==0xC){
				mc.setChannelIndex(info[i+1]&0x0F);
				mc.progChange(info[i+2]);
				i+=3;
			}else{
				ArrayList<Byte> time=new ArrayList<Byte>();
				do{
					time.add(info[i]);
				}while((info[i++]&0x80)!=0);
				int[] timearr=new int[time.size()];
				for(int u=0;u<time.size();u++)timearr[u]=time.get(u);
				mc.playEvents.add(concatAll(timearr,new int[]{info[i],info[i+1],info[i+2]}));
				i+=3;
			}
		}
		return mc;
	}
	public static int indexof(byte[] array,byte[] res){
		return indexof(array,res,0);
	}
	public static int indexof(byte[] array,byte[] res,int start){
		ss:for(int i=start;i<array.length;i++){
			for(int u=0;u<res.length;u++){
				if(array[i+u]!=res[u])continue ss;
			}
			return i;
		}
		return -1;
	}
	public static int byteToInt2(byte[] b){
		int mask=0xff;
		int temp=0;
		int n=0;
		for(int i=0;i<b.length;i++){
			n<<=8;
			temp=b[i]&mask;
			n|=temp;
		}
		return n;
    }
	public static int[] concatAll(int[] first, int[]... rest) {  
		int totalLength = first.length;  
		for (int[] array : rest) {  
			totalLength += array.length;  
		}  
		int[] result = Arrays.copyOf(first, totalLength);  
		int offset = first.length;  
		for (int[] array : rest) {  
			System.arraycopy(array, 0, result, offset, array.length);  
			offset += array.length;  
		}  
		return result;  
	}
	public static byte[] concatAll(byte[] first, byte[]... rest) {  
		int totalLength = first.length;  
		for (byte[] array : rest) {  
			totalLength += array.length;  
		}  
		byte[] result = Arrays.copyOf(first, totalLength);  
		int offset = first.length;  
		for (byte[] array : rest) {  
			System.arraycopy(array, 0, result, offset, array.length);  
			offset += array.length;  
		}  
		return result;  
	}
	public static <T>T[] concatAll(T[] first, T[]... rest) {  
		int totalLength = first.length;  
		for (T[] array : rest) {  
			totalLength += array.length;  
		}  
		T[] result = Arrays.copyOf(first, totalLength);  
		int offset = first.length;  
		for (T[] array : rest) {  
			System.arraycopy(array, 0, result, offset, array.length);  
			offset += array.length;  
		}  
		return result;  
	}
	public static boolean equal_array(byte[] a,byte[] b){
		if(a.length!=b.length)return false;
		for(int i=0;i<a.length;i++)if(a[i]!=b[i])return false;
		return true;
	}
	public static byte[] cutArray(byte[] res,int start,int len){
		byte[] result=new byte[len];
		System.arraycopy(res,start,result,0,len);
		return result;
	}
}
