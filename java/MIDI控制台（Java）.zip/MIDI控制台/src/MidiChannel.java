
import java.util.Vector;
import java.util.*;

public class MidiChannel
{	
	public int mChannelIndex = 1;
	public final int mark=0x80;
	// The collection of events to play, in time order
	public Vector<int[]> playEvents = new Vector<int[]>();   

	public MidiChannel(){}

	public MidiChannel(int channelIndex/*default 1, between 00 to FF*/)
	{		
		mChannelIndex = channelIndex;
	}

	public void setChannelIndex(int channelIndex)
	{
		mChannelIndex = channelIndex;
	}

	/** Store a program-change event at current position */
	public void progChange (int prog/*0x00-0x7f*/)
	{
		int[] data = new int[3];
		data[0] = 0;
		data[1] = 0xC0 + mChannelIndex;
		data[2] = prog;
		playEvents.add(data);
	}

	/** Store a note-on event */
	public void noteOn (int delta, int note, int velocity)
	{
		ArrayList<Integer> delay=new ArrayList<Integer>();
		do{
			if(delay.size()==0)delay.add(delta%128);
			else delay.add((delta%128)|mark);
		}while((delta/=128)>0);
		int[] data = new int[3+delay.size()];
		for(int i=delay.size()-1,j=0;i>=0;i--,j++)data[j]=delay.get(i);
		data[delay.size()] = 0x90 + mChannelIndex;
		data[1+delay.size()] = note;
		data[2+delay.size()] = velocity;
		playEvents.add (data);
	}

	/** Store a note-off event */
	public void noteOff (int delta, int note)
	{
		ArrayList<Integer> delay=new ArrayList<Integer>();
		do{
			if(delay.size()==0)delay.add(delta%128);
			else delay.add((delta%128)|mark);
		}while((delta/=128)>0);
		int[] data = new int[3+delay.size()];
		for(int i=delay.size()-1,j=0;i>=0;i--,j++)data[j]=delay.get(i);
		data[delay.size()] = 0x80 + mChannelIndex;
		data[1+delay.size()] = note;
		data[2+delay.size()] = 0;
		playEvents.add (data);
	}

	/** Store a note-on event followed by a note-off event a note length
	 later. There is no delta value — the note is assumed to
	 follow the previous one with no gap. */
	public void noteOnOffNow (int duration, int note, int velocity)
	{
		noteOn (0, note, velocity);
		noteOff (duration, note);
	}
	public void noteOnOffNow (int duration, int[] note, int velocity)
	{
		for(int i:note){noteOn (0, i, velocity);}
		noteOff (duration, note[0]);
		for(int i=1;i<note.length;i++)noteOff (0, note[i]);
	}
	public void noteArpeggio (int duration, int[] note, int velocity)
	{
		noteOn(0,note[0],velocity);
		for(int i=1;i<note.length;i++)noteOn((int)(MIDIScript.one*0.05f), note[i], velocity);
		noteOff (duration-(int)(MIDIScript.one*0.05f)*note.length-1, note[0]);
		for(int i=1;i<note.length;i++)noteOff (0, note[i]);
	}
	public void noteSequenceFixedVelocity (int[] sequence, int velocity)
	{
	    boolean lastWasRest = false;
	    int restDelta = 0;
	    for (int i = 0; i < sequence.length; i += 2)
	    {
	    	int note = sequence[i];
	    	int duration = sequence[i + 1];
	    	if (note < 0) 
	    	{
	    		// This is a rest
	    		restDelta += duration;
	    		lastWasRest = true;
	    	} 
	    	else
	    	{
	    		// A note, not a rest
	    		if (lastWasRest)
	    		{
	    			noteOn (restDelta, note, velocity);
	    			noteOff (duration, note);
	    		}
	    		else
	    		{
	    			noteOn (0, note, velocity);
	    			noteOff (duration, note);
	    		}
	    		restDelta = 0;
	    		lastWasRest = false;
	    	}
	    }
	}

	public String toString(int which)
	{
		String str="";
		for(int i:playEvents.get(which))str+=(Integer.toHexString(i)+",");
		return str;
	}
	
}
