import java.io.*;

public class MIDIScript
{
	public static final int[][] UP={{0,0,0,0,0,0,0},
									{0,0,0,1,0,0,0},
									{1,0,0,1,0,0,0},
									{1,0,0,1,1,0,0},
									{1,1,0,1,1,0,0},
									{1,1,0,1,1,1,0},
									{1,1,1,1,1,1,0},
									{1,1,1,1,1,1,1}};
	
	public static final int[][] DOWN=
	{{0,0,0,0,0,0,-1},
	{0,0,-1,0,0,0,-1},
	{0,0,-1,0,0,-1,-1},
	{0,-1,-1,0,0,-1,-1},
	{0,-1,-1,0,-1,-1,-1},
	{-1,-1,-1,0,-1,-1,-1},
	{-1,-1,-1,-1,-1,-1,-1}};
	
	public static final int[] tone={0,2,4,5,7,9,11};
	MidiFile midi;
	MidiChannel nowchannel;
	public static final int one_raw=0x78;
	public static int one=0x78;
	public static int[] sig=new int[7];
	int volume=100;
	float playrate=1;
	
	public void loadscript(String file){
		midi=new MidiFile();
		String[] res=readwb(file).split("\n");
		for(String i:res){
			if(i.startsWith("//"))continue;
			String[] cmd=i.split(" ");
			switch(cmd[0].toLowerCase()){
				case "tempo":
					midi.setTempo(Integer.parseInt(cmd[1]));
					break;
				case "keysig":
					//midi.setKeySig(Integer.parseInt(cmd[1]));
					int temp=Integer.parseInt(cmd[1]);
					if(temp>=0)sig=UP[temp];
					else sig=DOWN[-temp];
					break;
				case "channel":
					midi.addChannel(new MidiChannel());
					nowchannel=midi.getChannel(midi.getChannelSize()-1);
					volume=100;
					break;
				case "progchange":
					nowchannel.progChange(Integer.parseInt(cmd[1]));
					break;
				case "volume":
					volume=Integer.parseInt(cmd[1]);
					break;
				case "rate":
					playrate=Float.parseFloat(cmd[1]);
					one=Math.round(one_raw/playrate);
					System.out.println(one);
					break;
				case "click":{
					String[] items=cmd[1].split(";");
					int[] yfs=new int[items.length];
					for(int u=0;u<items.length;u++){
						int change=0;
						boolean hy=false;
						if(items[u].endsWith("#"))change=1;
						else if(items[u].endsWith("b"))change=-1;
						else if(items[u].endsWith("※"))hy=true;
						if(hy||change!=0)items[u]=items[u].substring(0,items[u].length()-1);
						int[] yf=str2int(items[u].split(",|，"));
						yfs[u]=(yf[0]+5)*12+tone[yf[1]-1]+change+(hy?0:sig[yf[1]-1]);
					}
					nowchannel.noteOnOffNow((int)(Float.parseFloat(cmd[2])*one),yfs,volume);
					}break;
				case "down":{
						int change=0;
						boolean hy=false;
						if(cmd[1].endsWith("#"))change=1;
						else if(cmd[1].endsWith("b"))change=-1;
						else if(cmd[1].endsWith("※"))hy=true;
						
						if(hy||change!=0)cmd[1]=cmd[1].substring(0,cmd[1].length()-1);
						int[] yf=str2int(cmd[1].split(",|，"));
						nowchannel.noteOn((int)(Float.parseFloat(cmd[2])*one),(yf[0]+5)*12+tone[yf[1]-1]+change+(hy?0:sig[yf[1]-1]),volume);
					}break;
				case "up":{
						int change=0;
						boolean hy=false;
						if(cmd[1].endsWith("#"))change=1;
						else if(cmd[1].endsWith("b"))change=-1;
						else if(cmd[1].endsWith("※"))hy=true;
						
						if(hy||change!=0)cmd[1]=cmd[1].substring(0,cmd[1].length()-1);
						int[] yf=str2int(cmd[1].split(",|，"));
						nowchannel.noteOff((int)(Float.parseFloat(cmd[2])*one),(yf[0]+5)*12+tone[yf[1]-1]+change+(hy?0:sig[yf[1]-1]));
					}break;
				case "arpeggio":{
						String[] items=cmd[1].split(";");
						int[] yfs=new int[items.length];
						for(int u=0;u<items.length;u++){
							int change=0;
							boolean hy=false;
							if(items[u].endsWith("#"))change=1;
							else if(items[u].endsWith("b"))change=-1;
							else if(items[u].endsWith("※"))hy=true;
							
							if(hy||change!=0)items[u]=items[u].substring(0,items[u].length()-1);
							int[] yf=str2int(items[u].split(",|，"));
							yfs[u]=(yf[0]+5)*12+tone[yf[1]-1]+change+(hy?0:sig[yf[1]-1]);
						}
						nowchannel.noteArpeggio((int)(Float.parseFloat(cmd[2])*one),yfs,volume);
					}break;
				case "delay":{
						nowchannel.noteOn((int)(Float.parseFloat(cmd[1])*one),0,0);
					}break;
			}
		}
	}
	public MidiFile getMidi(){
		return midi;
	}
	public MidiChannel getChannel(int index){
		return midi.getChannel(index);
	}
	public static String readwb(String name)
	{
		String re=null;
		try
		{
			InputStream is=new FileInputStream(name);
			byte[] b=new byte[is.available()];
			is.read(b);re=new String(b);
		}
		catch (IOException e)
		{}
		return re;
	}
	public static int[] str2int(String[] a){
		int[] b=new int[a.length];
		for(int i=0;i<b.length;i++){
			try{
				b[i]=Integer.parseInt(a[i]);
			}catch(Exception e){}
		}
		return b;
	}
	public static float[] str2float(String[] a){
		float[] b=new float[a.length];
		for(int i=0;i<b.length;i++){
			try{
				b[i]=Float.parseFloat(a[i]);
			}catch(Exception e){}
		}
		return b;
	}
}
