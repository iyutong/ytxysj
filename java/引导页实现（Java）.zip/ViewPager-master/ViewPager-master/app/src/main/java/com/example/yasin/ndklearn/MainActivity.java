package com.example.yasin.ndklearn;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;

public class MainActivity extends Activity
 {

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         *SharedPreferences的使用
         *使用步骤：
         * 1、得到SharedPreferences对象
         * 2、调用SharedPreferences对象的edit()方法来获取一个SharedPreferences.Editor对象。
         * 3、向SharedPreferences.Editor对象中添加数据。
         * 4、调用commit方法将添加的数据提交。
         */
        
        //得到一个名叫first的且读写权限设置为只能被本程序读写的SharedPreferences对象
        SharedPreferences pref = getSharedPreferences("first",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        //向SharedPreferences.Editor对象中添加一个boolean类型的键值对数据
        editor.putBoolean("status",false);
        //提交数据
        editor.commit();



    }
}
