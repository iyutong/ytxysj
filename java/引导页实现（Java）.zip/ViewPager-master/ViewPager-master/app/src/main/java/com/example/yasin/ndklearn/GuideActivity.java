package com.example.yasin.ndklearn;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;


import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class GuideActivity extends Activity implements OnPageChangeListener
{

    private ViewPager vp;
    private ViewPagerAdapter vpAdapter;
    private List<View> views;

    // 底部小点图片
    private ImageView[] dots;

    // 记录当前选中位置
    private int currentIndex;
    Boolean isFirst;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_layout);

        // 初始化页面
        initViews();

        // 初始化底部小点
        initDots();
    }

    private void initViews()
    {
        //first名字，可以任意字符串，建议写成有意义的
        //MODE_PRIVATE  只能被本程序读写的操作模式
        SharedPreferences pref = getSharedPreferences("first", Activity.MODE_PRIVATE);
        //获取数据
        isFirst = pref.getBoolean("status", true);
        //通过SharedPreferences得到的布尔值判断是否跳过引导页面直接加载主页面
        if (!isFirst)
        {
            //Intent跳转到主界面布局
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            //关闭之前的布局
            finish();
        }
        //LayoutInflater对象的作用通俗的说,将一个xml中定义的布局找出来.
        LayoutInflater inflater = LayoutInflater.from(this);
        //找到guide_four这个布局
        RelativeLayout guideFour = (RelativeLayout) inflater.inflate(R.layout.guide_four, null);
        //获取guide_four这个布局里的button按钮
        guideFour.findViewById(R.id.toMain).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    //点击按钮跳转至主页面
                    Intent intent = new Intent(GuideActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
        views = new ArrayList<View>();
        // 初始化引导图片列表
        views.add(inflater.inflate(R.layout.guide_one, null));
        views.add(inflater.inflate(R.layout.guide_two, null));
        views.add(inflater.inflate(R.layout.guide_three, null));
        views.add(guideFour);
        // 初始化Adapter
        vpAdapter = new ViewPagerAdapter(views);

        vp = (ViewPager) findViewById(R.id.viewpager);
        vp.setAdapter(vpAdapter);
        // 绑定回调
        vp.setOnPageChangeListener(this);


    }

    private void initDots()
    {
        LinearLayout ll = (LinearLayout) findViewById(R.id.ll);

        dots = new ImageView[views.size()];

        // 循环取得小点图片
        for (int i = 0; i < views.size(); i++)
        {
            dots[i] = (ImageView) ll.getChildAt(i);
            dots[i].setEnabled(true);// 都设为灰色
        }

        currentIndex = 0;
        dots[currentIndex].setEnabled(false);// 设置为白色，即选中状态
    }

    private void setCurrentDot(int position)
    {
       /*
         这三句实现灰点和白点之间的轮番切换
       
       */
         
        dots[position].setEnabled(false);
        dots[currentIndex].setEnabled(true);
        currentIndex = position;
    }

    // 当滑动状态改变时调用
    @Override
    public void onPageScrollStateChanged(int arg0)
    {
    }

    // 当当前页面被滑动时调用
    @Override
    public void onPageScrolled(int arg0, float arg1, int arg2)
    {
    }

    // 当新的页面被选中时调用
    @Override
    public void onPageSelected(int position)
    {
        // 将position位置传入从而达到设置底部小点选中状态功能
        setCurrentDot(position);
    }

}
