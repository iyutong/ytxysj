package com.example.testproject;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.gauravk.bubblenavigation.BubbleNavigationLinearView;
import com.gauravk.bubblenavigation.listener.BubbleNavigationChangeListener;

import java.util.ArrayList;

public class Main_1 extends AppCompatActivity {
    BubbleNavigationLinearView bubbleNavigationLinearView;
    ViewPager viewPager;
    private ArrayList<Fragment>fragments;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout6);
        init();


    }
    public void init(){
        viewPager=findViewById(R.id.layout6viewpager);
        bubbleNavigationLinearView = findViewById(R.id.bottom_navigation_view_linear);
        bubbleNavigationLinearView.setBadgeValue(0, null);
        bubbleNavigationLinearView.setBadgeValue(1, null); //invisible badge
        bubbleNavigationLinearView.setBadgeValue(2, null);


        fragments = new ArrayList<Fragment>();
        fragments.add(new ViewFragment4());
        fragments.add(new ViewFragment5());
        fragments.add(new ViewFragment5());

        viewPager.setAdapter(viewPagerAdapter);


        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                bubbleNavigationLinearView.setCurrentActiveItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        bubbleNavigationLinearView.setNavigationChangeListener(new BubbleNavigationChangeListener() {
            @Override
            public void onNavigationChanged(View view, int position) {
                viewPager.setCurrentItem(position, true);
            }
        });
    }

    FragmentStatePagerAdapter viewPagerAdapter=new FragmentStatePagerAdapter(getSupportFragmentManager())
    {
        @Override
        public int getCount()
        {
            return fragments.size();
        }
        //public CharSequence getPageTitle(int position)
        //{
           // return fragments[position];
       // }
        @Override
        public Fragment getItem(int position)
        {
            if (position >= 0 && position < fragments.size()){
                return fragments.get(position);
            }

            return fragments.get(position);
        }

    };
}
