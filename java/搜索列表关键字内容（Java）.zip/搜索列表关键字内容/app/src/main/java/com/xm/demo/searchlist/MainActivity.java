package com.xm.demo.searchlist;

import android.app.*;
import android.os.*;
import android.text.*;
import android.util.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity 
{
	private ListView list;
	private EditText edit;
	private ArrayList<Map<String,Object>> mData = new ArrayList<>();
	private ArrayList<Map<String,Object>> sData = new ArrayList<>();
	private SimpleAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //QQ群241449466
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		list=findViewById(R.id.mainListView1);
		edit=findViewById(R.id.mainEditText1);
		adapter = new SimpleAdapter(this,mData,R.layout.list,new String[]{"t","c"},new int[]{R.id.listTextView1,R.id.listTextView2});
		list.setAdapter(adapter);
		initData();
		
		edit.addTextChangedListener(new TextWatcher(){

				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
					mData.clear();

					for(Map<String,Object> map: sData){
						mData.add(map);
					}
					adapter.notifyDataSetChanged();
					if(p1.length()>0){
						Log.i(p1.toString(),p1+"");
					findData(p1.toString());
					}
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
				}
			});
    }
	
	public void findData(String a){
		Iterator<Map<String,Object>> iter=mData.iterator();
		while(iter.hasNext()){
			Map<String,Object> itt=(Map<String, Object>) iter.next();
			Collection<Object> s=itt.values();
			Iterator ite=s.iterator();
			if(ite.next().toString().indexOf(a)==-1&&ite.next().toString().indexOf(a)==-1){
				iter.remove();
			}
		}
		adapter.notifyDataSetChanged();
	}
	
	public void initData(){
		mData.clear();
		for(int i=0;i<1000;i=i+2){
			Map<String,Object> map=new HashMap<>();	
			map.put("t",i+"");
			map.put("c",i*2/4+"");
			mData.add(map);
		}
		//sData=new ArrayList<Map<String,Object>>(mData);
		for(Map<String,Object> map: mData){
			sData.add(map);
		}
		adapter.notifyDataSetChanged();
	}
}
