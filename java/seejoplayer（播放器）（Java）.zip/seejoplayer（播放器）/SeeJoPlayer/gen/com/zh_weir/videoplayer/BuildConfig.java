/** Automatically generated file. DO NOT MODIFY */
package com.zh_weir.videoplayer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}