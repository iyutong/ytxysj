package com.sink.falsevideo;

import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.AdapterView.*;

public class StartActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		AlertDialog.Builder builder= new AlertDialog.Builder(this);
		builder.setTitle("请选择您要进入的平台");
		builder.setItems(new String[]{"腾讯视频","优酷","爱奇艺","芒果TV","PPTV","搜狐视频","乐视视频"}, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					Intent intent=new Intent(StartActivity.this,MainActivity.class);
					switch(p2){
						case 0:
							//腾讯视频
							//https://m.v.qq.com/x/cover/l/lcpwn26degwm7t3.html?vid=a002708679j
							//https://m.v.qq.com/x/cover/l/lcpwn26degwm7t3.html?ptag=
							//https://m.v.qq.com/x/cover/4/408kfn9ysqew6tw.html?vid=m0027d7sd4p&ptag=
							intent.putExtra("mainurl","http://m.v.qq.com/");
							intent.putExtra("zengzhe","https://m.v.qq.com/([a-z]/)?cover/.{1}?/.+?\\.html(\\?vid=.+?(&ptag=)?)?");
						break;
					    case 1:
							//优酷
							//https://m.youku.com/video/id_XMzY0MTUzMjk2OA==.html?spm=a2hww.20020887.m_205923.5~5~5~5~5%212~5~5~A
							//https://m.youku.com/video/id_XMzgxMTY5ODc1Ng==.html?spm=a2hww.20020887.m_205971.5~5%212~5~5~5~5~5~A
							intent.putExtra("mainurl","https://www.youku.com/");
							intent.putExtra("zengzhe","https://m.youku.com/video/id_.+");
						break;
						case 2:
							//爱奇艺
							intent.putExtra("mainurl","http://m.iqiyi.com/");
							intent.putExtra("zengzhe","http://m.iqiyi.com/v_.+?\\.html(#.+)?");
						break;
						case 3:
							//芒果TV
							intent.putExtra("mainurl","https://m.mgtv.com/channel/home/");
							intent.putExtra("zengzhe","https://m.mgtv.com/b/[0-9]+?/[0-9]{2,}\\.html");
						break;
						case 4:
							//PPTV
							intent.putExtra("mainurl","http://m.pptv.com/");
							intent.putExtra("zengzhe","http://m.pptv.com/show/.+?\\.html");
						break;
						case 5:
							//搜狐视频
							//https://m.tv.sohu.com/v4948261.shtml?aid=9506708&channeled=1210020001&columnid=57
							//https://m.tv.sohu.com/u/vw/105956327.shtml?aid=9472790&channeled=1210010300&columnid=15
							//https://m.tv.sohu.com/u/vw/105966312.shtml?channeled=1210010300&columnid=15
							intent.putExtra("mainurl","https://m.tv.sohu.com/");
							intent.putExtra("zengzhe","https://m.tv.sohu.com/((u/vw/)|v)[0-9]+?\\.shtml\\?.+");
						break;
						case 6:
							//乐视视频
							intent.putExtra("mainurl","http://m.le.com/");
							intent.putExtra("zengzhe","http://m.le.com/vplay_[0-9]+?\\.html");
						break;
					}
					startActivity(intent);
					finish();
				}
			});
		builder.create().show();
			
	}
	
	
}
