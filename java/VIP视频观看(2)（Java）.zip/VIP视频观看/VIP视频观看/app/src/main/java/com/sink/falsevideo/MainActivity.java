package com.sink.falsevideo;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.tencent.smtt.export.external.interfaces.*;
import com.tencent.smtt.sdk.*;

public class MainActivity extends Activity 
{
	private WebView mWebView;
	private ProgressBar mProgressBar;
	private LinearLayout mLinearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		//不显示程序的标题栏
        requestWindowFeature( Window.FEATURE_NO_TITLE );
        //不显示系统的标题栏          
        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
							 WindowManager.LayoutParams.FLAG_FULLSCREEN );
		getWindow().setFormat(PixelFormat.TRANSLUCENT);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Toast.makeText(this,"开发者.Sink:QQ468766131\n各位大佬且用且珍惜!",3000).show();
		mWebView=findViewById(R.id.webview);
        mProgressBar=findViewById(R.id.mainProgressBar);
		mLinearLayout=findViewById(R.id.mainLinearLayout1);
		WebSettings webSetting = mWebView.getSettings();
		webSetting.setAllowFileAccess(true);
		webSetting.setSupportZoom(true);
		webSetting.setBuiltInZoomControls(true);
		webSetting.setUseWideViewPort(true);
		webSetting.setSupportMultipleWindows(false);
		webSetting.setAppCacheEnabled(true);
		webSetting.setDomStorageEnabled(true);
		webSetting.setJavaScriptEnabled(true);
		webSetting.setGeolocationEnabled(true);
		webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
		webSetting.setAppCachePath(this.getDir("appcache", 0).getPath());
		webSetting.setDatabasePath(this.getDir("databases", 0).getPath());
		webSetting.setGeolocationDatabasePath(this.getDir("geolocation", 0)
											  .getPath());		
		mWebView.loadUrl(getIntent().getStringExtra("mainurl"));
		mWebView.setWebChromeClient(new WebChromeClient(){
				//加载进度回调
				@Override
				public void onProgressChanged(WebView view, int newProgress) {
					mProgressBar.setProgress(newProgress);
				}
			});
		mWebView.setWebViewClient(new WebViewClient(){
				@Override
				public boolean shouldOverrideUrlLoading(WebView view, String url) {
					if(url.matches(getIntent().getStringExtra("zengzhe"))){
						//Toast.makeText(getApplication(),url,3000).show();
						mWebView.loadUrl("http://jx.618g.com/?url="+url);
						return true;
					}
					
					return super.shouldOverrideUrlLoading(view, url);
				}
			
				
				@Override
				public void onPageFinished(WebView view, String url) {
					mProgressBar.setVisibility(View.GONE);
					mLinearLayout.setVisibility(View.GONE);
				}

				@Override
				public void onPageStarted(WebView view, String url, Bitmap favicon) {//页面开始加载
					mProgressBar.setVisibility(View.VISIBLE);
					mLinearLayout.setVisibility(View.VISIBLE);
				}
		});
    }
	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (mWebView.canGoBack() && keyCode == KeyEvent.KEYCODE_BACK){
            mWebView.goBack(); 
            return true;
        }
        return super.onKeyDown(keyCode,event);
    }
}
