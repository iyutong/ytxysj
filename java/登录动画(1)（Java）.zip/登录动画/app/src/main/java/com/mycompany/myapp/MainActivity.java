package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import com.mycompany.myapp.OwlView;
import android.widget.*;
public class MainActivity extends Activity 
{
	OwlView mOwlView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		mOwlView=(OwlView)findViewById(R.id.aaa);
		EditText eee=(EditText)findViewById(R.id.mi);
		eee.setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {

                @Override
                public void onFocusChange(View v, boolean hasFocus) {

                    if (hasFocus) {
						mOwlView.open();
                        // 获得焦点

                    } else {
						mOwlView.close();
                        // 失去焦点

                   }

                }


            });
		
    }
		
    
	
	
	
	
}
