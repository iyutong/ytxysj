package xiaoheng.vandg;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

/*
by_小亨
2018.6.17
*/

public class MainActivity extends Activity 
{
	private TextView txv;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		LinearLayout ll=(LinearLayout)findViewById(R.id.mainLinearLayout);
		txv=(TextView)findViewById(R.id.mainTextView);
		
		ll.setOnClickListener(new OnClickListener()
		{
				@Override
				public void onClick(View p1)
				{
					if(txv.getVisibility()==0)
					{
						txv.setVisibility(8);
					}
					else if(txv.getVisibility()==8)
					{
						txv.setVisibility(0);
					}
				}
			});
			
    }
}
