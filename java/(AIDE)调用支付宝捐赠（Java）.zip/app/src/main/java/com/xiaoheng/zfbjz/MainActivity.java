package com.xiaoheng.zfbjz;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		Button b1=(Button)findViewById(R.id.b1);
		Button b2=(Button)findViewById(R.id.b2);
		Button b3=(Button)findViewById(R.id.b4);
		
		
		b1.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					//支付宝捐赠核心代码
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=https%3A%2F%2Fqr.alipay.com%2FFKX00776US7D6RTHLZE76B%3F_s%3Dweb-other&_t=1486300416691#Intent;scheme=alipays;package=com.eg.android.AlipayGphone;end")));
					
				}
			});
			
			
			b2.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					//支付宝扫描转账核心代码
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("alipayqr://platformapi/startapp?saId=10000007")));
					
				}
			});
			
			
			
			b3.setOnClickListener(new OnClickListener()
			{@Override public void onClick(View p1){
				
				//支付宝手机充值核心代码
				startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("alipayqr://platformapi/startapp?saId=10000003")));
				
			}});
		
		}public Void b3(View view){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));return null;}}
/****************************************
 *                                      *
 *      不会改找我，不免费。               *
 *      价格好说，我做示例也不容易。         *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/