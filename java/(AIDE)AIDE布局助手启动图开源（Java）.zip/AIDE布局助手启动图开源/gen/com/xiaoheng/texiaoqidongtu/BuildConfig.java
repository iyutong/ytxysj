/** Automatically generated file. DO NOT MODIFY */
package com.xiaoheng.texiaoqidongtu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}