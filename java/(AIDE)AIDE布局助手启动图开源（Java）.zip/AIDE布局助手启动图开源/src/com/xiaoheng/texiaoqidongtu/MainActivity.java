package com.xiaoheng.texiaoqidongtu;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private LinearLayout l,ll,lll;
	private Handler handler;
	private CountDownTimer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//隐藏状态栏
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);//隐藏操作栏
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaohengmain);
		
		overridePendingTransition(R.anim.push_up_in,R.anim.push_up_out);//进入动画
		
		 l=(LinearLayout)findViewById(R.id.xiaohengmainLinearLayout1);
		ll=(LinearLayout)findViewById(R.id.xiaohengmainLinearLayout2);
		lll=(LinearLayout)findViewById(R.id.xiaohengmainLinearLayout3);
		final TextView t=(TextView)findViewById(R.id.xiaohengmainTextView1);
		
		//渐变
		Animation a=AnimationUtils.loadAnimation(MainActivity. this,R.anim.jianbian);
		l.startAnimation(a);
		lll.startAnimation(a);
		
		//旋转
		Animation b=AnimationUtils.loadAnimation(MainActivity. this,R.anim.xuanzuan);
		ll.startAnimation(b);
		
		
		//新建线程
		handler=new Handler();
		Runnable updateThread = new Runnable()
		{
			public void run()
			{
				//加载本地html文件
				WebView webView=(WebView)findViewById(R.id.xiaohengmainWebView1);
				webView.loadUrl("file:///android_asset/xiaoheng.html");
			}
		};
		handler.post(updateThread);//开启线程
		
		//倒计时
		timer=new CountDownTimer(6000,10)
		{
			public void onTick(long millisUntilFinished)
			{
				t.setText(millisUntilFinished/1000+"秒");
			}
			public void onFinish()
			{
				startActivity(new Intent(MainActivity.this,xiaohengactivity.class));
				overridePendingTransition(R.anim.push_left_in,R.anim.push_left_out);
				MainActivity.this.finish();
			}
		};
		timer.start();
	}
	
	
}
