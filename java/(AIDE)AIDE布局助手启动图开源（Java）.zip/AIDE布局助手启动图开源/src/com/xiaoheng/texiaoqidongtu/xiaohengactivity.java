package com.xiaoheng.texiaoqidongtu;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.xiaoheng.texiaoqidongtu.*;
import android.view.View.*;

public class xiaohengactivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaoheng);
		
		
		////////////////这里往下的代码不用管/////////////////////
		
		
		Button button1=(Button)findViewById(R.id.xiaohengButton1);
		Button button2=(Button)findViewById(R.id.xiaohengButton2);
		
		button1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					joinQQGroup("Miow_lT2ccTyvxNShCd33miSMDb90jeP");
				}
				public boolean joinQQGroup(String key)
				{
					Intent intent = new Intent();
					intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
					try
					{
						startActivity(intent);
						return true;
					}
					catch (Exception e)
					{
						return false;
					}
					
				}
			});
		
		button2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					try{
						startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=https%3A%2F%2Fqr.alipay.com%2FFKX00776US7D6RTHLZE76B%3F_s%3Dweb-other&_t=1486300416691#Intent;scheme=alipays;package=com.eg.android.AlipayGphone;end")));
						Toast.makeText(xiaohengactivity.this,"正在打开支付宝",Toast.LENGTH_LONG).show();
					}catch(Exception e)
					{
						AlertDialog.Builder dg=new AlertDialog.Builder(xiaohengactivity.this);
						dg.setTitle("提示");
						dg.setMessage("亲，您的手机还没有安装支付宝呢！");
						dg.setPositiveButton("去下载", new DialogInterface.OnClickListener(){
								@Override
								public void onClick(DialogInterface p1, int p2)
								{
									//去下载按钮按钮的点击事件
									startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://ds.alipay.com/")));
								}
							});
						dg.setNegativeButton("取消",new DialogInterface.OnClickListener(){
								@Override
								public void onClick(DialogInterface p1, int p2)
								{
									//取消按钮点击事件
								}
							});
						dg.show();
					}
				}
			});
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.xiaohengmenu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
			case R.id.xiaohengitem3:
				String 小亨QQ号= getResources().getString(R.string.小亨QQ);
				try
				{
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+小亨QQ号)));
				}
				catch(Exception e)
				{
					Toast.makeText(xiaohengactivity.this, "转跳失败，未安装手Q或当前版本不支持", 1000).show();
				}
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem2:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://fir.im/AIDElayout")));
		}

		switch(item.getItemId())
		{
			case R.id.xiaohengitem1:
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://pan.baidu.com/s/1slRXapB")));
		}
		return super.onOptionsItemSelected(item);
	}
	
	
}

    /****************************************
	 *      2017.9.9                        *
	 *                                      *
	 *      微信号：heng1919196455           *
	 *      小亨QQ：1919196455               *
	 *      QQ群聊：234257176                *
	 *                                      *
	 ****************************************/
