package com.scave.cnfunc.部件;

import android.view.View;
import android.content.Context;

public class 控件<T extends View> extends View
{
	public 控件(Context 上下文){
		super(上下文);
	}
}
