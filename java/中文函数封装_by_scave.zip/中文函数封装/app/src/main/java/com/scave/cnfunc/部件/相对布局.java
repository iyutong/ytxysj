package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class 相对布局 extends RelativeLayout
{
	public 相对布局(Context 上下文){
		super(上下文);
	}

	public 相对布局(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 相对布局(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 相对布局(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 相对布局 新建相对布局(Context 上下文){
		相对布局 btn = new 相对布局(上下文);
		return btn;
	}

	public void 添加控件(View 控件) {
		addView(控件);
	}

    public void 添加控件(View 控件, int 索引) {
		addView(控件,索引);
	}

    public void 添加控件(View 控件, int 宽度, int 高度) {
		addView(控件,宽度,高度);
	}

    public void 添加控件(View 控件, ViewGroup.LayoutParams 布局参数) {
		addView(控件,布局参数);
	}

    public void 添加控件(View 控件, int 索引, ViewGroup.LayoutParams 布局参数) {
		addView(控件,索引,布局参数);
	}
}
