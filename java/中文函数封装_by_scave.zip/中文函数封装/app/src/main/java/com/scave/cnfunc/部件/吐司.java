package com.scave.cnfunc.部件;

import android.content.Context;
import android.view.View;
import android.widget.Toast;

public class 吐司
{
	public static final int 长时 = 1;
    public static final int 短时 = 0;
	private Toast tw;
	
	public 吐司(Context 上下文){
		tw = new Toast(上下文);
	}
	
	public void 显示() {
		tw.show();
	}

    public void 取消() {
		tw.cancel();
	}

    public void 置控件(View 控件实例) {
		tw.setView(控件实例);
	}

    public View 取控件() {
		return tw.getView();
	}

    public void 置时长(int 时长) {
		tw.setDuration(时长);
	}

    public int 取时长() {
		return tw.getDuration();
	}

    public void 置边距(float 横向边距, float 纵向边距) {
		tw.setMargin(横向边距,纵向边距);
	}

    public float 取横向边距() {
		return tw.getHorizontalMargin();
	}

    public float 取纵向边距() {
		return tw.getVerticalMargin();
	}

    public void 置重力(int 重力, int xOffset, int yOffset) {
		tw.setGravity(重力,xOffset,yOffset);
	}

    public int 取重力() {
		return tw.getGravity();
	}

    public static void 显示文本(Context 上下文, CharSequence 文本, int 时长) {
		Toast.makeText(上下文,文本,时长).show();
	}

    public static void 显示文本(Context 上下文, int 资源ID, int 时长) {
		Toast.makeText(上下文,资源ID,时长).show();
	}

    public void 置文本(int 资源ID) {
		tw.setText(资源ID);
	}

    public void 置文本(CharSequence 文本) {
		tw.setText(文本);
	}
	
}
