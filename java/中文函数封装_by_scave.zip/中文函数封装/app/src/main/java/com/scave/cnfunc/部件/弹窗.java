package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

public class 弹窗 extends PopupWindow
{
	public 弹窗(Context 上下文) {
		super(上下文);
	}

    public 弹窗(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 弹窗(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 弹窗(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

    public 弹窗() {
		super();
	}

    public 弹窗(View 布局) {
		super(布局);
	}

    public 弹窗(int 宽度, int 高度) {
		super(宽度,高度);
	}

    public 弹窗(View 布局, int 宽度, int 高度) {
		super(布局,宽度,高度);
	}

    public 弹窗(View 布局, int 宽度, int 高度, boolean focusable) {
		super(布局,宽度,高度,focusable);
	}
	
	public void 置布局(View 布局){
		setContentView(布局);
	}
	
	public void 置动画风格(int 动画){
		setAnimationStyle(动画);
	}
	
	public void 指定显示(View 父布局,int 重力,int x坐标,int y坐标){
		showAtLocation(父布局,重力,x坐标,y坐标);
	}
	
	public void 置可取焦点(boolean 布尔值){
		setFocusable(布尔值);
	}
	
	public void 取消(){
		dismiss();
	}
}
