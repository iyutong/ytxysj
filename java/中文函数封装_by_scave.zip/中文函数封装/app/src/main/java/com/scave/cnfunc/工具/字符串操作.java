package com.scave.cnfunc.工具;

import android.content.ClipboardManager;
import android.content.Context;

public class 字符串操作
{
	public static String 截取字符(String 文本,String 开始,String 结束){
		if(文本.contains(开始) && 文本.contains(结束)){
			文本 = 文本.substring(文本.indexOf(开始)+结束.length());
			return 文本.substring(0, 文本.indexOf(结束));
		}
		return "";
	}

	public static void 置剪切板内容(Context context, String text) {
		ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setText(text);
	}
}
