package com.scave.cnfunc.操作系统;

import android.content.Context;
import android.os.Looper;
import android.util.Log;
import com.scave.cnfunc.工具.文件操作;
import com.scave.cnfunc.部件.吐司;
import java.io.File;

public class 崩溃处理程序 implements java.lang.Thread.UncaughtExceptionHandler
 {

    public static final String 标志 = "崩溃处理程序";  
    private Thread.UncaughtExceptionHandler 默认程序;  
    private static 崩溃处理程序 实例 = new 崩溃处理程序();  
    private Context 上下文;  

    //保证只有一个实例
    private 崩溃处理程序() {  
    }  

    //获取实例 ,单例模式
    public static 崩溃处理程序 取实例() {  
        return 实例;  
    }  
	
    public void 初始化(Context context) {  
        上下文 = context;  
        默认程序 = Thread.getDefaultUncaughtExceptionHandler();  
        Thread.setDefaultUncaughtExceptionHandler(this);  
    } 

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        if (!handleException(ex) && 默认程序 != null) {
            默认程序.uncaughtException(thread, ex);  
        } else {  
            try {  
                Thread.sleep(3000);  
            } catch (InterruptedException e) {  
                Log.d(标志, "error : ", e);  
            }  
            //退出程序  
            android.os.Process.killProcess(android.os.Process.myPid());  
            System.exit(0);  
        }

    }

    private boolean handleException(Throwable ex) {
        if (ex == null) {  
            return false;  
        }   
        new Thread() {  
            @Override  
            public void run() {  
                Looper.prepare();  
                吐司.显示文本(上下文, "很抱歉,程序出现异常,即将退出.", 吐司.短时);  
                Looper.loop();  
            }  
        }.start();  

        //在此可执行其它操作，如获取设备信息、执行异常登出请求、保存错误日志到本地或发送至服务端
		文件操作.写入文本(new File("/sdcard/log.txt"),ex.getMessage());
        return true;
    }

}
