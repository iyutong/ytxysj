package com.scave.cnfunc.部件;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import com.scave.cnfunc.接口.单击监听器;
import com.scave.cnfunc.接口.长按监听器;

public class 图片框 extends ImageView
{
	public 图片框(Context 上下文){
		super(上下文);
	}

	public 图片框(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 图片框(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 图片框(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 图片框 新建图片框(Context 上下文){
		图片框 btn = new 图片框(上下文);
		return btn;
	}
	
	public Drawable 取图像() {
		return getDrawable();
	}

    public void 置图像资源(int 资源ID) {
		setImageResource(资源ID);
	}

    public void 置图像URI(Uri URI) {
		setImageURI(URI);
	}

    public void 置图像(Drawable 图像) {
		setImageDrawable(图像);
	}

    public void 置图像位图(Bitmap 位图) {
		setImageBitmap(位图);
	}
	
    public void 置单击事件(final 单击监听器 监听器实例){
		setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View 控件实例)
				{
					监听器实例.被单击();
				}
			});
	}

	public void 置长按事件(final 长按监听器 监听器实例){
		setOnLongClickListener(new OnLongClickListener(){
				@Override
				public boolean onLongClick(View 控件实例)
				{
					监听器实例.被长按();
					return true;
				}
			});
	}
	
}
