package com.scave.cnfunc.接口;

import android.view.View;

public abstract interface 单击监听器
{
	public abstract void 被单击();
}
