package com.scave.cnfunc.工具;

import java.io.*;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import com.scave.cnfunc.接口.网络请求监听器;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class 网络操作
{
	public static Http任务 发送数据(String 网址, String 数据, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "POST", null, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

    public static Http任务 发送数据(String 网址, String 数据, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "POST", null, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

    public static Http任务 发送数据(String 网址, String 数据, String cookie, 网络请求监听器 回调) {
        Http任务 task = cookie.matches("[\\w\\-\\.:]+") && Charset.isSupported(cookie) ? new Http任务(网址, "POST", null, cookie, null, 回调) : new Http任务(网址, "POST", cookie, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

    public static Http任务 发送数据(String 网址, String 数据, String cookie, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = cookie.matches("[\\w\\-\\.:]+") && Charset.isSupported(cookie) ? new Http任务(网址, "POST", null, cookie, header, 回调) : new Http任务(网址, "POST", cookie, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

    public static Http任务 发送数据(String 网址, String 数据, String cookie, String 编码, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "POST", cookie, 编码, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

    public static Http任务 发送数据(String 网址, String 数据, String cookie, String 编码, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "POST", cookie, 编码, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 数据);
        return task;
    }

	public static Http任务 取数据(String 网址,网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", null, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 取数据(String 网址, Map<String, String> header,网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", null, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 取数据(String 网址, String cookie, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = cookie.matches("[\\w\\-\\.:]+") && Charset.isSupported(cookie) ? new Http任务(网址, "GET", null, cookie, header, 回调) : new Http任务(网址, "GET", cookie, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 取数据(String 网址, String cookie, 网络请求监听器 回调) {
        Http任务 task = cookie.matches("[\\w\\-\\.:]+") && Charset.isSupported(cookie) ? new Http任务(网址, "GET", null, cookie, null, 回调) : new Http任务(网址, "GET", cookie, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 取数据(String 网址, String cookie, String 编码, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", cookie, 编码, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 取数据(String 网址, String cookie, String 编码, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", cookie, 编码, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        return task;
    }

    public static Http任务 下载(String 网址, String 路径, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", null, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 路径);
        return task;
    }

    public static Http任务 下载(String 网址, String 路径, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", null, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 路径);
        return task;
    }

    public static Http任务 下载(String 网址, String 路径, String cookie, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", cookie, null, null, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 路径);
        return task;
    }

    public static Http任务 下载(String 网址, String 路径, String cookie, Map<String, String> header, 网络请求监听器 回调) {
        Http任务 task = new Http任务(网址, "GET", cookie, null, header, 回调);
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, 路径);
        return task;
    }

	static class Http任务 extends AsyncTask {
		private String mUrl;
		private 网络请求监听器 mCallback;
		private byte[] mData;
		private String mCode;
		private String mCharset;
		private String mCookie;
		private String mContent;
		private Map<String,String> mHeader;
		private String mMethod;
		long file_length,total_length;


		public Http任务(String url,String method,String cookie,String charset,Map<String,String> header,网络请求监听器 callback) {
			mUrl = url;
			mMethod = method;
			mCookie = cookie;
			mCharset = charset;
			mHeader = header;
			mCallback = callback;
		}


		@Override
		protected Object doInBackground(Object[] p1) {
			try {
				URL url = new URL(mUrl);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setConnectTimeout(8000);
				conn.setFollowRedirects(true);
				conn.setDoInput(true); //允许输入流，即允许下载
				conn.setDoOutput(true); //允许输出流，即允许上传
				conn.setUseCaches(false); //不使用缓冲
				conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
				conn.setRequestProperty("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
				conn.setRequestProperty("Accept-Language","zh-CN,en-GB;q=0.9,en-US;q=0.8");
				if (mCharset == null)
					mCharset = "UTF-8";
				conn.setRequestProperty("Accept-Charset", mCharset);

				if (mCookie != null)
					conn.setRequestProperty("Cookie", mCookie); 

				if (mHeader != null) {
					Set<Map.Entry<String, String>> entries=mHeader.entrySet();
					for (Map.Entry<String, String> entry:entries) {
						conn.setRequestProperty(entry.getKey(), entry.getValue());
					}
				}

				if (mHeader != null) {
					Set<Map.Entry<String, String>> entries=mHeader.entrySet();
					for (Map.Entry<String, String> entry:entries) {
						conn.setRequestProperty(entry.getKey(), entry.getValue());
					}
				}

				if (mMethod != null)
					conn.setRequestMethod(mMethod);

				if (!"GET".equals(mMethod) && p1.length != 0) {
					mData = formatData(p1);

					conn.setDoOutput(true);
					conn.setRequestProperty("Content-length", "" + mData.length); 
				}

				conn.connect();

				//download
				if ("GET".equals(mMethod) && p1.length != 0) {
					file_length = conn.getContentLengthLong();

					File f=new File((String)p1[0]);
					if(!f.getParentFile().exists())
						f.getParentFile().mkdirs();
					FileOutputStream os = new FileOutputStream(f);
					InputStream is = conn.getInputStream();
					copyFile(is,os);
					mCode = conn.getResponseCode()+"";
					mHeader = (Map<String, String>) conn.getHeaderFields();
					return new Object[]{mCode,mHeader};
				}

				//post upload
				if (p1.length != 0) {
					OutputStream os=conn.getOutputStream();
					os.write(mData);
				}

				int code=conn.getResponseCode();
				Map<String, List<String>> hs=conn.getHeaderFields();
				if (code >= 200 && code < 400) {
					String encoding=conn.getContentEncoding();
					List<String> cs=hs.get("Set-Cookie");
					StringBuffer cok=new StringBuffer();
					if (cs != null)
						for (String s:cs) {
							cok.append(s + ";");
						}

					InputStream is = conn.getInputStream();
					BufferedReader reader=new BufferedReader(new InputStreamReader(is, mCharset));
					StringBuffer buf=new StringBuffer();
					String line;

					while ((line = reader.readLine()) != null && !isCancelled()){
						buf.append(line + '\n');
					}
					is.close();
					mCode=code+"";
					mContent=new String(buf);
					mCookie=cok.toString();
					mHeader=(Map<String, String>) hs;
					return new Object[]{mCode,mContent,mCookie,mHeader};
				}
				else {
					mCode=code+"";
					mContent=new String(conn.getResponseMessage());
					//cookie=cok.toString();
					mHeader= (Map<String, String>) hs;
					return new Object[]{mCode,mContent,null,mHeader};
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				mCode="-1";
				mContent=e.getMessage();
				hand.sendEmptyMessage(0);
				//mCallback.onFailed(响应码,内容);
				return new Object[]{mCode,mContent};
			}

		}

		private byte[] formatData(Object[] p1) throws UnsupportedEncodingException, IOException {
			// TODO: Implement this method
			byte[] bs = null;
			if (p1.length == 1) {
				Object obj=p1[0];
				if (obj instanceof String)
					bs = ((String)obj).getBytes(mCharset);
				else if (obj.getClass().getComponentType() == byte.class)
					bs = (byte[])obj;
				else if (obj instanceof File)
					bs = readAll(new FileInputStream((File)obj));
				else if (obj instanceof File)
					bs = formatData((Map)obj);
			}
			return bs;
		}

		private byte[] formatData(Map obj) throws UnsupportedEncodingException {
			// TODO: Implement this method
			StringBuilder buf=new StringBuilder();
			Set<Map.Entry<String, String>> entries=mHeader.entrySet();
			for (Map.Entry<String, String> entry:entries) {
				buf.append(entry.getKey() + "=" + entry.getValue() + "&");
			}
			return buf.toString().getBytes(mCharset);
		}

		/*
		 public void cancel() {
		 // TODO: Implement this method
		 super.cancel(true);
		 }
		 */



		@Override
		protected void onPostExecute(Object result) {
			// TODO: Implement this method
			super.onPostExecute(result);
			if(isCancelled())
				return;
			try {
				mCallback.成功(mCode,mContent,mCookie,mHeader);
			}
			catch (Exception e) {
				mCallback.失败(mCode,e.getMessage());
				e.printStackTrace();
			}
		}

		@Override
		protected void onProgressUpdate(Object[] values)
		{
			mCallback.进度改变(values[0]);
		}


		private byte[] readAll(InputStream input) throws IOException {
			ByteArrayOutputStream output = new ByteArrayOutputStream(4096);
			byte[] buffer = new byte[2 ^ 32];
			int n = 0;
			while (-1 != (n = input.read(buffer))) {
				output.write(buffer, 0, n);
			}
			byte[] ret= output.toByteArray();
			output.close();
			return ret;
		}

		private boolean copyFile(InputStream in, OutputStream out) { 
			try { 
				int byteread = 0; 
				byte[] buffer = new byte[1024 * 1024]; 
				while ((byteread = in.read(buffer)) != -1) { 
				    total_length+=byteread;
					int value = (int)((total_length/(float)file_length)*100);
					publishProgress(value);
					out.write(buffer, 0, byteread); 
				} 
				//in.close();
				//out.close();
			} 
			catch (Exception e) { 
				return false;
			} 
			return true;
		} 


		Handler hand = new Handler(){

			@Override
			public void handleMessage(Message msg)
			{
				mCallback.失败(mCode,mContent);
				super.handleMessage(msg);
			}

		};
	}
}
