package com.scave.cnfunc.接口;

import android.content.DialogInterface;

public abstract class 对话框接口
{
	
	public static abstract interface 单击监听器{
		public abstract void 被单击(int 索引);
	}
	
	public static abstract interface 关闭监听器{
		public abstract void 被关闭();
	}
}
