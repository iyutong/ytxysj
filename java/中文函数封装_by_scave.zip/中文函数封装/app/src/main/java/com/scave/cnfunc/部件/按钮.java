package com.scave.cnfunc.部件;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.Layout;
import android.text.method.MovementMethod;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import com.scave.cnfunc.接口.单击监听器;
import com.scave.cnfunc.接口.长按监听器;

public class 按钮 extends Button
{
	
	public 按钮(Context 上下文){
		super(上下文);
	}

	public 按钮(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 按钮(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 按钮(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 按钮 新建按钮(Context 上下文){
		按钮 btn = new 按钮(上下文);
		return btn;
	}
	
	public void 置启用(boolean 布尔值) {
		setEnabled(布尔值);
	}

    public void 置字体(Typeface 字体, int 风格) {
		setTypeface(字体,风格);
	}

	public void 置文本(CharSequence 文本){
		setText(文本);
	}

	public void 置文本(int 资源ID){
		setText(资源ID);
	}

	public String 取文本() {
		return getText().toString();
	}

	public void 置提示文本(CharSequence 文本){
		setHint(文本);
	}

	public void 置提示文本(int 资源ID){
		setHint(资源ID);
	}

    public int 取长度() {
		return length();
	}

    public Editable 取可编辑文本() {
		return getEditableText();
	}

    public int 取行高() {
		return getLineHeight();
	}

    public final Layout 取布局() {
		return getLayout();
	}

	public final MovementMethod 取运动方法() {
		return getMovementMethod();
	}

    public final void 置运动方法(MovementMethod 方法) {
		setMovementMethod(方法);
	}

	public void 置内边距(int 左, int 上, int 右, int 下) {
		setPadding(左,上,右,下);
	}

    public float 取文本大小() {
		return getTextSize();
	}

    public void 置文本大小(float 大小) {
		setTextSize(大小);
	}

    public void 置文本大小(int 单元, float 大小) {
		setTextSize(单元,大小);
	}

    public void 置字体(Typeface 字体) {
		setTypeface(字体);
	}

	public void 置文本颜色(int 颜色) {
		setTextColor(颜色);
	}

	public void 置文本颜色(String 颜色字符串) {
		setTextColor(Color.parseColor(颜色字符串));
	}

    public void 置文本颜色(ColorStateList 色态列) {
		setTextColor(色态列);
	}

    public final void 置提示文本颜色(int 颜色) {
		setHintTextColor(颜色);
	}

	public final void 置提示文本颜色(String 颜色字符串) {
		setHintTextColor(Color.parseColor(颜色字符串));
	}

    public final void 置提示文本颜色(ColorStateList 色态列) {
		setHintTextColor(色态列);
	}

    public void 置重力(int 重力) {
		setGravity(重力);
	}

    public int 取重力() {
		return getGravity();
	}

    public void 置高度(int px) {
		setHeight(px);
	}

    public void 置宽度(int px) {
		setWidth(px);
	}
	
	public void 置单击事件(final 单击监听器 监听器实例){
		setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View 控件实例)
				{
					监听器实例.被单击();
				}
			});
	}
	
	public void 置长按事件(final 长按监听器 监听器实例){
		setOnLongClickListener(new OnLongClickListener(){
				@Override
				public boolean onLongClick(View 控件实例)
				{
					监听器实例.被长按();
					return true;
				}
			});
	}
	
}
