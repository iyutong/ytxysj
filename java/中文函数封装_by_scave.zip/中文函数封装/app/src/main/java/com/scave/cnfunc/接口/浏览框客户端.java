package com.scave.cnfunc.接口;

import android.graphics.Bitmap;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import com.scave.cnfunc.部件.浏览框;

public class 浏览框客户端
{
	public boolean 重载网址(浏览框 浏览框实例, String 网址){
		return false;
	}
	public boolean 重载网址(浏览框 浏览框实例, WebResourceRequest 请求){
		return false;
	}
	public void 开始加载(浏览框 浏览框实例, String 网址, Bitmap 位图){}
	public void 加载完成(浏览框 浏览框实例, String 网址){}
	public void 加载资源(浏览框 浏览框实例, String 网址){}
	public void 接收错误(浏览框 浏览框实例, int 错误码, String 描述, String 失败网址){}
	public void 接收错误(浏览框 浏览框实例, WebResourceRequest 请求, WebResourceError 错误){}
	public void 接收Http错误(浏览框 浏览框实例, WebResourceRequest 请求, WebResourceResponse 请求2){}
	public void 接收Ssl错误(浏览框 浏览框实例, SslErrorHandler 处理程序, SslError 错误){}
}
