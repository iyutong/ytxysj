package com.scave.cnfunc.接口;

public abstract interface 列表单击监听器
{
	public abstract void 被单击(int 索引);
}
