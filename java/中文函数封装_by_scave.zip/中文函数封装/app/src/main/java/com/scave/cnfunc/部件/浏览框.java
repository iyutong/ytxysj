package com.scave.cnfunc.部件;

import android.webkit.*;
import com.scave.cnfunc.接口.*;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.NinePatchDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Environment;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.scave.cnfunc.R;
import com.scave.cnfunc.内容.意图;
import com.scave.cnfunc.工具.字符串操作;
import com.scave.cnfunc.工具.网络操作;
import com.scave.cnfunc.应用.对话框;
import com.scave.cnfunc.应用.活动;
import com.scave.cnfunc.部件.吐司;
import com.scave.cnfunc.部件.适配器.数组适配器;
import java.io.File;
import java.util.Map;

public class 浏览框 extends WebView
{
	private View 视图1;
	private 进度条 进度条1;
	private 浏览框 临时浏览框;
	private 浏览框客户端 客户端1;
	private 内核客户端 客户端2;
	private String 文件名;
	private Activity 活动;
	private int X坐标;
	private int Y坐标;
	private int index = 10;
    private int 原始方向;
	private int 原始系统可见性;
    private int 结果码 = 5173;
    private int 结果码_安卓5 = 5174;
	private boolean 是否显示进度条=true;
    private ValueCallback<Uri> 上传信息1;
    private ValueCallback<Uri[]> 上传信息2;
	private View 控件;
	private 列表 列表1;
	private 线性布局 线性布局1;
	private 数组适配器<String> 适配器;
	private 弹窗 弹窗1;
	String[] 文本 = {"保存图片","复制图片链接"};
    private WebChromeClient.CustomViewCallback 浏览框回调;
	
	public 浏览框(Context 上下文){
		super(上下文);
	}

	public 浏览框(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 浏览框(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 浏览框(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 浏览框 新建浏览框(Context 上下文){
		浏览框 btn = new 浏览框(上下文);
		return btn;
	}
	
	public void 初始化(Activity 活动){
		this.活动 = 活动;
		this.临时浏览框 = this;
		构建();
	}
	
	public void 构建(){
		控件 = LayoutInflater.from(getContext()).inflate(R.layout.popupwindow,null);
        列表1 = 控件.findViewById(R.id.列表1);
		线性布局1 = 控件.findViewById(R.id.线性布局1);
		Bitmap 位图 = BitmapFactory.decodeResource(活动.getResources(),R.drawable.back);
		NinePatchDrawable 背景 = new NinePatchDrawable(位图, 位图.getNinePatchChunk(),new Rect(),"back");  
		线性布局1.置背景图像(背景);
		适配器 = new 数组适配器<String>(活动,android.R.layout.simple_list_item_1,文本);
		列表1.置适配器(适配器);
		
        进度条1 = new 进度条(活动, null, android.R.attr.progressBarStyleHorizontal);
        进度条1.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,10,0,0));
        添加控件(进度条1);

        WebSettings webSettings = getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setUseWideViewPort(true); 
        webSettings.setAllowFileAccess(true); 
        webSettings.setDomStorageEnabled(true);
        webSettings.setPluginState(WebSettings.PluginState.ON);
        webSettings.setSupportZoom(true); 
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); 
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
		
		置浏览框客户端(new 浏览框客户端());
		置内核客户端(new 内核客户端());
		置下载监听器(new 下载监听器(){
				@Override
				public void 开始下载(String 网址, String 用户代理, String Header, String 类型, long 内容长度)
				{
					下载(网址,Header,内容长度);
				}
			});
		置长按事件(new 长按监听器() {
				public void 被长按(){
					WebView.HitTestResult result = getHitTestResult();
					int type = result.getType();
					switch (type){
						case WebView.HitTestResult.EDIT_TEXT_TYPE:
							 break;
						case WebView.HitTestResult.PHONE_TYPE:
							break;
						case WebView.HitTestResult.EMAIL_TYPE:
							break;
						case WebView.HitTestResult.SRC_ANCHOR_TYPE:
							final String 网址 = result.getExtra();
							文本 = new String[]{"复制链接","打开链接","分享链接"};
							适配器 = new 数组适配器<String>(活动, android.R.layout.simple_list_item_1, 文本);
							列表1.置适配器(适配器);
							显示弹窗1();
							列表1.置列表单击事件(new 列表单击监听器(){
									@Override
									public void 被单击(int 索引) {
										弹窗1.取消();
										if (索引 == 0){
											字符串操作.置剪切板内容(活动, 网址);
											吐司.显示文本(活动, "已复制", 吐司.短时);
										}
										if (索引 == 1)
											加载网址(网址);
										else{
										}
									}
								});
							break;
						case WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE:
						case WebView.HitTestResult.IMAGE_TYPE: 
							final String 网址2 = result.getExtra();
							文本 = new String[]{"保存图片","复制图片链接"};
							适配器 = new 数组适配器<String>(活动, android.R.layout.simple_list_item_1, 文本);
							列表1.置适配器(适配器);
							显示弹窗1();
							列表1.置列表单击事件(new 列表单击监听器(){
									@Override
									public void 被单击(int 索引){
										弹窗1.取消();
										if (索引 == 1){
											字符串操作.置剪切板内容(活动, 网址2);
										    吐司.显示文本(活动, "已复制", 吐司.短时);
										}
										else{
											++index;
											网络操作.下载(网址2, "/sdcard/Download/image_" + index + ".png", new 网络请求监听器(){
													@Override
													public void 成功(String 响应码, String 内容, String cookie, Map<String,String> header){
														吐司.显示文本(活动, "保存成功", 吐司.短时);
													}
												});
										}
									}
								});
							break;
						case WebView.HitTestResult.UNKNOWN_TYPE:
							break;
					}
				}
			});
	}
	
	private void 显示弹窗1() {
        弹窗1 = new 弹窗(this,ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        弹窗1.置布局(控件);
        弹窗1.置可取焦点(true);
		弹窗1.置动画风格(R.style.pop_animation);
        弹窗1.指定显示(this,Gravity.BOTTOM,X坐标,Y坐标);
    }
	
	public void 显示进度条(){
		进度条1.setVisibility(View.GONE);
		是否显示进度条 = false;
	}
	
	public void 隐藏进度条(){
		进度条1.setVisibility(View.VISIBLE);
		是否显示进度条 = true;
	}
	
    public void 加载网址(String 网址) {
		loadUrl(网址);
	}

    public void 停止加载() {
		stopLoading();
	}

    public void 重载() {
		reload();
	}

    public boolean 可后退() {
		return canGoBack();
	}

    public void 后退() {
		goBack();
	}

    public boolean 可前进() {
		return canGoForward();
	}

    public void 前进() {
		goForward();
	}
	
	public String 取网址(){
		return getUrl();
	}
	
	public String 取标题(){
		return getTitle();
	}
	
	public int 取进度(){
		return getProgress();
	}
	
	public void 添加控件(View 控件){
		addView(控件);
	}
	
	public void 置浏览框客户端(浏览框客户端 客户端){
		this.客户端1 = 客户端;
		setWebViewClient(new MyWebViewClient());
	}
	
	public void 置内核客户端(内核客户端 客户端){
		this.客户端2 = 客户端;
		setWebChromeClient(new MyWebChromeClient());
	}
	
	public void 置下载监听器(final 下载监听器 监听器实例){
		setDownloadListener(new DownloadListener(){
				@Override
				public void onDownloadStart(String p1, String p2, String p3, String p4, long p5)
				{
					监听器实例.开始下载(p1,p2,p3,p4,p5);
				}
			});
	}
	
	public void 置长按事件(final 长按监听器 监听器){
		setOnLongClickListener(new OnLongClickListener(){
				@Override
				public boolean onLongClick(View p1) {
					监听器.被长按();
					return true;
				}
			});
	}
	//选择文件回调
    public void 回调 (int 请求码, int 结果码,Intent 意图) {
        if (请求码 == 结果码) {
            if (null == 上传信息1) {
                return;
            }
            Uri result = 意图 == null || 结果码 != Activity.RESULT_OK ? null  : 意图.getData();
            上传信息1.onReceiveValue(result);
            上传信息1 = null;
        } else if (请求码 == 结果码_安卓5) {
            if (null == 上传信息2) {
                return;
            }
            上传信息2.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(结果码, 意图));
            上传信息2 = null;
        }
	}

	private void 打开应用(Context 上下文,String 网址){
        try {
            意图 意图1 = new 意图(意图.ACTION_VIEW,Uri.parse(网址));
            意图1.置标志(意图.FLAG_ACTIVITY_NEW_TASK|意图.FLAG_ACTIVITY_SINGLE_TOP);
            上下文.startActivity(意图1);
        } catch (Exception e) {
            吐司.显示文本(上下文,"您未安装该应用",吐司.短时);
        }
    }
	public void 展示视频(View 控件,WebChromeClient.CustomViewCallback 回调){
        视图1 = 控件;
        原始系统可见性 = 活动.getWindow().getDecorView().getSystemUiVisibility();
        原始方向 =活动.getRequestedOrientation();
        浏览框回调 = 回调;
        FrameLayout decor = (FrameLayout) 活动.getWindow().getDecorView();
        decor.addView(视图1, new FrameLayout.LayoutParams(
                          ViewGroup.LayoutParams.MATCH_PARENT,
                          ViewGroup.LayoutParams.MATCH_PARENT));
        活动.getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_IMMERSIVE);
        活动.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    public void 关闭视频(){
        FrameLayout decor = (FrameLayout) 活动.getWindow().getDecorView();
        decor.removeView(视图1);
        视图1 = null;
        decor.setSystemUiVisibility(原始系统可见性);
        活动.setRequestedOrientation(原始方向);
        浏览框回调.onCustomViewHidden();
        浏览框回调 = null;
    }
	
	private void 下载(final String 网址,String Header,long 字节长度){
        final 编辑框 编辑框1 = new 编辑框(活动);
        final Uri uri=Uri.parse(网址);
        文件名 = uri.getLastPathSegment();
        if (Header != null) {
            String p="filename=\"";
            int i=Header.indexOf(p);
            if (i != -1) {
                i += p.length();
                int n=Header.indexOf('"', i);
                if (n > i)
                    文件名 = Header.substring(i, n);
            }
        }
        编辑框1.setText(文件名);
        new 对话框(活动)
            .置标题(文件名)
            .置信息("大小: " + 转换大小(字节长度))
            .置控件(编辑框1)
            .置积极按钮("下载", new 对话框接口.单击监听器(){
                @Override
                public void 被单击(int 索引) {
                    文件名 = 编辑框1.getText().toString();
                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setTitle(文件名);
                    File saveFile = new File(Environment.getExternalStorageDirectory(), 文件名);
                    request.setDestinationUri(Uri.fromFile(saveFile));
                    DownloadManager manager = (DownloadManager) 活动.getSystemService(Context.DOWNLOAD_SERVICE);
                    long downloadId = manager.enqueue(request);
                }
            })
            .置消极按钮("取消", null)
			.显示();
    }
	
	public String 转换大小(long size){
        long rest = 0;
        if(size < 1024){
            return String.valueOf(size) + "B";
        }else{
            size /= 1024;
        }

        if(size < 1024){
            return String.valueOf(size) + "K";
        }else{
            rest = size % 1024;
            size /= 1024;
        }

        if(size < 1024){
            size = size * 100;
            return String.valueOf((size / 100)) + "." + String.valueOf((rest * 100 / 1024 % 100)) + "M";
        }else{
            size = size * 100 / 1024;
            return String.valueOf((size / 100)) + "." + String.valueOf((size % 100)) + "G";
        }
    }

	@Override
    public void onScrollChanged(int l, int t, int oldl, int oldt) {
        LayoutParams lp = (LayoutParams) 进度条1.getLayoutParams();
        lp.x = l;
        lp.y = t;
        进度条1.setLayoutParams(lp);
        super.onScrollChanged(l, t, oldl, oldt);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                if (可后退())
                    后退();
                else
                    System.exit(0);
                return true;
            default:
                return super.onKeyUp(keyCode, event);
        }
    }
    
	class MyWebViewClient extends WebViewClient{
		@Override
		public boolean  shouldOverrideUrlLoading(WebView 浏览框实例,final String 网址){
			if (!网址.startsWith("http")&&!网址.startsWith("file")) {
				new 对话框(活动).置标题("提示")
					.置信息("该网页即将打开应用,是否允许？")
					.置积极按钮("允许", new 对话框接口.单击监听器(){
						@Override
						public void 被单击(int 索引) {
							打开应用(活动,网址);
						}
					})
					.置消极按钮("取消",null)
					.置可取消(false)
					.显示();
				return true;
			}
			客户端1.重载网址(临时浏览框,网址);
			return super.shouldOverrideUrlLoading(浏览框实例,网址);
		}
		@Override
		public boolean shouldOverrideUrlLoading(WebView 浏览框实例, WebResourceRequest 请求) {
			客户端1.重载网址(临时浏览框,请求);
			return super.shouldOverrideUrlLoading(浏览框实例, 请求);
		}
		@Override
		public void onPageStarted(WebView 浏览框实例, String 网址, Bitmap 位图) {
			客户端1.开始加载(临时浏览框,网址,位图);
		}
		@Override
		public void onPageFinished(WebView 浏览框实例, String 网址) {
			客户端1.加载完成(临时浏览框,网址);
		}
		@Override
		public void onLoadResource(WebView 浏览框实例, String 网址) {
			客户端1.加载资源(临时浏览框,网址);
			super.onLoadResource(浏览框实例, 网址);
		}
		@Override
		public void onReceivedError(WebView 浏览框实例, int 错误码, String 描述, String 失败网址) {
			客户端1.接收错误(临时浏览框,错误码,描述,失败网址);
			super.onReceivedError(浏览框实例, 错误码, 描述, 失败网址);
		}
		@Override
		public void onReceivedError(WebView 浏览框实例, WebResourceRequest 请求, WebResourceError 错误) {
			客户端1.接收错误(临时浏览框,请求,错误);
			super.onReceivedError(浏览框实例, 请求, 错误);
		}
		@Override
		public void onReceivedHttpError(WebView 浏览框实例, WebResourceRequest 请求1, WebResourceResponse 请求2) {
			客户端1.接收Http错误(临时浏览框,请求1,请求2);
			super.onReceivedHttpError(浏览框实例, 请求1, 请求2);
		}
		@Override
		public void onReceivedSslError(WebView 浏览框实例, SslErrorHandler 处理程序, SslError 错误) {
			客户端1.接收Ssl错误(临时浏览框,处理程序,错误);
			super.onReceivedSslError(浏览框实例, 处理程序, 错误);
		}
	}
	
	class MyWebChromeClient extends WebChromeClient{
		@Override
		public void  onProgressChanged(WebView 浏览框实例,int 进度值){
			客户端2.进度改变(临时浏览框,进度值);
			if(是否显示进度条==true){
				if (进度值 == 100) {
					进度条1.setVisibility(GONE);
				} else {
					if (进度条1.getVisibility() == GONE)
						进度条1.setVisibility(VISIBLE);
					进度条1.置进度值(进度值);
				}
				super.onProgressChanged(浏览框实例,进度值);
			}
		}
		@Override
		public void onReceivedTitle(WebView 浏览框实例, String 标题){
			客户端2.接收标题(临时浏览框,标题);
			super.onReceivedTitle(浏览框实例, 标题);
		}
		@Override
		public void onReceivedIcon(WebView 浏览框实例, Bitmap 位图){
			客户端2.接收图标(临时浏览框,位图);
			super.onReceivedIcon(浏览框实例, 位图);
		}
		@Override
		public void onConsoleMessage(String 信息, int 行号, String 资源ID){
			客户端2.控制台信息(信息,行号,资源ID);
			super.onConsoleMessage(信息, 行号, 资源ID);
		}
		@Override
		public boolean onConsoleMessage(ConsoleMessage 控制台信息){
			客户端2.控制台信息(控制台信息);
			return super.onConsoleMessage(控制台信息);
		}
		
		@Override
		public Bitmap getDefaultVideoPoster() {
			return BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher);
		}
		@Override
		public void onShowCustomView(View 控件,WebChromeClient.CustomViewCallback 回调) {
			if (视图1 != null){
				onHideCustomView(); 
				return;
				}
			展示视频(控件,回调);
		}
		@Override
		public void onHideCustomView() {
			if (视图1 ==null){
			关闭视频();
			return ;
			}
			setVisibility(View.VISIBLE);
		}
		@Override
		public View getVideoLoadingProgressView() {
			return super.getVideoLoadingProgressView();
		}
		public void openFileChooser(ValueCallback<Uri> 上传信息,String 接收类型, String capture) {
			上传信息1 = 上传信息;
			Intent i = new Intent(Intent.ACTION_GET_CONTENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("*/*");
			活动.startActivityForResult(Intent.createChooser(i, "文件选择"), 结果码);
		}
		@TargetApi(Build.VERSION_CODES.LOLLIPOP)
		public boolean onShowFileChooser(WebView 浏览框实例,ValueCallback<Uri[]> 上传信息,WebChromeClient.FileChooserParams 文件参数) {
			if (上传信息2 != null) {
				上传信息2.onReceiveValue(null);
				上传信息2 = null;
			}
			上传信息2 = 上传信息;
			Intent intent = 文件参数.createIntent();
			try {
				活动.startActivityForResult(intent,结果码_安卓5);
			} catch (ActivityNotFoundException e) {
				上传信息2 = null;
				return false;
			}
			return true;
		}
	}
	
	@Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        X坐标 = (int) event.getRawX();
        Y坐标 = (int) event.getRawY();
        return super.onInterceptTouchEvent(event);
    }
	
}
