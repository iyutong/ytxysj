package com.scave.cnfunc;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import com.scave.cnfunc.应用.活动;
import com.scave.cnfunc.接口.内核客户端;
import com.scave.cnfunc.接口.单击监听器;
import com.scave.cnfunc.接口.浏览框客户端;
import com.scave.cnfunc.部件.按钮;
import com.scave.cnfunc.部件.浏览框;
import com.scave.cnfunc.部件.编辑框;
import com.scave.cnfunc.基本.基本操作;
import org.apache.http.impl.io.ContentLengthInputStream;
import android.content.Context;

public class MainActivity extends 活动 
{ 
    private 编辑框 编辑框1;
	private 按钮 按钮1;
	private 浏览框 浏览框1;
	活动 当前活动 = MainActivity.this;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		置布局(R.layout.main);
		编辑框1 = 找控件(R.id.编辑框1);
		按钮1 = 找控件(R.id.按钮1);
		浏览框1 = 找控件(R.id.浏览框1);
		浏览框1.初始化(this);
		浏览框1.加载网址("https://www.baidu.com");
		浏览框1.置浏览框客户端(new 浏览框客户端(){
			@Override
			public void 开始加载(浏览框 浏览框实例,String 网址,Bitmap 位图){
				编辑框1.置文本(网址);
			}
		});
		浏览框1.置内核客户端(new 内核客户端(){
			@Override
			public void 接收标题(浏览框 浏览框实例,String 标题) {
				置标题(标题);
			}
		});
		按钮1.置单击事件(new 单击监听器(){

                private Context Context;
				@Override
				public void 被单击() {
					浏览框1.加载网址(编辑框1.取文本());
                    基本操作.弹出提示(Context,编辑框1.取文本(),1000);
					/*网络操作.取数据(浏览框1.取网址(),new 网络请求监听器(){
						@Override
						public void 成功(String 响应码,String 内容,String cookie,Map<String,String> header){
							new 对话框(当前活动).置标题("网页源码")
							.置信息(内容)
							.置积极按钮("确定",null)
							.置可取消(假).显示();
						}
					});*/
				}
			});
    }

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		浏览框1.回调(requestCode,resultCode,data);
		super.onActivityResult(requestCode, resultCode, data);
	}

}
