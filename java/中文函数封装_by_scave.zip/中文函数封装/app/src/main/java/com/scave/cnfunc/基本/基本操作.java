package com.scave.cnfunc.基本;

import android.widget.Toast;
import android.content.Context;

public class 基本操作 {

    public static void 弹出提示(Context context,String 内容,int 时间)   {      

        Toast.makeText(context,内容,时间).show();   

    }

}
