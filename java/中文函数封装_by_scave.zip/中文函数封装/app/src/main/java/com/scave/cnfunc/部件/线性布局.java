package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.graphics.drawable.Drawable;

public class 线性布局 extends LinearLayout
{
	public 线性布局(Context 上下文){
		super(上下文);
	}

	public 线性布局(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 线性布局(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 线性布局(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}
	
	public static 线性布局 新建线性布局(Context 上下文){
		线性布局 btn = new 线性布局(上下文);
		return btn;
	}
	
	public void 添加控件(View 控件) {
		addView(控件);
	}

    public void 添加控件(View 控件, int 索引) {
		addView(控件,索引);
	}

    public void 添加控件(View 控件, int 宽度, int 高度) {
		addView(控件,宽度,高度);
	}

    public void 添加控件(View 控件, ViewGroup.LayoutParams 布局参数) {
		addView(控件,布局参数);
	}

    public void 添加控件(View 控件, int 索引, ViewGroup.LayoutParams 布局参数) {
		addView(控件,索引,布局参数);
	}
	
	public void 置背景图像(Drawable 图像){
		setBackgroundDrawable(图像);
	}
}
