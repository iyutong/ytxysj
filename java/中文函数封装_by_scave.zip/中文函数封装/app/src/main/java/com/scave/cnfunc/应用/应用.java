package com.scave.cnfunc.应用;

import android.app.Application;
import android.content.Context;

public class 应用 extends Application
{
	public Context 取上下文(){
		return getApplicationContext();
	}
}
