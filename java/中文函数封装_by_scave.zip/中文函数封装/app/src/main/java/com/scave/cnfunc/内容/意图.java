package com.scave.cnfunc.内容;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class 意图 extends Intent
{
	static 意图 意图实例;
	
	public 意图(){
		super();
		意图实例 = this;
	}
	
	public 意图(Intent 实例) {
		super(实例);
		意图实例 = this;
	}

    public 意图(String 动作) {
		super(动作);
		意图实例 = this;
	}

    public 意图(String 动作, Uri URI) {
		super(动作,URI);
		意图实例 = this;
	}

    public 意图(Context 上下文, Class<?> 类) {
		super(上下文,类);
		意图实例 = this;
	}

    public 意图(String 动作, Uri URI, Context 上下文, Class<?> 类) {
		super(动作,URI,上下文,类);
		意图实例 = this;
	}
	
	public static 意图 取意图(String uri){
		意图实例 = new 意图(uri);
		return 意图实例;
	}

    public static 意图 解析URI(String uri, int 标志) {
		意图实例 = new 意图(uri);
		意图实例.setFlags(标志);
		return 意图实例;
	}
	
	public 意图 置标志(int 标志){
		意图 tmp = 意图实例;
		tmp.setFlags(标志);
		return tmp;
	}

    public String 取动作() {
		return getAction();
	}

    public Uri 取数据() {
		return getData();
	}

    public String 取数据字符串() {
		return getDataString();
	}

    public String 取协议() {
		return getScheme();
	}

    public String 取类型() {
		return getType();
	}
	
	
}
