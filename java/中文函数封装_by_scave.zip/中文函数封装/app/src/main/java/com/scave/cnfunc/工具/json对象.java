package com.scave.cnfunc.工具;

import android.widget. *;
import android.os. *;
import android.view. *;
import android.view.View. *;
import android.webkit. *;
import android.graphics. *;
import android.graphics.drawable. *;
import android.app. *;
import android.content. *;
import android.content.res. *;
import java.util. *;
import org.json. *;


public class json对象 {
    private JSONObject obj;
    public json对象() {
        super();
        this.obj = new JSONObject();
    }
    public json对象(JSONObject obj) {
        this.obj = obj;
    }
    
    
    public void 置json文本(String json文本) throws JSONException
    {
        try{
            
         this.obj = new JSONObject(json文本);
         
        }
        catch (JSONException e) {
            throw new RuntimeException("JSON文本错误");
        }
        
        
    }
    
    
}
