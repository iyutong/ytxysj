package com.scave.cnfunc.接口;

import android.view.View;

public abstract interface 长按监听器
{
	public abstract void 被长按();
}
