package com.scave.cnfunc.工具;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class 加解密操作 
{
	public static String MD5加密(String 文本) {
		char hexDigits[] = { '0', '1', '2', '3', '4','5', '6', '7', 
			'8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		try {
			byte[] btInput = 文本.getBytes();
			MessageDigest mdInst = MessageDigest.getInstance("MD5");
			mdInst.update(btInput);
			byte[] md = mdInst.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];
				str[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(str);
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String SHA加密(String 文本) {
		try{
			MessageDigest sha = MessageDigest.getInstance("SHA");
			sha.update(文本.getBytes());
			return new String(sha.digest());
		}catch (Exception e){
			return null;
		}
    }

	public static String Base64加密(String 文本){
		byte[] str = Base64.getEncoder().encode(文本.getBytes());
		return new String(str);
	}
	public static String Base64解密(String 文本){
		byte[] str = Base64.getDecoder().decode(文本);
		return new String(str);
	}

	public static String DES加密(String 文本, String 密码) {
        try{
            SecureRandom random = new SecureRandom();
            DESKeySpec desKey = new DESKeySpec(密码.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey securekey = keyFactory.generateSecret(desKey);
            Cipher cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.ENCRYPT_MODE, securekey, random);
            return new String(cipher.doFinal(文本.getBytes()));
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

	public static String DES解密(String 文本, String 密码) {
		try{
			SecureRandom random = new SecureRandom();
			DESKeySpec desKey = new DESKeySpec(密码.getBytes());
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(desKey);
			Cipher cipher = Cipher.getInstance("DES");
			cipher.init(Cipher.DECRYPT_MODE, securekey, random);
			return new String(cipher.doFinal(文本.getBytes()));
		}catch (Exception e){
			return null;
		}
    }

	public static String AES加密(String 文本,String 密码){
        try {
            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            keygen.init(128, new SecureRandom(密码.getBytes()));
            SecretKey original_key = keygen.generateKey();
            byte [] raw = original_key.getEncoded();
            SecretKey key = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte [] byte_encode = 文本.getBytes("utf-8");
            byte [] byte_AES = cipher.doFinal(byte_encode);
            String AES_encode = new String(byte_AES);
            return AES_encode;
        } catch (Exception e) {
            e.printStackTrace();
			return null;         
		}
	}

	public static String AES解密(String 文本,String 密码){
        try {
            KeyGenerator keygen = KeyGenerator.getInstance("AES");
            keygen.init(128, new SecureRandom(密码.getBytes()));
            SecretKey original_key = keygen.generateKey();
            byte [] raw = original_key.getEncoded();
            SecretKey key = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte [] byte_content = 文本.getBytes();
            byte [] byte_decode=cipher.doFinal(byte_content);
            String AES_decode=new String(byte_decode,"utf-8");
            return AES_decode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;         
    }

	public static String RC4加解密(String 文本,String 密码) {
		int[] iS = new int[256];
		byte[] iK = new byte[256];
		for (int i=0;i<256;i++)
			iS[i]=i;
		int j = 1;
		for (short i= 0;i<256;i++)
			iK[i]=(byte)密码.charAt((i % 密码.length()));
		j=0;
		for (int i=0;i<255;i++) {
			j=(j+iS[i]+iK[i]) % 256;
			int temp = iS[i];
			iS[i]=iS[j];
			iS[j]=temp;
		}
		int i=0;
		j=0;
		char[] iInputChar = 文本.toCharArray();
		char[] iOutputChar = new char[iInputChar.length];
		for(short x = 0;x<iInputChar.length;x++) {
			i = (i+1) % 256;
			j = (j+iS[i]) % 256;
			int temp = iS[i];
			iS[i]=iS[j];
			iS[j]=temp;
			int t = (iS[i]+(iS[j] % 256)) % 256;
			int iY = iS[t];
			char iCY = (char)iY;
			iOutputChar[x] =(char)( iInputChar[x] ^ iCY) ;
		}
		return new String(iOutputChar);
	}
}
