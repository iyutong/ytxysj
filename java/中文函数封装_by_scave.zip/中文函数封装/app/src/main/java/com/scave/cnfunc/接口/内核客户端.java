package com.scave.cnfunc.接口;

import android.graphics.Bitmap;
import android.webkit.ConsoleMessage;
import com.scave.cnfunc.部件.浏览框;

public class 内核客户端
{
	public void 进度改变(浏览框 浏览框实例, int 进度值){}
    public void 接收标题(浏览框 浏览框实例, String 标题){}
    public void 接收图标(浏览框 浏览框实例, Bitmap 图标){}
    public void 控制台信息(String 信息, int 行号, String 资源ID){}
    public boolean 控制台信息(ConsoleMessage 控制台信息){
		return false;
	}
}
