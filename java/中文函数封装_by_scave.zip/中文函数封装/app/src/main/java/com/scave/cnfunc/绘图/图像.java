package com.scave.cnfunc.绘图;

import android.graphics.drawable.Drawable;
import android.graphics.ColorFilter;
import android.graphics.Canvas;

public class 图像 extends Drawable
{
	public 图像(){
		super();
	}
	
	@Override
	public void draw(Canvas p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void setAlpha(int p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void setColorFilter(ColorFilter p1)
	{
		// TODO: Implement this method
	}

	@Override
	public int getOpacity()
	{
		// TODO: Implement this method
		return 0;
	}
	
}
