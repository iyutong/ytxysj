package com.scave.cnfunc.应用;

import android.app.Activity;
import android.view.View;
import android.os.Bundle;
import com.scave.cnfunc.内容.意图;

public class 活动 extends Activity
{
	public static final boolean 真 = true;
	public static final boolean 假 = false;
	
	public void 置标题(CharSequence 标题){
		setTitle(标题);
	}
	
	public void 置主题(int 主题){
		setTheme(主题);
	}
	
	public void 置布局(int 资源ID){
		setContentView(资源ID);
	}
	
	public void 置布局(View 控件实例){
		setContentView(控件实例);
	}
	
	public <T extends View> T 找控件(int 资源ID){
		return findViewById(资源ID);
	}
	
	public 意图 取意图(){
		return new 意图(getIntent());
	}
}
