package com.scave.cnfunc.接口;

import android.text.Editable;

public abstract interface 文本改变监听器
{
	public abstract void 文本改变前(CharSequence 文本, int 开始位置, int 数量, int 文本长度);
	public abstract void 文本正在改变(CharSequence 文本, int 开始位置, int 文本长度, int 数量);
	public abstract void 文本改变后(Editable 可编辑文本);
}
