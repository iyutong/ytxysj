package com.scave.cnfunc.部件.适配器;

import android.content.Context;
import android.widget.ArrayAdapter;
import java.util.List;

public class 数组适配器<T extends Object> extends ArrayAdapter
{
	public 数组适配器(Context 上下文, int 布局) {
		super(上下文,布局);
	}

    public 数组适配器(Context 上下文, int 布局, int 文本资源ID) {
		super(上下文,布局,文本资源ID);
	}
	
    public 数组适配器(Context 上下文, int 布局, T[] 数组) {
		super(上下文,布局,数组);
	}

    public 数组适配器(Context 上下文, int 布局, int 文本资源ID, T[] 数组) {
		super(上下文,布局,文本资源ID,数组);
	}

    public 数组适配器(Context 上下文, int 布局, List<T> 集合) {
		super(上下文,布局,集合);
	}

    public 数组适配器(Context 上下文, int 布局, int 文本资源ID, List<T> 集合) {
		super(上下文,布局,文本资源ID,集合);
	}
	
}
