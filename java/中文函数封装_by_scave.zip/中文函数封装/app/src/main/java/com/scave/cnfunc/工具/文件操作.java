package com.scave.cnfunc.工具;

import android.widget.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import java.util.*;
import java.io.*;
import java.util.*;
import android.net.*;
import java.text.*;

import android.content.Context;
import android.os.Environment;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;



public class 文件操作
{
	public static final File file=Environment.getExternalStorageDirectory();

    public static String 取文件名(String 路径) {
        return FileUtils.getFileName(路径);
    }
	
    public static void 取文件列表所有文件名(String path,ArrayList<String> fileNameList) {
        File file = new File(path);
        File[] tempList = file.listFiles();

        for (int i = 0; i < tempList.length; i++) {
            if (tempList[i].isFile()) {
       fileNameList.add(tempList[i].getName());
            }
            if (tempList[i].isDirectory()) {
          取文件列表所有文件名(tempList[i].getAbsolutePath(),fileNameList);
            }
        }
        return;
    }
    
    public static String 取文件前缀名(String 路径) {
        return FileUtils.getFilePrefix(new File(路径));
    }
    
    public static String 取文件后缀名(String 路径) {
        return FileUtils.getFileSuffix(new File(路径));
    }
    
    public static String 取文件MD5(String 路径) {
        try {
            return FileUtils.getMD5(new File(路径));
        } catch (IOException e) {
            e.printStackTrace();
        }
		return "";
    }
    
    public static String 取文件SHA1(String 路径) {
        try {
            return FileUtils.getSHA1(new File(路径));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    
    public static String 取文件crc32(String 路径) {
        try {
            return FileUtils.getCRC32(new File(路径));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    
    
    
    public static boolean 创建文件目录(String 路径){
        
        return FileUtils.createDirectory(new File(路径));
    }
    
    
    public static boolean 创建文件(String 路径){

        return FileUtils.createFile(new File(路径));
    }
    
    public static String 取文件编码(String 路径) {
        try {
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(new File(路径)));
            in.mark(4);
            byte[] first3bytes = new byte[3];
            in.read(first3bytes);
            in.reset();
            if (first3bytes[0] == (byte) -17 && first3bytes[1] == (byte) -69 && first3bytes[2] == (byte) -65) {
                return "utf-8";
            }
            if (first3bytes[0] == (byte) -1 && first3bytes[1] == (byte) -2) {
                return "unicode";
            }
            if (first3bytes[0] == (byte) -2 && first3bytes[1] == (byte) -1) {
                return "utf-16be";
            }
            if (first3bytes[0] == (byte) -1 && first3bytes[1] == (byte) -1) {
                return "utf-16le";
            }
            return "GBK";
        } catch (Exception e) {
            //e.printStackTrace();
            throw new RuntimeException("取文件编码( 未找到文件:" + 路径);
		}
    }
    
    
    
    
    
    
	//读取Assets文本
	public static String 读Assets(Context 上下文, String 文件名) {
        try {
            InputStream is = 上下文.getAssets().open(文件名);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer, "utf-8");
			return text;
        }
		catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
	
	//写入文本
	public static boolean 写入文本(File 文件, String 文本){
		byte[] sourceByte = 文本.getBytes();
		if (null != sourceByte){
			try{
				if (!文件.exists()){	
					File dir = new File(文件.getParent());
					dir.mkdirs();
					文件.createNewFile();
				}
				FileOutputStream outStream = new FileOutputStream(文件);
				outStream.write(sourceByte);
				outStream.close();	
				return true;
			}
			catch (Exception e){
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	//读取文本
	public static String 读取文本(File 文件) {
		try {
			InputStreamReader reader = new InputStreamReader(new FileInputStream(文件)); 
			BufferedReader br = new BufferedReader(reader); 
			String line = "";  
			line = br.readLine();  
			while (line != null) {  
				line = br.readLine(); 
			}  
			return line;
		}
		catch (Exception e) {
			return "";
		}
	}
	
	//复制文件
	public static void 复制文件(File 原始文件, File 导出文件,Boolean 覆盖){
		if (!原始文件.exists())
			return;
		if (!原始文件.isFile()) 
			return ;
		if (!原始文件.canRead())
			return ;
		if (!导出文件.getParentFile().exists())
			导出文件.getParentFile().mkdirs();
		if (导出文件.exists() && 覆盖)
			导出文件.delete();
		try {
			FileInputStream fosfrom = new FileInputStream(原始文件);
			FileOutputStream fosto = new FileOutputStream(导出文件);
			byte bt[] = new byte[1024];
			int c;
			while ((c = fosfrom.read(bt)) > 0) {
				fosto.write(bt, 0, c);
			}
			fosfrom.close();
			fosto.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//删除文件
	public static void 删除文件(File 文件) {
		if (文件.isDirectory()) {
			File[] files = 文件.listFiles();
			for (File file : files) {
				删除文件(file);
				file.delete();
			}
		}else{
			文件.delete();
			new File(file+"/tmp").delete();
		}}
		
	public static boolean 文件存在(File 文件) {
            if (!文件.exists())
				return false;
		return true;
    }
    
    
    public static boolean 重命名文件(String 原路径,String 新路径) {
        if (新路径.equals(原路径)) {
            return true;
        }
        File oldfile = new File(原路径);
        if (!oldfile.exists()) {
            return false;
        }
        File newfile = new File(新路径);
        if (newfile.exists()) {
            return false;
        }
        if (oldfile.renameTo(newfile)) {
            return true;
        }
		return false;
        }
        
        
    public static boolean 复制文件2(String 文件路径, String 欲复制到路径){
   
    try {
        FileUtils.copyTo(new File(文件路径), new File(欲复制到路径));
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
    return true;
    }
    
    
    public static void 移动文件(String 文件路径, String 欲移到路径){
    try {
        FileUtils.moveTo(new File(文件路径), new File(欲移到路径));
    } catch (IOException e) {
        e.printStackTrace();
    }
    }
    
    
    public static String 读入文本文件(String 路径, String 编码){
        try {
            return FileUtils.readString(new File(路径), 编码);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
        }
    
    
    public static void 写出文本文件(String 路径, String 欲写出内容){
        try {
            FileUtils.write(new File(路径), 欲写出内容);
        } catch (IOException e) {
            e.printStackTrace();
        }
    
    }
    
    public static String 取文件大小(String 路径){
        
        File file = new File(路径);
        try {
            if (file.isDirectory()) {
                return getFileSizes(file);
            }
            return getFileSize(file);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("取文件大小( 错误");
		}
        
    }

    private static String getFileSizes(File file) {
        return null;
    }
    
    private static String[] UNITS = new String[] { "B", "K", "M", "G", "T", "P", "E", "Z", "Y" };
    
    public static String getFileSize(File file) {
        long size = file.length();
        int unit = 0;
        while (size > 1024) {
            size >>= 10;//2^10 = 1024
            unit++;
        }
        BigDecimal bd = new BigDecimal(file.length());
        BigDecimal divider = new BigDecimal(1024);
        for (int i = 0; i < unit; i++) {
            bd = bd.divide(divider, 2, BigDecimal.ROUND_HALF_UP);
        }
        return bd.toPlainString() + UNITS[unit];
    }

    
    
}
