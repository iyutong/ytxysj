package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;
import android.widget.ListAdapter;
import com.scave.cnfunc.接口.列表单击监听器;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Adapter;

public class 列表 extends ListView
{
	public 列表(Context 上下文){
		super(上下文);
	}

	public 列表(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 列表(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 列表(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 列表 新建列表(Context 上下文){
		列表 btn = new 列表(上下文);
		return btn;
	}
	
	public void 置适配器(ListAdapter 适配器){
		setAdapter(适配器);
	}
	
	public void 置列表单击事件(final 列表单击监听器 监听器){
		setOnItemClickListener(new OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					监听器.被单击(p3);
				}
			});
	}
}
