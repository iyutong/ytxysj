package com.scave.cnfunc.绘图;

import android.widget.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import java.util.*;
import android.text.*;
import java.io.*;

import android.view.GestureDetector.SimpleOnGestureListener;
import com.scave.cnfunc.部件.控件;
import com.scave.cnfunc.接口.长按监听器;

public class 画板 extends View {
    
    private Paint backgroundColor;
    private String backgroundImage = "";
    private int backgroundImage2 = -1;
    private int canvasheight;
    private int canvaswidth;
    private int currX;
    private int currY;
    private int lastX;
    private int lastY;
    private GestureDetector mGestureDetector;
    private Paint paintColor;
    private int paintsize;
    private int paintstyle;
    private float textsize;
    private Typeface typeface = null;
    private int 索引;

    public static int extractARGB(Paint paint) {
        return paint.getColor() | (paint.getAlpha() << 24);
    }

    public static void changePaint(Paint paint, int argb) {
        if ((-16777216 & argb) == 0) {
            paint.setAlpha(0);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            return;
        }
        paint.setColor(16777215 & argb);
        paint.setAlpha((argb >> 24) & 255);
        paint.setXfermode(null);
    }
    class MyGestureListener extends SimpleOnGestureListener {

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            int deltaX = (int) (e1.getRawX() - e2.getRawX());
            int deltaY = (int) (e1.getRawY() - e2.getRawY());
            int direction = Math.abs(deltaX) > Math.abs(deltaY) ? deltaX > 0 ? 4 : 5 : deltaY > 0 ? 2 : 3;
          //  挂接事件 触摸手势(direction);
            return true;
        }

        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            int direction = Math.abs(distanceX) > Math.abs(distanceY) ? distanceX > 0.0f ? 8 : 9 : distanceY > 0.0f ? 6 : 7;
            //挂接事件 触摸手势(direction);
            return true;
        }

        public boolean onSingleTapConfirmed(MotionEvent e) {
          //  挂接事件 触摸手势(0);
            return true;
        }

        public boolean onDoubleTap(MotionEvent e) {
        //    挂接事件 触摸手势(1);
            return true;
        }
    }

    public class CanvasView extends View {
        protected Bitmap bitmap;
        protected Canvas canvas;

        protected void onDraw(Canvas canvas) {
            if (this.bitmap != null) {
                canvas.drawBitmap(this.bitmap, 0.0f, 0.0f, null);
            }
        }

        public CanvasView(Context context) {
            super(context);
            this.bitmap = Bitmap.createBitmap(context.getWallpaperDesiredMinimumWidth(), context.getWallpaperDesiredMinimumWidth(), Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
        }

        public void reset(int w, int h) {
            this.bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            this.canvas.setBitmap(this.bitmap);
        }
    }
    
    public void onClick(View p1) {
      //  挂接事件 被单击();
    }

   
    public boolean onTouch(View p1, MotionEvent event) {
        this.lastX = this.currX;
        this.lastY = this.currY;
        this.currX = (int) event.getX();
        this.currY = (int) event.getY();
        switch (event.getAction()) {
            case 0:
                this.lastX = this.currX;
                this.lastY = this.currY;
             //   挂接事件 被按下(this.currX, this.currY);
                break;
            case 1:
                this.lastX = this.currX;
                this.lastY = this.currY;
              //  挂接事件 被弹起(this.currX, this.currY);
                break;
            case 2:
               // 挂接事件 被移动(this.lastX, this.lastY, this.currX, this.currY);
                break;
        }
        this.mGestureDetector.onTouchEvent(event);
        return false;
	}
    
    
    public 画板(Context 上下文){
        super(上下文);
        canvasheight = 上下文.getWallpaperDesiredMinimumWidth();
        canvaswidth = 上下文.getWallpaperDesiredMinimumWidth();
	}
    
   
    public View 创建视图(Context 上下文) {
        CanvasView view = new CanvasView(上下文);
       // view.setOnClickListener(this);
        view.setFocusable(true);
        this.backgroundColor = new Paint();
        this.paintColor = new Paint(1);
        this.paintColor.setStrokeWidth(1.0f);
        this.mGestureDetector = new GestureDetector(new MyGestureListener());
      //  view.setOnTouchListener(this);
		return view;
       
    }
    
    
    public int 背景颜色(){
        return extractARGB(this.backgroundColor);
	}
    
    /*public void 背景颜色(int 背景颜色){
        
        changePaint(this.backgroundColor, 背景颜色);
        CanvasView view = (CanvasView) getView();
        view.canvas.drawPaint(this.backgroundColor);
		view.invalidate();
        
    }*/
    public void 置长按事件(final 长按监听器 监听器){
        setOnLongClickListener(new OnLongClickListener(){
                @Override
                public boolean onLongClick(View p1) {
                    监听器.被长按();
                    return true;
                }
			});
            }
}
