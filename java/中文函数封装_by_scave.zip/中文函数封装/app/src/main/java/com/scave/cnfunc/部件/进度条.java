package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

public class 进度条 extends ProgressBar
{
	public 进度条(Context 上下文){
		super(上下文);
	}

	public 进度条(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 进度条(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 进度条(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 进度条 新建进度条(Context 上下文){
		进度条 btn = new 进度条(上下文);
		return btn;
	}
	
	public void 置启用(boolean 布尔值) {
		setEnabled(布尔值);
	}
	
	public void 置进度值(int 进度值){
		setProgress(进度值);
	}
	
	public int 取进度值(){
		return getProgress();
	}
}
