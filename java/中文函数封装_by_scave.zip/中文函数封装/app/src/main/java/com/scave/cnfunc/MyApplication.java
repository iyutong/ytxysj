package com.scave.cnfunc;

import com.scave.cnfunc.应用.应用;
import com.scave.cnfunc.操作系统.崩溃处理程序;

public class MyApplication extends 应用
{

	@Override
	public void onCreate()
	{
		super.onCreate();
		崩溃处理程序 程序 = 崩溃处理程序.取实例();
		程序.初始化(取上下文());
	}
	
}
