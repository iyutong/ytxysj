package com.scave.cnfunc.部件;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Spinner;

public class 下拉列表框 extends Spinner
{
	public 下拉列表框(Context 上下文){
		super(上下文);
	}

	public 下拉列表框(Context 上下文, AttributeSet 属性集) {
		super(上下文,属性集);
	}

    public 下拉列表框(Context 上下文, AttributeSet 属性集, int defStyleAttr) {
		super(上下文,属性集,defStyleAttr);
	}

    public 下拉列表框(Context 上下文, AttributeSet 属性集, int defStyleAttr, int defStyleRes) {
		super(上下文,属性集,defStyleAttr,defStyleRes);
	}

	public static 下拉列表框 新建下拉列表框(Context 上下文){
		下拉列表框 btn = new 下拉列表框(上下文);
		return btn;
	}

	public void 置启用(boolean 布尔值) {
		setEnabled(布尔值);
	}
}
