package com.scave.cnfunc.接口;

public abstract interface 下载监听器{
	public abstract void 开始下载(String 网址, String 用户代理, String Header, String 类型, long 内容长度);
}
