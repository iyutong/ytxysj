package com.scave.cnfunc.接口;

import java.util.Map;

public class 网络请求监听器
{
	public void 成功(String 响应码,String 结果,String cookie,Map<String,String> Header){}
	public void 失败(String 响应码,String 结果){}
	public void 进度改变(int value){}
}
