package com.scave.cnfunc.应用;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import com.scave.cnfunc.接口.对话框接口;
import com.scave.cnfunc.绘图.图像;

public class 对话框 extends AlertDialog.Builder
{
	对话框 对话框实例;
	AlertDialog ad;
	
	public 对话框(Context 上下文){
		super(上下文);
		初始化();
	}
	public 对话框(Context 上下文, int 主题){
		super(上下文,主题);
		初始化();
	}
	
	private void 初始化(){
		对话框实例 = this;
	}
	
	public 对话框 置标题(CharSequence 标题){
		对话框 tmp = 对话框实例;
		tmp.setTitle(标题);
		return tmp;
	}
	
	public 对话框 置标题(int 标题ID){
		对话框 tmp = 对话框实例;
		tmp.setTitle(标题ID);
		return tmp;
	}
	
	public 对话框 置信息(CharSequence 信息){
		对话框 tmp = 对话框实例;
		tmp.setMessage(信息);
		return tmp;
	}
	
	public 对话框 置信息(int 信息ID){
		对话框 tmp = 对话框实例;
		tmp.setMessage(信息ID);
		return tmp;
	}
	
	public 对话框 置图标(int 资源ID){
		对话框 tmp = 对话框实例;
		tmp.setIcon(资源ID);
		return tmp;
	}
	
	public 对话框 置图标(图像 图像实例){
		对话框 tmp = 对话框实例;
		tmp.setIcon(图像实例);
		return tmp;
	}
	
	public 对话框 置可取消(boolean 布尔值){
		对话框 tmp = 对话框实例;
		tmp.setCancelable(布尔值);
		return tmp;
	}
	
	public 对话框 置控件(View 控件){
		对话框 tmp = 对话框实例;
		tmp.setView(控件);
		return tmp;
	}
	
	public 对话框 置控件(int 控件ID){
		对话框 tmp = 对话框实例;
		tmp.setView(控件ID);
		return tmp;
	}
	
	public void 显示(){
		ad = 对话框实例.create();
		ad.show();
	}
	
	public void 关闭(){
		ad.dismiss();
	}
	
	public 对话框 置列表(CharSequence[] 文本,final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setItems(文本, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引){
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置列表(int 文本ID,final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setItems(文本ID, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引){
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置积极按钮(CharSequence 文本, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setPositiveButton(文本, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置积极按钮(int 文本ID, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setPositiveButton(文本ID, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置消极按钮(CharSequence 文本, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setNegativeButton(文本, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置消极按钮(int 文本ID, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setNegativeButton(文本ID, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置中立按钮(CharSequence 文本, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setNeutralButton(文本, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置中立按钮(int 文本ID, final 对话框接口.单击监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setNeutralButton(文本ID, new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface 接口, int 索引) {
					if(监听器 != null)
					监听器.被单击(索引);
				}
			});
		return tmp;
	}
	
	public 对话框 置关闭监听器(final 对话框接口.关闭监听器 监听器){
		对话框 tmp = 对话框实例;
		tmp.setOnDismissListener(new DialogInterface.OnDismissListener(){
				@Override
				public void onDismiss(DialogInterface 接口) {
					if(监听器 != null)
					监听器.被关闭();
				}
			});
		return tmp;
	}
}
