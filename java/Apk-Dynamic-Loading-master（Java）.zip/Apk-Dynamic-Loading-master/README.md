# Apk-Dynamic-Loading
从服务器下载过来的Dex、jar或者apk文件，通过本地apk动态调用加载其中的方法实现插件化开发的Demo,简单易懂
