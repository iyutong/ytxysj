package assets;

/**
 * Created by Administrator on 2017/10/25.
 */

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import android.app.Activity;

public interface IDynamic {
    void init(Activity var1);

    void showBanner();

    void showDialog();

    void showFullScreen();

    void showAppWall();

    void destroy();
}
