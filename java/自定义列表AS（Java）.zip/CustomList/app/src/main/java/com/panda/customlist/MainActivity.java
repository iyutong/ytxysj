package com.panda.customlist;

import android.app.Activity;
import java.util.Map;
import java.util.List;

import android.support.v7.app.AppCompatActivity;
import android.widget.SimpleAdapter;
import android.widget.ListView;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private List<Map<String, Object>> lists;
    private SimpleAdapter adapter;
    private ListView listView;

    private String[] theme = {"狗", "猪", "熊","狗", "猪", "熊","狗", "猪", "熊","狗", "猪", "熊","狗", "猪", "熊"};
    private String[] content = {"600 602 501", "666 620 502", "666 620 503","狗", "猪", "熊","狗", "猪", "熊","狗", "猪", "熊","狗", "猪", "熊"};
    private int[] image = {R.drawable.ic_launcher,R.drawable.b9s,R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.b9s,R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.b9s,R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.b9s,R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.b9s,R.drawable.ic_launcher};  //用到的图片是mipmap中的ic_launcher

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       //把文字And图片打印在list上
        lists = new ArrayList<>();
        for (int i = 0; i < theme.length; i++) {
            Map<String, Object> map = new HashMap<>();
            map.put("image", image[i]);
            map.put("theme", theme[i]);
            map.put("content", content[i]);
            lists.add(map);
        }

       //适配器指定id
        adapter = new SimpleAdapter(MainActivity.this, lists, R.layout.list_view, new String[]{"image", "theme", "content"}, new int[]{R.id.image1, R.id.text_theme, R.id.text_content});
        listView = findViewById(R.id.listview);
        listView.setAdapter(adapter);
}}
