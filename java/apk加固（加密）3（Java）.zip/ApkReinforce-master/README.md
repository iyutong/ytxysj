
#  Android中的Apk的加固(加壳)原理解析和实现

http://blog.csdn.net/jiangwei0910410003/article/details/48415225/