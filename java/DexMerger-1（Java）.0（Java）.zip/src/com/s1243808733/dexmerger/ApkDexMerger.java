package com.s1243808733.dexmerger;

import com.android.dexj.Dex;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApkDexMerger {

    private final DxContext mContext;

    private final File mApkFile;

    public final File mWorkDir;

    public final File mDecompressDir;

    public ApkDexMerger(File apkFile) {
        this(new DxContext(), apkFile);
    }

    public ApkDexMerger(DxContext context, File apkFile) {
        context.out.println("初始化...");
	    this.mContext = context;
        this.mApkFile = apkFile;
        mWorkDir = new File(apkFile.getParentFile(), ".dexmerger");
        mDecompressDir = new File(mWorkDir, "decompress");
        clearWorkDir();
    }

    public void merger(File apkOut) throws IOException {
		long startTime = System.nanoTime();
        mContext.out.println("正在解压...");
		try {
			ZipUtils.unzipFile(mApkFile, mDecompressDir);
		} catch (IOException e) {
			mContext.err.println("解压失败");
			throw e;
		}

        multDexMerger: {
            mContext.out.println("获取Dex...");
            List<File> dexFiles = array2List(mDecompressDir.listFiles(new DexFileFilter()));
			if (dexFiles == null) {
				throw new IOException("获取dex列表失败");
			} else if (dexFiles.isEmpty()) {
				throw new IOException("无dex文件");
			}
            Collections.sort(dexFiles, new DexFileComparator());

            MultDexMerger.Builder builder = new MultDexMerger.Builder(mContext);
		    builder.add(dexFiles.toArray(new File[]{}));

            print: {
                for (int i = 0; i < dexFiles.size(); i++) {
                    File dexFile = dexFiles.get(i);
                    String fileName = dexFile.getName();
                    mContext.out.println("[" + i + "] " + fileName);
                }
            }

            mContext.out.println("开始合并Dex...");

			List<Dex> dexs;
			try {
				MultDexMerger multDexMerger = builder.create();
				dexs = multDexMerger.merger();
			} catch (IOException e) {
				mContext.err.println("Dex合并失败");
				throw e;
			}

			deleteDexFile: {
				for (File dexFile : dexFiles) {
					dexFile.delete();
				}
			}

			for (int i = 0; i < dexs.size(); i++) {
				Dex dex = dexs.get(i);
				String fileName = String.format("classes%s.dex", i < 1 ?"": String.valueOf(i + 1));
				mContext.out.println("[" + i + "] " + fileName);
				File outDir = mDecompressDir;
				if (!outDir.exists()) {
					outDir.mkdirs();
				}
				File out = new File(outDir, fileName);
				dex.writeTo(out);
			}

		}

		File out = new File(mWorkDir, "build/apk");
		out.getParentFile().mkdirs();
		zipFiles: {
			mContext.out.println("重新构建APK...");
			List<File> fileList = array2List(mDecompressDir.listFiles());
			if (fileList == null || fileList.isEmpty()) {
				throw new IOException("获取文件列表失败");
			}
			try {
				ZipUtils.zipFiles(fileList, out);
			} catch (IOException e) {
				mContext.err.println("APK构建失败");
				throw e;
			}
			if (!out.renameTo(apkOut)) {
				mContext.err.println("APK导出失败");
			}
		}

		mContext.out.println("清除缓存...");
		clearWorkDir();
		mContext.out.printf("完成/%.1fs",(System.nanoTime() - startTime) / 1000000000f);
		
	}

	public void clearWorkDir() {
		delectAllFileInDir(mWorkDir);
	}

    public static List<String> getClassesDexPathsFormApk(File apkFile) throws IOException {
        List<String> pathList = new ArrayList<>();
        List<String> getFilesPath = ZipUtils.getFilesPath(apkFile);
        for (String name : getFilesPath) {
            if (name.contains("/")) continue;
            if (name.startsWith("classes") && name.endsWith(".dex")) {
                pathList.add(name);
            }
        }
        return pathList;
    }

    private static <T> List<T> array2List(T[] array) {
        if (array == null) return null;
        ArrayList<T> list = new ArrayList<>(array.length);
        for (int i = 0; i < array.length; i++) {
            list.add(array[i]);
        }
        return list;
    }

    private static void delectAllFileInDir(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] listFiles = file.listFiles();
            for (int i = 0; listFiles != null && i < listFiles.length; i++) {
                delectAllFileInDir(listFiles[i]);
            }
            file.delete();
        } else {
            file.delete();
        }
    }

	private boolean isDexFileByName(File file) {
		String name = file.getName();
		return file.isFile() && name.startsWith("classes")
			&& name.endsWith(".dex");
	}

	private class DexFileFilter implements FileFilter {

        @Override
        public boolean accept(File file) {
            return isDexFileByName(file);
        }

    }

    private class DexFileComparator implements Comparator<File> {

        @Override
        public int compare(File f1, File f2) {
            if (isDexFileByName(f1) && isDexFileByName(f2)) {
                int pos = getDexFilePosByName(f1, 1);
                int pos2 = getDexFilePosByName(f2, 1);
				return  pos - pos2;
            }
            return f1.compareTo(f2);
        }

        private int getDexFilePosByName(File file, int def) {
            if (!isDexFileByName(file)) return def;
			String fileName = file.getName();
			try {
				String posStr = fileName.substring("classes".length(), fileName.length() - ".dex".length());
				if (posStr.trim().length() != 0) {
					return Integer.parseInt(posStr);
				}
			} catch (Throwable e) {
				mContext.err.println(e.toString());
			}
            return def;
        }

    }

}
