package com.s1243808733.dexmerger;

import com.android.dexj.Dex;
import com.android.dexj.DexIndexOverflowException;
import com.android.dx.merge.CollisionPolicy;
import com.android.dx.merge.DexMerger;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MultDexMerger {

	private static final int COMPACT_WASTE_THRESHOLD = 1024 * 1024;

	private final DxContext mContext;

	private final Parameter mParameter;

	public MultDexMerger(DxContext context, Parameter parameter) {
		this.mContext = context;
		this.mParameter = parameter;
	}

    public List<Dex> merger() throws IOException {
		ArrayList<Dex> out = new ArrayList<Dex>();
		mergerTo(out);
		return out;
	}

	public void mergerTo(List<Dex> out) throws IOException {
		List<List<Dex>> groupDexs = mParameter.getGroupDexs();
	    for (int i = 0; out != null && groupDexs != null && i < groupDexs.size(); i++) {
            List<Dex> childs = groupDexs.get(i);
            Dex[] dexs = childs.toArray(new Dex[]{});
            Dex dex = merger(dexs);
            out.add(dex);
        }
	}

	public Dex merger(Dex... dexs) throws IOException {
		return merger(dexs, dexs[0], 1);
	}

	private Dex merger(Dex[] dexs, Dex dexA, int start) throws IOException {
		if (start + 1 > dexs.length) {
			return dexA;
		}
		Dex dexB = dexs[start];
		DexMerger dm = new DexMerger(dexA, dexB, mParameter.getCollisionPolicy());
		dm.setCompactWasteThreshold(mParameter.getCompactWasteThreshold());
		return merger(dexs, dm.merge(), start + 1);
	}

    public DxContext getContext() {
        return mContext;
    }

	public Parameter getParameter() {
		return mParameter;
	}

    public static class Parameter {

		private List<List<Dex>> mGroupDexs;

		private CollisionPolicy mCollisionPolicy = CollisionPolicy.KEEP_FIRST;

		private int mCompactWasteThreshold = MultDexMerger.COMPACT_WASTE_THRESHOLD;

		public Parameter() {
		}

		public Parameter setGroupDexs(List<List<Dex>> groupDexs) {
			this.mGroupDexs = groupDexs;
			return this;
		}

		public List<List<Dex>> getGroupDexs() {
			return mGroupDexs;
		}

		public Parameter setCollisionPolicy(CollisionPolicy collisionPolicy) {
			this.mCollisionPolicy = collisionPolicy;
			return this;
		}

		public CollisionPolicy getCollisionPolicy() {
			return mCollisionPolicy;
		}

		public Parameter setCompactWasteThreshold(int compactWasteThreshold) {
			this.mCompactWasteThreshold = compactWasteThreshold;
			return this;
		}

		public int getCompactWasteThreshold() {
			return mCompactWasteThreshold;
		}

	}

    public static class Builder {

        private final DxContext mDxContext;

        private List<Dex> mDexs = new ArrayList<>();

		private CollisionPolicy mCollisionPolicy = CollisionPolicy.KEEP_FIRST;

		private int mCompactWasteThreshold = MultDexMerger.COMPACT_WASTE_THRESHOLD;

		private int mMaxIndex = 0xFFFF;

		public Builder() {
            this(new DxContext());
        }

        public Builder(DxContext dxContext) {
            this.mDxContext = dxContext;
        }

		public void setDexs(List<Dex> mDexs) {
			this.mDexs = mDexs;
		}

		public List<Dex> getDexs() {
			return mDexs;
		}

        public Builder add(Dex dex) {
            if (dex != null) {
				this.mDexs.add(dex);
			}
            return this;
        }

        public Builder add(Dex... dexs) {
            for (int i = 0; dexs != null && i < dexs.length; i++) {
                add(dexs[i]);
            }
            return this;
        }

        public Builder add(File dexFile) throws IOException {
            return add(new Dex(dexFile));
        }

        public Builder add(File... dexFiles) throws IOException {
            for (int i = 0; dexFiles != null && i < dexFiles.length; i++) {
                add(dexFiles[i]);
            }
            return this;
        }

        public Builder add(String dexFile) throws IOException {
            return add(new File(dexFile));
        }

        public Builder add(String... dexFiles) throws IOException {
            for (int i = 0; dexFiles != null && i < dexFiles.length; i++) {
                add(dexFiles[i]);
            }
            return this;
        }

		public Builder setCollisionPolicy(CollisionPolicy collisionPolicy) {
			if (collisionPolicy == null) {
				throw new IllegalArgumentException("collisionPolicy is null");
			}
			this.mCollisionPolicy = collisionPolicy;
			return this;
		}

		public CollisionPolicy getCollisionPolicy() {
			return mCollisionPolicy;
		}

		public Builder setCompactWasteThreshold(int compactWasteThreshold) {
			this.mCompactWasteThreshold = compactWasteThreshold;
			return this;
		}

		public void setMaxIndex(int maxIndex) {
			if (maxIndex < 0 || maxIndex > 0xFFFFFF) {
				throw new DexIndexOverflowException("type ID not in [0, 0xffff]: " + maxIndex);
			}
			this.mMaxIndex = maxIndex;
		}

        public Builder clear() {
            mDexs.clear();
            return this;
        }

		public Builder builder() {
            return this;
        }

        public MultDexMerger create() {
            List<List<Dex>> groupDexs=new ArrayList<>();

            add(groupDexs, 0);
			print(groupDexs);

			Parameter configuration = new Parameter();
			configuration.setGroupDexs(groupDexs);
			configuration.setCollisionPolicy(mCollisionPolicy);
			configuration.setCompactWasteThreshold(mCompactWasteThreshold);

            MultDexMerger merger = new MultDexMerger(mDxContext, configuration);
            return merger;
        }

        private void add(List<List<Dex>> groupDexs, int start) {
			if (groupDexs == null || start < 0 || start >= mDexs.size()) {
				return;
			}

            List<Dex> childs = new ArrayList<>();

            int totalFieldCount = 0;
            int totalMethodCount = 0;
            int totalTypeCount = 0;
			int totalProtoIdCount = 0;
			for (int i = start; i < mDexs.size(); i++) {

                Dex dex = mDexs.get(i);

				totalFieldCount += dex.fieldIds().size();
				totalMethodCount += dex.methodIds().size();
				totalTypeCount += dex.typeIds().size();
				totalProtoIdCount += dex.protoIds().size();

                if (isIndexOverflow(totalFieldCount,
									totalMethodCount,
									totalTypeCount,
									totalProtoIdCount)) {
					continue;
                }

                ++start;
                childs.add(dex);
            }

            groupDexs.add(childs);

            add(groupDexs, start); 
        }

		private boolean isIndexOverflow(int... indexs) {
			for (int i = 0; indexs != null && i < indexs.length; i++) {
				if (indexs[i] > mMaxIndex) {
					return true;
				}
			}
			return false;
		}

		private void print(List<List<Dex>> groupDexs) {
            mDxContext.out.println("group size:" + groupDexs.size());
            for (int i = 0; i < groupDexs.size(); i++) {
                List<Dex> dexs = groupDexs.get(i);
                int methodCount = 0;
                for (Dex dex : dexs) {
                    methodCount += dex.methodIds().size();
                }
                mDxContext.out.println("[" + i + "] size:" + dexs.size() + ", method=" + methodCount);
            }
        }

    }

}

