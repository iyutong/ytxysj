package com.s1243808733.dexmerger;

import java.io.PrintStream;

public class DxContext {

	public PrintStream out = System.out;

	public PrintStream err = System.err;

	public DxContext() {

	}

	public DxContext(PrintStream out, PrintStream err) {
		this.out = out;
		this.err = err;
	}
	
}
