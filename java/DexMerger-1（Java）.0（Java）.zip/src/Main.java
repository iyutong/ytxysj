import com.s1243808733.dexmerger.ApkDexMerger;
import java.io.File;

public class Main {

    public static void main(String[] args) throws Exception {

		File in = new File("/storage/emulated/0/MT2/apks/app.apk");
		File out = new File(in.getAbsolutePath().replace(".apk", ".mergered.apk"));

        new ApkDexMerger(in)
            .merger(out);

    }
	
}
