package com.mycompany.myapp2;
import android.database.sqlite.*;
import android.content.*;
import android.widget.*;

public class MyDatabaseHelper extends SQLiteOpenHelper
{
	public static final String CREATE_BOOK="create table Book("
	+"id integer primary key autoincrement,"
	+"author text)";
	private Context ct;
	public MyDatabaseHelper(Context context,String name,
	SQLiteDatabase.CursorFactory factory,int version){
		super(context,name,factory,version);
		ct=context;
	}

@Override
public void onCreate(SQLiteDatabase db)
{
 // TODO: Implement this method
 db.execSQL(CREATE_BOOK);
 db.execSQL(CREATE_GATEGORY);
 Toast.makeText(ct,"创建成功",Toast.LENGTH_SHORT).show();
}

@Override
public void onUpgrade(SQLiteDatabase db, int p2, int p3)
{
	// TODO: Implement this method
	db.execSQL("drop table if exists Book");
	db.execSQL("drop table if exists Category");
	onCreate(db);
}
public static final String CREATE_GATEGORY="create table Category("
+"id integer primary key autoincrement,"
+"category_name text,"
+"category_code integer)";


	
	
	
}
