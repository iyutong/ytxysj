package com.mycompany.myapp2;

import android.app.*;
import android.os.*;
import android.view.*;
import android.database.sqlite.*;
import android.content.*;
import android.database.*;
import android.widget.*;

public class MainActivity extends Activity
{
	private EditText et;
	private TextView tv;
	private MyDatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		et=(EditText)findViewById(R.id.mainEditText);
		tv = (TextView)findViewById(R.id.mainTextView);
		dbHelper = new MyDatabaseHelper(this, "BookStore.db", null, 2);
    }
	public void db(View v)
	{

		dbHelper.getWritableDatabase();

	}
	public void tj(View v)
	{

		SQLiteDatabase db=dbHelper.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("author", et.getText().toString());
		db.insert("Book", null, values);
		

	}
	public void cx(View v)
	{


		SQLiteDatabase db=dbHelper.getWritableDatabase();
		Cursor cursor=db.query("Book", null, null, null, null, null, null);
		if (cursor.moveToFirst())
		{
			do{

				String author=cursor.getString(cursor.getColumnIndex("author"));

				tv.setText(author);
			}
			while (cursor.moveToNext());
			
		}

		cursor.close();

	}
	
	public void lb(View v)
	{
		Intent intent = new Intent();
		intent.setClass(MainActivity.this, Lb.class);

		startActivity(intent);
}
}

