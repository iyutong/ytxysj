package com.mycompany.myapp2;

public class bj
{
	private String name;
	public bj(String name){

		this.name=name;

	}

	public String getName(){

		return name;


	}
}
