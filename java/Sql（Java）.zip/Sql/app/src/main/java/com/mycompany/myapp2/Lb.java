package com.mycompany.myapp2;
import android.os.*;
import android.app.*;
import android.widget.*;
import android.view.*;
import java.util.*;
import android.database.sqlite.*;
import android.database.*;

public class Lb extends Activity
{private MyDatabaseHelper dbHelper;
	private List<bj> ml=new ArrayList<>();
	 protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
		dbHelper = new MyDatabaseHelper(this, "BookStore.db", null, 2);
   init();
		ListView lv=(ListView)findViewById(R.id.listListView);
		 

		 ListAdapter adapter = new ArrayAdapter(Lb.this,android.R.layout.simple_list_item_1, ml);
		 
		 lv.setAdapter(adapter);
		 lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){

				 @Override
				 public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				 {
					 // TODO: Implement this method
				 }
				 
	
			 
			 
		 });
		}
	private void init()
	{
		SQLiteDatabase db=dbHelper.getWritableDatabase();//获取数据库实例
		Cursor cursor=db.query("Book",null,null,null,null,null,null);
		if(cursor.moveToFirst())
		{
			do
			{
				//遍历Cursor对象，取出数据
				String 歌曲文件名=cursor.getString(cursor.getColumnIndex("author"));
				bj b=new bj(歌曲文件名);
				ml.add(b);
			}while(cursor.moveToNext());
		}
		cursor.close();
	}
		
		
		
		
		}
		
		
		
		

