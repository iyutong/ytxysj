package com.xiaoheng.gengxin;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.telephony.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import java.util.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		final EditText edit=(EditText)findViewById(R.id.mainEditText1);
		
		TelephonyManager telephonyManager= (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);//获取imei码，需要写权限
		final String imei=telephonyManager.getDeviceId();//变量给imei
		
		final Button button=(Button)findViewById(R.id.mainButton);
		final TextView textview=(TextView)findViewById(R.id.mainTextView);
		final TextView textview1=(TextView)findViewById(R.id.mainTextView1);
		
		edit.setText("你的IMEI码:"+imei);
		
		Bmob.initialize(this,"43c64da08521eb85c5d655c1d9b21328");//这里写你的Application ID
		//后台是：IMEI注册机
		
		button.setOnClickListener(new OnClickListener()//检测按钮，开始
		{
				@Override
				public void onClick(View p1)
				{
					//按钮的点击事件
					
					
					/**********************获取全部行的数据进行判断*******************/
					/************************小亨个人建议使用这种********************/
					
					BmobQuery<xiaohengimeizhucheji>xiaoheng666=new BmobQuery<xiaohengimeizhucheji>();
					xiaoheng666.findObjects(MainActivity.this, new FindListener<xiaohengimeizhucheji>(){

							@Override
							public void onSuccess(List<xiaohengimeizhucheji> p1)
							{
								//正常
								
								String quanbushuju="";
								for (xiaohengimeizhucheji xxhh:p1)
								{
									quanbushuju += xxhh.getxh()+"\n";//将每条数据换行
									textview.setText(quanbushuju);
								}
								
								
								if(quanbushuju.contains(imei))//判断每一行数据是否包含你手机的imei码
								{
									textview1.setText("已注册✔");
									startActivity(new Intent(MainActivity.this,zhuchechenggongactivity.class));
									textview1.setTextColor(Color.GREEN);
									//MainActivity.this.finish();//结束界面
								}
								else
								{
									textview1.setText("未注册✘");
									textview1.setTextColor(Color.RED);//设置字体颜色为红色
								}
								
								
							}

							@Override
							public void onError(int p1, String p2)
							{
								//异常
								//无网络或其他情况执行这里
								Toast.makeText(MainActivity.this,"获取数据失败\n请检查设备是否联网",Toast.LENGTH_LONG).show();
							}
						});
						
						
						
						
		/*
					/******************获取指定行进行数据判断*****************
					/******************小亨个人不建议采用*****************
					BmobQuery<xiaohengimeizhucheji>xiaoheng666=new BmobQuery<xiaohengimeizhucheji>();
					
					//xiaoheng666.setLimit(3);//指定获取第几行数据，我这里是3所以获取第三行数据
					
					xiaoheng666.findObjects(getApplication(), new FindListener<xiaohengimeizhucheji>()
						{
							//按钮的点击事件
							@Override
							public void onSuccess(List<xiaohengimeizhucheji> p1)
							{
								//正常
								for(xiaohengimeizhucheji xiaoheng:p1)
								{
									//xiaoheng是获取到的内容
									String Bmobimei=xiaoheng.getxh();
									textview.setText(Bmobimei);
								}
								
								if(textview.getText().toString().contains(imei))//获取文本内容判断是否包含你手机的imei码
								{
									textview1.setText("已注册");
									startActivity(new Intent(MainActivity.this,zhuchechenggongactivity.class));
									MainActivity.this.finish();//结束界面
								}
								else
								{
									textview1.setText("未注册");
									textview1.setTextColor(Color.RED);//设置字体颜色为红色
								}
								
							}
							@Override
							public void onError(int p1, String p2)
							{
								//异常
								//无网络或其他情况执行这里
								Toast.makeText(MainActivity.this,"获取数据失败\n请检查设备是否联网",Toast.LENGTH_LONG).show();
							}
						});//获取数据结束
		*/
					
				}});//检测按钮，结束
				
				
		Button fuzibutton=(Button)findViewById(R.id.mainButton1);
		fuzibutton.setOnClickListener(new OnClickListener()//复制按钮，开始
		{
				@Override
				public void onClick(View p1)
				{
					//复制按钮的点击事件
					
					AlertDialog.Builder a=new AlertDialog.Builder(MainActivity.this);
					//a.setIcon(R.drawable.ic_launcher);//图标
					a.setCancelable(false);//点击界面其他它地方弹窗不会消失，按返回键也没吊用
					a.setTitle("提示");//标题
					a.setMessage("亲，您的IMEI为:"+imei+"\n快去联系作者注册吧！");//弹窗内容
					a.setPositiveButton("找小亨注册去", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								//弹窗第一个按钮的点击事件
								
								try//异常处理
								{
									//正常运行这里
									ClipboardManager manager=(ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
									manager.setText(imei);//要复制的内容
									Toast.makeText(MainActivity.this,"复制成功",Toast.LENGTH_SHORT).show();
									startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=1919196455")));//转跳到小亨QQ（临时聊天）
								}
								catch(Exception heng1)
								{
									//异常运行这里
									Toast.makeText(MainActivity.this,"转跳失败，QQ异常",Toast.LENGTH_LONG).show();
								}
								
							}
						});

					a.setNegativeButton("复制",new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								//弹窗第二个按钮的点击事件
								
								ClipboardManager manager=(ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
								manager.setText(imei);//要复制的内容
								Toast.makeText(MainActivity.this,"复制成功",Toast.LENGTH_SHORT).show();
								
							}
						});

					a.setNeutralButton("取消", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								//弹窗第三个按钮的点击事件
							}
						});
					a.show();
					
				}
			});//复制按钮，结束
				
    }
}



/****************************************
 *         2017.8.19                    *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
