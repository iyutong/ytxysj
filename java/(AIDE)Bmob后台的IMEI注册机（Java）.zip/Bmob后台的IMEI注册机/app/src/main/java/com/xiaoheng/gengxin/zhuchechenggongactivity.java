package com.xiaoheng.gengxin;

import android.app.*;
import android.os.*;

public class zhuchechenggongactivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zhuchechenggongmain);
	}
	
}
