package com.xiaoheng.gengxin;
import cn.bmob.v3.*;

class xiaohengimeizhucheji extends BmobObject
{
	private String IMEI;//后台截取IMEI(更新字符)
	
	public String getxh(){return IMEI;}
	public void setxh(String imei)
	{
		this.IMEI=imei;
		}
	
}
