# CheckFourMark
java生成炫酷验证码，不区分大小写。登陆，发送手机验证码，防止注册机，android开发。

具体描述以及效果图请看：http://blog.csdn.net/qq_21376985/article/details/52101552 

作者：程序员小冰，CSDN博客：http://blog.csdn.net/qq_21376985 

QQ986945193 微博：http://weibo.com/mcxiaobing 



![效果图请看：](http://img.blog.csdn.net/20160809162959877)


其实以前我给大家提供过生成随机四位数字的验证码。由于当时区分了大小写。

所以，这次不区分大小写进行验证。而且ui方面也比以前的二维码好看。当然，区不区分大小写处理的话很简单。

文章后面会给大家链接。

首先给大家放源代码的下载链接吧。只有两个类，很简单。

我相信你能用得上。传送门：http://download.csdn.net/detail/qq_21376985/9593482 

git开源中国下载地址：http://git.oschina.net/MCXIAOBING/CheckFourMark

java生成四位随机数，包含数字和字母 区分大小写传送门： 

http://blog.csdn.net/qq_21376985/article/details/51207422 

android开发之java代码中字符串对比忽略大小写。

可用来比对验证码等问题传送门： 

http://blog.csdn.net/qq_21376985/article/details/51532142
