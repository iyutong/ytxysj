package chineseframe;
import java.util.LinkedList;
import java.util.stream.Stream;

public class 列表<T> extends LinkedList<T>
{

	public T 获取(int id){
		return get(id);
	}
	public void 添加(T obj){
		add(obj);
	}
	public int 数量(){
		return size();
	}
	public void 清除数据(){
		clear();
	}
	public boolean 是否为空(){
		return isEmpty();
	}
	
}