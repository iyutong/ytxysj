package $package_name$;

import android.view.*;
import chineseframe.*;

public class MainActivity extends 活动
{

	@Override
	public void 子线程()
	{
		// 实现这个方法
	}


	@Override
	public void 主线程()
	{
		//提示("测试",1000);//显示1000毫秒
// 应用工具类
//使用事例
		提示(应用工具.获取应用名称(MainActivity.this,"com.mycompany.myapp"),1000);
		/*
 获取应用名称
 获取应用图标
 获取应用第一次安装日期
 获取应用更新日期
 获取应用大小
 获取应用apk文件
 获取应用版本名称
 获取应用版本号
 获取应用的安装市场
 获取应用签名
 获取应用兼容sdk
 获取应用uid
 获取Cpu内核数
 获得root权限
 获取应用的所有权限
 是否有权限
 应用是否安装
 安装应用
 卸载应用
 是否是系统应用
 服务是否在运行
 停止服务
 结束进程
 运行脚本
 启动应用
 清除应用内部缓存
 清除应用内部数据库
 清除应用内部SP
 */
 
//密码工具类
/*
  字符串md5
 字符串md5小写
 输入流md5
 Base64加密
 Base64解密
 异或加密
 异或解密
 字符串sha1值
 文件hash校验
*/

//日期工具类
/*
 格式化日期时间
 格式化日期
 格式化时间
 自定义格式的格式化日期时间
 将时间字符串转换成Date
 获取系统日期
 获取系统时间
 获取系统日期时间
 计算两个时间差
 得到几天后的时间
 获取当前时间为本月的第几周
 获取当前时间为本周的第几天
 */
//屏幕工具类
/*
 dp转像素
 dip转sp
 像素转dp
 像素转sp
 sp转像素
 sp转dip
 获取屏幕宽度
 获取屏幕高度
 获取屏幕的真实高度
 获取状态栏高度
 获取导航栏高度


*/
//设备信息工具
/*
 获取AndroidID
 获取设备IMEI码
 获取设备IMSI码
 获取MAC地址
 获取网络IP地址//(优先获取wifi地址)
 获取WIFI连接下的ip地址
 获取GPRS连接下的ip地址
 获取设备序列号
 获取SIM序列号
 获取网络运营商代号 //46000,46002,46007 为中国移动,46001 中国联通,46003 中国电信
 获取网络运营商//中国电信,中国移动,中国联通
 获取硬件型号
 获取编译厂商
 获取编译服务器主机
 获取描述Build的标签
 获取系统编译时间
 获取系统编译作者
 获取编译系统版本
 获取开发代号
 获取源码控制版本号
 获取编译的SDK
 获取修订版本列表
 获取CPU指令集
 获取硬件制造厂商
 获取系统启动程序版本号
获取屏幕DisplayID
 获取系统版本号
 获取语言
 获取国家
 获取系统版本:5.1.1
 获取GSF序列号
 获取蓝牙地址
 获取Android设备物理唯一标识符
 获取构建标识//包括brand,name,device,version.release,id,version.incremental,type,tags这些信息
 获取硬件信息
 获取产品信息
 获取设备信息
 获取主板信息
 获取基带版本//(无线电固件版本 Api14以上)
 获取浏览器ua
 获取得屏幕密度
 获取google账号

*/

//文件工具类
/*
 关闭IO流
 文件是否存在
 将字符串写入到文件
 从文件中读取字符串
 从文件中读取字符串//(可设置编码)
 复制文件
 快速复制
 分享文件
 zip压缩
 zip解压
 格式化文件大小
 将输入流写入到文件
 创建文件夹//(支持覆盖已存在的同名文件夹)
 获取文件名
 获取文件大小
 重名名
 获取文件夹名称
 获取文件夹下所有文件
 删除文件
 打开图片
 打开视频
 打开链接
 下载文件
 是否挂载SDCard
 获取应用在SDCard上的工作路径
 获取SDCard上目录的路径
*/
//网络工具
/*
 获取网络类型
 获取网络名称
 检查网络状态
 网络可用性
 是否wifi
 打开网络设置界面
 设置wifi状态
 设置数据流量状态
 获取wifi列表
 过滤扫描结果
 获取wifi连接信息
 
 */
//进制工具类 
/*
十六转二
二转十六

*/
//储存工具
/*
 存储SharedPreferences值
 获取SharedPreferences值
 清除所有的SP值
*/

// 字符工具
/*
 汉字转成ASCII码
 单字解析
 词组解析
替换null
 是否是空字符串
 中文长度
 字符串长度
 获取指定长度的字符所在位置
 是否是中文
 是否包含中文
 不足2位前面补0
 类型安全转换
 指定小数输出
*/

//系统工具类
/*
 调用系统发送短信
 跳转到拨号
 发邮件
 打开浏览器
 打开联系人
 打开系统设置
 * com.android.settings.AccessibilitySettings 辅助功能设置
 * com.android.settings.ActivityPicker 选择活动
 * com.android.settings.ApnSettings APN设置
 * com.android.settings.ApplicationSettings 应用程序设置
 * com.android.settings.BandMode 设置GSM/UMTS波段
 * com.android.settings.BatteryInfo 电池信息
 * com.android.settings.DateTimeSettings 日期和时间设置
 * com.android.settings.DateTimeSettingsSetupWizard 日期和时间设置
 * com.android.settings.DevelopmentSettings 应用程序设置=》开发设置
 * com.android.settings.DeviceAdminSettings 设备管理器
 * com.android.settings.DeviceInfoSettings 关于手机
 * com.android.settings.Display 显示——设置显示字体大小及预览
 * com.android.settings.DisplaySettings 显示设置
 * com.android.settings.DockSettings 底座设置
 * com.android.settings.IccLockSettings SIM卡锁定设置
 * com.android.settings.InstalledAppDetails 语言和键盘设置
 * com.android.settings.LanguageSettings 语言和键盘设置
 * com.android.settings.LocalePicker 选择手机语言
 * com.android.settings.LocalePickerInSetupWizard 选择手机语言
 * com.android.settings.ManageApplications 已下载（安装）软件列表
 * com.android.settings.MasterClear 恢复出厂设置
 * com.android.settings.MediaFormat 格式化手机闪存
 * com.android.settings.PhysicalKeyboardSettings 设置键盘
 * com.android.settings.PrivacySettings 隐私设置
 * com.android.settings.ProxySelector 代理设置
 * com.android.settings.RadioInfo 手机信息
 * com.android.settings.RunningServices 正在运行的程序（服务）
 * com.android.settings.SecuritySettings 位置和安全设置
 * com.android.settings.Settings 系统设置
 * com.android.settings.SettingsSafetyLegalActivity 安全信息
 * com.android.settings.SoundSettings 声音设置
 * com.android.settings.TestingSettings 测试——显示手机信息、电池信息、使用情况统计、Wifi
 * information、服务信息 com.android.settings.TetherSettings 绑定与便携式热点
 * com.android.settings.TextToSpeechSettings 文字转语音设置
 * com.android.settings.UsageStats 使用情况统计
 * com.android.settings.UserDictionarySettings 用户词典
 * com.android.settings.VoiceInputOutputSettings 语音输入与输出设置
 * com.android.settings.WirelessSettings 无线和网络设置
 *
 隐藏系统键盘
 判断当前应用程序是否后台运行
 判断手机是否处理睡眠
 安装apk
 是否root
 当前设备是否是模拟器
 返回Home
 三十二位签名
 获取设备可用空间
 清理后台进程和服务
 获取进程名字
 创建桌面快捷方式
 创建快捷方式
 分享文本
 分享文件//(此方法是调用FileUtils.shareFile中的方式)
 获取可接受分享的应用
 获取当前系统的语言 
 获取当前系统的语言
 GPS是否打开
 显示软键盘
 关闭软键盘
 显示软键盘
 关闭软键盘
 打开微信扫描
 打开支付宝扫描
 打开支付宝支付码
 获取随机数
*/

//验证工具类
/*
 判断姓名格式
//真实姓名可以是汉字,也可以是字母,但是不能两者都有,也不能包含任何符号和数字，如果是英文名,可以允许英文名字中出现空格，英文名的空格可以是多个,但是不能连续出现多个，汉字不能出现空格
 判断手机号格式// (匹配11数字,并且13-19开头)
 判断账号格式// (4-20位字符)
 判断密码格式// (6-12位字母或数字)
 判断字母密码格式// (6-12位字母或数字,必须同时包含字母和数字)
 判断邮箱格式
 判断IP地址
 判断链接// (http,https,ftp)
 判断中国民用车辆号牌
 判断身份证号码格式
 是否数值型
 是否匹配正则
 匹配中国邮政编码
 */
//这个库参考了众多网络中的代码,在此对这些无私奉献的人致以最诚挚的感谢。
		}

	@Override
	public void Ui线程()
	{
		加载布局(R.layout.main);
		// 实现这个方法
	}

	@Override
	public void 副线程()
	{
		//实现这个方法
	}

	

	
	
	
}