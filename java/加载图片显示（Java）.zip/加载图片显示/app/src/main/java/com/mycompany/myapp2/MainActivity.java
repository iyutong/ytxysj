package com.mycompany.myapp2;

import android.app.*;
import android.os.*;
import android.view.*;

import android.app.*;
import android.os.*;
import com.ant.liao.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity implements OnClickListener
{

	@Override
	public void onClick(View p1)
	{

		if(flag){
			//显示第一次见到的gif
			gv.showCover();
			flag=false;
		}else{
			//显示gif
			gv.showAnimation();
			flag=true;
		}

	}

	GifView gv;
	boolean flag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		gv=(GifView) findViewById(R.id.mainGifView1);
		gv.setGifImage(R.drawable.gf_01);
		gv.setOnClickListener(this);
    }
}
