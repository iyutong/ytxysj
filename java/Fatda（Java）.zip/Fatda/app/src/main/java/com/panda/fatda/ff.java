package com.panda.fatda;

import android.widget.Toast;
import android.content.Context;
import android.util.Log;
import android.icu.text.SimpleDateFormat;
import java.sql.Date;
import android.widget.TextView;
import android.text.Html;
import java.util.Calendar;
import java.io.File;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;

public class ff {
    
	Context mcontext;
	StringBuilder sb1 =new StringBuilder();
	
	public ff(Context context){
		this.mcontext=context;
	}
	
	public void Contopr(String text){
		Contopr(text,0);
	}

	public void Contopr(String text,int show){
		int int1 = 0;
		if(show==0){int1 =Toast.LENGTH_SHORT;}
		if (show == 1) {int1=Toast.LENGTH_LONG;}
		Toast.makeText(mcontext, text, int1).show();
	}
	
	public String sj(){
		Calendar Cld = Calendar.getInstance();
        int YY = Cld.get(Calendar.YEAR) ;
        int MM = Cld.get(Calendar.MONTH)+1;
        int DD = Cld.get(Calendar.DATE);
        int HH = Cld.get(Calendar.HOUR_OF_DAY);
        int mm = Cld.get(Calendar.MINUTE);
        int SS = Cld.get(Calendar.SECOND);
        int MI = Cld.get(Calendar.MILLISECOND);   
		return YY + "-" + MM + "-" + DD + " " + HH + ":" + mm + ":" + SS + ":" + MI + " ";
	}
	
	public void log(String str1){
		log(str1.toString(),"black");
		//((TextView)((MainActivity)mcontext).findViewById(R.id.output)).setText(sb1.append(sj()+": "+str1+"\n").toString());
	}
	
	public void log(String str1,String str2){
		((TextView)((MainActivity)mcontext).findViewById(R.id.output)).setText(Html.fromHtml( sb1.append("<font color='"+str2+"'>").append(sj()+": "+str1).append("</font><br/>").toString()));
	}
	
	
	public String ReadFile(String Path){
		File file = new File(Path);
		if(file.exists()){
			StringBuffer strbuff = new StringBuffer();
			try {
				InputStream instream = new FileInputStream(file); 
				InputStreamReader inputreader = new InputStreamReader(instream);
				BufferedReader buffreader = new BufferedReader(inputreader);

				String line;
				int i=0;
				while (( line = buffreader.readLine()) != null) {
					i=i++;
					strbuff.append(line);
					strbuff.append("\n");
				}                
				try {
					instream.close();
				} catch (IOException e) {
					
				}
			}
			catch (IOException e) 
			{
				
			}
			log(strbuff.toString());
			return strbuff.toString();
		}
		else{
			return "warning:file not exists!";
		}
    }
	
	
	
	//创建文件夹
	public void CreateFile(String files){
		File file = new File(files);
		if (!file.exists()) {
			try {
				file.mkdirs();
				log("The file was created successfully!","black");
			} catch (Exception e) {
				log(e.toString(),"red");
			}
		}
		else{
			log("Error: The file already exists !","red");//文件已存在
		}
	}
	
	/*
	public void ff(String str1){
		Log.d("hshs","t");
		tw(str1);
	}*/
	
	
    
    
}
