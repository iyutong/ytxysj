package com.panda.fatda;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.panda.fatda.MainActivity;
//import com.panda.fatda.SystemTools.FLog;
import java.lang.reflect.Method;
import java.util.List;
import java.util.ArrayList;
import com.panda.fatda.ff;

public class MainActivity extends Activity { 
     
private final String TAG = "MYAPP";

private ff mff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		mff =new ff(this);
        ((Button)findViewById(R.id.code_run)).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					String[] str1 =((EditText)findViewById(R.id.textEditor)).getText().toString().split("\n");
					for (int i = 0; i < str1.length; i++) {
						String str2 = str1[i];
						if(!k(str2)||str2.startsWith("//")){
							run(str2);
						}
					}
					
				}
			});
    }
	
	Object run(String name){
		try{
		name = name.trim();
		String name1 = name.substring(0,name.indexOf("("));
		
		String name2_0 =j(name,"(",")");
		
		String[] name2_1 = name2_0.split(",");
		//ArrayList<Class> list1 = new ArrayList<Class>();
		Class[] list1 =new Class[name2_1.length];
		//ArrayList<String> list2 = new ArrayList<String>();
		Object[] list2=new Object[name2_1.length];
		
		for (int i = 0; i < name2_1.length; i++) {
			String name2_2 = name2_1[i];
			if(!k(name2_2)&&name2_2.contains("\""))
				name2_2=j(name2_2,"\"","\"");
			//list1.add(String.class);
			list1[i]=String.class;
			list2[i]=name2_2;
		}
			Method md1 = ff.class.getMethod(name1,list1);
			return md1.invoke(mff,list2);
		}catch(Exception e){
			mff.log(e.toString(),"red");
		}
		return null;
	}
	
	boolean k(Object obj1){
		return obj1==null || "".equals(obj1);
	}
	
  String j(String str1,String str2,String str3){

		if(k(str1)){
			return "";
		}

		int int1 = str1.indexOf(str2);
		int int2 = str1.indexOf(str3);

		if(int1<0 || int2<0){
			return "";
		}

		int int3 =str1.indexOf(str3,int1+str2.length());
		return str1.substring(int1+str2.length(),int3);
	}
	
} 
