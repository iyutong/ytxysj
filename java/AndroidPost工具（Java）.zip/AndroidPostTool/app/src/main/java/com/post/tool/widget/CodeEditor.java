package com.post.tool.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.WindowManager;
import android.graphics.Typeface;


public class CodeEditor extends NativeEditor {
    private Context context;
    private Paint textPaint = new Paint();
	private int rectStartX,rectStartY;	//绘制当前行的背景色的开始X Y坐标
	private int rectEndX,rectEndY;	  	//绘制当前行的背景色的结束X Y坐标
	private float textX,textY;
	private Paint.FontMetrics metrics;

	private int MARGIN_LEFT;
	private Paint rectPaint;

	private int screenWidth;

	private int screenHeight;

	public CodeEditor(Context context) {
        super(context);
        this.context = context;
        init(context);
    }
    public CodeEditor(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init(context);
    }
	public float dip2px(Context context, float dpValue)
	{
		float scale =context.getResources().getDisplayMetrics().density;
		return dpValue * scale + 0.5f;
	}

	public float px2dip(Context context, float pxValue)
	{
		float scale = context.getResources().getDisplayMetrics().density;
		return pxValue / scale + 0.5f;
	}
    public void init(Context context)
	{
		MARGIN_LEFT = (int) dip2px(context,32);
		setGravity(Gravity.TOP);
		setPadding((int)dip2px(context,32), 0, 0, 0);
		textPaint = new Paint();
		textPaint.setAntiAlias(true);
		textPaint.setTextSize(dip2px(context,14));
		rectPaint = new Paint();
		rectPaint.setColor(0x80ccddff);
		textPaint.setColor(0xff888888);
		textPaint.setTypeface(Typeface.DEFAULT);
		setHorizontallyScrolling(true);
		WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		screenWidth = windowManager.getDefaultDisplay().getWidth();
		screenHeight = windowManager.getDefaultDisplay().getHeight();

		metrics = textPaint.getFontMetrics();
		rectStartX = MARGIN_LEFT;
		textY = metrics.descent - metrics.ascent + metrics.leading;
	}

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();
		drawText(canvas);
		canvas.restore();
        super.onDraw(canvas);

    }

//绘制文本行
	public void drawText(Canvas canvas)
	{
		if (!hasSelection())
		{
			rectEndX = getLayout().getWidth();
			rectStartY = getRowHeight() * (getCurrRow() - 1) + getRowHeight() / 8;
			rectEndY = getRowHeight() * getCurrRow() + getRowHeight() / 8;
			canvas.drawRect(rectStartX, rectStartY, rectEndX, rectEndY, rectPaint);
		}

		if (getText().toString().length() != 0)
		{
			for (int i=0;i < getLineCount();i++)
			{
				textY = (i + 1) * getLineHeight(); 
				canvas.drawText(String.valueOf(i + 1), textX, textY,textPaint);
			}
		}
		else
		{
			canvas.drawText(String.valueOf(1), textX, textY,textPaint);
		}
	}



	/* 获得行 行高 当前行 */
	public int getRowHeight()
	{

		return getLineHeight();
	}

	public int getTotalRows()
	{
		return getLineCount();
	}

	public int getCurrRow()
	{
		return getLayout().getLineForOffset(getSelectionStart()) + 1;
	}


	public interface OnTextChangedListener
	{
		public void onTextChanged(String text);
	}
}
