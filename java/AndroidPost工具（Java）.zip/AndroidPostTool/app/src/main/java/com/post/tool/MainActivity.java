package com.post.tool;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import com.post.tool.widget.CodeEditor;

public class MainActivity extends Activity 
{
	private EditText url;
	private Button getpost;
	private Button exchange;
	private Button visit;
	private Button match;
	private Button check;
	private Button data;
	private Button make;
	private CodeEditor html;
	private WebView web;
	private ProgressBar pb;
	String 验证码网址="";//验证码网址
	String resultCode;
	String source;//网页源码
	private ProgressDialog pd;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initView();
		//html.setHighLight(false);
		pd = new ProgressDialog(this);
		pd.setMessage("正在取源...");
		pd.setCancelable(false);
		
		//访问
		visit.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					web.loadUrl(url.getText().toString());
				}
			});
		//切换
		exchange.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					if(web.getVisibility()==View.GONE){
						web.setVisibility(View.VISIBLE);
						html.setVisibility(View.GONE);
					}else{
						web.setVisibility(View.GONE);
						html.setVisibility(View.VISIBLE);
					}
				}
			});
		//取源
		getpost.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					html.setHighLightType("Html");
					pd.show();
					String address = url.getText().toString();
					if(!address.isEmpty() && address.startsWith("http")){
						new Thread(new Runnable(){
								@Override
								public void run() {
									getSource(url.getText().toString());
								}
							}).start();
					}else toast("您未输入网址或输入的网址不全，请以http://开头或以https://开头");
				}
			});
		//截取
		match.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					if(!html.getText().toString().isEmpty()){
						if(html.getText().toString().contains("<form")){
							String str = match(html.getText().toString(),"<form","</form>");
							html.setText("<form"+str+"</form>");
							toast("截取成功");
						}else toast("截取失败");
					}else toast("您还未提取");
				}
			});
		//验证码
		check.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
					adb.setTitle("设置验证码");
					adb.setMessage("请手动输入验证码地址");
					final EditText et = new EditText(MainActivity.this);
					et.setText(验证码网址);
					adb.setView(et);
					adb.setPositiveButton("确定", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2) {
								验证码网址 = et.getText().toString();
							}
						});
					adb.setNegativeButton("取消",null);
					adb.setCancelable(false);
					adb.show();
				}
			});
		//取数据
		data.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					String 关键代码="";
					String Post = "无Post数据";
					String 表单 = html.getText().toString();
					String 网址 = url.getText().toString();
					String 临时文本;
					if(表单.startsWith("<form")){
						try{
							表单 = match(表单,"<input","</form>");
							关键代码 = 表单.replace("'","\"");
							关键代码 = 关键代码.replace(" ","");
							String[] 数组 = 关键代码.split("name=");
							int 数组长度 = 数组.length;
							for(int 计数 = 1;计数 < 数组长度;计数++) {
								String 返回 = 数组[计数];
								String name = match(返回, "\"", "\"");
								String value = match(返回, "value=\"", "\"");
								Post = Post + "&" + name + "=" + value;
							}
							Post = Post.replace("无Post数据&","");
							临时文本 = "【提交网址】" + 网址 + "【提交网址】\n【提交数据】" + Post + "【提交数据】";
							if(表单.contains("<img")){
								验证码网址 = match(表单,"src=\"","\"");
								if(!验证码网址.contains("http")){
									if(网址.startsWith("http://")){
										验证码网址 = "http://"+match(表单,"src=\"","\"");
									}
									if(网址.startsWith("https://")){
										验证码网址 = "https://"+match(表单,"src=\"","\"");
									}
								}
							}
							if(验证码网址.startsWith("http")||验证码网址.startsWith("https")){
								临时文本 = "【验证码网址】" + 验证码网址 + "【验证码网址】\n【提交网址】" + 网址 + "【提交网址】\n【提交数据】" + Post + "【提交数据】";
								}
							html.setText(临时文本);
							toast("已写入文本框\n自己查看是否需要修改提交内容");
						}catch(Exception e){
							toast("程序发生异常"+"\n"+e.toString());
						}
					}
					else toast("您还未截取");
				}
			});
		//生成
		make.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
					final String 内容 = html.getText().toString();
					final String 代码 = "";
					if(内容.contains("【提交网址】") && 内容.contains("【提交数据】")){
						new AlertDialog.Builder(MainActivity.this)
						.setTitle("请选择生成类型")
							.setItems(new String[]{"Java","AndroLua","iApp"}, new DialogInterface.OnClickListener(){
								@Override
								public void onClick(DialogInterface p1, int p2){
									toast(p2+"");
									html.setHighLight(true);
									switch(p2){
										case 0:
											if(验证码网址.startsWith("http")){
												String 代码 = readAssets("JavaPost2");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												代码 = 代码.replace("验证码网址",验证码网址);
												html.setHighLightType("Java");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											if(验证码网址.isEmpty()){
												String 代码 = readAssets("JavaPost1");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												html.setHighLightType("Java");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											break;
										case 1:
											if(验证码网址.startsWith("http")){
												String 代码 = readAssets("LuaPost2");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												代码 = 代码.replace("验证码网址",验证码网址);
												html.setHighLightType("Lua");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											if(验证码网址.isEmpty()){
												String 代码 = readAssets("LuaPost1");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												html.setHighLightType("Lua");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											break;
										case 2:
											if(验证码网址.startsWith("http")){
												String 代码 = readAssets("iAppPost2");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												代码 = 代码.replace("验证码网址",验证码网址);
												html.setHighLightType("iApp");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											if(验证码网址.isEmpty()){
												String 代码 = readAssets("iAppPost1");
												代码 = 代码.replace("提交网址",match(内容,"【提交网址】","【提交网址】"));
												代码 = 代码.replace("提交参数",match(内容,"【提交数据】","【提交数据】"));
												html.setHighLightType("iApp");
												html.setText(代码);
												toast("代码已生成，请自己修正！");
											}
											break;
									}
								}
							}).show();
					}else toast("您还未取数据");
				}
			});
	}
	private void initView(){
		url = (EditText) findViewById(R.id.url);
		visit = (Button) findViewById(R.id.visit);
		exchange = (Button) findViewById(R.id.exchange);
		getpost = (Button) findViewById(R.id.getpost);
		match = (Button) findViewById(R.id.match);
		check = (Button) findViewById(R.id.check);
		data = (Button) findViewById(R.id.data);
		make = (Button) findViewById(R.id.make);
		html = (CodeEditor) findViewById(R.id.html);
		pb = (ProgressBar) findViewById(R.id.pb);
		web = (WebView) findViewById(R.id.web);
		pb.getProgressDrawable().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
		WebSettings webSettings = web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setUseWideViewPort(true); 
        webSettings.setAllowFileAccess(true); 
        webSettings.setPluginState(WebSettings.PluginState.ON);
        webSettings.setSupportZoom(true); 
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); 
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
		web.setWebViewClient(new WebViewClient(){
			@Override
			public boolean shouldOverrideUrlLoading(WebView v,String url){
				return super.shouldOverrideUrlLoading(v,url);
			}
			public void onPageStarted(WebView view, String uuu, Bitmap favicon){
				url.setText(uuu);
			}
			public void onReceivedSslError(WebView v,SslErrorHandler handler,SslError error){
				handler.proceed();
			}
		});
		web.setWebChromeClient(new WebChromeClient(){
			@Override
			public void onProgressChanged(WebView view,int p){
				if(p==100){
					pb.setVisibility(View.GONE);
				}else{
					pb.setVisibility(View.VISIBLE);
					pb.setProgress(p);
				}
			}
		});
	}
	
	private void getSource(String url){
		if(url.startsWith("http://")){
			try{
				StringBuffer sb=new StringBuffer();
				String line="";
				BufferedReader br=new BufferedReader(new InputStreamReader(new URL(url).openStream()));
				while((line=br.readLine())!=null){sb.append("\n"+line);}
				source = sb.toString();
				resultCode = "succeed";
			}catch (IOException e){
				resultCode = "failed";
			}
		}
		if(url.startsWith("https://")){
			HttpsURLConnection httpsURLConnection = null;
			BufferedReader reader = null;
			try {
				URL ur = new URL(url);
				httpsURLConnection = (HttpsURLConnection) ur.openConnection();
				httpsURLConnection.setConnectTimeout(6500);
				httpsURLConnection.setDoInput(true);
				httpsURLConnection.setUseCaches(false);
				httpsURLConnection.connect();
				reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
				StringBuilder sBuilder = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					sBuilder.append("\n"+line);
				}
				source = sBuilder.toString();
				resultCode = "succeed";
			} catch (Exception e) {
				resultCode = "failed";
			}
		}
		hand.sendMessage(hand.obtainMessage());
	}
	
	//用于处理UI事件
	Handler hand = new Handler(){
		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			switch(resultCode){
				case "succeed":
					web.setVisibility(View.GONE);
					html.setVisibility(View.VISIBLE);
					html.setText(source);
					pd.hide();
					break;
				case "failed":
					pd.hide();
					toast("取源失败");
					break;
			}
		}
	};
	private void toast(String msg){
		Toast.makeText(this,msg,3000).show();
	}
	public String match(String str,String start,String end){
		if(str.contains(start) && str.contains(end)){
			str = str.substring(str.indexOf(start)+start.length());
			return str.substring(0, str.indexOf(end));
		}
		return "";
	}
	
	public String readAssets(String fileName) {
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer, "utf-8");
			return text;
        }
		catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
	
	@Override
	public void onBackPressed() {
		if(web.canGoBack()){
			web.goBack();
		}else{
			finish();
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add("帮助").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return true;
	}
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		if(item.getTitle().toString().equals("帮助")){
			String msg = "\n①在编辑框输入网址，然后点击访问\n"+
			"②在要提取参数的网页点击取源，即可\n"+
			"③取源成功后，点击截取，即可取出网页中的表单\n"+
			"④截取成功后，点击取数据，即可取出参数\n"+
			"⑤取数据成功后，点击生成，选择相应类型，即可生成，生成后请根据实际进行修改！\n\n"+
			"取数据可能会出现验证码地址出错的问题，请点击验证码按钮，输入自定义的验证码地址即可！";
			new AlertDialog.Builder(this).setTitle("使用帮助")
			.setMessage(msg)
			.setPositiveButton("确定",null)
			.show();
		}
		return true;
	}
	
	
}
