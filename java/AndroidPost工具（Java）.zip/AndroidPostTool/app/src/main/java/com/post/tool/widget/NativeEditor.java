package com.post.tool.widget;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spannable;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.ReplacementSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NativeEditor extends EditText{
	
  //  private static final Pattern PATTERN_NUMBERS = Pattern.compile("\\b(\\d*[.]?\\d+|null|true|false)\\b");
	private static final Pattern OPERATORS = Pattern.compile("[\\p{P}+~$`^=]");
	private static final Pattern STRINGS = Pattern.compile("[^\\s]+(?==)");
	//以下是不同语言的不同高亮词
	/*
	*Lua
	*/
    private static final Pattern Lua_KEYWORDS = Pattern.compile(
            "\\b(" +
			"and|break|do|else|elseif|end|false|for|function|goto|if|" +
                    "in|local|nil|not|or|repeat|return|then|true|until|while" +
                    ")\\b");

    private static final Pattern Lua_BUILTINS = Pattern.compile(
            "\\b(pcall|print|rawequal|rawget|rawlen|rawset|require|select|self|" +
                    "getmetatable|ipairs|load|loadfile|loadstring|module|next|pairs|" +
                    "setmetatable|tointeger|tonumber|tostring|type|unpack|xpcall|" +
                    "TextView|assert|collectgarbage|dofile|error|findtable|" +
                    "coroutine|debug|io|luajava|math|os|package|string|table|utf8|" +
                    "setmetatable|setupvalue|setuservalue|traceback|upvalueid|upvaluejoin|sethook|" +
                    "close|flush|input|lines|open|output|popen|read|stderr|stdin|stdout|tmpfile|type|" +
                    "loaded|luapath|new|newInstance|package|tostring|abs|acos|asin|atan|ceil|cos|" +
                    "pow|rad|random|randomseed|sin|sinh|sqrt|tan|tanh|tointeger|type|ult|task|thread|timer|" +
                    "clock|date|difftime|execute|exit|getenv|remove|rename|setlocale|time|tmpname|" +
                    "byte|char|dump|find|format|gfind|gmatch|gsub|len|lower|match|pack|packsize|rep|" +
                    "activity|call|compile|dump|each|enum|import|loadbitmap|loadlayout|loadmenu|set|" +
                    "setlocal|write)\\b");
    private static final Pattern Lua_COMMENTS = Pattern.compile("--\\[\\[(?:.|[\\n\\r])*?\\]\\]|--.*");
	
	/*
	*Java
	*/
	private static final Pattern Java_KEYWORDS = Pattern.compile("\\b(private|protected|public|abstract|class|"+
	"extends|final|implements|interface|native|new|static|strictfp|synchronized|transient|volatile|break|"+
	"continue|return|do|while|if|else|for|instanceof|switch|case|default|try|catch|throw|throws|import|package|"+
	"super|this|goto|const)\\b");
	
	private static final Pattern Java_BUILTINS = Pattern.compile("\\b(boolean|byte|char|double|float|int|long|short|void|"+
	"String|CharSequence|Override)\\b");
	
	private static final Pattern Java_COMMENTS = Pattern.compile("//(.*)|/\\*(.|[\r\n])*?\\*/");
	
	/*
	*Js
	*/
	private static final Pattern Js_KEYWORDS = Pattern.compile("\\b()\\b");

	private static final Pattern Js_BUILTINS = Pattern.compile("\\b()\\b");

	private static final Pattern Js_COMMENTS = Pattern.compile("");
	
	/*
	*iApp
	*/
	private static final Pattern iApp_KEYWORDS = Pattern.compile("\\b(s|ss|sss|t|java|javax|javanew|javags|javacb|cls|clsm|clssm|loadjar|loadso|uigo|tw|utw|syso|"+
	"ssj|fd|fe|fs|fr|fc|fw|fl|ft|fi|fdir|fuz|fuzs|fj|fo|s2|sn|sr|sj|sl|siof|slof|ssg|slg|strim|slower|supper|stop|sran|"+
	"nsz|sgsz|sssz|sgszl|hs|hd|hw|hws|ug|us|endutw|bfm|bfv|ula|ulsulag|ulas|usms|ucall|time|swh|sutf8to|stobm|uycl|ushsp|uapp|ftz|"+
	"uapplist|uapplistgo|uninapp|huf|nvw|uall|urvw|sbp|bfs|sdeg|tot|tzz|tsf|tfz|tcc|sxb|shb|usjxm|bfvs|bfvss|addv|gvs|aslist|sslist|gslist|"+
	"gslistl|dslistl|gslistisz|gslistis|gslistiof|gslistlof|nuibs|ngde|sit|uit|git|uqr|zdp|zpd|zps|zsp|lan|sjxx|simsi|simei|hdfl|hdfla|"+
	"hdd|hddgl|hddg|hdds|hdduigo|ufnsui|se|usg|uzd|usxq|usxh|usx|ujp|sqlite|sql|sqlsele|dha|dhs|dht|dhr|dhset|dhas|dhast|dh|dhon|dhb|has|"+
	"hsas|uxf|tts|blp|otob|btoo|sot|sota|res|call|json|zj)\\b");

	private static final Pattern iApp_BUILTINS = Pattern.compile("\\b(null|true|false|end|ends|f|else|w|for|endcode|break|fn|endkeyboard)\\b");

	private static final Pattern iApp_COMMENTS = Pattern.compile("//(.*)|/\\.(.|[\r\n])*?\\./");
	

	/*
	 *html
	 */
	private static final Pattern Html_KEYWORDS = Pattern.compile("(<[^>\\s]*|(/|\\?)\\s*>|>)");

	private static final Pattern Html_COMMENTS = Pattern.compile("<!--.*?-->|<!\\[]CDATA\\[.*?\\]\\]>|^.*-->|<!--.*$");
	
	
    private final Handler updateHandler = new Handler();
    private OnTextChangedListener onTextChangedListener;
	private static int Lua = 1;
	private static int Java = 2;
	private static int Js = 3;
	private static int iApp = 4;
	private static int Html = 5;
	private static int types = Html;
    private int updateDelay;
    private boolean dirty = false;
    private boolean modified = true;
	private boolean hl = true;
    private int colorNumber;
    private int colorKeyword;
    private int colorBuiltin;
    private int colorComment;
    private final Runnable updateRunnable =
            new Runnable() {
                @Override
                public void run() {
                    Editable e = getText();

                    if (onTextChangedListener != null)
                        onTextChangedListener.onTextChanged(
                                e.toString());
								if(hl){
                    highlightWithoutChange(e);
					}
                }
            };
    private int tabWidth = 0;
    private Context context;
	public NativeEditor(Context context) {
        super(context);
        init(context);
    }
    public NativeEditor(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private static void clearSpans(Editable e) {
        {
            ForegroundColorSpan spans[] = e.getSpans(
                    0,
                    e.length(),
                    ForegroundColorSpan.class);

            for (int n = spans.length; n-- > 0; )
                e.removeSpan(spans[n]);
        }

        {
            StyleSpan spans[] = e.getSpans(
                    0,
                    e.length(),
                    StyleSpan.class);

            for (int n = spans.length; n-- > 0; )
                e.removeSpan(spans[n]);
        }
    }

    public boolean isModified() {
        return dirty;
    }

    private void init(Context context) {
        this.context = context;
        //setTextColor(0xffffffff);
		//setBackgroundColor(0xff000000);
        this.updateDelay = 10;

        setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(
                            CharSequence source,
                            int start,
                            int end,
                            Spanned dest,
                            int dstart,
                            int dend) {
                        if (modified &&
                                end - start == 1 &&
                                start < source.length() &&
                                dstart < dest.length()) {
                            char c = source.charAt(start);

                            if (c == '\n')
                                return autoIndent(
                                        source,
                                        dest,
                                        dstart,
                                        dend);
                        }

                        return source;
                    }
                }});


            addTextChangedListener(
                    new TextWatcher() {
                        private int start = 0;
                        private int count = 0;

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            this.start = start;
                            this.count = count;
                        }

                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void afterTextChanged(Editable e) {
                            cancelUpdate();
                            convertTabs(e, start, count);

                            if (!modified)
                                return;

                            dirty = true;
                            updateHandler.postDelayed(
                                    updateRunnable,
                                    updateDelay);
                        }
                    });

        setSyntaxColors(context);
    }

    private void setSyntaxColors(Context context) {
        colorNumber = 0xff6ab0e2;
        colorKeyword = 0xfff9a825;
        colorBuiltin = 0xff0a9aff;
        colorComment = 0xffd0d0d0;

    }

    private void cancelUpdate() {
        updateHandler.removeCallbacks(updateRunnable);
    }

    private void highlightWithoutChange(Editable e) {
        modified = false;
        highlight(e);
        modified = true;
    }
	
	public void setHighLight(boolean b){
		if(b){
			hl = true;
		}else{
			hl = false;
		}
	}
	
	public void setHighLightType(String type){
		switch(type){
			case "Lua":
				types = Lua;
				break;
			case "Java":
				types = Java;
				break;
			case "Js":
				types = Js;
				break;
			case "iApp":
				types = iApp;
				break;
			case "Html":
				types = Html;
				break;
		}
	}
	
    private Editable highlight(Editable e) {
        try {
            clearSpans(e);
			if (e.length() == 0)
                return e;
			for (Matcher m = OPERATORS.matcher(e); m.find(); )
                e.setSpan(new ForegroundColorSpan(Color.parseColor("#FF00BEFF")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			//判断高亮类型
			//Lua
			if(types==Lua){
            for (Matcher m = Lua_KEYWORDS.matcher(e); m.find(); ) {
                e.setSpan(new ForegroundColorSpan(colorKeyword), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                e.setSpan(new StyleSpan(Typeface.BOLD), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }

            for (Matcher m = Lua_BUILTINS.matcher(e); m.find(); )
                e.setSpan(new ForegroundColorSpan(colorBuiltin), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//默认高亮
				
            for (Matcher m = Lua_COMMENTS.matcher(e); m.find(); ) {
                e.setSpan(new ForegroundColorSpan(colorComment), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                e.setSpan(new StyleSpan(Typeface.ITALIC), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
			for (Matcher m = Pattern.compile("\\\"(.*?)\\\"|\\\'(.*?)\\\'|\\[\\[(.*?)\\]\\]").matcher(e); m.find(); ) 
					e.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFF00D1")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				
		}
		//Java
			if(types==Java){
				for (Matcher m = Java_KEYWORDS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorKeyword), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.BOLD), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}

				for (Matcher m = Java_BUILTINS.matcher(e); m.find(); )
					e.setSpan(new ForegroundColorSpan(colorBuiltin), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

				for (Matcher m = Java_COMMENTS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorComment), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.ITALIC), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				
				for (Matcher m = Pattern.compile("\\\"(.*?)\\\"|\\\'(.*?)\\\'|\\[\\[(.*?)\\]\\]").matcher(e); m.find(); ) 
					e.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFF00D1")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				
			}
		//Js
			if(types==Js){
				for (Matcher m = Js_KEYWORDS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorKeyword), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.BOLD), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}

				for (Matcher m = Js_BUILTINS.matcher(e); m.find(); )
					e.setSpan(new ForegroundColorSpan(colorBuiltin), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

				for (Matcher m = Js_COMMENTS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorComment), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.ITALIC), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				
				for (Matcher m = Pattern.compile("\\\"(.*?)\\\"|\\\'(.*?)\\\'|\\[\\[(.*?)\\]\\]").matcher(e); m.find(); ) 
					e.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFF00D1")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				
			}
		//iApp
			if(types==iApp){
				for (Matcher m = iApp_KEYWORDS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorKeyword), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.BOLD), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}

				for (Matcher m = iApp_BUILTINS.matcher(e); m.find(); )
					e.setSpan(new ForegroundColorSpan(colorBuiltin), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					
				for (Matcher m = iApp_COMMENTS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorComment), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					e.setSpan(new StyleSpan(Typeface.ITALIC), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
				
				for (Matcher m = Pattern.compile("\\\"(.*?)\\\"|\\\'(.*?)\\\'|\\[\\[(.*?)\\]\\]").matcher(e); m.find(); ) 
					e.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFF00D1")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				
			}
			//Html
			if(types==Html){
				for (Matcher m = Html_KEYWORDS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorKeyword), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}

				/*for (Matcher m = Html_BUILTINS.matcher(e); m.find(); )
					e.setSpan(new ForegroundColorSpan(colorBuiltin), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
*/
				for (Matcher m = Html_COMMENTS.matcher(e); m.find(); ) {
					e.setSpan(new ForegroundColorSpan(colorComment), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				}

				for (Matcher m = Pattern.compile("\\\"(.*?)\\\"|\\\'(.*?)\\\'|\\[\\[(.*?)\\]\\]").matcher(e); m.find(); ) 
					e.setSpan(new ForegroundColorSpan(Color.parseColor("#FFFF00D1")), m.start(), m.end(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

			}
            
        } catch (IllegalStateException error) {
        }
        return e;
    }

    private CharSequence autoIndent(
            CharSequence source,
            Spanned dest,
            int dstart,
            int dend) {
        String indent = "";
        int istart = dstart - 1;

        boolean dataBefore = false;
        int pt = 0;

        for (; istart > -1; --istart) {
            char c = dest.charAt(istart);

            if (c == '\n')
                break;

            if (c != ' ' &&
                    c != '\t') {
                if (!dataBefore) {
                    if (c == '{' ||
                            c == '+' ||
                            c == '-' ||
                            c == '*' ||
                            c == '/' ||
                            c == '%' ||
                            c == '^' ||
                            c == '=')
                        pt--;

                    dataBefore = true;
                }

                if (c == '(')
                    --pt;
                else if (c == ')')
                    ++pt;
            }
        }

        if (istart > -1) {
            char charAtCursor = dest.charAt(dstart);
            int iend;

            for (iend = ++istart;
                 iend < dend;
                 ++iend) {
                char c = dest.charAt(iend);

                if (charAtCursor != '\n' &&
                        c == '/' &&
                        iend + 1 < dend &&
                        dest.charAt(iend) == c) {
                    iend += 2;
                    break;
                }

                if (c != ' ' &&
                        c != '\t')
                    break;
            }

            indent += dest.subSequence(istart, iend);
        }

        if (pt < 0)
            indent += "\t";

        return source + indent;
    }

    private void convertTabs(Editable e, int start, int count) {
        if (tabWidth < 1)
            return;

        String s = e.toString();

        for (int stop = start + count;
             (start = s.indexOf("\t", start)) > -1 && start < stop;
             ++start)
            e.setSpan(
                    new TabWidthSpan(),
                    start,
                    start + 1,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    public interface OnTextChangedListener {
        void onTextChanged(String text);
    }

    private class TabWidthSpan extends ReplacementSpan {
        @Override
        public int getSize(
                Paint paint,
                CharSequence text,
                int start,
                int end,
                Paint.FontMetricsInt fm) {
            return tabWidth;
        }

        @Override
        public void draw(
                Canvas canvas,
                CharSequence text,
                int start,
                int end,
                float x,
                int top,
                int y,
                int bottom,
                Paint paint) {
        }
    }

}
