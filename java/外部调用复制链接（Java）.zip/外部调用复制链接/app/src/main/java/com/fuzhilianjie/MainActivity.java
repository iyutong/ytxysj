package com.fuzhilianjie;
 
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.ClipData;

public class MainActivity extends Activity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        

        android.content.Intent intent = getIntent();
        if (intent != null) {
            String action = intent.getAction();
            String dataString = intent.getDataString();

            if (dataString != null) {
                android.widget.Toast.makeText(this, "复制成功:\n"+dataString, android.widget.Toast.LENGTH_LONG).show();
                copy(this,dataString);
                this.finish();
            }
        }
        
        
    }
    
    //系统剪贴板-复制:   s为内容
    public static void copy(Context context, String s) {
        // 获取系统剪贴板
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        // 创建一个剪贴数据集，包含一个普通文本数据条目（需要复制的数据）
        ClipData clipData = ClipData.newPlainText(null, s);
        // 把数据集设置（复制）到剪贴板
        clipboard.setPrimaryClip(clipData);
    }
    
	
} 
