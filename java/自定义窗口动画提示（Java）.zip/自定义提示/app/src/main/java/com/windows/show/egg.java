package com.windows.show;
import android.view.*;
import android.os.*;
import android.app.*;
import android.widget.*;
import android.widget.ActionMenuView.*;
import android.content.*;
import android.content.res.*;



public class egg
{
	
	Context context;
	
	public egg(Context context){
		this.context=context;
	}
	
	
	public void setActionColor(Window window,View view,int color){
		
		LinearLayout.LayoutParams Layout=(LinearLayout.LayoutParams)view.getLayoutParams();
		//Layout.setMargins(0,getActionHeight(this.context),0,0);
		Layout.height=getActionHeight(this.context);
		
		ViewGroup decorViewGroup = (ViewGroup) window.getDecorView();
        View statusBarView = new View(window.getContext());
        int statusBarHeight =egg.getActionHeight(window.getContext());
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, statusBarHeight);
        params.gravity = Gravity.TOP;
        statusBarView.setLayoutParams(params);
        statusBarView.setBackgroundColor(color);
        decorViewGroup.addView(statusBarView);
	}
	
	
	
	public static void setWindowStatusBarColor(Activity activity, int colorResId) {  
        try {  
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {  
                Window window = activity.getWindow();  
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);  
                window.setStatusBarColor(activity.getResources().getColor(colorResId));  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
	
	public static LinearLayout.LayoutParams getLayoutParams(View id)
	{
		LinearLayout.LayoutParams Params=(LinearLayout.LayoutParams)id.getLayoutParams();
		return Params;
	}
	
	public static RelativeLayout.LayoutParams getRelativeLayout(View id)
	{
		RelativeLayout.LayoutParams Params=(RelativeLayout.LayoutParams)id.getLayoutParams();
		return Params;
	}
	
	public static int getActionHeight(Context context)
	{
		int statusBarHeight = 0;
        Resources res = context.getResources();
        int resourceId = res.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            statusBarHeight = res.getDimensionPixelSize(resourceId);
        }
        return statusBarHeight;
	}
}
