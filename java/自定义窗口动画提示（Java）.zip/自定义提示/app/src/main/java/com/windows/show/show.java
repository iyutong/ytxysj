package com.windows.show;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.*;
import android.view.animation.*;
import android.view.animation.Animation.AnimationListener;
public class show extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.Show);
		
		Window window=getWindow();
		window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		TextView con=findViewById(R.id.ConText);
		LinearLayout lio=findViewById(R.id.ShowBa);
		Intent intent=getIntent();
		String c=intent.getStringExtra("Toast");
		con.setText(c);
		
		float[] f=new float[]{10,10,10,10,10,10,10,10};
		RoundRectShape shape=new RoundRectShape(f,null,null);
		ShapeDrawable ShapeD=new ShapeDrawable(shape);
		ShapeD.getPaint().setColor(0xff2196f3);
		lio.setBackground(ShapeD);
		final RelativeLayout rel=findViewById(R.id.LayoutAlp);
		LinearLayout imV=findViewById(R.id.RoundILin);
		RoundIcon ro=new RoundIcon(getApplication());
		ro.setImageResource(R.drawable.image_1);
		imV.addView(ro);
		
		
		
		AnimationSet animation=new AnimationSet(true);
		AlphaAnimation alpha=new AlphaAnimation(0,1);
		alpha.setDuration(1500);
		animation.addAnimation(alpha);
		rel.startAnimation(animation);
		
		try{
			
	
		new Handler().postDelayed(new Runnable(){
				@Override
				public void run()
				{
					// TODO: Implement this method
					AnimationSet ani=new AnimationSet(true);
			AlphaAnimation alphaEnd=new AlphaAnimation(1,0);
					alphaEnd.setAnimationListener(new AnimationListener(){

							@Override
							public void onAnimationStart(Animation p1)
							{
								// TODO: Implement this method
							}

							@Override
							public void onAnimationEnd(Animation p1)
							{
								// TODO: Implement this method
								finish();
							}

							@Override
							public void onAnimationRepeat(Animation p1)
							{
								// TODO: Implement this method
								
							}
						});
			ani.addAnimation(alphaEnd);
			
			TranslateAnimation transAnima=new TranslateAnimation(0,0,0,200);
			ani.addAnimation(transAnima);
			ani.setDuration(1500);
			rel.startAnimation(ani);
			
				}
			}, 3000);
		
			}catch(Exception e){
				
			}
			finally{
				
			}
		
	}
	
	
	
	
}



