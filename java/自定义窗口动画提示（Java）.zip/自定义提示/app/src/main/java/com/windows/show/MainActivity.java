package com.windows.show;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;
import android.graphics.drawable.*;
import android.graphics.drawable.shapes.*;
import android.graphics.*;
public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
		//蛋壳作品 QQ1970284668 官方群:581741931
        final String contents = "世界这么大，我想去看看。";
		Window window=this.getWindow();
		window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
		LinearLayout TopLin=findViewById(R.id.TitleTop);
		Button buttonCome=findViewById(R.id.comeButton);
		egg Egg=new egg(this);
		Egg.setActionColor(window,TopLin,0x55000000);
		
		float[] outerRadian = new float[]{20, 20, 20, 20, 20,20, 20, 20};
		RoundRectShape roundRectShape  = new RoundRectShape(outerRadian, null,null); 
		ShapeDrawable drawable = new ShapeDrawable(roundRectShape);
		drawable.getPaint().setColor(0xff2196f3);
		buttonCome.setBackground(drawable);
		
		
		buttonCome.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Intent intent=new Intent(MainActivity.this,show.class);
					intent.putExtra("Toast",contents);
					startActivity(intent);
				}
			
		});
		
    }
}
