package android.kz;

import android.os.Bundle;
import android.view.View;
import java.util.List;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.EditText;
import android.graphics.Color;

public class MainActivity extends Base 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        
		inlayout(R.layout.main);
        super.onCreate(savedInstanceState);
		Bar(R.id.mainView1).setBackgroundColor(Color.BLUE);
   //注意上面的顺序
   OtherUtils.builder().returnmaxoom(OtherUtils.builder().Mb);
   //↑返回程序最大oom,类型是int
		Toastkeeper.getInstance()
			.createBuilder(this)
			.setMessage("Toastkeeper测试")
			.setGravity(Toastkeeper.GRAVITY_TOP)
			.show();
	   
   }
   public void copyfile(View v){
	   OtherUtils.builder()
	   .setfile("测试复制", ((EditText)findViewById(R.id.mainEditText1)).getText().toString(), ((EditText)findViewById(R.id.mainEditText2)).getText().toString())
	   .setmaxspeed(100000)/*复制的速度，默认是1m/s，如果输入2，就是2M/s*/.setmessage(new message(){

			   @Override
			   public void dosome(String out, boolean state)
			   {
				   //out是进度，完成时，会返回所用时间，失败时，会返回错误信息
				   //state是返回的状态
				   //注:如果要在这里进行UI操作，务必在这里主动调用ui线程
				   show(out);
			   }


		   }).show();
   }
	private void show(final String in){
		runOnUiThread(new Runnable() {
                @Override
                public void run() {
					TextView a=findViewById(R.id.mainTextView1);
					a.setText(in);

                }
            });
	}
		
	
	public void requestPermission(View view) {
        KzPermissions.with(this)
			//targetSdkVersion要注意，有的权限要大于23，有的要大于26，不满足的话，会log显示的
			//.constantRequest() //可设置被拒绝后继续申请，直到用户授权或者永久拒绝
			.permission(Permission.SYSTEM_ALERT_WINDOW) //支持请求6.0悬浮窗权限8.0请求安装权限
			.permission(Permission.Group.STORAGE, Permission.Group.CALENDAR) //不指定权限则自动获取清单中的危险权限
			.request(new OnPermission() {

				@Override
				public void hasPermission(List<String> granted, boolean isAll) {
					if (isAll) {
						toa("获取权限成功");
					}else {
						toa("获取权限成功，部分权限未正常授予");
					}
				}

				@Override
				public void noPermission(List<String> denied, boolean quick) {
					if(quick) {
						toa("被永久拒绝授权，请手动授予权限");
						//如果是被永久拒绝就跳转到应用权限系统设置页面
						KzPermissions.gotoPermissionSettings(MainActivity.this);
					}else {
						toa("获取权限失败");
					}
				}
			});
    }

    public void isHasPermission(View view) {
        if (KzPermissions.isHasPermission(MainActivity.this, Permission.Group.STORAGE)) {
            toa("已经获取到权限，不需要再次申请了");
        }else {
            toa("还没有获取到权限或者部分权限未授予");
        }
    }
	void toa(String in){
		Toast.makeText(this,in,10).show();
	}
    public void gotoPermissionSettings(View view) {
        KzPermissions.gotoPermissionSettings(MainActivity.this);
    }
}
