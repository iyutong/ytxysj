package com.xiaoheng.danxuanDialog;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button btn=(Button)findViewById(R.id.mainButton);
		btn.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//界面按钮点击事件
					AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this,0);
					//dialog.setIcon(R.drawable.ic_launcher);//设置弹窗图标
					dialog.setCancelable(false);//按对话框按界面其它地方不消失返回键也没吊用
					dialog.setTitle("标题");//设置弹窗标题
					final String xiaoheng[]={"小亨","大帅比","666","234257176","1919196455"};//单选内容
					dialog.setSingleChoiceItems(xiaoheng, 0, new DialogInterface.OnClickListener()//0是默认选中第几个，0是默认选择第一个，1是第二个，以此来推
					{

							@Override
							public void onClick(DialogInterface p1, int xiao)
							{
								//单选点击事件
								try
								{
									startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+xiaoheng[xiao])));
								}catch(Exception xiaoheng)
								{
									Toast.makeText(MainActivity.this,"转跳到小亨QQ异常",Toast.LENGTH_SHORT).show();
								}
								
								Toast.makeText(MainActivity.this,xiaoheng[xiao],Toast.LENGTH_SHORT).show();
							}
						});
					
					dialog.setPositiveButton("取消", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int heng)
							{
								//取消按钮的点击事件
								Toast.makeText(MainActivity.this,"你点击了取消", Toast.LENGTH_SHORT).show();
							}
						});//弹窗取消按钮
					dialog.show();//将弹窗显示出来
					
					
				}
			});
    }
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *      2017.8.10                       *
 ****************************************/
