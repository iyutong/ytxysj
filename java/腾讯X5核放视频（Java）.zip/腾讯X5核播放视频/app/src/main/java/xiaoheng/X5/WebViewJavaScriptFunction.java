package xiaoheng.X5;

public interface WebViewJavaScriptFunction
{
	void onJsFunctionCalled(String tag);
}
