package xiaoheng.X5;

import android.app.*;
import android.os.*;
import android.content.*;

/*
By 小亨
2018.8.29
*/

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Intent intent = new Intent(MainActivity.this,FullScreenActivity.class);
		MainActivity.this.startActivity(intent);
		
    }
}
