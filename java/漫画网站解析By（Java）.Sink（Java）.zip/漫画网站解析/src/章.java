public class 章
{
	//章节地址
	String url;
	//名字
	String name;

	@Override
	public String toString()
	{
		// TODO: Implement this method
		return "章名:"+name+"url"+url;
	}

    
	public void setUrl(String url)
	{
		this.url = url;
	}

	public String getUrl()
	{
		return url;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
}
