import org.jsoup.*;
import org.jsoup.nodes.*;
import java.io.*;

public class 观看
{
	public static  void main(String[] args){
		try
		{
			Element element= Jsoup.connect("http://m.gufengmh.com/manhua/doupocangqiongdafanwaiyaolaochuanqi/468927.html").
				get().body();
			String 图片地址= element.select("mip-img").get(0).attr("src");
			System.out.println("正文图片:"+图片地址);
			System.out.println("上一章:"+element.select("div.action-list").select("mip-link").get(0).attr("href"));
			System.out.println("上一页:"+element.select("div.action-list").select("mip-link").get(1).attr("href"));
			System.out.println("下一页:"+element.select("div.action-list").select("mip-link").get(2).attr("href"));
			System.out.println("下一章:"+element.select("div.action-list").select("mip-link").get(3).attr("href"));
		}
		catch (IOException e)
		{}
	}
}
