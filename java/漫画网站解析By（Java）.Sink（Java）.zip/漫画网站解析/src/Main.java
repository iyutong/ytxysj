import java.util.*;
import org.jsoup.*;
import java.io.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;

public class Main
{
	public static void main(String[] args)
	{
		//获取搜索界面
		try
		{
			Element element= Jsoup.connect("http://m.gufengmh.com/search/?keywords=斗破").
			get().body();
			Elements elements = element.select("div.itemBox");
			for(Element e:elements){
				Book book=new Book();
				book.setImgUrl(e.select("div.itemImg").select("mip-img").attr("src"));
				book.setDescUrl(e.select("div.itemTxt").select("a.title").attr("href"));
				book.setTitle(e.select("div.itemTxt").select("a.title").text());
				book.setAuthor(e.select("div.itemTxt").select("p.txtItme").get(0).text());
				book.setType(e.select("div.itemTxt").select("p.txtItme").get(1).text());
				book.setDate(e.select("div.itemTxt").select("p.txtItme").get(2).text());
				章 aa=new 章();
				aa.setName(e.select("a.coll").text());
				aa.setUrl(e.select("a.coll").attr("href"));
				book.set最新章节(aa);
				System.out.println(book);
			}
			
		}
		catch (IOException e)
		{}

	}
}
