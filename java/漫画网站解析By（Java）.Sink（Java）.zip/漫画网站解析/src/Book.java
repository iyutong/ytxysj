public class Book
{
	//封面url
	String imgUrl;
	//标题
	String title;
	//详情界面url
	String descUrl;
	//作者
	String author;
	//日期
	String date;
	//类别
	String type;
	//最新章节
	章 最新章节;

	@Override
	public String toString()
	{
		
		return "   书名:"+title+"  作者:"+author+"  详情界面URL:"+descUrl+"  封面URL:"+imgUrl+"  类别:"+type+"  更新日期:"+date+"  最新章节:"+最新章节.toString();
	}
	
	public void setAuthor(String author)
	{
		this.author = author;
	}

	public String getAuthor()
	{
		return author;
	}

	public void setImgUrl(String imgUrl)
	{
		this.imgUrl = imgUrl;
	}

	public String getImgUrl()
	{
		return imgUrl;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getTitle()
	{
		return title;
	}

	public void setDescUrl(String descUrl)
	{
		this.descUrl = descUrl;
	}

	public String getDescUrl()
	{
		return descUrl;
	}

	public void set最新章节(章 最新章节)
	{
		this.最新章节 = 最新章节;
	}

	public 章 get最新章节()
	{
		return 最新章节;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getType()
	{
		return type;
	}
	


	public void setDate(String date)
	{
		this.date = date;
	}

	public String getDate()
	{
		return date;
	}
}
