import org.jsoup.*;
import org.jsoup.nodes.*;
import java.io.*;
import org.jsoup.select.*;

public class 章节列表
{
	public static void main(String args[]){
		try
		{
			Element element= Jsoup.connect("http://m.gufengmh.com/manhua/doupocangqiongdafanwaiyaolaochuanqi/").get().body();
			Elements elements=element.select("div.list").select("a");
			for(Element e:elements){
			   System.out.println(e.text()+"   地址:"+e.attr("href"));
			}
		}
		catch (IOException e)
		{}
	}
}
