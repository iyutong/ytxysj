package com.miao.myapp;
import android.content.Context;
import android.widget.Toast;
import com.miao.Api.Bean;
import com.miao.Api.Plugin;

public class Main implements Plugin
{

	@Override
	public void onLoad(Bean out)
	{
		Context a=	out.getCon();
		Toast.makeText(a, "加载成功", 1000).show();
		//被激活时执行
	}

}
