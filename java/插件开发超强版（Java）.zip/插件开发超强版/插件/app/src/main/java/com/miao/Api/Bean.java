package com.miao.Api;
import android.content.Context;

public class Bean
{
	private Context con;


	public void setCon(Context con)
	{
		this.con = con;
	}

	public Context getCon()
	{
		return con;
	}
}
	
