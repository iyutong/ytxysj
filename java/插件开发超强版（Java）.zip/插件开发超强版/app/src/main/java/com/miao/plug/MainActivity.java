package com.miao.plug;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import android.support.v7.widget.LinearLayoutManager;

public class MainActivity extends AppCompatActivity {
	private List<PackageInfo> list;
	private RecyclerView lb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		add();
		if (list.size() != 0) {
			lb = findViewById(R.id.activitymainRecyclerView1);
			LinearLayoutManager manager = new LinearLayoutManager(this);
			manager.setOrientation(LinearLayoutManager.VERTICAL);
			lb.setLayoutManager(manager);
			lb.setAdapter(new lbspq(this, list));
		} else {
			Toast.makeText(this, "无", 1000).show();
		}
	}

	private void add() {
		list = new ArrayList<>();
		PackageManager pm = getPackageManager();
		List<PackageInfo> packages = pm.getInstalledPackages(0);
		for (PackageInfo packageInfo : packages) {
			// 判断系统/非系统应用
			if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				try {
					if (ismiaoplug(packageInfo.packageName)) {
						list.add(packageInfo);
					}
				} catch (Exception e) {

				}
			}
		}
	}
	
	private boolean ismiaoplug(String pn){
		boolean value;
		try{
			ApplicationInfo ai = getPackageManager().getApplicationInfo(pn, PackageManager.GET_META_DATA);
			value = ai.metaData.getBoolean("miaoplug", false);
			return value;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
