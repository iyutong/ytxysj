package com.miao.plug;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import dalvik.system.DexClassLoader;
import com.miao.Api.Plugin;
import com.miao.Api.Bean;

public class lbspq extends RecyclerView.Adapter<lbspq.MyViewHolder> {
    private List<PackageInfo> list;
	private Context context;
	private View inflater;

	public lbspq(Context context, List<PackageInfo> list) {
		this.list = list;
		this.context =  context;
	}

	@Override
	public lbspq.MyViewHolder onCreateViewHolder(ViewGroup p1, int p2) {
		inflater = LayoutInflater.from(context).inflate(R.layout.item, p1, false);
		MyViewHolder myViewHolder = new MyViewHolder(inflater);
		return myViewHolder;
	}

	@Override
	public void onBindViewHolder(lbspq.MyViewHolder p1, int p2) {
		final PackageInfo pi = list.get(p2);
		p1.textView.setText(pi.applicationInfo.loadLabel(context.getPackageManager()));
		p1.textView.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					try {
						ApplicationInfo ai = context.getPackageManager().getApplicationInfo(pi.packageName, PackageManager.GET_META_DATA);
						DexClassLoader dcl = new DexClassLoader(ai.sourceDir, context.getCacheDir().getPath(), null, context.getClassLoader());
						Class<?> cls = dcl.loadClass(ai.metaData.getString("plugclass", "false"));
						Plugin plugin = (Plugin) cls.newInstance();
						Bean bean = new Bean();
						bean.setCon(context);
						plugin.onLoad(bean);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}

	@Override
	public int getItemCount() {
		return list.size();
	}

	class MyViewHolder extends RecyclerView.ViewHolder {
		TextView textView;
		public MyViewHolder(View v) {
			super(v);
			textView = v.findViewById(R.id.itemTextView1);
		}
	}
}
