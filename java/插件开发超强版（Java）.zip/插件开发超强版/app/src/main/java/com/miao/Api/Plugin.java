package com.miao.Api;

public interface Plugin
{
	void onLoad(Bean out)
}
