package com.mycompany.myapp;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity
{
	private Button cv;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		cv=(Button)findViewById(R.id.sr);
		
		cv.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent shareIntent = new Intent(); 
					shareIntent.setAction(Intent.ACTION_SEND);					
					Toast.makeText(MainActivity.this,"人生对你的分享",Toast.LENGTH_SHORT).show();					
					shareIntent.putExtra(Intent.EXTRA_TEXT,      " 人生对你们的分享，");			

					shareIntent.setType("text/plain");			

					startActivity(Intent.createChooser(shareIntent, "分享到"));

					
					
					
					
					// TODO: Implement this method
				}
			});
		
		
    }
}
