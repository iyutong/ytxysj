package com.duhuang.loginre;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class Register extends Activity
{
	private EditText userName;//用户名
	private EditText userEmail;//邮箱
	private EditText password;//密码
	private Button register;//注册按钮
	private OwlView mOwl;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		userName = (EditText) findViewById(R.id.registerEditText3);
		password = (EditText) findViewById(R.id.registerEditText2);
		register = (Button) findViewById(R.id.registerButton1);
		userEmail = (EditText) findViewById(R.id.registerEditText1);
		mOwl = (OwlView) findViewById(R.id.registerimageview1);

		password.setOnFocusChangeListener(new OnFocusChangeListener(){

				@Override
				public void onFocusChange(View p1, boolean p2)
				{
					// TODO: Implement this method
					if (p2)
					{
						mOwl.open();
					}
					else
					{
						mOwl.close();
					}
				}
			});
	}

}
