package com.duhuang.loginre;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private EditText userName;//用户名
	private EditText password;//密码
	private Button login;//登录按钮
	private TextView skipRegister;//跳转注册
	private OwlView mOwl;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
		userName = (EditText) findViewById(R.id.loginEditText1);
		password = (EditText) findViewById(R.id.loginEditText2);
		login = (Button) findViewById(R.id.loginButton1);
		skipRegister = (TextView) findViewById(R.id.loginTextView1);
		mOwl = (OwlView) findViewById(R.id.loginimageview1);

		password.setOnFocusChangeListener(new OnFocusChangeListener(){

				@Override
				public void onFocusChange(View p1, boolean p2)
				{
					// TODO: Implement this method
					if (p2)
					{
						mOwl.open();
					}
					else
					{
						mOwl.close();
					}
				}
			});

		skipRegister.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					startActivity(new Intent(MainActivity.this, Register.class));
				}
			});
    }
}
