package com.duhuang.loginre;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;

public class Start extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//去掉信息栏
		setContentView(R.layout.start);
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					// TODO: Implement this method
					try
					{
						Thread.sleep(2000);
						startActivity(new Intent(Start.this, MainActivity.class));
						finish();
					}
					catch (InterruptedException e)
					{}
				}
			}).start();
	}

}
