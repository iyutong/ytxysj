package security;

public class config {
	public static String path(){
		return "sdcard/aa/";
	}
}
