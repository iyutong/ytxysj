/** Automatically generated file. DO NOT MODIFY */
package me.imid.swipebacklayout.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}