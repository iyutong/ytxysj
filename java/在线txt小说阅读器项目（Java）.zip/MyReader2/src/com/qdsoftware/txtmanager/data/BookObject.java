package com.qdsoftware.txtmanager.data;


import com.qdsoftware.txtmanager.util.DataManager;

import android.graphics.Bitmap;

public class BookObject implements Comparable<BookObject>{
	
	//全参的构造方法
	public BookObject(String mAbspath, String mName, String mSuffix,
			String mMd5, String mHanyutopinyin, long mTimestamp, String mLength,
			int mOpenCount, long mLastTime) {
		super();
		this.mAbspath = mAbspath;
		this.mName = mName;
		this.mSuffix = mSuffix;
		this.mMd5 = mMd5;
		this.mHanyutopinyin = mHanyutopinyin;
		this.mTimestamp = mTimestamp;
		this.mLength = mLength;
		this.mOpenCount = mOpenCount;
		this.mLastTime = mLastTime;
	}
	public BookObject(String mAbspath, String mName, 
			 String mHanyutopinyin, long mTimestamp, String mLength,
			int mOpenCount, long mLastTime) {
		super();
		this.mAbspath = mAbspath;
		this.mName = mName;
		this.mHanyutopinyin = mHanyutopinyin;
		this.mTimestamp = mTimestamp;
		this.mLength = mLength;
		this.mOpenCount = mOpenCount;
		this.mLastTime = mLastTime;
	}
	
	//无参的构造方法
	public BookObject() {
		super();
	}

	//文件绝对路径
	private String mAbspath = null;
	//图书的书名
    private String mName = null;
    //文件后缀名
    private String mSuffix = null;
    //md5 加密编码
    private String mMd5;
    //文件名的汉语拼音编码
    private String mHanyutopinyin = null;
    //数据插入数据库的时间
    private long mTimestamp = 0;
    //图书文件大小
    private String mLength = null;
    //文件打开次数
    private int mOpenCount = 0;
    //最近打开时间
    private long mLastTime = 0;
    
    private Bitmap corver;
    
    public void setBookCorver(Bitmap corver){
    	this.corver=corver;
    }
    public Bitmap getBitmap(){
    	
    	return corver;
    }
    
	public String getmAbspath() {
		return mAbspath;
	}
	public void setmAbspath(String mAbspath) {
		this.mAbspath = mAbspath;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getmSuffix() {
		return mSuffix;
	}
	public void setmSuffix(String mSuffix) {
		this.mSuffix = mSuffix;
	}
	public String getmMd5() {
		return mMd5;
	}
	public void setmMd5(String mMd5) {
		this.mMd5 = mMd5;
	}
	public String getmHanyutopinyin() {
		return mHanyutopinyin;
	}
	public void setmHanyutopinyin(String mHanyutopinyin) {
		this.mHanyutopinyin = mHanyutopinyin;
	}
	public long getmTimestamp() {
		return mTimestamp;
	}
	public void setmTimestamp(long mTimestamp) {
		this.mTimestamp = mTimestamp;
	}
	public String getmLength() {
		return mLength;
	}
	public void setmLength(String mLength) {
		this.mLength = mLength;
	}
	public int getmOpenCount() {
		return mOpenCount;
	}
	public void setmOpenCount(int mOpenCount) {
		this.mOpenCount = mOpenCount;
	}
	public long getmLastTime() {
		return mLastTime;
	}
	public void setmLastTime(long mLastTime) {
		this.mLastTime = mLastTime;
	}
	
	//重写toString()方法
	@Override
	public String toString() {
		return "BookObject [mAbspath=" + mAbspath + ", mName=" + mName
				+ ", mSuffix=" + mSuffix + ", mMd5=" + mMd5
				+ ", mHanyutopinyin=" + mHanyutopinyin + ", mTimestamp="
				+ mTimestamp + ", mLength=" + mLength + ", mOpenCount="
				+ mOpenCount + ", mLastTime=" + mLastTime + "]";
	}
	//0-书名 1-最近阅读 2-大小 3-插入时间
	public int compareTo(BookObject another) {
		int i=0;
		switch (DataManager.compare_style) {
		case 0:
			
			break;

		case 1:
			i=another.getmLastTime() >this.mLastTime?1:(another.getmLastTime()==this.mLastTime?0:-1);
			
			break;
		case 2:
			int another_length=Integer.parseInt(another.getmLength());
			int this_length=Integer.parseInt(this.getmLength());
			i= another_length>this_length?1:(another_length==this_length?0:-1);
			break;
		case 3:
			i=another.getmTimestamp() >this.mTimestamp?1:(another.getmTimestamp()==this.mTimestamp?0:-1);
			
			break;
		}	
		if(DataManager.curView != DataManager.curView_recentView){
			i=DataManager.compare_order==DataManager.compare_order_dowm?i:-i;
			}else{
				if(another.getmLastTime()>this.mLastTime){
					i=1;
				}else if(another.getmLastTime()==this.mLastTime){
					i=0;
				}else if(another.getmLastTime()<this.mLastTime){
					i=-1;
				}
			}
		return i;
	}
}