package com.qdsoftware.txtmanager.data;

import android.graphics.Bitmap;

public class ConfigInin {
	public static Bitmap bookCover;
	public static Bitmap bookCorver_bg;
	public static Bitmap bookshelf;
	public static int whigth;
}
