package com.qdsoftware.txtmanager.view;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.R.layout;
import com.qdsoftware.txtmanager.downloadthread.DownLoadThread;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

public class InternetView {
	private	LayoutInflater inflater;
	private Context context;
	private LinearLayout layout;
	public InternetView(Context context,LinearLayout layout){
	this.context=context;
	inflater=LayoutInflater.from(context);
	this.layout=layout;
	}
	public void inin(){
		View view=	inflater.inflate(R.layout.webview, null);
		final WebView webView=(WebView) view.findViewById(R.id.webview);
		layout.removeAllViews();
		layout.addView(view);
		webView.loadUrl("http://q478631266.3GDISK.NET");
		
		
		webView.setWebViewClient(new WebViewClient(){

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				webView.loadUrl(url);
				try {
					new DownLoadThread(context,new URL(url), new File(DataManager.sdCardPath+"/123")).start();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				return super.shouldOverrideUrlLoading(view, url);
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				
				super.onLoadResource(view, url);
			}
			
		});
	}
}
