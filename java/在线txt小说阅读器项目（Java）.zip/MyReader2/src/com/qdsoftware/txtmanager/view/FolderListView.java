package com.qdsoftware.txtmanager.view;

import java.io.File;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.adapter.FolderListAdapter;
import com.qdsoftware.txtmanager.data.BookObject;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class FolderListView extends View implements Runnable{
	private Context context;
	private LayoutInflater infalter;
	private File file;
	File[] filelist;
	private ListView listview;
	private FolderListAdapter adapter;
	private TextView filepath;
	private ImageView backimg;
	private LinearLayout l;
	private LinearLayout layout;
	public FolderListView(Context context,LinearLayout layoutView) {
		super(context);
		this.context=context;
		
		infalter=LayoutInflater.from(context);
		
		layout=layoutView;
		
	}
	public void inin(BaseAdapter adapter){
		this.adapter=(FolderListAdapter) adapter;
		
		new	Thread(this).start(); 
	}
	public  String goBack(File f,Context c) {
		Log.d("dd",""+f.getParent());
		if (f.getParent().equals("/")) {
			backimg.setImageBitmap(DataManager.folderListViewBackImgNomal);
			backimg.setEnabled(false);
			DataManager.curView=-1;
			Log.d("DataManager.curView",""+DataManager.curView);
			return null;
		} else {
			backimg.setImageBitmap(DataManager.folderListViewBackImgActive);
			backimg.setEnabled(true);
			return f.getParent();
		}
		
	}
	public void run() {
		mHandler.sendEmptyMessage(0);
		l=(LinearLayout) infalter.inflate(R.layout.folderlistview, null);
		listview = (ListView) l.findViewById(R.id.filelistview);
		filepath = (TextView)l.findViewById(R.id.filepath);
		backimg = (ImageView) l.findViewById(R.id.back);
		file=DataManager.file;
		backimg.setOnTouchListener(new OnTouchListener() {
			
			public boolean onTouch(View v, MotionEvent event) {
				back();
				return false;
			}
			
		
		});
		listview.setOnItemClickListener(new OnItemClickListener() {

			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				file = DataManager.ParentFileList.get(position);
				if (file.isDirectory() & file.listFiles() != null) {
						DataManager.curView=DataManager.curView_shelf_folderListView;
						DataManager.ParentFileList=DataManager.getSonFile(file.getAbsolutePath(),DataManager.allfileList);
						adapter = new FolderListAdapter(context,
								DataManager.ParentFileList);
						listview.setAdapter(adapter);
						filepath.setText(file.getAbsolutePath());
					
					goBack(file,context);
					
				}else if(!file.isDirectory()){
					
					if(file.getName().endsWith("txt")){
						
						if(DataManager.dbHelp.checkBook(file.getAbsolutePath())){
							
							Toast.makeText(context, "此书已存在书架",
									
									Toast.LENGTH_SHORT).show();
							
						}else{
							String name=file.getName();
							String absolutePath=file.getAbsolutePath();
						BookObject book=new BookObject(absolutePath, name, "暂无", System.currentTimeMillis(),""+ file.length(), 0,0);
						book.setBookCorver(DataManager.getBookCorver(name));
						DataManager.allBookCorver.add(book);
						DataManager.dbHelp.insert(book);
						}
					} 
				}else if(file.isDirectory() & file.listFiles() == null){
					Toast.makeText(context, "文件夹为空",
							Toast.LENGTH_SHORT).show();
				}

			}

		});
		while(!DataManager.titleMoveFinished){
			
		}
		
		mHandler.sendEmptyMessage(1);
		
	}
	
	public Handler mHandler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			if(msg.what==0){
				layout.removeAllViews();
				layout.addView(DataManager.layout);
			}else{
				filepath.setText(file.getParent());
				back();
				adapter=new FolderListAdapter(context, DataManager.ParentFileList);
				listview.setAdapter(adapter);
				layout.removeAllViews();
				layout.addView(l);
			}
			super.handleMessage(msg);
		}
		
	};
	public void back(){
		if(goBack(file,context)!=null){
			filepath.setText(file.getParent());
			
			file=new File( goBack(file,context));
			
			DataManager.ParentFileList=	DataManager.getSonFile(file.getAbsolutePath(), DataManager.allfileList);
			DataManager.curView=DataManager.curView_shelf_folderListView;	
		}
			adapter=new FolderListAdapter(context, DataManager.ParentFileList);
			
			listview.setAdapter(adapter);
			
			goBack(file, context);
			
				
			
	}
}
