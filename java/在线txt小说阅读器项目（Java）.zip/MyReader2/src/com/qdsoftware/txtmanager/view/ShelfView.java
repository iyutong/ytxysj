package com.qdsoftware.txtmanager.view;

import java.util.Collections;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.adapter.FolderListAdapter;
import com.qdsoftware.txtmanager.adapter.MyAlertDialog;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

public class ShelfView extends View implements Runnable{//我的书架
	LayoutInflater infalter;
	Context context;
	Button set,shelfList,folder,btn;
	ImageView older;
	private byte state=1;//用于保存bottombtn的选中状态
	int whigth;
	Spinner spinner;
	private LinearLayout layout;
	LinearLayout l;
	public LinearLayout view;
	ShelfListView shelfListView;
	MyAlertDialog  dialog;
	
	FolderListView folderListView;
	public ShelfView(Context context,LinearLayout layout) {
		super(context);
		this.context=context;
		this.layout=layout;
		infalter=LayoutInflater.from(context);
		l=(LinearLayout) infalter.inflate(R.layout.shelfview, null);
		
		view =(LinearLayout) l.findViewById(R.id.shelfview); //
		
		shelfListView=new ShelfListView(context,view);
		folderListView=new FolderListView(context,view);
		state=1;
	
		

	}
		public void inin(){
			//1-书架,2-文件目录,3-设置
			older= (ImageView) l.findViewById(R.id.order);
			
			btn=(Button) l.findViewById(R.id.nearlyread);
			
			new Thread(this).start();
			
		}
		

		public void setininBtnImg(int state){
			switch (state) {
			case 1:shelfList.setBackgroundResource(R.drawable.shelf_seleted);
				break;
			case 2:
				folder.setBackgroundResource(R.drawable.folder_seleted);
				break;
			case 3:set.setBackgroundResource(R.drawable.set_active);
				break;
			default:
				break;
			}
			
		}
		
		public  void setBtnImg(int state){//设置图标背景
			switch (state) {
			case 1:shelfList.setBackgroundResource(R.drawable.shelf_normal);
				break;
			case 2:
				folder.setBackgroundResource(R.drawable.folder_normal);
				break;
			case 3:set.setBackgroundResource(R.drawable.set_icon);
			break;
			default:
				break;
			}
		}
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {
			if(DataManager.curView==DataManager.curView_shelf_folderListView){
				folderListView.back();
			}else{
				super.onKeyDown(keyCode, event);
			}
			return true ;
		}
		public void run() {
			mHandler.sendEmptyMessage(0);
			
			older.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					if(DataManager.compare_order==DataManager.compare_order_up){
						
						older.setBackgroundResource(R.drawable.order_arrow_down);
						
						DataManager.compare_order=DataManager.compare_order_dowm;
						
					}else if(DataManager.compare_order==DataManager.compare_order_dowm){
						older.setBackgroundResource(R.drawable.order_arrow_up);
						
						DataManager.compare_order=DataManager.compare_order_up;
					}
					
					Collections.sort(DataManager.allBookCorver);
					
					shelfListView.adapter.notifyDataSetChanged();
				}
			});
			
			
			btn.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					
					dialog=new MyAlertDialog(TxtManagerActivity.activity,R.style.dialog);
					
					Window win =dialog .getWindow();
					
					LayoutParams params = new LayoutParams();
					
					params.height=200;
					
					params.x =-DataManager.width/2+(btn.getRight()-btn.getWidth()/2);//设置x坐标
					params.y =-(DataManager.height/2-(DataManager.height-btn.getBottom()));//设置y坐标
					
					win.setAttributes(params);
					
					dialog.setCanceledOnTouchOutside(true);//设置点击Dialog外部任意区域关闭Dialog
										
					dialog.show();
					
					final Button btn_name=(Button) dialog.findViewById(R.id.btn1);
					
					final Button btn_size=(Button) dialog.findViewById(R.id.btn2);
					
					final Button btn_time=(Button) dialog.findViewById(R.id.btn3);
					
					final Button btn_lastRead=(Button) dialog.findViewById(R.id.btn4);

					View.OnClickListener listener=new View.OnClickListener() {
						
						public void onClick(View v) {
							
							switch (v.getId()) {
							case R.id.btn1:   //书名
								DataManager.compare_style=DataManager.compare_style_name;
								btn.setText(btn_name.getText());
								
								break;
							case R.id.btn2:  //大小
								DataManager.compare_style=DataManager.compare_style_size;
								btn.setText(btn_size.getText());
								break;
								
							case R.id.btn3:  //加入时间时间
								DataManager.compare_style=DataManager.compare_style_time;
								btn.setText(btn_time.getText());
								
								break;
							case R.id.btn4: // 阅读时间
								DataManager.compare_style=DataManager.compare_style_recentRead;
								btn.setText(btn_lastRead.getText());
								break;
							default:
								break;
							}
							dialog.dismiss();
							Collections.sort(DataManager.allBookCorver);
							
							shelfListView.adapter.notifyDataSetChanged();
							
						}
						
					};

					btn_lastRead.setOnClickListener(listener);
					
					btn_name.setOnClickListener(listener);
					
					btn_size.setOnClickListener(listener);
					
					btn_time.setOnClickListener(listener);
					
				}
			});
			set=(Button) l.findViewById(R.id.set);
			shelfList=(Button) l.findViewById(R.id.shelf_normal);
			folder=(Button) l.findViewById(R.id.folder_normal);
			folder.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					FolderListAdapter	adapter=new FolderListAdapter(context, DataManager.ParentFileList);
					
					folderListView.inin(adapter);
					
					setBtnImg(state);
					
					folder.setBackgroundResource(R.drawable.folder_seleted);
					
					state=2;
				}
			});
			set.setOnTouchListener(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						setBtnImg(state);
						
						set.setBackgroundResource(R.drawable.set_active);
						break;

					case MotionEvent.ACTION_UP:
						setininBtnImg(state);
						
						set.setBackgroundResource(R.drawable.set_icon);
						break;
					}
					
					
					return true;
				}
			});
			shelfList.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					
					
					shelfListView.inin();
					
					setBtnImg(state);
					
					shelfList.setBackgroundResource(R.drawable.shelf_seleted);
					
					
					state=1;
				}
			});
			
			mHandler.sendEmptyMessage(1);
			
		}
		public Handler mHandler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				if(msg.what==0){
					inin_older_background();
					
					inin_style_background();
					
					layout.removeAllViews();
					
					
				}else{
					setininBtnImg(state);
					
					layout.removeAllViews();
				
					DataManager.curView=DataManager.curView_shelf_shelfListView;
					//用于加载上次的界面
					if(state==1){
					
						shelfListView.inin();
					
					}else if(state==2){
						
						FolderListAdapter	adapter=new FolderListAdapter(context, DataManager.ParentFileList);
						folderListView.inin(adapter);
					}
					layout.addView(l);
				}
			}
		};
		@Override
		public void onConfigurationChanged(Configuration newConfig) {
			
			if(DataManager.curView==DataManager.curView_shelf_shelfListView){
		
				shelfListView.onConfigurationChanged(newConfig);
				
			}
		}
		
		public void inin_older_background(){
	if(DataManager.compare_order==DataManager.compare_order_up){
				
		older.setBackgroundResource(R.drawable.order_arrow_up);
				
				
				
			}else if(DataManager.compare_order==DataManager.compare_order_dowm){
				
				older.setBackgroundResource(R.drawable.order_arrow_down);
			}
			
		}
		
		public void inin_style_background(){
			if(DataManager.compare_style==DataManager.compare_style_name){
				btn.setText("文件名称");
				
			}else if(DataManager.compare_style==DataManager.compare_style_recentRead){
				btn.setText("最近阅读");
				
			}else if(DataManager.compare_style==DataManager.compare_style_size){
				btn.setText("文件大小");
				
			}else if(DataManager.compare_style==DataManager.compare_style_time){
				btn.setText("文件日期");
			}
		}
}
