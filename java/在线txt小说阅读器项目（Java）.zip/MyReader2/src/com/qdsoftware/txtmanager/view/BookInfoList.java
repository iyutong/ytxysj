package com.qdsoftware.txtmanager.view;


import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.adapter.ServerBookAdapter;
import com.qdsoftware.txtmanager.downxml.DownXml;

import android.R.anim;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class BookInfoList {
	Context  context;
	LinearLayout layout;
	LayoutInflater infalter;
	ListView listView;
	public BookInfoList(Context context,LinearLayout layout){
		this.context=context;
		this.layout=layout;
		infalter=LayoutInflater.from(context);
	}
	public void inin(){
		View view=infalter.inflate(R.layout.booklistview, null);
		listView=(ListView) view.findViewById(R.id.book_listview);
		ServerBookAdapter adapter =new ServerBookAdapter(context,new DownXml(context).getBookInfo() );
		listView.setAdapter(adapter);
		layout.removeAllViews();
		layout.addView(view);
	}

}
