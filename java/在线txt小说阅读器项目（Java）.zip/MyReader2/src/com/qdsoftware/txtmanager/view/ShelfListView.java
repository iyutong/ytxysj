package com.qdsoftware.txtmanager.view;


import java.util.Collections;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.adapter.BookshelfAdapter;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
  
public class ShelfListView extends ListView implements Runnable{
	Context context;
	
	private LayoutInflater inflater;
	private LinearLayout l;
	private LinearLayout layout;
	ListView listview;
	BookshelfAdapter adapter;
	long lastTime;
	private boolean isRun;
	
	public ShelfListView(Context context,LinearLayout layout) {
		super(context);
		this.context =context;
		this.layout=layout;

	}
	public void inin( ){
		new Thread(this).start();
	}

	public void run() {
		DataManager.curView=DataManager.curView_shelf_shelfListView;
		isRun=true;

		mHandler .sendEmptyMessage(0);
		
		while(isRun){
		if(DataManager.isLoadFinished){

	
		isRun=false;
			}
		}
		
	Collections.sort(DataManager.allBookCorver);
		
	this.adapter=new BookshelfAdapter(context, DataManager.allBookCorver);
	
	
		
		inflater=LayoutInflater.from(context);
		
		l=(LinearLayout) inflater.inflate(R.layout.shelflist_view, null);
		
		listview=(ListView) l.findViewById(R.id.bookshelflist);
	
		listview.setAdapter(adapter);
		while(!DataManager.titleMoveFinished){
			
		}
		
		mHandler .sendEmptyMessage(1);
	}
	public Handler mHandler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			if(msg.what==0){
				
				layout.removeAllViews();
				layout.addView(DataManager.layout);
				
			}else{
				if(DataManager.curView==DataManager.curView_shelf_shelfListView){
				layout.removeAllViews();
				
				layout.addView(l);
				}
			}
			super.handleMessage(msg);
		}
	};
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		if(DataManager.curView==DataManager.curView_shelf_shelfListView){
			
			this.adapter.inin();
			
			this.adapter.notifyDataSetChanged();	
		}
	}
}
