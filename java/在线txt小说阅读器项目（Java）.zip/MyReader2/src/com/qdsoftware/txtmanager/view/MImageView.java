package com.qdsoftware.txtmanager.view;

import java.io.IOException;

import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.widget.ImageView;

public class MImageView extends ImageView implements Runnable {
	private Context context;
	private float x;
	private boolean update;
	private int curPos;
	private int moveToPs;
	private Thread mThread;
	private Bitmap b;
	private Rect src;
	private Rect dst;
	private DisplayMetrics dm=new DisplayMetrics();
	private int width;
	private int moveRange;
	private boolean isStatrtFist=true;
	
	public MImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		
	}

	public MImageView(Context context) {
		super(context);
	}

	public MImageView(Context context, AttributeSet attrs) {

		super(context, attrs);
		this.context = context;
		((TxtManagerActivity)context).getWindowManager().getDefaultDisplay().getMetrics(dm);
		inin();
		src = new Rect();
		src.left = 0;
		src.top = 0;
		src.right = b.getWidth();
		src.bottom = b.getHeight();

		dst = new Rect();
		dst.top = 0;
		curPos = 0;
	
		if (mThread == null) {
			mThread = new Thread(this);
			mThread.start();
			
		}
	}
	public void setW(int w){
		this.width=w;
	}
	public int getW(){
		return this.width;
	}
	public void setX(float x) {
		this.x = x;

	}

	public void update(boolean stop) {
		this.update = stop;
	}

	public float getX() {
		return this.x;
	}
	private int i;//每次移动i的像素
	@Override
	protected void onDraw(Canvas canvas) {
	
		int w=dm.widthPixels;
		
		if(w<=480){
			i=18;
			moveRange=126;
			if(isStatrtFist){
				setX(moveRange);
				curPos = moveRange;
				isStatrtFist=false;
			}
			dst.right = (int) (126 + getX());
		
		
		}
			
		else{
			i=19;
			moveRange=152;
			if(isStatrtFist){
				setX(moveRange);
				curPos = moveRange;
				isStatrtFist=false;
			}
			dst.right = (int) (b.getWidth() + getX());
		}
		dst.left = (int) getX();
			dst.bottom = 84;
		canvas.drawBitmap(b, src, dst, new Paint());
		super.onDraw(canvas);
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		float x = event.getX();
		if (x >= 0 & x < moveRange) {
			moveToPs = 0;
		} else if (x >= moveRange & x < 2*moveRange) {
			moveToPs = moveRange;
		} else if (x >= 2*moveRange & x < 3*moveRange) {
			moveToPs = 2*moveRange;
			
		}
		if (moveToPs != curPos) {
			update(true);
			DataManager.titleMoveFinished=false;
		}
		return false;
	}

	public void run() {
		while (true) {
			while (update) {
				try {
					
					Thread.sleep(50);
					
				} catch (Exception e) {
					
					e.printStackTrace();
					
				}
				if (moveToPs > getX()) {
					setX(getX() + i);
					if (getX() >= moveToPs) {
						update = false;
						DataManager.titleMoveFinished = true;
						curPos = moveToPs;

					}
				} else if (moveToPs < getX()) {
					setX(getX() - i);
					if (getX() <= moveToPs) {
						update = false;
						DataManager.titleMoveFinished = true;
						curPos = moveToPs;
					}

				}
				postInvalidate();
			}

		}
	}
	public int getRang(){
		return moveRange;
	}

	public void inin() {
		try {
		
			if(dm.widthPixels<=480){
			b=BitmapFactory.decodeStream(context.getAssets().open("top_tab_selected_smal.png"));
			}else{
			b=BitmapFactory.decodeStream(context.getAssets().open("top_tab_selected_500.png"));	
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
