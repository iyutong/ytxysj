package com.qdsoftware.txtmanager.view;

import java.util.Collections;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.adapter.RecentListViewAdapter;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;



public class RecentView extends View  implements Runnable{
	private Context context;

	private LinearLayout layout;
	private LayoutInflater inflater;
	private RecentListViewAdapter adapter;
	private ListView listview;
	private LinearLayout l;
	private boolean isRun;
	
	
	public RecentView(Context context,LinearLayout layout) {
		super(context);
		this.context=context;
		this.layout=layout;
		inflater=LayoutInflater.from(context);
	}
	public void inin(){
					
		new	Thread(this).start();
		
	}
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		if(DataManager.curView==DataManager.curView_recentView){
			adapter.inin();
			adapter.notifyDataSetChanged();
		}
		super.onConfigurationChanged(newConfig);
	}
	public void run() {
		DataManager.curView=DataManager.curView_recentView;
		isRun=true;
		l=(LinearLayout) inflater.inflate(R.layout.recentlistview, null);
		listview=(ListView) l.findViewById(R.id.recentlistview);
		
		mhandler.sendEmptyMessage(0);
		while(isRun){
			
			if(DataManager.isLoadFinished){
				isRun=false;
			}
			
		}
		Collections.sort(DataManager.allBookCorver);
		while(!DataManager.titleMoveFinished){
			
		}
		mhandler.sendEmptyMessage(1);
		
	}
	public Handler mhandler=new Handler(){
		
		@Override
		public void handleMessage(Message msg) {
		if(msg.what==0){
			layout.removeAllViews();
			layout.addView(DataManager.layout);
		}else{
			if(DataManager.curView==DataManager.curView_recentView){
			adapter =new RecentListViewAdapter(context, DataManager.allBookCorver);
			listview.setAdapter(adapter);
			layout.removeAllViews();
			layout.addView(l);
			}
			
		}
			super.handleMessage(msg);
		}
		
	};
}
