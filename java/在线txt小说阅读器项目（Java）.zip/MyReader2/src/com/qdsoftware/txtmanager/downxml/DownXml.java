package com.qdsoftware.txtmanager.downxml;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import android.content.ContentProvider;
import android.content.Context;
import android.util.Log;


public class DownXml implements Serializable{
	String name;
	String url;
	Context context;
	
	public DownXml(Context context) {
		this.context = context;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public ArrayList<DownXml> getBookInfo() {
		ArrayList<DownXml> books = new ArrayList<DownXml>() ;
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		Document document = null;
		factory = DocumentBuilderFactory.newInstance();
		HttpURLConnection conn = null;
		try {
			URL url=new URL("http://192.168.2.188:8080/test/books.xml");
			conn=(HttpURLConnection) url.openConnection();
			conn.setReadTimeout(3000);
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
		builder = factory.newDocumentBuilder();
		InputSource is=	new InputSource(conn.getInputStream()); 
		is.setEncoding("GBK");
		document = builder.parse(is);
			Element root = document.getDocumentElement();
			NodeList nodes = root.getElementsByTagName("book");
			DownXml xmlInfo=null;
			for(int i=0;i<nodes.getLength();i++){
				xmlInfo=new DownXml(context);
				Element riverElement=(Element)(nodes.item(i));
                Element name=(Element)riverElement.getElementsByTagName("name").item(0);
                Element url=(Element) riverElement.getElementsByTagName("url").item(0);
                String s= name.getFirstChild().getNodeValue();
                xmlInfo.setName(s);
                xmlInfo.setUrl(url.getFirstChild().getNodeValue());
              
               books.add(xmlInfo);
               conn.connect();
          
              
			}
		} catch (Exception e) {

		}
		

		return books;
	}
}
