package com.qdsoftware.txtmanager;

import java.io.IOException;

import com.qdsoftware.txtmanager.util.DBHelp;
import com.qdsoftware.txtmanager.util.DataManager;
import com.qdsoftware.txtmanager.view.BookInfoList;
import com.qdsoftware.txtmanager.view.MImageView;
import com.qdsoftware.txtmanager.view.RecentView;
import com.qdsoftware.txtmanager.view.ShelfView;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.LinearLayout;

public class TxtManagerActivity extends Activity implements Runnable{
	/** Called when the activity is first created. */
	MImageView mImageView;
	DisplayMetrics mt;
	LinearLayout view;
	AlertDialog.Builder builder;
	public static Activity activity;
	int widthPixels;
	
	ShelfView shelfView;
	RecentView recentView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		activity = this;
		
		setContentView(R.layout.main);
		
		inin(getApplicationContext());
		
		DataManager.ininBitmap(getApplicationContext());
		
		new Thread(this).start();
		
		mImageView = (MImageView) this.findViewById(R.id.title_bar);
		
		view = (LinearLayout) findViewById(R.id.view);
		
		mt = new DisplayMetrics();

		getWindowManager().getDefaultDisplay().getMetrics(mt);

		widthPixels = mt.widthPixels;
		
		DataManager.height=mt.heightPixels;
		
		DataManager.width=widthPixels;
		

		shelfView = new ShelfView(getApplicationContext(), view);
		recentView = new RecentView(getApplicationContext(),
				 view);
		recentView.inin();// 转到最近阅读
		mImageView.setW(widthPixels);
		if (widthPixels <= 480) {

			try {
				mImageView.setImageBitmap(BitmapFactory.decodeStream(this
						.getAssets().open("top_tab_smal.png")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				mImageView.setImageBitmap(BitmapFactory.decodeStream(this
						.getAssets().open("top_tab_500.png")));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		mImageView.setFocusable(true);
		mImageView.setOnTouchListener(new OnTouchListener() {

			public boolean onTouch(View v, MotionEvent event) {
				mImageView.onTouchEvent(event);
				float x = event.getX();
				int moveRange = mImageView.getRang();
			
				if (x >= 0 & x < moveRange) {
					if(DataManager.curView!=DataManager.curView_shelf_folderListView&&DataManager.curView!=DataManager.curView_shelf_shelfListView){
					shelfView.inin();
					}

				} else if (x >= moveRange & x < 2 * moveRange) {
					if(DataManager.curView!=DataManager.curView_recentView){
						shelfView.view.removeAllViews();
						recentView.inin();
					
					}

				} else if (x >= 2 * moveRange & x < 3 * moveRange) {
					DataManager.curView=DataManager.curView_net;
//					webView.inin();
					new BookInfoList(getApplicationContext(), view).inin();

				}

				return false;
			}
		});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (DataManager.curView == DataManager.curView_shelf_folderListView) {
						
				shelfView.onKeyDown(keyCode, event);

			} else {
				
				AlertDialog ad = builder.create();
				ad.show();

			}
		}

		return true;
	}
	

	public void inin(Context context) {
		try {
			builder = new AlertDialog.Builder(this);
			builder.setTitle("提示:")
					.setMessage("确定退出阅读器吗")
					.setPositiveButton("是",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									
									finish();
									
								}
							})
					.setNegativeButton("否",
							new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface dialog,
										int which) {

								}
							});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if(DataManager.isLoadFinished){
		getWindowManager().getDefaultDisplay().getMetrics(mt);
		widthPixels = mt.widthPixels;
		DataManager.width=widthPixels;
		DataManager.height=mt.heightPixels;

		if(DataManager.curView==DataManager.curView_shelf_shelfListView){

			
			shelfView.onConfigurationChanged(newConfig);
			
			
		}else if(DataManager.curView==DataManager.curView_recentView){
		
			recentView.onConfigurationChanged(newConfig);
			}
		}
		
	}

	public void run() {
		DataManager.ininData(getApplicationContext());
		
	}

	@Override
	protected void onStop() {
		SharedPreferences userInfo=TxtManagerActivity.activity.getSharedPreferences("Cities",0);  
		SharedPreferences.Editor userInfoEditor=userInfo.edit();  
		userInfoEditor.putInt("compare_style", DataManager.compare_style);
		userInfoEditor.putInt("compare_order", DataManager.compare_order);
		userInfoEditor.commit();
		super.onStop();
	}

	

}