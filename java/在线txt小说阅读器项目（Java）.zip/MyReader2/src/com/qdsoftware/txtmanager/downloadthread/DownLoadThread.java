package com.qdsoftware.txtmanager.downloadthread;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.data.BookObject;
import com.qdsoftware.txtmanager.util.DBHelp;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class DownLoadThread extends Thread {
	URL url;
	File file;
	DBHelp db;
	Context context;
	public DownLoadThread(Context context,URL url,File file){
		this.context=context;
		this.url=url;
		this.file=file;
		db=new DBHelp(context);

	}
	@Override
	public void run() {
		HttpURLConnection con=null;
		BufferedInputStream bis=null;
		BufferedOutputStream bos=null;
		byte [] buffer=new byte[1024];
		int len=0;
		try {
			con=(HttpURLConnection) url.openConnection();
			bis=new BufferedInputStream(con.getInputStream());
			bos=new BufferedOutputStream(new FileOutputStream(file));
			while((len=bis.read(buffer))!=-1){
				bos.write(buffer, 0, len);
			}
			bos.flush();
			bis.close();
			bos.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		mHandler.sendEmptyMessage(0);
		BookObject book=new BookObject(file.getAbsolutePath(), file.getName(), "暂无", System.currentTimeMillis(),""+ file.length(), 0, 0);
		book.setBookCorver(DataManager.getBookCorver(file.getName()));
		DataManager.allBookCorver.add(book);
		db.insert(book);
		super.run();
	}
	private Handler mHandler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			Toast.makeText(TxtManagerActivity.activity, file.getName()+"下载完成，路径"+file.getAbsolutePath(), Toast.LENGTH_LONG).show();
			super.handleMessage(msg);
		}
		
	};

}
