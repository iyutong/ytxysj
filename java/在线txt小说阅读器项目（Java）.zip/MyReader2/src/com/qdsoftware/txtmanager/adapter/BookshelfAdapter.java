package com.qdsoftware.txtmanager.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.data.BookObject;
import com.qdsoftware.txtmanager.util.DBHelp;
import com.qdsoftware.txtmanager.util.DataManager;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BookshelfAdapter extends BaseAdapter {
	private ArrayList<BookObject> bookCover;
	private Context context;
	private LayoutInflater inflater;
	private int panding;
	private int count;
	private int bookid=-1;
	private int length;
	private BookObject book;
	private DBHelp db;
	private long lastTime;
	private BookMsgDialog bookMsgDialog;
	private RenameDialog renameDialog;
	private AlertDialog.Builder builder;
	private AlertDialog dialog;
	
	
	public void inin(){
		if(bookCover.size()!=0){
			count = DataManager.width/((bookCover.get(0).getBitmap().getWidth())+30);
			panding=(DataManager.width-count*(bookCover.get(0).getBitmap().getWidth()))/(2*count);
		}else{
			count = 1;
		}
		length = bookCover.size()==0?0:((bookCover.size()%count==0)?bookCover.size()/count:bookCover.size()/count+1);
		
	}


	public BookshelfAdapter(Context context, ArrayList<BookObject> bookCover) {
		this.context = context;
		db=new DBHelp(context);
		this.bookCover = DataManager.allBookCorver;
		inflater = LayoutInflater.from(context);
		builder=new AlertDialog.Builder(TxtManagerActivity.activity);
		inin();
		
	}

	public int getCount() {
		return length<5?5:length;
	}

	public Object getItem(int position) {
		return bookCover.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		int n=0;
		if (convertView == null) {
			holder = new Holder();
			convertView = inflater.inflate(R.layout.bookshelflayout, null);
			holder.layout = (LinearLayout) convertView
					.findViewById(R.id.bbokshelflayout);
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();

		}
		holder.layout.removeAllViews();
		if(position<=((bookCover.size()/count)-1)){
			n=count;

		}else if(position==(bookCover.size()/count)){
			
			n=bookCover.size()%count;
}
		for (int i = 0; i <n; i++) {
			holder.bookCorver = new ImageView(context);
			holder.bookCorver.setPadding(panding, 29, panding, 0);//
			holder.bookCorver.setId(position*count+i);
			holder.bookCorver.
					setImageBitmap(bookCover.get(position*count+i).getBitmap());
			holder.bookCorver.setOnLongClickListener(new OnLongClickListener() {
				
				public boolean onLongClick(View v) {
					final int id=v.getId();
					if(!new File(DataManager.allBookCorver.get(id).getmAbspath()).exists()){
						db.del(DataManager.allBookCorver.get(id));
						
						DataManager.allBookCorver.remove(id);
						Collections.sort(DataManager.allBookCorver);
						
						notifyDataSetChanged();
						Toast.makeText(context, "文件不存在", Toast.LENGTH_SHORT).show();
						return true;
					}
					
					bookMsgDialog=new BookMsgDialog(TxtManagerActivity.activity,R.style.dialog);
			
					bookMsgDialog.setCanceledOnTouchOutside(true);//设置点击Dialog外部任意区域关闭Dialog
					bookMsgDialog.show();
					WindowManager.LayoutParams params = bookMsgDialog.getWindow()   
			                .getAttributes();   
			        params.width =400;   
			        params.height = 300;   
			        params.x = 0;   
			        params.y = 0;    
			        bookMsgDialog.getWindow().setAttributes(params); 
			        ImageView bookcorver=(ImageView) bookMsgDialog.findViewById(R.id.bookcorver);
					
					bookcorver.setImageBitmap(DataManager.allBookCorver.get(id).getBitmap());
					
					TextView _bookname =(TextView) bookMsgDialog.findViewById(R.id.bookname);
					
					_bookname.setText(DataManager.allBookCorver.get(id).getmName());
					
					TextView _bookdate =(TextView) bookMsgDialog.findViewById(R.id.date);
					
					_bookdate.setText(DataManager.framtTime(DataManager.allBookCorver.get(id).getmTimestamp()));
					
					TextView bookname =(TextView) bookMsgDialog.findViewById(R.id.filename);
					
					bookname.setText("文件名称:"+DataManager.allBookCorver.get(id).getmName());
					
					TextView   bookSize=(TextView) bookMsgDialog.findViewById(R.id.filesize);
					
					bookSize.setText("文件大小:"+DataManager.allBookCorver.get(id).getmLength());
					         
					TextView   bookDate=(TextView) bookMsgDialog.findViewById(R.id.filedate);
					
					bookDate.setText("文件日期:"+DataManager.framtTime(DataManager.allBookCorver.get(id).getmTimestamp()));
					         
					TextView   BookPath=(TextView) bookMsgDialog.findViewById(R.id.filepath);
					
					BookPath.setText("文件路径:"+DataManager.allBookCorver.get(id).getmAbspath());
					
					ImageView del=(ImageView) bookMsgDialog.findViewById(R.id.del);
					
					ImageView rename=(ImageView) bookMsgDialog.findViewById(R.id.rename_view);
					
					ImageView read=(ImageView) bookMsgDialog.findViewById(R.id.read);
					
					read.setOnClickListener(new OnClickListener() {
						
						public void onClick(View v) {
							
							BookObject b=DataManager.allBookCorver.get(id);
							
							book=new BookObject(b.getmAbspath(), b.getmName(), b.getmHanyutopinyin(), b.getmTimestamp(), b.getmLength(), b.getmOpenCount()+1, System.currentTimeMillis());
							
							book.setBookCorver(b.getBitmap());
							
							DataManager.allBookCorver.set(id, book);
							
							db.update(b.getmAbspath(), book);
							
								DataManager.turnTxtReader(context, DataManager.allBookCorver.get(id).getmAbspath());
						
							Collections.sort(DataManager.allBookCorver);
							
							notifyDataSetChanged();
							
							bookMsgDialog.dismiss();
							
						}
					});
					
					rename.setOnClickListener(new OnClickListener() {
						
						public void onClick(View v) {
							View view=inflater.inflate(R.layout.rename, null);
							builder.setView(view);
							final AlertDialog renameDialog=builder.create();
							renameDialog.show();
							
							WindowManager.LayoutParams params = renameDialog.getWindow()   
					                .getAttributes();   
					        params.width = 400;   
					        params.x = 0;   
					        params.y = 0;    
					        renameDialog.getWindow().setAttributes(params); 
							Button btn_yes=(Button) view.findViewById(R.id.yes);
						final EditText rename_edit=(EditText) view.findViewById(R.id.name_textview);
							btn_yes.setOnClickListener(new OnClickListener() {
								
								public void onClick(View v) {
									BookObject bookobj=new BookObject(DataManager.allBookCorver.get(id).getmAbspath(), rename_edit.getText().toString(), DataManager.allBookCorver.get(id).getmHanyutopinyin(), DataManager.allBookCorver.get(id).getmTimestamp(), DataManager.allBookCorver.get(id).getmLength(), DataManager.allBookCorver.get(id).getmOpenCount(), DataManager.allBookCorver.get(id).getmLastTime());
									db.update(DataManager.allBookCorver.get(id).getmAbspath(), bookobj);
									bookobj.setBookCorver(DataManager.getBookCorver(rename_edit.getText().toString()));
									DataManager.allBookCorver.set(id, bookobj);
									renameDialog.dismiss();
									bookMsgDialog.dismiss();
									Collections.sort(DataManager.allBookCorver);
									notifyDataSetChanged();
								}
							});
							Button cancle=(Button) renameDialog.findViewById(R.id.cancle);
							cancle.setOnClickListener(new OnClickListener() {
								
								public void onClick(View v) {

									renameDialog.dismiss();
									
									
								}
							});
							
							
							
						}
					});
					
					del.setOnClickListener(new OnClickListener() {
						
						public void onClick(View v) {
							BookObject delbook=DataManager.allBookCorver.get(id);
							
							DataManager.allBookCorver.remove(id);
							
							db.del(delbook);
							
							Collections.sort(DataManager.allBookCorver);
							
							notifyDataSetChanged();
							
							bookMsgDialog.dismiss();
							
						}
					});
					return false;
				}
			});
			
			holder.bookCorver.setOnClickListener(new OnClickListener() {
				

				public void onClick(View v) {
					if(System.currentTimeMillis()-lastTime<=300){
					bookid=v.getId();
					
					BookObject b=DataManager.allBookCorver.get(bookid);
					
					book=new BookObject(b.getmAbspath(), b.getmName(), b.getmHanyutopinyin(), b.getmTimestamp(), b.getmLength(), b.getmOpenCount()+1, System.currentTimeMillis());
					
					book.setBookCorver(b.getBitmap());
					
					DataManager.allBookCorver.set(bookid, book);
					
					
					db.update(b.getmAbspath(), book);
					if(new File(DataManager.allBookCorver.get(bookid).getmAbspath()).exists()){
						DataManager.turnTxtReader(context, DataManager.allBookCorver.get(bookid).getmAbspath());
					}else{
						DataManager.allBookCorver.remove(bookid);
						db.del(DataManager.allBookCorver.get(bookid));
						Toast.makeText(context, "文件不存在", Toast.LENGTH_SHORT);
					}
					
					
					Collections.sort(DataManager.allBookCorver);
					
					notifyDataSetChanged();
					}
					lastTime=System.currentTimeMillis();
				}
			});
			holder.layout.addView(holder.bookCorver);
	}
		convertView.setBackgroundResource(R.drawable.bookshelfbg);
		return convertView;

	}
	public int getboojkd(){
		return bookid;
	}
	
}
class Holder {
	LinearLayout layout;
	ImageView bookCorver;

}
