package com.qdsoftware.txtmanager.adapter;
import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.util.DataManager;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

public class BookMsgDialog extends AlertDialog {

	public BookMsgDialog(Context context, int theme) {
		super(context, theme);

	}
	public BookMsgDialog(Context context){
		super(context);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bookmsg);
		
	}


}


