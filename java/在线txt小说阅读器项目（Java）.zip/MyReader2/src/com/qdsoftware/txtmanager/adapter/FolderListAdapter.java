package com.qdsoftware.txtmanager.adapter;

import java.io.File;
import java.util.ArrayList;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FolderListAdapter extends BaseAdapter {
	private Context context;
	private ArrayList<File> fileList;
	LayoutInflater inflater;

	public FolderListAdapter(Context context, ArrayList<File> fileList) {
		this.context = context;
		this.fileList = fileList;
		inflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return fileList.size();
	}

	public Object getItem(int position) {
		return position;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		int len;
		if (convertView == null) {
			
			holder = new ViewHolder();
			
			convertView = inflater.inflate(R.layout.folderlistitem, null);
			
			holder.bookImg = (ImageView) convertView
					.findViewById(R.id.fileimage);
			
			holder.filename = (TextView) convertView
					.findViewById(R.id.filename);
			
			holder.fileitems = (TextView) convertView
					.findViewById(R.id.itemcount);
			
			holder.img = (ImageView) convertView.findViewById(R.id.img);
			
			convertView.setTag(holder);
			
		} else {
			
			holder = (ViewHolder) convertView.getTag();
		}
		if (fileList.get(position).isDirectory()) {
			
			holder.bookImg.setImageBitmap(DataManager.filepackge);
			
			holder.filename.setText(fileList.get(position).getName());
			
			len = DataManager.getSonFile(
					fileList.get(position).getAbsolutePath(),
					DataManager.allfileList).size();
			
			holder.fileitems.setText("文件夹  " + len + "  项");
			
		} else if (fileList.get(position).getName().endsWith("txt")) {
			
			holder.filename.setText(fileList.get(position).getName());
			
			holder.bookImg.setImageBitmap(DataManager.txt);
			
			holder.fileitems.setText("文本  " + fileList.get(position).length()
					+ "  byte");
			
		} else {
			
			holder.filename.setText(fileList.get(position).getName());
			
			holder.bookImg.setImageBitmap(DataManager.defult);
		}
		
		holder.img.setImageBitmap(DataManager.img);
		
		return convertView;
	}

}

class ViewHolder {
	ImageView bookImg;
	TextView filename;
	TextView fileitems;
	ImageView img;

}
