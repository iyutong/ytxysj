package com.qdsoftware.txtmanager.adapter;

import java.util.ArrayList;
import java.util.Collections;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.data.BookObject;
import com.qdsoftware.txtmanager.util.DBHelp;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class RecentListViewAdapter extends BaseAdapter {
	int count;
	int w;
	Context context;
	ArrayList<BookObject> bookCorver;
	int len;
	LayoutInflater inflater;
	int paddingleft;
	long lastTime;
	DBHelp db;
	
	public void  inin(){
		db=new DBHelp(context);
		this.w=DataManager.width;
		count= w <= 600 ? 2 : 3;
		
		if(bookCorver.size()!=0){
			
			len=bookCorver.size()/count==0?bookCorver.size()/count:(bookCorver.size()/count)+1;
			
				paddingleft=(w-count*(bookCorver.get(0).getBitmap().getWidth()))/(2*count);
		}
		else{
			len=0;
		}
		
	}
	
	
	public RecentListViewAdapter(Context context , ArrayList<BookObject> bookCorver){
		this.context=context;
		inflater=LayoutInflater.from(context);
		this.bookCorver=bookCorver;
		inin();
		
	}

	public int getCount() {

		return 2;
	}

	public Object getItem(int position) {
		return null;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		int n=0;
		RecentViewHolder holder=null;
		if(convertView==null){
			holder=new RecentViewHolder();
			convertView=inflater.inflate(R.layout.recentlist_item, null);
			holder.layout=(LinearLayout) convertView.findViewById(R.id.recentlistview_item);
			convertView.setTag(holder);
			
		}else{
			holder=(RecentViewHolder) convertView.getTag();
		}
		holder.layout.removeAllViews();
		if(position<=((bookCorver.size()/count)-1)){
			n=count;
			
		}else if(position==bookCorver.size()/count){
			n=bookCorver.size()%count;
			
		}
		for (int i = 0; i <n; i++) {
			if(bookCorver.get(position*count+i).getmLastTime()!=0){
			holder.bookCorver = new ImageView(context);
			holder.bookCorver.setPadding(paddingleft, 29, paddingleft, 0);//
			holder.bookCorver.setId(position*count+i);
			holder.bookCorver.
					setImageBitmap(bookCorver.get(position*count+i).getBitmap());
			
			
			holder.bookCorver.setOnClickListener(new OnClickListener() {
				

				public void onClick(View v) {
					if(System.currentTimeMillis()-lastTime<=300){
					int bookid=v.getId();
					
					BookObject b=DataManager.allBookCorver.get(bookid);
					
					BookObject book=new BookObject(b.getmAbspath(), b.getmName(), b.getmHanyutopinyin(), b.getmTimestamp(), b.getmLength(), b.getmOpenCount()+1, System.currentTimeMillis());
					
					book.setBookCorver(b.getBitmap());
					
					DataManager.allBookCorver.set(bookid, book);
					
					db.update(b.getmAbspath(), book);
					
					DataManager.turnTxtReader(context, DataManager.allBookCorver.get(bookid).getmAbspath());
					
					Collections.sort(DataManager.allBookCorver);
					
					notifyDataSetChanged();
					}
					lastTime=System.currentTimeMillis();
				}
			});
			holder.layout.addView(holder.bookCorver);
			}
	}
			
		convertView.setBackgroundResource(R.drawable.bookshelfbg);
		
		
		return convertView;
	}
	class RecentViewHolder{
		ImageView bookCorver;
		LinearLayout layout;
	}
}
