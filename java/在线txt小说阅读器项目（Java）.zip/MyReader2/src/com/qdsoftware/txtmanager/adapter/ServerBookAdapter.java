package com.qdsoftware.txtmanager.adapter;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.downloadthread.DownLoadThread;
import com.qdsoftware.txtmanager.downxml.DownXml;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ServerBookAdapter extends BaseAdapter {
	Context context;
	ArrayList<DownXml> list;
	LayoutInflater inflater;
	public ServerBookAdapter(Context context,ArrayList<DownXml> list){
		this.context=context;
		this.list=list;
		inflater=LayoutInflater.from(context);
		
	}

	public int getCount() {
		return list.size();
	}

	public Object getItem(int position) {
		return position;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		ServerBookViewHolder holder=null;
		if(convertView==null){
			holder=new ServerBookViewHolder();
			convertView = inflater.inflate(R.layout.serverbook, null);
			holder.textview=(TextView) convertView.findViewById(R.id.server_bookname);
			holder.btn=(Button) convertView.findViewById(R.id.download);
			convertView.setTag(holder);
		}else{
			holder=(ServerBookViewHolder) convertView.getTag();
		}
			holder.textview.setText(list.get(position).getName());
			holder.btn.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
				try {
					File f=new File("mnt/sdcard/"+list.get(position).getName());
					if(!f.exists()){
						try {
							f.createNewFile();
							new	DownLoadThread(context,new URL(list.get(position).getUrl()),f).start();
							
							Log.d("url",list.get(position).getUrl());
							
						} catch (IOException e) {
							e.printStackTrace();
						}
					}else{
						
						Toast.makeText(context, "文件已存在", Toast.LENGTH_SHORT).show();
						
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				} 
					
				}
			});
		return convertView;
	}
	
}
	class ServerBookViewHolder{
		TextView textview;
		Button btn;
	
}
