package com.qdsoftware.txtmanager.adapter;

import java.io.File;

import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.util.DataManager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FileListAdapter extends BaseAdapter {
	private Context context;
	private File[] fileList;
	LayoutInflater inflater;

	public FileListAdapter(Context context, File[] fileList) {
		this.context = context;
		this.fileList = fileList;
		inflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return fileList.length;
	}

	public Object getItem(int position) {
		return position;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		Holder1 holder = null;
		int len;
		if (convertView == null) {
			holder = new Holder1();
			convertView = inflater.inflate(R.layout.listviewadapter, null);
			holder.bookImg = (ImageView) convertView
					.findViewById(R.id.fileimage);
			holder.filename = (TextView) convertView
					.findViewById(R.id.filename);
			holder.fileitems = (TextView) convertView
					.findViewById(R.id.itemcount);
			holder.img = (ImageView) convertView.findViewById(R.id.img);
			convertView.setTag(holder);
		} else {
			holder = (Holder1) convertView.getTag();
		}
		if (fileList[position].isDirectory()) {
			holder.bookImg.setImageBitmap(DataManager.filepackge);
			holder.filename.setText(fileList[position].getName());
			
			if (fileList[position].getAbsoluteFile().listFiles() != null) {
				
				len=0;
			} else {
				len = 0;
			}
			holder.fileitems.setText("Folder  " + len + "  Item");
		} else if (fileList[position].getName().endsWith("txt")) {
			holder.filename.setText(fileList[position].getName());
			holder.bookImg.setImageBitmap(DataManager.txt);
		} else {
			holder.filename.setText(fileList[position].getName());
			holder.bookImg.setImageBitmap(DataManager.defult);
		}
		holder.img.setImageBitmap(DataManager.img);
		return convertView;
	}

}

class Holder1{
	ImageView bookImg;
	TextView filename;
	TextView fileitems;
	ImageView img;

}
