package com.qdsoftware.txtmanager;

import android.app.Activity;
import android.os.Bundle;

public class DownLoadActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onStart() {
		
		
		super.onStart();
	}
	

}
