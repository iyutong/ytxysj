package com.qdsoftware.txtmanager.util;

import java.io.File;
import java.util.ArrayList;

import com.qdsoftware.txtmanager.data.BookObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelp extends SQLiteOpenHelper {
	private Context context;
	private static final String DATABASE_NAME = "txtmanager.db";

    private static final String FILEVIEW_TABLE = "bookstable";

    public static final String KEY_ID = "_id";

    public static final String KEY_ABSPATH = "_abspath";

    public static final String KEY_NAME = "_name";
    
    public static final String KEY_LENTH = "_lenth";

    //insert time
    public static final String KEY_TIMESTAMP = "_timestamp";
    
    public static final String KEY_HANYUTOPINYIN = "_hanyutopinyin";
    
    public static final String KEY_OPENCOUNT = "_opencount";

    //last read time
    public static final String KEY_LASTTIME = "_lasttime";
	public DBHelp(Context context) {
		super(context, DATABASE_NAME, null, 1);
		this.context=context;
	
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String sql = "CREATE TABLE "+ FILEVIEW_TABLE +
				"( _id INTEGER PRIMARY KEY AUTOINCREMENT, "+
				" _name TEXT, _abspath TEXT, "+ 
				" _lenth LONG, _timestamp LONG, "+ 
				" _opencount INTEGER, _lasttime LONG, "+ 
				" _hanyutopinyin VARCHAR(10));";
		db.execSQL(sql);

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		String sql = "DROP TABLE IF EXITS"+FILEVIEW_TABLE;
		db.execSQL(sql);
		onCreate(db);

	}
	public void insert(BookObject book){
		ContentValues values=new ContentValues();
		SQLiteDatabase db=this.getWritableDatabase();
		values.put(KEY_NAME, book.getmName());
		values.put(KEY_ABSPATH, book.getmAbspath());
		values.put(KEY_LENTH, book.getmLength());
		values.put(KEY_TIMESTAMP, book.getmTimestamp());
		values.put(KEY_OPENCOUNT, book.getmOpenCount());
		values.put(KEY_LASTTIME, book.getmLastTime());
		values.put(KEY_HANYUTOPINYIN, book.getmHanyutopinyin());
		db.insert(FILEVIEW_TABLE, null, values);
		db.close();
		this.close();
	}
	
	public void insertBookList(ArrayList<BookObject> bookList){
		ContentValues values=new ContentValues();
		SQLiteDatabase db=this.getWritableDatabase();
		for(int i=0;i<bookList.size();i++){
			values.put(KEY_NAME, bookList.get(i).getmName());
			values.put(KEY_ABSPATH, bookList.get(i).getmAbspath());
			values.put(KEY_LENTH, bookList.get(i).getmLength());
			values.put(KEY_TIMESTAMP, bookList.get(i).getmTimestamp());
			values.put(KEY_OPENCOUNT, bookList.get(i).getmOpenCount());
			values.put(KEY_LASTTIME, bookList.get(i).getmLastTime());
			values.put(KEY_HANYUTOPINYIN, bookList.get(i).getmHanyutopinyin());
			db.insert(FILEVIEW_TABLE, null, values);
		}
		db.close();
		this.close();
	}
	public void del(BookObject book){
		SQLiteDatabase db = this.getWritableDatabase();
		String where = KEY_NAME+"=?";
		String[] whereValues = {book.getmName()};
		db.delete(FILEVIEW_TABLE, where, whereValues);
		db.close();
		this.close();
	}
	public void update(String bookPath,BookObject book){
		ContentValues values=new ContentValues();
		SQLiteDatabase db=this.getWritableDatabase();
		values.put(KEY_NAME, book.getmName());
		values.put(KEY_ABSPATH, book.getmAbspath());
		values.put(KEY_LENTH, book.getmLength());
		values.put(KEY_TIMESTAMP, book.getmTimestamp());
		values.put(KEY_OPENCOUNT, book.getmOpenCount());
		values.put(KEY_LASTTIME, book.getmLastTime());
		values.put(KEY_HANYUTOPINYIN, book.getmHanyutopinyin());
		String where =KEY_ABSPATH+"=?";
		String[] whereValues = {bookPath};
		db.update(FILEVIEW_TABLE, values, where, whereValues);
		db.close();
		this.close();
	}
	public ArrayList<BookObject> getAllBook(){
		String name;
		String absPath;
		String length;
		long timeTamp;
		int openCount;
		long lastTime;
		String hanyutopinyin;
		SQLiteDatabase db=this.getReadableDatabase();
		ArrayList<BookObject> allBookList=new ArrayList<BookObject>();
		String sql="select * from bookstable";
		Cursor cursor=db.rawQuery(sql, null);
		while(cursor.moveToNext()){
			name=cursor.getString(cursor.getColumnIndex(KEY_NAME));
			absPath=cursor.getString(cursor.getColumnIndex(KEY_ABSPATH));
			length=cursor.getString(cursor.getColumnIndex(KEY_LENTH));
			timeTamp=cursor.getLong(cursor.getColumnIndex(KEY_TIMESTAMP));
			openCount=cursor.getInt(cursor.getColumnIndex(KEY_OPENCOUNT));
			lastTime=cursor.getLong(cursor.getColumnIndex(KEY_LASTTIME));
			hanyutopinyin=cursor.getString(cursor.getColumnIndex(KEY_HANYUTOPINYIN));
			BookObject book=new BookObject(absPath, name, hanyutopinyin, timeTamp, length, openCount, lastTime);
			allBookList.add(book);
		}
		cursor.close();
		db.close();
		this.close();
		return allBookList;
	}
	public BookObject getBook(String bookname){
		String name;
		String absPath;
		String length;
		long timeTamp;
		int openCount;
		long lastTime;
		String hanyutopinyin;
		SQLiteDatabase db=this.getReadableDatabase();
		String sql = "select * from "+"bookstable"+" where _name = ?";
		Cursor cursor=db.rawQuery( sql, new String[]{bookname});
		cursor.moveToFirst();
		
		name=cursor.getString(cursor.getColumnIndex(KEY_NAME));
		absPath=cursor.getString(cursor.getColumnIndex(KEY_ABSPATH));
		length=cursor.getString(cursor.getColumnIndex(KEY_LENTH));
		timeTamp=cursor.getLong(cursor.getColumnIndex(KEY_TIMESTAMP));
		openCount=cursor.getInt(cursor.getColumnIndex(KEY_OPENCOUNT));
		lastTime=cursor.getLong(cursor.getColumnIndex(KEY_LASTTIME));
		hanyutopinyin=cursor.getString(cursor.getColumnIndex(KEY_HANYUTOPINYIN));
		BookObject book=new BookObject(absPath, name, hanyutopinyin, timeTamp, length, openCount, lastTime);
		cursor.close();
		db.close();
		this.close();
		return book;
		
	}
	public boolean checkBook(String bookPath){
		SQLiteDatabase db=this.getReadableDatabase();
		String sql = "select * from "+"bookstable"+" where _abspath = ?";
		Cursor cursor=db.rawQuery( sql, new String[]{bookPath});
		boolean b= cursor.moveToFirst();
		cursor.close();
		db.close();
		this.close();
		return b;
		
	}
	public ArrayList<BookObject> getLastSixBooks() {
		String name;
		String absPath;
		String length;
		long timeTamp;
		int openCount;
		long lastTime;
		String hanyutopinyin;
		SQLiteDatabase db = this.getReadableDatabase();
		String sql = "SELECT * FROM bookstable ORDER BY _lasttime DESC limit 0,6";
		ArrayList<BookObject> lastSixBooks = new ArrayList<BookObject>();
		Cursor cursor = db.rawQuery(sql, null);
	
		while(cursor.moveToNext()){
			if(cursor.getLong(cursor.getColumnIndex(KEY_LASTTIME))!=0){
			name=cursor.getString(cursor.getColumnIndex(KEY_NAME));
			absPath=cursor.getString(cursor.getColumnIndex(KEY_ABSPATH));
			length=cursor.getString(cursor.getColumnIndex(KEY_LENTH));
			timeTamp=cursor.getLong(cursor.getColumnIndex(KEY_TIMESTAMP));
			openCount=cursor.getInt(cursor.getColumnIndex(KEY_OPENCOUNT));
			lastTime=cursor.getLong(cursor.getColumnIndex(KEY_LASTTIME));
			hanyutopinyin=cursor.getString(cursor.getColumnIndex(KEY_HANYUTOPINYIN));
			BookObject book=new BookObject(absPath, name, hanyutopinyin, timeTamp, length, openCount, lastTime);
			lastSixBooks.add(book);
			}
		}
		cursor.close();
		db.close();
		this.close();
		return lastSixBooks;
	}
}
