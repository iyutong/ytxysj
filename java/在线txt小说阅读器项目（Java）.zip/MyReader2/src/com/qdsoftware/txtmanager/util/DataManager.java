package com.qdsoftware.txtmanager.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.qdsoftware.txtmanager.R;
import com.qdsoftware.txtmanager.TxtManagerActivity;
import com.qdsoftware.txtmanager.data.BookObject;
import com.qdsoftware.txtmanager.data.ConfigInin;

public class DataManager {
	public static byte compare_style=-1;
	
	public static byte compare_style_name=0;
	
	public static byte compare_style_recentRead=1;
	
	public static byte compare_style_size=2;
	
	public static byte compare_style_time=3;
	
	public static byte compare_order=-1;
	
	public static byte compare_order_up=1;
	
	public static byte compare_order_dowm=0;

	public static ArrayList<File> allfileList;// 所有文件

	public static ArrayList<File> ParentFileList;

	public static String sdCardPath;
	
	public static boolean isLoadFinished;

	public static Bitmap filepackge, txt, defult, img;

	public static Bitmap folderListViewBackImgNomal;

	public static Bitmap folderListViewBackImgActive;

	public static LinearLayout layout;

	public static DBHelp dbHelp;

	private static LayoutInflater inflater;

	private static ArrayList<BookObject> allBook;

	public static ArrayList<BookObject> allBookCorver;

	public static byte curView = -1;

	public static byte curView_shelf_shelfListView = 0;

	public static byte curView_shelf_folderListView = 1;

	public static byte curView_recentView = 2;

	public static byte curView_net = 3;
	
	public static boolean titleMoveFinished=true;



	public static int width;
	public static int height;

	public static File file;

	public static ArrayList<File> refreshFileList(String strPath) {// 通过路径找出所有的文件夹和TXT文件
		ArrayList<File> filelist = new ArrayList<File>();
		File dir = new File(strPath);
		File[] files = dir.listFiles();
		if (files == null)
			return new ArrayList<File>();
		for (int i = 0; i < files.length; i++) {
			if (files[i].canRead() && files[i].canWrite()) {
				if (files[i].isDirectory()) {// 如果是个文件夹
					filelist.add(files[i]);
					filelist.addAll(refreshFileList(files[i].getAbsolutePath()));
				} 
				else {
					if (files[i].getName().endsWith(".txt")) {
						filelist.add(files[i]);
					}
				}
			}
		}
		return filelist;
	}

	public static ArrayList<BookObject> refreshTxtList(ArrayList<File> _filelist) {// 通过路径找出所有的TXT文件
		ArrayList<BookObject> filelist = new ArrayList<BookObject>();
		for (int i = 0; i < _filelist.size(); i++) {
			if (_filelist.get(i).getName().endsWith(".txt")) {
				filelist.add(new BookObject(_filelist.get(i).getAbsolutePath(),
						_filelist.get(i).getName(), "", System
								.currentTimeMillis(), ""
								+ _filelist.get(i).length(), 0, 0));
			}
		}
		return filelist;
	}

	public static ArrayList<File> getSonFile(String parent, ArrayList<File> file) {// 在指定集合中找出所有有相同父目录的File
		ArrayList<File> fileList = new ArrayList<File>();
		for (int i = 0; i < file.size(); i++) {
			if (file.get(i).getParent().equals(parent)) {
				fileList.add(file.get(i));
			}
		}

		return fileList;
	}

	public static void ininBitmap(Context context) { // 初始化
		try {
			ConfigInin.bookCorver_bg=BitmapFactory.decodeStream(
					context.getAssets().open("book_shadow.png"))
					.copy(Bitmap.Config.ARGB_8888, true);
			Canvas c=new Canvas(ConfigInin.bookCorver_bg);
			
			ConfigInin.bookCover = BitmapFactory.decodeStream(
					context.getAssets().open("book_no_cover.png"))
					.copy(Bitmap.Config.ARGB_8888, true);
			
			c.drawBitmap(ConfigInin.bookCover, 2, 2,new Paint());
			

			ConfigInin.bookshelf = BitmapFactory.decodeStream(
					context.getAssets().open("bookshelfbg.png")).copy(
					Bitmap.Config.ARGB_8888, true);

			filepackge = BitmapFactory.decodeStream(context.getAssets().open(
					"default_folder_cover.png"));

			txt = BitmapFactory.decodeStream(context.getAssets().open(
					"default_txt.png"));

			defult = BitmapFactory.decodeStream(context.getAssets().open(
					"default_epub.png"));

			img = BitmapFactory.decodeResource(context.getResources(),
					R.drawable.classficationrightarrow);

			folderListViewBackImgNomal = BitmapFactory.decodeResource(
					context.getResources(),
					R.drawable.categories_bar_exit_unable);

			folderListViewBackImgActive = BitmapFactory.decodeResource(
					context.getResources(),
					R.drawable.categories_bar_exit_active);
			inflater = LayoutInflater.from(context);

			layout = (LinearLayout) inflater.inflate(R.layout.waittxt, null);



		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public static void ininData(Context context){
		isLoadFinished=false;

		String path;
		if (Environment.getExternalStorageDirectory().getParent() == "/") {
			path = Environment.getExternalStorageDirectory()
					.getAbsolutePath();
			file = Environment.getExternalStorageDirectory();
			
		} else {
			path = Environment.getExternalStorageDirectory().getParent();
			file = Environment.getExternalStorageDirectory();

		}


		DataManager.sdCardPath = path;

		DataManager.allfileList = DataManager.refreshFileList(path);

		DataManager.ParentFileList = DataManager.getSonFile(
				file.getParent(), DataManager.allfileList);


		dbHelp = new DBHelp(context);
;
		if (dbHelp.getAllBook().size() == 0) {
			
			allBook = refreshTxtList(DataManager.allfileList);
			
			dbHelp.insertBookList(allBook);

		}else{
		
			allBook = dbHelp.getAllBook();
		
		}
		allBookCorver = getBookShelfBitmap(context, allBook);
		
		SharedPreferences userInfo=TxtManagerActivity.activity.getSharedPreferences("Cities",0);  
		
		SharedPreferences.Editor userInfoEditor=userInfo.edit();  

		compare_style=(byte) userInfo.getInt("compare_style", 0)==-1?0:(byte) userInfo.getInt("compare_style", 0);
		
		compare_order=(byte) userInfo.getInt("compare_order", 0)==-1?0:(byte) userInfo.getInt("compare_order", 0);
		
		userInfoEditor.commit();
		
		isLoadFinished=true;
		
		
	}

	public static ArrayList<BookObject> getBookShelfBitmap(Context context,
		ArrayList<BookObject> bookList) {// 传入书名返回 带名字的书的封面
		ArrayList<BookObject> bookCorverList = new ArrayList<BookObject>();
		Paint p = new Paint();
		p.setTextSize(16);
		for (int i = 0; i < bookList.size(); i++) {
			bookList.get(i).setBookCorver(getBookCorver(bookList.get(i).getmName()));
			bookCorverList.add(bookList.get(i));
		}
		return bookCorverList;
	}

	public static Bitmap getBookCorver(String name) {
		Bitmap b = ConfigInin.bookCorver_bg.copy(Config.ARGB_8888, true);
		Canvas cover = new Canvas(b);
		Paint p = new Paint();
		p.setTextSize(13);
		p.setAntiAlias(true);
	String s=	name.split(".txt")[0];
		if(s.length()>5){
		s=s.substring(0,5) + "...";
		}
		cover.drawText(s, 35, 60, p);
		return b;

	}

	public static void turnTxtReader(Context context, String path) {
		Intent intent = new Intent();
		intent.setData(Uri.parse((path)));
		intent.setComponent(new ComponentName("sf.hmg.turntest",
				"sf.hmg.turntest.TxtReaderActiv"));
		TxtManagerActivity.activity.startActivity(intent);
	}
	public static String framtTime(long milliseconds){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy年MM月dd日");
		sdf.format(new Date(milliseconds));
		
		return sdf.format(new Date(milliseconds));
	}

}
