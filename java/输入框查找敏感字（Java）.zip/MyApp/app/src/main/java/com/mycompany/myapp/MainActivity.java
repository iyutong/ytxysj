package com.mycompany.myapp;

import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.widget.EditText;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.support.v4.widget.TextViewCompatJb;
import android.widget.TextView;
import java.util.*;
import android.view.*;
public class MainActivity extends AppCompatActivity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		final EditText edc= (EditText) findViewById(R.id.activitymainEditText1);
        final TextView iii=(TextView)findViewById(R.id.pppp);

		final Toast toast =  Toast.makeText(this, "土司内容", 1);
		toast.setGravity(Gravity.CENTER,0,0);
		toast.show();
		//延长土司时间
		new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();
                }
            },6000);
		
		
		
		
		
        Button a=(Button)findViewById(R.id.wdc);
        a.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    
                    String u= edc.getText().toString();
                  
                    
                    //判断一些
                    
                    String aa []={"草","草泥马","尼玛","逼"};

                    List<String> list=Arrays.asList(aa);
                    if(list.contains(u)){
                        Toast.makeText(MainActivity.this, "没", Toast.LENGTH_SHORT).show();
                        iii.setText(u);
						
						
						
						
                    }else{

                        Toast.makeText(MainActivity.this, "有", Toast.LENGTH_SHORT).show();
                        String si=u.replace("草","*");//更改
                        iii.setText(si);
                    }
                    
                    
                    
                    //判断单个
              /*      int l=u.indexOf("草泥马");
                    if(l==-1){ //等于-1表示这个字符串中没有o这个字符

                    Toast.makeText(MainActivity.this, "没", Toast.LENGTH_SHORT).show();
                        iii.setText(u);
                    }else{

                        Toast.makeText(MainActivity.this, "有", Toast.LENGTH_SHORT).show();
                        String si=u.replace("草","*");
                      iii.setText(si);
                       
                    }
                    */
                    }
                    });
    }

  
    
  
}
