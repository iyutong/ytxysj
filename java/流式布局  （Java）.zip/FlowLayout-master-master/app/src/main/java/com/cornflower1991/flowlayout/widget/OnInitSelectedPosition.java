package com.cornflower1991.flowlayout.widget;

/**
 * 初始化选择
 * Created by yexiuliang on 2016/7/11.
 */

public interface OnInitSelectedPosition {
    boolean isSelectedPosition(int position);
}
