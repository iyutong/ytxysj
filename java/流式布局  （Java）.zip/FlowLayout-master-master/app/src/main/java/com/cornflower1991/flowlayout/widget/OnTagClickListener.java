package com.cornflower1991.flowlayout.widget;

import android.view.View;

/**
 * 点击
 * Created by yexiuliang on 2016/7/11.
 */
public interface OnTagClickListener {
    void onItemClick(FlowTagLayout parent, View view, int position);
}
