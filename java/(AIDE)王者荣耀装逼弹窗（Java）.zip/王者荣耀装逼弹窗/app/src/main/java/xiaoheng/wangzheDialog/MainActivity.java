package xiaoheng.wangzheDialog;

import android.app.*;
import android.content.pm.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

/*
by_小亨
写于2018.6.16
*/

public class MainActivity extends Activity 
{
	private TextView t,t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		this.requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		t=(TextView)findViewById(R.id.mainTextView1);
		t1=(TextView)findViewById(R.id.mainTextView2);
		t2=(TextView)findViewById(R.id.mainTextView3);
		
		//自定义设置字体样式
		Typeface heng=Typeface.createFromAsset (getAssets(),"xiaohengttf.ttf");
		t.setTypeface(heng);
		t1.setTypeface(heng);
		t2.setTypeface(heng);
    }
}
