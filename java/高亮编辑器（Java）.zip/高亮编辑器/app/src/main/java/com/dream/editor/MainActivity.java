package com.dream.editor;

import android.app.*;
import android.os.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		TextEditor editor=new TextEditor(this);
        setContentView(editor);
		//把焦点放到editor
		editor.requestFocus();
    }
}
