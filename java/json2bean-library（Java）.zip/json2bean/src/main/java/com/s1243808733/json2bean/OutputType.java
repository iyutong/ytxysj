package com.s1243808733.json2bean;

public enum OutputType {
    WHOLE,
    SPLIST,
    ZIP
    ;
}
