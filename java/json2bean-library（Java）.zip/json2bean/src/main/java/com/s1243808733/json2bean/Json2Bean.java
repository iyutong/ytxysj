package com.s1243808733.json2bean;

import com.s1243808733.json2bean.util.FileUtils;
import com.s1243808733.json2bean.util.Utils;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Json2Bean {

    private final Configuration mConfiguration;

    public Json2Bean(Configuration configuration)  {
        this.mConfiguration = configuration;
    }

    public JavaBean toBean(final File file) throws IOException, JSONException {
        return toBean(FileUtils.readFile2String(file));
    }

    public JavaBean toBean(final Reader reader) throws IOException, JSONException  {
        return toBean(FileUtils.read2String(reader));
    }

    public JavaBean toBean(final String json) throws JSONException {
        Object object = null;
        try {
            object = new JSONObject(json);
        } catch (JSONException e) {
            try {
                object = new JSONArray(json);
            } catch (JSONException e2) {
                throw new JSONException("JSON parse failed");
            }
        }
        if (object instanceof JSONObject) {
            return toBean((JSONObject)object);
        } else {
            return toBean((JSONArray)object);
        }
    }

    public JavaBean toBean(final JSONArray ja) throws JSONException  {
        if (ja.length() > 0) {
            final Object object = ja.get(0);
            if (object instanceof JSONObject) {
                return toBean((JSONObject)object);
            } else {
                throw new JSONException("Keyless array conversion is not supported");
            }
        } else {
            return toBean(new JSONObject("{}"));
        }
    }

    public JavaBean toBean(final JSONObject jo) throws JSONException {
        final JavaClass root = createClass(null, mConfiguration.getClassName(), mConfiguration.getRootClassModifiers());
        final JavaClass clazz = parseObject(root, jo);
        final JavaBean bean=new JavaBean(mConfiguration, root, clazz);
        return bean;
    }

    private JavaClass parseObject(final JavaClass parent, final JSONObject jo) throws JSONException {
        Iterator<String> it = jo.keys();
        while (it.hasNext()) {
            final String key= it.next();
            if (Utils.isTrimEmpty(key)) continue;
            final Object value = jo.get(key);
            if (JSONObject.NULL == value && !mConfiguration.isAcceptNullValue()) {
                continue;
            }
            parseObject(parent, key, value, jo);
        }
        return parent;
    }

    private void parseObject(final JavaClass parent, final String key, final Object value, final Object parentValue) throws JSONException {
        if (value instanceof JSONObject) {
            final JSONObject jo = (JSONObject)value;
            handleObject(parent, key, jo, parentValue instanceof JSONArray);
        } else if (value instanceof JSONArray) {
            final JSONArray ja = (JSONArray)value;
            if (ja.length() > 0) {
                parseObject(parent, key, ja.get(0), value);
            } else {
                //empty array []
            }
        } else {
            handleValue(parent, key, value, parentValue instanceof JSONArray, parent.getImportTypes());
        }
    }

    private JavaField createField(final JavaClass parent, final String jsonKey, final Object value, final boolean isJsonArray) {

        final JavaField field = new JavaField()
            .setModifiers(mConfiguration.getFieldModifiers())
            .setKey(jsonKey)
            .setIsArray(isJsonArray);

        field.setType(value);
        if (value instanceof JavaClass) {
            field.setTypeName(((JavaClass)value).getClassName());
        } else {
            field.setTypeName(value.getClass().getSimpleName());
        }

        if (mConfiguration.isUseLongIntegers() && Integer.class == value.getClass()) {
            field.setValue(new Long((Integer)value));
        } else {
            field.setValue(value);
        }

        String fieldName;
        if (Utils.isJavaKeyword(jsonKey)) {
            fieldName = getFieldNeme(parent.getFields(), jsonKey, 1);
        } else if (mConfiguration.isPrettyType()) {
            String prettyType;
            prettyType: {
                boolean isKeepUnderline = true;
                if (mConfiguration.hasAnnotationStyle()) {
                    isKeepUnderline = false;
                }
                prettyType = Utils.getPrettyType(jsonKey, isKeepUnderline, !mConfiguration.hasAnnotationStyle());
            }
            fieldName = getFieldNeme(parent.getFields(), prettyType, 0);
        } else {
            fieldName = jsonKey;
        }

        field.setName(fieldName);
        return field;
    }

    private static String getFieldNeme(final List<JavaField> fields, final String name, final int index) {
        final String fieldName = String.format("%1$s%2$s", name, (index > 0 ?String.valueOf(index): ""));
        for (final JavaField field: fields) {
            if (fieldName.equals(field.getName())) {
                return getFieldNeme(fields, name, index + 1);
            }
        }
        return fieldName;
    }

    private static String getClassNeme(final JavaClass parent, final String name, final int index) {
        final String clsName = String.format("%1$s%2$s", name, (index > 0 ?String.valueOf(index): ""));
        if (clsName.equals(parent.getClassName())) {
            return getClassNeme(parent, name, index + 1);
        }
        List<JavaClass> kinds=parent.getChildClass();
        for (final JavaClass clazz: kinds) {
            if (clsName.equals(clazz.getClassName())) {
                return getClassNeme(parent, name, index + 1);
            }
        }
        return clsName;
    }
    
    private JavaClass createClass(final JavaClass parent, final String className, final int modifiers) {
        final JavaClass clazz = new JavaClass(parent, className, modifiers);
        addBaseImportedTypes(clazz.getImportTypes());

        if (mConfiguration.isMakeClassesParcelable()) {
            clazz.addInterfaces("Parcelable");
        }

        if (mConfiguration.isMakeClassesSerializable()) {
            clazz.addInterfaces("Serializable");
        }

        setPackageName: {
            String pkg = Utils.requireNonNullElse(mConfiguration.getPackageName(), "");
            final List<JavaClass> parents=clazz.getParents();
            final int parentCount = parents.size();
            if (parentCount > 1) {
                final StringBuilder sb=new StringBuilder();
                boolean b = false;
                final int start = parentCount - 2;
                for (int i = start;i >= 0;i--) {
                    if (i != start) {
                        b = !b;
                        if (b) {
                            continue;
                        }
                    }
                    final JavaClass cls = parents.get(i);
                    if (sb.length() != 0) {
                        sb.append(".");   
                    }
                    sb.append(cls.getClassName());
                }
                if (pkg.length() != 0) {
                    pkg += ".";   
                }
                pkg += sb.toString().toLowerCase(Locale.ENGLISH);
            }
            clazz.setPackageName(pkg);
        }

        return clazz;
    }

    private void addBaseImportedTypes(final ImportTypes importTypes) {

        if (mConfiguration.hasAnnotationStyle()) {
            if (mConfiguration.hasAnnotationStyle(AnnotationStyle.GSON)) {
                importTypes.add("com.google.gson.annotations.SerializedName");
            }
            if (mConfiguration.hasAnnotationStyle(AnnotationStyle.FASTJSON)) {
                importTypes.add("com.alibaba.fastjson.annotation.JSONField");
            } 
        }

        if (mConfiguration.isMakeClassesParcelable()) {
            importTypes.add("android.os.Parcel", "android.os.Parcelable");
        }

        if (mConfiguration.isMakeClassesSerializable()) {
            importTypes.add("java.io.Serializable");
        }

    }

    private void handleObject(final JavaClass parent, final String jsonKey, final JSONObject jsonObject, final boolean isArray) throws JSONException {

        final JavaClass javaClass = createClass(parent, null, mConfiguration.getClassModifiers());

        setClassName: {
            String className = Utils.toUpperCaseFirst(jsonKey);
            if (mConfiguration.isPrettyType()) {
                className = Utils.getPrettyType(className, false, true);
            }
            className = getClassNeme(parent, className, 0);
            javaClass.setClassName(className);
        }

        parseObject(javaClass, jsonObject);

        final JavaField field = createField(parent, jsonKey, javaClass, isArray);

        handleField(field, parent.getImportTypes());

        addFieldAndMethod(parent, field);
        parent.addChildClass(javaClass);
    }

    private void handleValue(final JavaClass parent, final String jsonKey, final Object value, final boolean isArray, final ImportTypes importedTypes) {
        final JavaField field = createField(parent, jsonKey, value, isArray);

        if (JSONObject.NULL == value) {
            field.setTypeName("Object");
        } else {
            setTypeNeme: {
                String type;
                final Class<?> valueClass =field.getValue().getClass();

                if (isArray) {
                    if (Utils.isBaseDataTypeWarpper(valueClass)) {
                        type = valueClass.getSimpleName();
                    } else {
                        if (mConfiguration.isUsePrimitiveTypes()) {
                            type = valueClass.getSimpleName();
                        } else {
                            type = Utils.unwarpper(valueClass).getSimpleName();
                        }
                    }
                } else if (Utils.isBaseDataTypeWarpper(valueClass)) {
                    if (mConfiguration.isUsePrimitiveTypes()) {
                        type = valueClass.getSimpleName();
                    } else {
                        type = Utils.unwarpper(valueClass).getSimpleName();
                    }
                } else {
                    type = valueClass.getSimpleName();
                }

                if (mConfiguration.isPrettyType() && !Utils.isBaseDataTypeWarpper(value.getClass())) {
                    field.setTypeName(Utils.getPrettyType(type, false, !mConfiguration.hasAnnotationStyle()));
                } else {
                    field.setTypeName(type);
                }

            }

            handleField(field, importedTypes);
        }
        addFieldAndMethod(parent, field);
    }

    private void handleField(final JavaField field, final ImportTypes importedTypes) {
        if (field.isArray()) {

            importedTypes.add("java.util.List");
            field.setTypeName(String.format("List<%s>", field.getTypeName()));

            if (mConfiguration.isInitializeCollections()) {
                importedTypes.add("java.util.ArrayList");
                field.setValueName("new ArrayList<>()");
            }

            if (mConfiguration.isMakeClassesParcelable()) {
                final Object value = field.getValue();
                final Class<?> valueClass = value.getClass();
                if (JavaClass.class == valueClass
                    || String.class == valueClass
                    || Utils.isBaseDataTypeWarpper(valueClass)) {
                    importedTypes.add("java.util.ArrayList");
                }
            }

        }
    }

    private void addFieldAndMethod(final JavaClass clazz, final JavaField field) {

        final String fieldType = field.getTypeName();
        final String fieldName = field.getName();

        clazz.addField(field);

        if (mConfiguration.isUseSetter()) {

            final JavaMethod method=new SetterMethod(field)
                .setModifiers(mConfiguration.getMethodModifiers())
                .addStatement(String.format("this.%1$s = %2$s", fieldName, fieldName));

            method.setParameters(new MethodParameter(fieldType, fieldName));

            setMethodName: {
                String methodName = Utils.toUpperCaseFirst(fieldName);
                if (mConfiguration.isPrettyType()) {
                    methodName = Utils.getPrettyType(methodName, false, true);
                }
                method.setName("set" + methodName);
            }

            if (mConfiguration.isUseReturnThis()) {
                method.setType(clazz.getClassName());
                method.addStatement("return this");
            } else {
                method.setType("void");
            }

            clazz.addMethod(method);

        }

        if (mConfiguration.isUseGetter()) {

            final JavaMethod method = new GetterMethod(field)
                .setModifiers(mConfiguration.getMethodModifiers())
                .setType(field.getTypeName())
                .addStatement(String.format("return %s", fieldName));

            setMethodName: {
                String methodName=Utils.toUpperCaseFirst(fieldName);
                if (mConfiguration.isPrettyType()) {
                    methodName = Utils.getPrettyType(methodName, false, true);
                }
                method.setName(String.format("%1$s%2$s", field.getValue() instanceof Boolean ?"is": "get", methodName));
            }

            clazz.addMethod(method);
        }

    }

    private static abstract class FieldMethod extends JavaMethod {

        private JavaField field;

        public FieldMethod(JavaField field) {
            this.field = field;
        }

        public boolean hasField() {
            return field != null;
        }

        public void setField(JavaField field) {
            this.field = field;
        }

        public JavaField getField() {
            return field;
        }
    }

    private static class SetterMethod extends FieldMethod {
        public SetterMethod(JavaField field) {
            super(field);
        }
    }

    private static class GetterMethod extends FieldMethod {
        public GetterMethod(JavaField field) {
            super(field);
        }
    }

    public static class Builder extends Configuration {

        public Builder() {
            super();
        }

        public Builder(String className) {
            this.className = className;
        }

        public Builder(String packageName, String className) {
            this.packageName = packageName;
            this.className = className;
        }

        public Builder setRootClassModifiers(int rootClassModifiers) {
            this.rootClassModifiers = rootClassModifiers;
            return this;
        }

        public Builder setClassModifiers(int classModifiers) {
            this.classModifiers = classModifiers;
            return this;
        }

        public Builder setFieldModifiers(int fieldModifiers) {
            this.fieldModifiers = fieldModifiers;
            return this;
        }

        public Builder setMethodModifiers(int methodModifiers) {
            this.methodModifiers = methodModifiers;
            return this;
        }

        public Builder setPackageName(String packageName) {
            this.packageName = packageName;
            return this;
        }

        public Builder setClassName(String className) {
            this.className = className;
            return this;
        }

        public Builder setUseGetter(boolean useGetter) {
            this.useGetter = useGetter;
            return this;
        }

        public Builder setUseSetter(boolean useSetter) {
            this.useSetter = useSetter;
            return this;
        }

        public Builder setUseInteger(boolean useInteger) {
            this.useInteger = useInteger;
            return this;
        }

        public Builder setOverrideToString(boolean overrideToString) {
            this.overrideToString = overrideToString;
            return this;
        }

        public Builder setUseReturnThis(boolean useReturnThis) {
            this.useReturnThis = useReturnThis;
            return this;
        }

        public Builder setPrettyType(boolean prettyType) {
            this.prettyType = prettyType;
            return this;
        }

        public Builder setAcceptNullValue(boolean acceptNullValue) {
            this.acceptNullValue = acceptNullValue;
            return this;
        }

        public Builder setInitializeCollections(boolean initializeCollections) {
            this.initializeCollections = initializeCollections;
            return this;
        }

        public Builder setMakeClassesParcelable(boolean makeClassesParcelable) {
            this.makeClassesParcelable = makeClassesParcelable;
            return this;
        }

        public Builder setMakeClassesSerializable(boolean makeClassesSerializable) {
            this.makeClassesSerializable = makeClassesSerializable;
            return this;
        }

        public Builder setUsePrimitiveTypes(boolean usePrimitiveTypes) {
            this.usePrimitiveTypes = usePrimitiveTypes;
            return this;
        }

        public Builder setUseLongIntegers(boolean useLongIntegers) {
            this.useLongIntegers = useLongIntegers;
            return this;
        }

        public Builder setOverrideEquals(boolean overrideEquals) {
            this.overrideEquals = overrideEquals;
            return this;
        }

        public Builder setOverrideHashCode(boolean overrideHashCode) {
            this.overrideHashCode = overrideHashCode;
            return this;
        }

        public Builder addAnnotationStyle(AnnotationStyle... annotationStyles) {
            for (AnnotationStyle annotationStyle:annotationStyles) {
                this.annotationStyle.put(annotationStyle, annotationStyle);
            }
            return this;
        }

        public Builder removeAnnotationStyle(AnnotationStyle annotationStyle) {
            this.annotationStyle.remove(annotationStyle);
            return this;
        }

        public Builder build() {
            return this;
        }

        public Json2Bean create() {
            return new Json2Bean(this);
        }

    }

}
