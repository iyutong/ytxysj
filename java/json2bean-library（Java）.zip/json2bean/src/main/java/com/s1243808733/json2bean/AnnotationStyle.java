package com.s1243808733.json2bean;

public enum AnnotationStyle {
    GSON,
    FASTJSON,
    ;
}

