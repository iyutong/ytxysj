package com.s1243808733.json2bean;

import com.s1243808733.json2bean.util.Utils;
import java.util.Collection;
import java.util.LinkedHashMap;

public class ImportTypes {

    private final LinkedHashMap<String,String> mImportedTypes = new LinkedHashMap<>();

    public ImportTypes add(final String importType) {
        if (!Utils.isTrimEmpty(importType)) {
            mImportedTypes.put(importType, importType);   
        }
        return this;   
    }

    public ImportTypes add(final String... types) {
        for (final String type:types) {
            add(type);
        }
        return this;
    }

    public ImportTypes add(final Collection<String> types) {
        return add(types.toArray(new String[]{}));
    }

    public Collection<String> values() {
        return mImportedTypes.values();   
    }
   
}
