package com.s1243808733.json2bean;

import java.lang.reflect.Modifier;
import java.util.LinkedHashMap;

public class Configuration {

    protected int rootClassModifiers;

    protected int classModifiers;

    protected int fieldModifiers;

    protected int methodModifiers;

    protected String packageName;

    protected String className;

    protected boolean useSetter;

    protected boolean useGetter;

    protected boolean useInteger;

    protected boolean useReturnThis;

    protected boolean overrideToString;

    protected boolean prettyType;

    protected boolean acceptNullValue;

    protected boolean initializeCollections;

    protected boolean makeClassesParcelable;

    protected boolean makeClassesSerializable;

    protected boolean usePrimitiveTypes;

    protected boolean useLongIntegers;

    protected boolean overrideEquals;

    protected boolean overrideHashCode;

    protected LinkedHashMap<AnnotationStyle,AnnotationStyle> annotationStyle = new LinkedHashMap<>();

    public Configuration() {
        setDefValue();   
    }

    private void setDefValue() {
        
        rootClassModifiers = Modifier.PUBLIC;
        classModifiers = Modifier.PUBLIC | Modifier.STATIC;
        fieldModifiers = Modifier.PRIVATE;
        methodModifiers = Modifier.PUBLIC;

        useSetter = true;
        useGetter = true;
        useReturnThis = false;
        prettyType = true;
        
    }

    public boolean hasAnnotationStyle(AnnotationStyle clazz) {
        return  hasAnnotationStyle() && annotationStyle.containsKey(clazz);
    }

    public boolean hasAnnotationStyle() {
        return annotationStyle != null && !annotationStyle.isEmpty();
    }

    public boolean isOverrideEquals() {
        return overrideEquals;
    }

    public boolean isOverrideHashCode() {
        return overrideHashCode;
    }

    public boolean isUseLongIntegers() {
        return useLongIntegers;
    }

    public boolean isUsePrimitiveTypes() {
        return usePrimitiveTypes;
    }

    public boolean isMakeClassesSerializable() {
        return makeClassesSerializable;
    }

    public boolean isPrettyType() {
        return prettyType;
    }

    public boolean isMakeClassesParcelable() {
        return makeClassesParcelable;
    }

    public boolean isInitializeCollections() {
        return initializeCollections;
    }

    public boolean isAcceptNullValue() {
        return acceptNullValue;
    }

    public int getClassModifiers() {
        return classModifiers;
    }

    public int getRootClassModifiers() {
        return rootClassModifiers;
    }

    public int getFieldModifiers() {
        return fieldModifiers;
    }

    public int getMethodModifiers() {
        return methodModifiers;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getClassName() {
        return className;
    }

    public boolean isUseSetter() {
        return useSetter;
    }

    public boolean isUseGetter() {
        return useGetter;
    }

    public boolean isUseInteger() {
        return useInteger;
    }

    public boolean isUseReturnThis() {
        return useReturnThis;
    }

    public boolean isOverrideToString() {
        return overrideToString;
    }
    
}
