package xiaoheng.Snackbar;

import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import xiaoheng.Snackbar.*;

public class MainActivity extends AppCompatActivity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button button=(Button)findViewById(R.id.mainButton1);
		button.setOnClickListener(new OnClickListener()
		{
				@Override
				public void onClick(View p1)
				{
					//按钮点击事件
					
					
					
					/*******核心代码↓*******/
					
					CoordinatorLayout layout = (CoordinatorLayout) findViewById(R.id.mainCoordinatorLayout1);
					Snackbar.make(layout,"小亨最帅", Snackbar.LENGTH_LONG)
					.setAction("嗯！", new View.OnClickListener()
						{
							@Override
							public void onClick(View p1)
							{
								//Snackbar提示的点击事件
								Toast.makeText(MainActivity.this,"你点击了",Toast.LENGTH_SHORT).show();
							}
						}).show();
						
					/*******核心代码↑******/
					
					
					
				}
			});
    }
}


/****************************************
 *      2017.10.29                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/

