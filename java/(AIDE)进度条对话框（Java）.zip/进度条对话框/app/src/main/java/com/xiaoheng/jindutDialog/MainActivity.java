package com.xiaoheng.jindutDialog;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;
import android.net.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button mainbutton = (Button) findViewById( R . id . mainButton1);
		mainbutton .setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					// 待办事项：实现这个方法
					try{
					startActivity( new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
					}catch(Exception e)
					{
						Toast.makeText(MainActivity.this,"打开QQ异常",Toast.LENGTH_SHORT).show();
					}
				}
			});
		
    }
	
	
	
	public void button (View view)
	{
		//样式1的点击事件
		ProgressDialog prodialog=(new ProgressDialog(this));//构建对话框
		prodialog.setIcon(R.drawable.ic_launcher);//设置图标
		prodialog.setTitle("进度条Dialog");//设置标题
		prodialog.setMessage("正在下载………");//设置内容
		prodialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);//设置进度条样式
		prodialog.show();//显示出来
		}
		
		
		public void button1(View view)
		{
			//样式2的点击事件
			ProgressDialog prodialog2=(new ProgressDialog(this));//构建对话框
			prodialog2.setIcon(R.drawable.ic_launcher);//设置图标
			prodialog2.setTitle("进度条Dialog");//设置标题
			prodialog2.setMessage("正在下载………");//设置内容
			prodialog2.setProgressStyle(ProgressDialog.STYLE_SPINNER);//设置进度条样式
			prodialog2.show();//显示出来
		}
	
	
}




/*小亨示例
2017.8.9
QQ:1919196455
*/
