import java.io.*;
import rose.decompile.XmlDecompiler;

public class Main
{
	public static void main(String[] args) throws IOException
	{
		System.out.println(
			XmlDecompiler.newInstance().decompile(
			new File("/storage/emulated/0/main.xml")
		));
		
		
		
	}
	
}
