/*
 *Powered By Rose
 *QQ:2073412493
 *转载和引用请注明出处
 *基本原理：android.content.res.XmlBlock
 */

package rose.decompile;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.io.IOException;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class XmlDecompiler
{
	private boolean mExtraWhiteSpace;
	
	private ArrayList<String> mNameSpaces;
	
	//private access for construtor,users must use static method to create it
	private XmlDecompiler(){
		mNameSpaces = new ArrayList<String>();
		mExtraWhiteSpace = false;
	}
	
	//make a new instance
	public static XmlDecompiler newInstance(){
		return new XmlDecompiler();
	}
	
	//decompile target file which is compiled to binary xml file
	public String decompile(File sourceFile) throws IOException {
		
		FileInputStream fis = new FileInputStream(sourceFile);
		try{
			byte[] bytes = new byte[fis.available()];
			fis.read(bytes);
			fis.close();
			return decompile(bytes);
		}catch(IOException e){
			fis.close();
			throw e;
		}
	}
	
	//decompile for bytes from a binary xml file
	public synchronized String decompile(byte[] source){
		//clear the name spaces that add by last time to prevent error in adding name space to the final content
		mNameSpaces.clear();
		try{
			//create XmlBlock Instance
			Class<?> block_class = Class.forName("android.content.res.XmlBlock");
			Constructor block_cons = block_class.getDeclaredConstructor(byte[].class);
			block_cons.setAccessible(true);
			Object block = block_cons.newInstance(source);
			
			//create xml parser
			XmlPullParser parser = (XmlPullParser) getDecMethod(block_class,"newParser").invoke(block);
			
			//get the result and add xml name spaces
			StringBuilder sb = new StringBuilder(getAll(parser));
			int start = sb.indexOf("<",39);
			if(start != -1){
				start = sb.indexOf("\n",start);
				for(int i= 0;i < mNameSpaces.size();i++){
					String nsuri = mNameSpaces.get(i);
					String nstr = "\nxmlns:" + nsuri.substring(nsuri.lastIndexOf("/")+1,nsuri.length()) + "=\"" + nsuri + "\"";
					sb.replace(start,start,nstr);
				}
			}
			
			//format xml and return
			return format(sb.toString());
		}catch(ClassNotFoundException|NoSuchMethodException|
				InvocationTargetException|IllegalAccessException|
				InstantiationException|SecurityException|IOException|XmlPullParserException e){
			if(e.getCause() instanceof IllegalArgumentException){
				throw new DecompileException("the file is not a binary xml file,we were unable to decompile");
			}
			throw new DecompileException(e);
		}
	}
	
	//get all contents
	private String getAll(XmlPullParser xpp) throws XmlPullParserException,IOException{
		StringBuilder sb = new StringBuilder();
		
		while(true){
			int token = xpp.next();
			sb.append(getContent(xpp,token)).append(mExtraWhiteSpace ? "\n\n" : "\n");
			
			if(token == xpp.END_DOCUMENT){
				break;
			}
		}
		
		return sb.toString();
	}
	
	//get current content for token 
	private String getContent(XmlPullParser xpp,int token){
		String str;
		switch(token){
			case XmlPullParser.START_DOCUMENT:
				str = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
				break;
			case XmlPullParser.END_DOCUMENT:
				str = "";
				break;
				//we do not need to use it
			/*case XmlPullParser.COMMENT:
				str = "<!--" + xpp.getText() + "-->";
				break;*/
			case XmlPullParser.TEXT:
			case XmlPullParser.IGNORABLE_WHITESPACE:
				str = xpp.getText();
				break;
			case XmlPullParser.START_TAG:
				str = "<" + xpp.getName();
				for(int i = 0;i < xpp.getAttributeCount();i++){
					str += "\n";
					String ns = xpp.getAttributeNamespace(i);
					if(ns == null || ns == ""){
						
					}else{
						if(!mNameSpaces.contains(ns)){
							mNameSpaces.add(ns);
						}
						str += ns.substring(ns.lastIndexOf("/") + 1,ns.length()) + ":";
					}
					str +=xpp.getAttributeName(i) + "=\"" + attrString(xpp.getAttributeValue(i)) + "\"";
				}
				str += ">";
				break;
			case XmlPullParser.END_TAG:
				str = "</" + xpp.getName() + ">";
				break;
			default:
				str = "";
		}
		return str;
	}
	
	//format the xml source
	private String format(String str){
		StringBuilder sb = new StringBuilder();
		String[] lines = str.split("\n");
		sb.append(lines[0]).append('\n');
		int space = -1;
		for(int i =1;i < lines.length;i++){
			if(lines[i].startsWith("<")&&!lines[i].startsWith("</")){
				space++;
			}
			String pre = "";
			for(int s = !lines[i].startsWith("<") ? -1 :0;s < space;s++){
				pre += "	";
			}
			sb.append(pre).append(lines[i]).append('\n');
			if(lines[i].endsWith("/>")||lines[i].startsWith("</")){
				space--;
			}
		}
		return sb.toString();
	}
	
	//to format attr strings and make it more readable
	private String attrString(String value){
		if(Pattern.matches("[@|\\?][0-9]+",value)){
			String prefix = value.substring(0,1);
			String numStr = Long.toHexString(Long.parseLong(value.substring(1))).toUpperCase();
			for(;numStr.length() < 8;){
				numStr = "0" + numStr;
			}
			return prefix + numStr;
		}
		
		if(Pattern.matches("0x[0-9|a-f|A-F]+",value)){
			String numStr = value.substring(2);
			for(;numStr.length() < 8;){
				numStr = "0" + numStr;
			}
			return "0x" + numStr.toUpperCase();
		}
		
		if(Pattern.matches("[0-9]+\\.0dip",value)){
			String num = value.substring(0,value.lastIndexOf("."));
			return num+"dp";
		}
		
		return value;
	}
	
	//get a declared method in a class and set accessible for it
	private Method getDecMethod(Class<?> clas,String name,Class<?>... classes) throws NoSuchMethodException{
		Method m = clas.getMethod(name,classes);
		m.setAccessible(true);
		return m;
	}
	
	//if true,will add another enter to each line
	public synchronized void setExtraWhiteSpaceEnabled(boolean is){
		mExtraWhiteSpace = is;
	}
	
	public boolean isExtraWhiteSpaceEnabled(){
		return mExtraWhiteSpace;
	}
}
