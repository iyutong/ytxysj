package rose.decompile;

public class DecompileException extends RuntimeException
{
	public DecompileException(){
		super();
	}
	
	public DecompileException(Throwable cause){
		super(cause);
	}
	
	public DecompileException(String msg){
		super(msg);
	}
	
	public DecompileException(String msg,Throwable cause){
		super(msg,cause);
	}
}
