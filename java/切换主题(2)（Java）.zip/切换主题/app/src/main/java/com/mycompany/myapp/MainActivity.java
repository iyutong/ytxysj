package com.mycompany.myapp;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.graphics.*;

public class MainActivity extends Activity 
{
	private SharedPreferences sp;
	
	private Boolean a=true;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		super.onCreate(savedInstanceState);
		sp=getSharedPreferences("abc",MODE_MULTI_PROCESS);
		if(sp.getBoolean("a",true)==true)
		{
			setTheme(R.style.first);
			getWindow().setStatusBarColor(MainActivity.this.getResources().getColor(R.color.first));
			getWindow().setNavigationBarColor(MainActivity.this.getResources().getColor(R.color.first));
			setContentView(R.layout.main);
		}
		else
		{
			setTheme(R.style.second);
			getWindow().setStatusBarColor(MainActivity.this.getResources().getColor(R.color.second));
			getWindow().setNavigationBarColor(MainActivity.this.getResources().getColor(R.color.second));
			setContentView(R.layout.main);
		}
		getActionBar().hide();
    }
	public void abc(View v)
	{
		if(sp.getBoolean("a",true)==true)
		{
			sp.edit().putBoolean("a",false).commit();
			Intent in=getIntent();
			in.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			finish();
			startActivity(in);
		}
		else
		{
			sp.edit().putBoolean("a",true).commit();
			Intent in=getIntent();
			in.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			finish();
			startActivity(in);
		}
	}
}
