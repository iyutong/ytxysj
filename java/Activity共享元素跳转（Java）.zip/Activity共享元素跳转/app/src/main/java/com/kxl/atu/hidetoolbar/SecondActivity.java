package com.kxl.atu.hidetoolbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.app.Activity;

import com.dingmouren.fallingview.FallingView;

public class SecondActivity extends Activity {

    FallingView fallingView;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
       
    }
}
