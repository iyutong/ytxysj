package com.mycompany.myapp4;
 
import android.app.Activity;
import android.os.Bundle;
import com.luoye.simpleC.view.TextEditor;
import com.myopicmobile.textwarrior.common.LanguageCpp;
import com.myopicmobile.textwarrior.common.LanguagePHP;
import com.myopicmobile.textwarrior.common.Lexer;
import com.myopicmobile.textwarrior.common.LanguageLua;

public class MainActivity extends Activity { 
    private TextEditor mEditor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mEditor = super.findViewById(R.id.mEditor);
        mEditor.setEditorLanguage(LanguageLua.getInstance());
        //Lexer.setLanguage(LanguageLua.getInstance());
    }
	
} 
