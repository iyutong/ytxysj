package xiaoheng.fangerchidabao;

import android.app.*;
import android.content.pm.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		try
		{
			PackageInfo a = getPackageManager().getPackageInfo("xiaoheng.fangerchidabao", PackageManager.GET_SIGNATURES);
			Signature[] b = a.signatures;
			Signature c = b[0];
			int d = c.hashCode();
			if(d!=-2072123462)
			{
				Toast.makeText(this,"被破解",Toast.LENGTH_LONG).show();
			}
			else
			{
				Toast.makeText(this,"未破解",Toast.LENGTH_LONG).show();
			}
		}
		catch (PackageManager.NameNotFoundException e)
		{}
		
		
		/***********注意************
		
		使用自定义签名教程：
		AIDE最右上角那个图标→更多→设置→构建&运行→APK签名
		然后新建一个自己的签名证书，新建完成就OK了，然后再去运行打包就可以防二次打包了
		
		
		绝对不能使用AIDE默认自带的签名，如果使用默认的那么不能实现防二次打包
		
		***************************/
		
		
		
		
		/*
		
		参考上面的例子，改成自己的，就可以用了
		
		try
		{
			PackageInfo a = getPackageManager().getPackageInfo("你当前软件的包名", PackageManager.GET_SIGNATURES);
			Signature[] b = a.signatures;
			Signature c = b[0];
			int d = c.hashCode();
			if(d!=这里写int变量d的值)
			{
				Toast.makeText(this,"被二次打包过",Toast.LENGTH_LONG).show();
			}
			else
			{
				Toast.makeText(this,"未被二次打包过",Toast.LENGTH_LONG).show();
			}
		}
		catch (PackageManager.NameNotFoundException e)
		{}
		*/
		
		
		
		
    }
}



/****************************************
 *      2017.10.22                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
