package com.mycompany.myapp3;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;

public class MainActivity extends Activity 
{
	private Button bn;
	private EditText ex;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		bn=(Button) findViewById(R.id.mainButton1);
		ex=(EditText) findViewById(R.id.mainEditText1);
		bn.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					String mc=ex.getText().toString().trim();
					AlertDialog.Builder vb=new AlertDialog.Builder(MainActivity.this);
					vb.setTitle("提示：");
					vb.setMessage("你输入了："+mc+"\n炫明制作QQ3510088586欢迎加我一起学习，我也是新手哟😄！");
					vb.setIcon(R.drawable.ic_launcher);
					vb.setPositiveButton("确定", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								
								// TODO: Implement this method
							}
						});
					
					
					vb.show();
					
					// TODO: Implement this method
				}
			});		
		

			}
	
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/