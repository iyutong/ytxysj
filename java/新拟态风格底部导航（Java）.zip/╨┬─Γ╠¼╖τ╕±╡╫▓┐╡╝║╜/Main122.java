package com.example.testproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class Main122 extends View {
   private Paint paint,paint1,paint2;

    public Main122(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.parseColor("#FFFFFF"));
        paint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint1.setColor(Color.parseColor("#d1dae2"));
        paint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint2.setColor(Color.parseColor("#E9F3FC"));

        setLayerType(View.LAYER_TYPE_SOFTWARE, paint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        //int w=getDefaultSize(getSuggestedMinimumWidth(),widthMeasureSpec);
        //int h=getDefaultSize(getSuggestedMinimumHeight(),heightMeasureSpec);
        //Log.e("TGA", w+h+"");
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int viewwidth=canvas.getWidth()/2;
        int viewheight=canvas.getHeight()/2;

        int freehwidth=viewwidth/2;
        int freehheight=viewheight/2;


        int spacefreewidth=viewwidth/10;
        int spacefreeheight=viewheight/10;

        int spacewidth=viewwidth-spacefreewidth;
        int spaceheight=viewheight-spacefreeheight;

        Log.e("tga","控件的宽"+viewwidth+"控件的高"+viewheight);
        Log.e("tga","控件外的宽"+freehwidth+"控件外的高"+freehheight);
        Log.e("tga","控件内的宽"+spacefreewidth+"控件内的高"+spacefreeheight);


        int whitewidth=freehwidth+spacefreewidth+spacewidth;
        int whiteheight=freehheight+spacefreeheight+spaceheight;

        paint.setMaskFilter(new BlurMaskFilter(30, BlurMaskFilter.Blur.NORMAL));
        canvas.drawRect(freehwidth-10, freehheight+10, whitewidth-40, whiteheight-40, paint);

        paint1.setMaskFilter(new BlurMaskFilter(30, BlurMaskFilter.Blur.NORMAL));
        canvas.drawRect(freehwidth+spacefreewidth+10, freehheight+spacefreeheight+10, viewwidth+freehwidth+10, viewheight+freehheight+10, paint1);

        RectF rect = new RectF(freehwidth+spacefreewidth-10 , freehheight+spacefreeheight-10, freehwidth+spacefreewidth+spacewidth-10, freehheight+spacefreeheight+spaceheight-10);
        canvas.drawRoundRect(rect, 30f, 30f, paint2);






    }

}
