package com.dream.ecydialog;

import android.app.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final MyDialog myDialog=new MyDialog(this, R.style.MyDialog);
		myDialog.setTitle("警告！");
		myDialog.setMessage("警告：您的手机3秒钟内自爆");
		myDialog.setYesOnclickListener("确定", new MyDialog.onYesOnclickListener() {
				@Override
				public void onYesOnclick() {
					Toast.makeText(getApplicationContext(), "拜拜，我们来生见", Toast.LENGTH_LONG).show();
					myDialog.dismiss();
				}
			});
		myDialog.setNoOnclickListener("取消", new MyDialog.onNoOnclickListener() {
				@Override
				public void onNoClick() {
					Toast.makeText(getApplicationContext(), "明智的选择", Toast.LENGTH_LONG).show();
					myDialog.dismiss();
				}
			});
		myDialog.show();
    }
}
