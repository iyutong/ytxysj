package com.error.encryption;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.error.encryption.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class MainActivity extends Activity implements OnClickListener {
	private TextView xianshi;
    private EditText jiami;
    private EditText jiemi;
    private Button dESjiami;
    private Button mD5jiami;
    private Button uTF_8jiami;
    private Button base64jiami;
    private Button dESjiemi;
    private Button uTF_8jiemi;
    private Button base64jiemi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		xianshi = (TextView) findViewById(R.id.text);
        jiami = (EditText) findViewById(R.id.jiami);
        jiemi = (EditText) findViewById(R.id.jiemi);
        dESjiami = (Button) findViewById(R.id.DESjiami);
        mD5jiami = (Button) findViewById(R.id.MD5jiami);
        uTF_8jiami = (Button) findViewById(R.id.UTF_8jiami);
        base64jiami = (Button) findViewById(R.id.Base64jiami);
        dESjiemi = (Button) findViewById(R.id.DESjiemi);
        uTF_8jiemi = (Button) findViewById(R.id.UTF_8jiemi);
        base64jiemi = (Button) findViewById(R.id.Base64jiemi);
        dESjiami.setOnClickListener(this);
        mD5jiami.setOnClickListener(this);
        uTF_8jiami.setOnClickListener(this);
        base64jiami.setOnClickListener(this);
        dESjiemi.setOnClickListener(this);
        uTF_8jiemi.setOnClickListener(this);
        base64jiemi.setOnClickListener(this);
    }

	@Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        String jiami1 = jiami.getText().toString();
        String jiemi1 = jiemi.getText().toString();
        switch (v.getId()) {
				//DES加密
            case R.id.DESjiami:
                String desjia = encrypt(jiami1);
                xianshi.setText(desjia);
                break;
				//MD5加密
            case R.id.MD5jiami:
                String md5jia = MD5(jiami1, true);

                xianshi.setText(md5jia);
                break;
				//UTF_8  加密
            case R.id.UTF_8jiami:
                try {
                    String utf_8jia = URLEncoder.encode(jiami1, "utf-8");
                    xianshi.setText(utf_8jia);
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
				//BASe64加密
            case R.id.Base64jiami:

                break;
				//DES解密
            case R.id.DESjiemi:
                String desjie = decrypt(jiemi1);
                xianshi.setText(desjie);
                break;
				//UTF_8解密
            case R.id.UTF_8jiemi:
                try {
                    String utf_8jie = URLDecoder.decode(jiemi1, "utf-8");
                    xianshi.setText(utf_8jie);
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
				//Base64解密
            case R.id.Base64jiemi:


                break;

        }
    }


    /**
     * MD5加密
     *
     * @param str
     * @param isUp true是否大写
     * @return
     */
    public static String MD5(String str, boolean isUp) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        char[] charArray = str.toCharArray();
        byte[] byteArray = new byte[charArray.length];

        for (int i = 0; i < charArray.length; i++) {
            byteArray[i] = (byte) charArray[i];
        }
        byte[] md5Bytes = md5.digest(byteArray);

        StringBuffer hexValue = new StringBuffer();
        for (int i = 0; i < md5Bytes.length; i++) {
            int val = (md5Bytes[i]) & 0xff;
            if (val < 16) {
                hexValue.append("0");
            }
            hexValue.append(Integer.toHexString(val));
        }
        if (isUp) {
            return (hexValue.toString()).toUpperCase();
        } else {
            return hexValue.toString();
        }
    }

    public String ALGORITHM_DES = "DES/CBC/PKCS5Padding";

    public String DESKEY = "QpOiUnYbVp3bB73Fsn7O12CX";

    /**
     * DES加密方式
     *
     * @param data
     * @return
     */
    public String encrypt(String data) {
        String str = encrypt(DESKEY, data);
        return str;
    }

    /**
     * DES解密方式
     *
     * @param data
     * @return
     */
    public String decrypt(String data) {

        String str = decrypt(DESKEY, data);
        return str;
    }

    /**
     * DES算法，加密
     *
     * @param data 待加密字符串
     * @param key  加密私钥，长度不能够小于8位
     * @return 加密后的字节数组，一般结合Base64编码使用
     * @throws InvalidAlgorithmParameterException
     * @throws Exception
     */
    public String encrypt(String key, String data) {
        if (data == null)
            return null;
        try {
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            // key的长度不能够小于8位字节
            Key secretKey = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
            AlgorithmParameterSpec paramSpec = iv;
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, paramSpec);
            byte[] bytes = cipher.doFinal(data.getBytes());
            return byte2hex(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            return data;
        }
    }

    /**
     * DES算法，解密
     *
     * @param data 待解密字符串
     * @param key  解密私钥，长度不能够小于8位
     * @return 解密后的字节数组
     * @throws Exception 异常
     */
    public String decrypt(String key, String data) {
        if (data == null)
            return null;
        try {
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            // key的长度不能够小于8位字节
            Key secretKey = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
            AlgorithmParameterSpec paramSpec = iv;
            cipher.init(Cipher.DECRYPT_MODE, secretKey, paramSpec);
            return new String(cipher.doFinal(hex2byte(data.getBytes())));
        } catch (Exception e) {
            e.printStackTrace();
            return data;
        }
    }

    /**
     * 二行制转字符串
     *
     * @param b
     * @return
     */
    private static String byte2hex(byte[] b) {
        StringBuilder hs = new StringBuilder();
        String stmp;
        for (int n = 0; b != null && n < b.length; n++) {
            stmp = Integer.toHexString(b[n] & 0XFF);
            if (stmp.length() == 1)
                hs.append('0');
            hs.append(stmp);
        }
        return hs.toString().toUpperCase();
    }

    private static byte[] hex2byte(byte[] b) {
        if ((b.length % 2) != 0)
            throw new IllegalArgumentException();
        byte[] b2 = new byte[b.length / 2];
        for (int n = 0; n < b.length; n += 2) {
            String item = new String(b, n, 2);
            b2[n / 2] = (byte) Integer.parseInt(item, 16);
        }
        return b2;
    }
}
