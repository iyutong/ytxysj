package com.mycompany.myapp;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.widget.Toast;

public class MainActivity extends Activity 
{
    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		ListView listview = findViewById(R.id.listview);
		// 添加数据
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();

		Map<String,Object> map = new HashMap<String,Object>();
		map.put("text", "本地音乐");
		map.put("image", R.drawable.ic_launcher);
		list.add(map);

		map = new HashMap<String,Object>();
		map.put("text", "本地音乐2");
		map.put("image", R.drawable.ic_launcher);
		// 注意一一对应
		list.add(map);
		// 添加至适配器
		SimpleAdapter adapter = new SimpleAdapter(this,
												  list,
												  R.layout.include_listview_item,
												  new String[]{"image","text"},//注意一一对应
												  new int[]{R.id.includelistviewitemImageView1,R.id.includelistviewitemTextView1});
		listview.setAdapter(adapter);


		// 点击事件
		listview.setOnItemClickListener(new OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					Toast.makeText(MainActivity.this, "你点击的位置是" + p3, Toast.LENGTH_SHORT).show();
				}	
			});

    }

}
