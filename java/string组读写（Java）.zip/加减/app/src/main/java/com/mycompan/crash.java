package com.mycompan;

import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;

public class crash extends Activity
{

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.crash);
		TextView crash=findViewById(R.id.crashTextView);
		crash.setText(APP.crash);
	}
}
