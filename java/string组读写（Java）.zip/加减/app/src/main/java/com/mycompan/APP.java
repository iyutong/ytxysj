package com.mycompan;
import android.app.Application;
import android.kz.Crash.CrashHandler;
import android.widget.Toast;
import android.content.Intent;


public class APP extends Application {
	public static String crash;
	@Override
	public void onCreate() {
		super.onCreate();

		
		CrashHandler.getInstance().initHandler(new CrashHandler.UncaughtExceptionCallBack() {
				@Override
				public void caughtUncaughtException(Thread t, Throwable e) {
					Toast.makeText(getApplicationContext(),"应用出错 异常为"+e.toString(),10).show();
					getApplicationContext().startActivity(new Intent(getApplicationContext(), crash.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

					crash=crash+"\n"+"偶吼吼，抓到错误信息了"+t.getName()+"内容"+e.toString();
					
				}
			});
	}
}
