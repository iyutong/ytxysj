package com.mycompan;
import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.IOException;

public enum datatool

{
	enum初始化;
	public static String[] readdata(String filePath){
		String out="";
		try {
			File file=new File(filePath);
			if(file.isFile() && file.exists()){ //判断文件是否存在
				InputStreamReader read = new InputStreamReader(
					new FileInputStream(file));
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				while((lineTxt = bufferedReader.readLine()) != null){
					out+="\n"+lineTxt;
				}
				read.close();
			}else{
				out="line找不到指定文件";
				
			}
		} catch (Exception e) {
			out="line读取内容出错"+e.getMessage();
			
		}
		
		return out.split("line");
	}
	public static void savedata(String path,String[] text,boolean iscorver) throws IOException {

		File checkFile = new File(path );
		FileWriter writer = null;
		try {
			// 二、检查目标文件是否存在，不存在则创建
			if (!checkFile.exists()) {
				checkFile.createNewFile();// 创建目标文件
			}
			// 三、向目标文件中写入内容
			// FileWriter(File file, boolean append)，append为true时为追加模式，false或缺省则为覆盖模式
			writer = new FileWriter(checkFile, iscorver);
			for(String out:text){
				writer.append(out+"\n");
			}
         writer.append("line"+"\n");
			writer.flush();
		
		} finally {
			if (null != writer)
				writer.close();
		}
	}
}
