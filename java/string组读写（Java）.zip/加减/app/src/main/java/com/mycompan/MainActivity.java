package com.mycompan;

import android.os.Bundle;

import android.graphics.Color;
import android.view.View;
import android.widget.EditText;
import java.io.IOException;
import android.widget.TextView;
import android.app.Activity;
import android.widget.Toast;

public class MainActivity extends Activity {

  EditText a,two;
  datatool tool=datatool.enum初始化;
  TextView b;
  String 路径="/storage/emulated/0/data"+".dat";
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		a=findViewById(R.id.activitymainEditText1);
	b=findViewById(R.id.activitymainTextView1);
		two=findViewById(R.id.activitymainEditText2);
		}
    public void op(View v){
		String[] in=new String[2];//输入框的个数
		in[0]=a.getText().toString().trim();//0对应第一行数据
		in[1]=two.getText().toString().trim();//1对应第二行数据
		//第三，四自己类推
		boolean ishave=false;
		String[] datas= datatool.readdata(路径);
		for(String out:datas){
			
			if(out.indexOf(a.getText().toString().trim())>-1)
			{
				ishave=true;
				b.setText("重复");
				a.setText("");
				break;
			}
		}
		if(!ishave){
			try
			{
				tool.savedata(路径, in, true);
			b.setText("成功");
				}
			catch (IOException e)
			{
				b.setText("失败"+e.getMessage());
			}
		}
	}
	
	public void dr(View v){
		
	String[] datas=	tool.readdata(路径);
	String bean="";
	boolean ishave=false;
		for (int j = 0; j < datas.length; j++) {
			String data = datas[j];
			if(data.indexOf(a.getText().toString().trim())>-1){
				bean=data;
				ishave=true;
				break;
			}
			
		}
		if(ishave)
		b.setText(bean);
		else
		b.setText("没有这个包名");
	}
	
	
}
