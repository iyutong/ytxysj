package com.jk.impl;

public interface onMusicOver {

	 public void onMusicOver();
	
}
