import java.util.*;

public class Main
{
	public static void main(String[] args) throws InterruptedException
	{
		System.out.println("               侯霞小卖部");
		int 余额=10000;
		System.out.println("个人余额：" + 余额);
		//声明商城东西价格/数量
		int 矿泉水=1;
		int 面包=2;
	    int 棒棒糖=1;
		//声明结束
		System.out.print("矿泉水:");
		System.out.println(矿泉水);
		System.out.print("面包:");
		System.out.println(面包);
		System.out.print("棒棒糖:");
		System.out.println(棒棒糖);
		System.out.println("--------------------------------");
		while (true)
		{
			Scanner input= new Scanner(System.in);
			String 物品=input.next();
			
			if (物品.equals("面包"))
			{
				System.out.println("请输入购买数量:");
				Scanner inputs= new Scanner(System.in);
				int 数量=inputs.nextInt();
				int 价格=面包 * 数量;

				if (余额 < 价格)
				{
					System.out.println("-------------系统消息------------");
					System.out.println("余额不足");
					System.out.println("你可以试试'搬砖赚钱'");
					System.out.println("--------------------------------");
				}
				else
				{
					余额 = 余额 - 价格;
					System.out.println("-------------系统消息------------");
					System.out.println("购买成功");
					System.out.println("个人余额：" + 余额);
					System.out.println("--------------------------------");
				}

			}
			else if (物品.equals("矿泉水"))
			{
				System.out.println("请输入购买数量:");
				Scanner inputs= new Scanner(System.in);
				int 数量=inputs.nextInt();
				int 价格=矿泉水 * 数量;

				if (余额 < 价格)
				{
					System.out.println("-------------系统消息------------");
					System.out.println("余额不足");
					System.out.println("你可以试试'搬砖赚钱'");
					System.out.println("--------------------------------");
				}
				else
				{
					余额 = 余额 - 价格;
					System.out.println("-------------系统消息------------");
					System.out.println("购买成功");
					System.out.println("个人余额：" + 余额);
					System.out.println("--------------------------------");
				}
			}
			else if (物品.equals("棒棒糖"))
			{
				System.out.println("请输入购买数量:");
				Scanner inputs= new Scanner(System.in);
				int 数量=inputs.nextInt();
				int 价格=棒棒糖 * 数量;

				if (余额 < 价格)
				{
					System.out.println("-------------系统消息------------");
					System.out.println("余额不足");
					System.out.println("你可以试试'搬砖赚钱'");
					System.out.println("--------------------------------");
				}
				else
				{
					余额 = 余额 - 价格;
					System.out.println("-------------系统消息------------");
					System.out.println("购买成功");
					System.out.println("个人余额：" + 余额);
					System.out.println("--------------------------------");
				}
			}
			else if (物品.equals("剩余余额"))
			{
				System.out.println("-------------系统消息------------");
				System.out.println("个人余额：" + 余额);
				System.out.println("--------------------------------");
			}
			else if (物品.equals("搬砖赚钱"))
			{
				System.out.println("-------------系统消息------------");
				System.out.println("正在搬砖中.....");
				for(int a=3;a>0;a--){
					Thread.sleep(1000);
					System.out.println("请稍等...");
				}
				System.out.println("努力了1个小时，赚了:3000");
				余额=余额+3000;
				System.out.println("--------------------------------");
			}
			else
			{
				System.out.println("-------------系统消息------------");
				System.out.println("该物品商城还未进购");
				System.out.println("--------------------------------");
			}
		}
	}
}
