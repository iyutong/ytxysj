package com.xiaoheng.if_else;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		final EditText a=(EditText)findViewById(R.id.mainEditText);
		Button b=(Button)findViewById(R.id.mainButton);
		final TextView c=(TextView)findViewById(R.id.mainTextView);
		
		b.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View p1)
			{
				
				if(a.getText().toString().equals(""))
				{
					c.setText("空");
					Toast.makeText(MainActivity.this,"你还没有输入",Toast.LENGTH_SHORT).show();
				}
				else if(a.getText().toString().equals("小亨"))
				{
					c.setText("真");
					Toast.makeText(MainActivity.this,"对了",Toast.LENGTH_SHORT).show();
				}
				else
				{
					c.setText("假");
					Toast.makeText(MainActivity.this,"错了",Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		//长按监听器
		b.setOnLongClickListener(new OnLongClickListener(){
				@Override
				public boolean onLongClick(View p1)
				{
					a.setText("小亨");
					//Toast.makeText(MainActivity.this,"请在编辑框输入小亨",Toast.LENGTH_LONG).show();
					return false;
				}
		});
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate main_menu.xml 
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{

		switch(item.getItemId())
		{
			case R.id.item:
				startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
				Toast.makeText(MainActivity.this,"正在转跳到小亨QQ·····",Toast.LENGTH_LONG).show();
		}

		return super.onOptionsItemSelected(item);
	}
	
	
}
/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/