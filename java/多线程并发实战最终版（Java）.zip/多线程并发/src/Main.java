import java.util.*;

public class Main
{
	public static List<String> aa=new ArrayList();
	public static volatile int judge;
	public static int 单次并发数=3;
	public static void main(String[] args)
	{
	  aa.add("1");
	  aa.add("2");
	  aa.add("3");
	  aa.add("4");
	  aa.add("5");
	  aa.add("6");
	  aa.add("7");
	  aa.add("8");
	  aa.add("9");
	  aa.add("10");
	  aa.add("11");
	  aa.add("12");
	  aa.add("13");
	  aa.add("14");
	  aa.add("15");
	  aa.add("16");
	  aa.add("17");
		int excess= aa.size()%单次并发数;//除3取余，这个余用单线程
		//System.out.println(excess);
		int concurrent= aa.size()/单次并发数;//除3取商，这个是执行for的次数
		for (int i=0;i < concurrent;i++) {
			judge=单次并发数;
			for (int num=0;num < 单次并发数;num++) {
           doo(aa.get(i*单次并发数+num));
			}
		   while(judge!=0){
			// System.out.println("阻塞状态");  
		   }
		}//3个3个执行后，剩余的直接用并发解决
		for (int b=0;b< excess;b++) {
			int c=b+ concurrent*单次并发数;
			doo(aa.get(c));
		}
	}
	public static void doo(final String in){
		new Thread(new Runnable(){

				@Override
				public void run()
				{
					Random rand=new Random();
					int sleep= rand.nextInt(5)*100;
					try
					{
						Thread.sleep(0);//产生随机数模拟每个应用安装时间不一致
						System.out.println(in+"处理完成");
						judge--;
					}
					catch (InterruptedException e)
					{
						System.out.println("出错"+e.getMessage());
					}
				}
			}).start();
	}
}
