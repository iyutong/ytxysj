package com.panda.goodlooktoast;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import es.dmoral.toasty.Toasty;
import android.widget.Toast;
import android.graphics.Color;

public class MainActivity extends Activity implements View.OnClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
        findViewById(R.id.a).setOnClickListener(this);
		findViewById(R.id.b).setOnClickListener(this);
		findViewById(R.id.c).setOnClickListener(this);
		findViewById(R.id.d).setOnClickListener(this);
		findViewById(R.id.e).setOnClickListener(this);
		findViewById(R.id.f).setOnClickListener(this);
    }
 
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.a:
				Toasty.success(MainActivity.this, "你好可爱哦", Toast.LENGTH_SHORT, true).show();
            break;
			case R.id.b:
				Toasty.info(MainActivity.this, "你好可爱哦", Toast.LENGTH_SHORT, true).show();
				break;
			case R.id.c:
				Toasty.error(MainActivity.this, "你好可爱哦", Toast.LENGTH_SHORT, true).show();
				break;
			case R.id.d:
				Toasty.warning(MainActivity.this, "你好可爱哦", Toast.LENGTH_SHORT, true).show();
				break;
			case R.id.e:
				Toasty.normal(this, "胖哒最可爱啦".toString(), R.drawable.ic_launcher).show();
				break;
			case R.id.f:
				Toasty.custom(this, "胖哒好可爱".toString(),R.drawable.ic_launcher, Color.BLACK, Color.WHITE, Toast.LENGTH_SHORT, true, true).show();
				break;
            default:
                break;
        }
    }
}
