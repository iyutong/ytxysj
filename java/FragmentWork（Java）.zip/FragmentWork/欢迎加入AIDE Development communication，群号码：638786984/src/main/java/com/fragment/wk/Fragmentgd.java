package com.fragment.wk;
import android.app.*;
import android.os.*;
import android.view.*;

public class Fragmentgd extends Fragment
{

	

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		return inflater.inflate(R.layout.fragmentgd,container,false);
	}
	
}
