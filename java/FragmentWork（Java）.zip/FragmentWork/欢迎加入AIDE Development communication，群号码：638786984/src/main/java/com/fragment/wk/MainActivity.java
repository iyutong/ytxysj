package com.fragment.wk;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.widget.RadioGroup.*;
import android.view.*;





public class MainActivity extends Activity 
{
	private static Fragment nowFragment;
    private RadioButton bn;
	private RadioButton cn;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
		
	    final Fragment fragment1 = new Fragmentxx();
		final Fragment fragment2 = new Fragmentsy();
		final Fragment fragment3 = new Fragmentgd();
		final Fragment fragment4 = new Fragmentfx();

		getFragmentManager().beginTransaction().add(R.id.mainRelativeLayout,fragment1).commit();
		nowFragment = fragment1;
		bn = (RadioButton) findViewById(R.id.mainRadioButton1);
		cn = (RadioButton) findViewById(R.id.mainRadioButton2);
		RadioGroup redioGroup = (RadioGroup) findViewById(R.id.mainRadioGroup);
        redioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(RadioGroup p1, int p2)
				{
					// TODO: Implement this method
					Fragment newFragment = nowFragment;
					FragmentTransaction transaction = getFragmentManager().beginTransaction();

					if(p2==R.id.mainRadioButton1)
					{
						newFragment = fragment1;
						Toast.makeText(MainActivity.this,"this is xx",
						Toast.LENGTH_SHORT).show();
					}
					else if(p2==R.id.mainRadioButton2)
					{
						newFragment = fragment2;
					}
					else if(p2==R.id.mainRadioButton3)
					{
						newFragment = fragment3;
					}
					else if(p2==R.id.mainRadioButton4)
					{
						newFragment = fragment4;
					}
					if(!newFragment.isAdded())
					{
						transaction.hide(nowFragment).add(R.id.mainRelativeLayout,newFragment).commit();

					}
					else 
					{
						transaction.hide(nowFragment).show(newFragment).commit();
					}
					nowFragment = newFragment;
				}
			});
		
    }
}
