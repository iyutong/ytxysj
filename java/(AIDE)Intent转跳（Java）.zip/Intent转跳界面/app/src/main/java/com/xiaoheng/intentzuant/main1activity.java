package com.xiaoheng.intentzuant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class main1activity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// 待办事项：实现这个方法
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main1);
		Button button=(Button)findViewById(R.id.main1Button1);
		button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// 待办事项：实现这个方法
					startActivity(new Intent(main1activity.this,main2activity.class));
					main1activity.this.finish();
				}
			});
	}
	
}
