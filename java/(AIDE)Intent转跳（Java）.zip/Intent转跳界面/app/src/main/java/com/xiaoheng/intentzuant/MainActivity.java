package com.xiaoheng.intentzuant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button button1=(Button)findViewById(R.id.mainButton1);
		button1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// 待办事项：实现这个方法
					startActivity(new Intent(MainActivity.this,main1activity.class));
					MainActivity.this.finish();
				}
			});
    }
}
