# This is an interesting loading animation
![image](https://github.com/BaymaxTong/HouseLoading/blob/master/loading.gif)
