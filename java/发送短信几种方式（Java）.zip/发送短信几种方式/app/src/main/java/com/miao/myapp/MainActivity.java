package com.miao.myapp;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity { 
	private EditText sjhm;
	private EditText dxnr;
	private Button dyxt;
	private Button zjfs;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		setTitle("By 雨夜飞雪");
		//qq 2034792405
		sjhm = findViewById(R.id.activitymainEditText1);
		dxnr = findViewById(R.id.activitymainEditText2);
		dyxt = findViewById(R.id.activitymainButton1);
		zjfs = findViewById(R.id.activitymainButton2);
		dyxt.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1) {
					try {
						Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + sjhm.getText().toString()));
						intent.putExtra("sms_body", dxnr.getText().toString());
						startActivity(intent);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		zjfs.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1) {
					try {
						String msg = dxnr.getText().toString();
						String pho = sjhm.getText().toString();
						SmsManager smsManager=SmsManager.getDefault();
						String SENT_SMS_ACTION = "SENT_SMS_ACTION";
						Intent sentIntent = new Intent(SENT_SMS_ACTION);
						PendingIntent sentPI = PendingIntent.getBroadcast(MainActivity.this, 0, sentIntent,  0);
						registerReceiver(new BroadcastReceiver() {

								@Override
								public void onReceive(Context _context, Intent _intent) {
									switch (getResultCode()) {
										case Activity.RESULT_OK:
											Toast.makeText(MainActivity.this, "短信发送成功!", Toast.LENGTH_SHORT).show();
											break;
										case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
											Toast.makeText(MainActivity.this, "普通错误", Toast.LENGTH_SHORT).show();
											break;
										case SmsManager.RESULT_ERROR_RADIO_OFF:
											Toast.makeText(MainActivity.this, "无线广播被明确的关闭", Toast.LENGTH_SHORT).show();
											break;
										case SmsManager.RESULT_ERROR_NULL_PDU:
											Toast.makeText(MainActivity.this, "没有提供PDU", Toast.LENGTH_SHORT).show();
											break;
										case SmsManager.RESULT_ERROR_NO_SERVICE:
											Toast.makeText(MainActivity.this, "服务当前不可用", Toast.LENGTH_SHORT).show();
											break;
									}
								}
							}, new IntentFilter(SENT_SMS_ACTION));
						String DELIVERED_SMS_ACTION = "DELIVERED_SMS_ACTION";
						Intent deliverIntent = new Intent(DELIVERED_SMS_ACTION);
						PendingIntent deliverPI = PendingIntent.getBroadcast(MainActivity.this, 0, deliverIntent, 0);
						registerReceiver(new BroadcastReceiver() {

								@Override
								public void onReceive(Context _context, Intent _intent) {
									Toast.makeText(MainActivity.this, "收信人已经成功接收！", Toast.LENGTH_SHORT).show();
								}
							}, new IntentFilter(DELIVERED_SMS_ACTION));
						smsManager.sendTextMessage(pho, null, msg, sentPI, deliverPI);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}
} 
