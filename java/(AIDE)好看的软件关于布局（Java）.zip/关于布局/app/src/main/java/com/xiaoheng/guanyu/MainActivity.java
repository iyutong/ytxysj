package com.xiaoheng.guanyu;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import cn.bmob.v3.*;
import cn.bmob.v3.listener.*;
import java.util.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		requestWindowFeature(Window.FEATURE_NO_TITLE);//隐藏操作栏
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		ImageView image=(ImageView)findViewById(R.id.image);
		TextView text1=(TextView)findViewById(R.id.text1);
		TextView text2=(TextView)findViewById(R.id.text2);
		LinearLayout ll1=(LinearLayout)findViewById(R.id.mainLinearLayout1);
		LinearLayout ll2=(LinearLayout)findViewById(R.id.mainLinearLayout2);
		LinearLayout ll3=(LinearLayout)findViewById(R.id.mainLinearLayout3);
		LinearLayout ll4=(LinearLayout)findViewById(R.id.mainLinearLayout4);
		LinearLayout ll5=(LinearLayout)findViewById(R.id.mainLinearLayout5);
		Bmob.initialize(this,"85bcde14eff9163cac8d87ef19b84470");//Application ID
		
		text1.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);//将远程管理加下划线效果
		text2.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);//将源码开源加下划线效果
		
		image.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//退出图片的点击事件
					finish();
				}});
			
		ll1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					
					
					BmobQuery<guanyubuju>zhidingy=new BmobQuery<guanyubuju>();
					zhidingy.findObjects(getApplication(), new FindListener<guanyubuju>(){

							@Override
							public void onSuccess(List<guanyubuju> p1)
							{
								//正常
								for(guanyubuju xiaoheng:p1)
								{
									//获取数据
									String gx=xiaoheng.getgx();
									//Toast.makeText(MainActivity.this,gx,Toast.LENGTH_SHORT).show();//查看开或关
									//判断获取到的数据
									if(gx.equals("开"))
									{
										//判断到开执行这里
										final String lj=xiaoheng.getlj();
										String tcnr=xiaoheng.getgonggao();
										AlertDialog.Builder ab=new AlertDialog.Builder(MainActivity.this);
										//ab.setIcon(R.drawable.ic_launcher);//图标
										ab.setCancelable(false);//点击界面其他地方弹窗不会消失
										ab.setTitle("发现新版本");//标题
										ab.setMessage(tcnr);//弹窗内容
										ab.setPositiveButton("前往更新", new DialogInterface.OnClickListener()
											{
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(lj)));
													finish();
												}});
										ab.setNegativeButton("退出",new DialogInterface.OnClickListener(){
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													finish();
												}
											});
										ab.show();

									}
									else if(gx.equals("关"))
									{
										//判断到关执行这里
										Toast.makeText(MainActivity.this,"没有可更新",Toast.LENGTH_SHORT).show();
									}
								}
								
								
							}

							@Override
							public void onError(int p1, String p2)
							{
								//异常
								//无网络或其他情况执行这里
								Toast.makeText(MainActivity.this,"获取数据失败\n请检查设备是否联网",Toast.LENGTH_LONG).show();
							}
						});

					
					
				}});
			
		ll2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//软件说明的点击事件
					
					
					AlertDialog.Builder a=new AlertDialog.Builder(MainActivity.this);
					//a.setIcon(R.drawable.ic_launcher);//图标
					//a.setCancelable(false);//点击界面其他它地方弹窗不会消失
					//a.setTitle("提示");//标题
					a.setMessage("\n此关于布局示例由小亨开发\n\n\n\n\n");//弹窗内容
					a.setPositiveButton("知道了", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								//第一个按钮按钮的点击事件
								Toast.makeText(MainActivity.this,"感谢支持！",Toast.LENGTH_LONG).show();
							}
						});
					a.show();
					
					
				}});
				
		ll3.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//赞助作者的点击事件
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("alipays://platformapi/startapp?saId=10000007&clientVersion=3.7.0.0718&qrcode=https%3A%2F%2Fqr.alipay.com%2FFKX00776US7D6RTHLZE76B%3F_s%3Dweb-other&_t=1486300416691#Intent;scheme=alipays;package=com.eg.android.AlipayGphone;end")));
				}});
				
		ll4.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//加入群聊的点击事件
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=234257176&card_type=group&source=qrcode")));
				}});
				
		ll5.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//联系作者的点击事件
					startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
				}});
		
		text1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//远程管理的点击事件
					startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bmob.cn/login")));
				}});
				
		text2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					//源码开源的点击事件
					Toast.makeText(MainActivity.this,"联系作者要",Toast.LENGTH_LONG).show();
				}});
				
    }
}

/****************************************
 *                                      *
 *      不会改找我，不免费。               *
 *      价格好说，我做示例也不容易。         *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/