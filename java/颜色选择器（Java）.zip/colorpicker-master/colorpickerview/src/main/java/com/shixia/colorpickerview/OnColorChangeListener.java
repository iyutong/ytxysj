package com.shixia.colorpickerview;

public interface OnColorChangeListener {
    void colorChanged(int color);
}
