package com.shixia.colorpickerview;

public interface OnProgressChangeListener {
    void onProgressChanged(int progress);
}
