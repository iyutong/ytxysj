package com.mill.accessibility.forcestop;

/**
 */
public class StatusConst {
    public static final int FORCESTOP_WAITING = 20;
    public static final int FORCESTOP_RUNNING = 21;
    public static final int FORCESTOP_SUCCESS = 22;
    public static final int FORCESTOP_FAILED = 23;
}
