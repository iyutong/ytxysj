# BarrageView
a custom view

something like this:![](https://github.com/Anler2015/BarrageView/blob/master/output/show2.gif)  
