package simon.bltpd;
import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.sdwfqin.cbt.CbtManager;
import com.sdwfqin.cbt.callback.ScanCallback;
import com.sdwfqin.cbt.callback.StateSwitchCallback;
import java.util.ArrayList;
import java.util.List;
import pub.devrel.easypermissions.EasyPermissions;
import simon.musicplayer.Base.BaseActivity;
import simon.musicplayer.Base.BaseAdapter;
import simon.musicplayer.View.MyRecyclerView;
import com.sdwfqin.cbt.callback.ConnectDeviceCallback;
import android.bluetooth.BluetoothSocket;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;
public class MainActivity extends BaseActivity implements EasyPermissions.PermissionCallbacks
{
    public static List<BluetoothDevice> datas=new ArrayList<BluetoothDevice>();
    @Override
    public void onPermissionsGranted(int p1, List<String> p2)
    {
    }

    @Override
    public void onPermissionsDenied(int p1, List<String> p2)
    {
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        CbtManager.getInstance().onDestroy();
    }
    public void open(View v){
        CbtManager
            .getInstance()
            .enableBluetooth(new StateSwitchCallback(){

                @Override
                public void onStateChange(boolean isOn)
                {
                    if (isOn) 
                        Toast.makeText("已开启");
                }
            });
    }
    public void search(View v){
        initData();
    }
    public void close(View v){
        CbtManager
            .getInstance()
            .disableBluetooth(new StateSwitchCallback(){

                @Override
                public void onStateChange(boolean isOn)
                {
                    if(!isOn)
                        Toast.makeText("已关闭");
                }
            });
    }
    private void initData() {
        CbtManager
            .getInstance()
            .scan(new ScanCallback() {
                @Override
                public void onScanStart(boolean isOn) {
                   Toast.makeText(isOn?"开始搜索":"搜索失败");
                }

                @Override
                public void onScanStop(List<BluetoothDevice> devices) {
                    RV.RV.getAdapter().notifyDataSetChanged();
                    Toast.makeText("搜索完成，有"+RV.RV.getAdapter().getItemCount()+"个结果");
                }

                @Override
                public void onFindDevice(BluetoothDevice device) {
                    datas.add(device);
                }
            });
    }
    private boolean checkGpsIsOpen() {
        boolean isOpen;
        LocationManager locationManager = (LocationManager) this.getSystemService(LOCATION_SERVICE);
        isOpen = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        return isOpen;
    }
    MyRecyclerView RV;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        hideActionBar();
        setContentView(R.layout.main);
        String[] perms = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION};
        if (!EasyPermissions.hasPermissions(this, perms)) {
            EasyPermissions.requestPermissions(this, "App正常运行需要存储权限、媒体权限", 1, perms);
        }
        if(!checkGpsIsOpen()){
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent,1);
            Toast.makeText("打开GPS才可以搜索蓝牙");
     }
        RV=findViewById(R.id.mainRV);
        RV.RV.setAdapter(new BaseAdapter<MainHolder>(){

                @Override
                public void onViewAttach(MainHolder holder, int position)
                {
                    holder.title.setText("名称"+datas.get(position).getName());
                    holder.summ.setText("地址"+datas.get(position).getAddress());
                }

                @Override
                public void onViewDetach(MainHolder holder, int position)
                {
                }

                @Override
                public MainHolder onCreateViewHolder(ViewGroup p1, int p2)
                {
                    return new MainHolder(LayoutInflater.from(p1.getContext()).inflate(R.layout.item,p1,false));
                }

                @Override
                public int getItemCount()
                {
                    return datas.size();
                }
            });
      
    }
  private static class MainHolder extends RecyclerView.ViewHolder{
      public TextView title,summ;
      public MainHolder(View v){
          super(v);
          title=v.findViewById(R.id.item_name);
          summ=v.findViewById(R.id.item_count);
         v.setOnClickListener(new View.OnClickListener(){

                  @Override
                  public void onClick(View view)
                  {
                      final BluetoothDevice item=datas.get(getAdapterPosition());
                      AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(view.getContext());
                      final EditText paswdeditText = new EditText(view.getContext());
                      dialogBuilder.setTitle("蓝牙名称"+item.getName());
                      paswdeditText.setHint("输入Pin，不输入则使用系统默认");
                      dialogBuilder.setPositiveButton("确定", new DialogInterface.OnClickListener(){

                              @Override
                              public void onClick(final DialogInterface p1, int p2)
                              {
                                  if(paswdeditText.getText().toString().length()>4){
                                      Toast.makeText("输入有误，pin应为0000-9999");
                                      p1.dismiss();
                                      return;}
                                      int pin;
                                      try{
                               pin=  Integer.parseInt(paswdeditText.getText().toString());
                              }catch(Throwable e){
                                  Toast.makeText("输入有误，pin应为数字");
                                  p1.dismiss();
                                  return;
                              }
                              if(!paswdeditText.getText().toString().equals(""))
                                   item.setPin(int2Bytes(pin));
                                   Toast.makeText("开始连接");
                                  CbtManager
                                      .getInstance()
                                      .connectDevice(item, new ConnectDeviceCallback() {
                                          @Override
                                          public void connectSuccess(BluetoothSocket socket, BluetoothDevice device) {
                                              // 连接成功
                                              Toast.makeText("连接成功");
                                              p1.dismiss();
                                          }

                                          @Override
                                          public void connectError(Throwable throwable) {
                                              // 连接失败
                                              Toast.makeText("连接失败"+throwable.getMessage());
                                              p1.dismiss();
                                          }
                                      });
                              }
                          });
                      dialogBuilder.setMessage("代理pin");
                      dialogBuilder.setView(paswdeditText);  
                      dialogBuilder.create().setCanceledOnTouchOutside(false);
                      dialogBuilder.show();
                  }
              });
        
      }
  }
    public static byte[] int2Bytes(int num) {
        byte[] bytes = new byte[4];
        //通过移位运算，截取低8位的方式，将int保存到byte数组
        bytes[0] = (byte)(num >>> 24);
        bytes[1] = (byte)(num >>> 16);
        bytes[2] = (byte)(num >>> 8);
        bytes[3] = (byte)num;
        return bytes;
	}
}
