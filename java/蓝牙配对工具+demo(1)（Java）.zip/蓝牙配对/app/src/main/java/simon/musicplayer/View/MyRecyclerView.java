package simon.musicplayer.View;
import android.content.Context;
import android.graphics.Rect;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import simon.musicplayer.Base.BaseView;
import android.graphics.Color;

public class MyRecyclerView extends LinearLayout implements BaseView
{

    @Override
    public void onStateChange(boolean isnight)
    {
        setBackgroundColor(isnight?Color.BLACK:Color.WHITE);
    }
    
    private static final int ANIM_TIME = 400;
    public RecyclerView RV;
    private Rect original = new Rect();
    private boolean isMoved = false;
    private float startYpos;
    /**
     * 阻尼系数
     */
    private static final float DAMPING_COEFFICIENT = 0.3f;
    private boolean isSuccess = false;
  //  private ScrollListener mScrollListener;
    public MyRecyclerView(Context context, AttributeSet attrs) {
        super(context,attrs);
        RV=new RecyclerView(context);
       // RV.setLayoutParams(getLayoutParams());
        RV.setLayoutManager(new LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false));
     LinearLayout.LayoutParams parms=   new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
        parms.topMargin=dip2px(context,80);
     RV.setLayoutParams(parms);
     addView(RV);
    }
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        original.set(RV.getLeft(), RV.getTop(), RV.getRight(), RV.getBottom());
    }
 /*   public void setScrollListener(ScrollListener listener) {
        mScrollListener = listener;
    }*/
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        float touchYpos = ev.getY();
        if (touchYpos >= original.bottom || touchYpos <= original.top) {
            if (isMoved) {
                recoverLayout();
            }
            return true;
        }
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startYpos = ev.getY();
            case MotionEvent.ACTION_MOVE:
                int scrollYpos = (int) (ev.getY() - startYpos);
                boolean pullDown = scrollYpos > 0 && canPullDown();
                boolean pullUp = scrollYpos < 0 && canPullUp();
                if (pullDown || pullUp) {
                    cancelChild(ev);
                    int offset = (int) (scrollYpos * DAMPING_COEFFICIENT);
                    RV.layout(original.left, original.top + offset, original.right, original.bottom + offset);
                   /* if (mScrollListener != null) {
                        mScrollListener.onScroll();
                    }*/
                    isMoved = true;
                    isSuccess = false;
                    return true;
                } else {
                    startYpos = ev.getY();
                    isMoved = false;
                    isSuccess = true;
                    return super.dispatchTouchEvent(ev);
                }
            case MotionEvent.ACTION_UP:
                if (isMoved) {
                    recoverLayout();
                }
                return !isSuccess || super.dispatchTouchEvent(ev);
            default:
                return true;
        }
    }
    /**
     * 取消子view已经处理的事件
     *
     * @param ev event
     */
    private void cancelChild(MotionEvent ev) {
        ev.setAction(MotionEvent.ACTION_CANCEL);
        super.dispatchTouchEvent(ev);
    }
    /**
     * 位置还原
     */
    private void recoverLayout() {
        TranslateAnimation anim = new TranslateAnimation(0, 0, RV.getTop() - original.top, 0);
        anim.setDuration(ANIM_TIME);
        RV.startAnimation(anim);
        RV.layout(original.left, original.top, original.right, original.bottom);
        isMoved = false;
    }
    /**
     * 判断是否可以下拉
     *
     * @return true：可以，false:不可以
     */
    private boolean canPullDown() {
        final int firstVisiblePosition = ((LinearLayoutManager) RV.getLayoutManager()).findFirstVisibleItemPosition();
        if (firstVisiblePosition != 0 && RV.getAdapter().getItemCount() != 0) {
            return false;
        }
        int mostTop = (RV.getChildCount() > 0) ? RV.getChildAt(0).getTop() : 0;
        return mostTop >= 0;
    }
    /**
     * 判断是否可以上拉
     *
     * @return true：可以，false:不可以
     */
    private boolean canPullUp() {
        final int lastItemPosition = RV.getAdapter()==null?0:RV.getAdapter().getItemCount() - 1;
        final int lastVisiblePosition = ((LinearLayoutManager) RV.getLayoutManager()).findLastVisibleItemPosition();
        if (lastVisiblePosition >= lastItemPosition) {
            final int childIndex = lastVisiblePosition - ((LinearLayoutManager) RV.getLayoutManager()).findFirstVisibleItemPosition();
            final int childCount = RV.getChildCount();
            final int index = Math.min(childIndex, childCount - 1);
            final View lastVisibleChild = RV.getChildAt(index);
            if (lastVisibleChild != null) {
                return lastVisibleChild.getBottom() <= RV.getBottom() - RV.getTop();
            }
        }
        return false;
    }

    @Override
    public void destroyDrawingCache()
    {
        RV=null;
        super.destroyDrawingCache();
    }
    
    /*public interface ScrollListener {
         //滚动事件回调
        void onScroll();
    }*/
}

