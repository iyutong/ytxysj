package simon.musicplayer.Base;

public interface BaseView
{
    void onStateChange(boolean isnight)
}
