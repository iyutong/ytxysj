package simon.bltpd;
import android.app.Application;
import com.sdwfqin.cbt.CbtManager;

public class App extends Application
{

    @Override
    public void onCreate()
    {
        super.onCreate();
        CbtManager
            .getInstance()
            .init(this);
            Toast.setContext(getApplicationContext());
    }
    
}
