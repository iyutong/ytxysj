package simon.musicplayer.Base;
import java.io.Serializable;

public class BaseModle implements Serializable
{
   private String title;
   private String summary;
   private String img;

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }

    public void setSummary(String summary)
    {
        this.summary = summary;
    }

    public String getSummary()
    {
        return summary;
    }

    public void setImg(String img)
    {
        this.img = img;
    }

    public String getImg()
    {
        return img;
    }
}
