package simon.musicplayer.Base;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Build;
import android.content.res.Configuration;
import android.view.View;

public class BaseActivity extends Activity
{
    private void setStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) 
            if((getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==16)
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);//实现状态栏图标和文字颜色为暗色
            else
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |View.SYSTEM_UI_FLAG_VISIBLE);
    }

    public void jump(Class<?> in){
        startActivity(new Intent(this,in));
    }

    public void hideActionBar(){
         getActionBar().hide();
        getWindow().addFlags(67108864);
        setStatusBar();
    }
}
