package simon.bltpd;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class Toast
{
    private static Context con;
    private static Handler uithread=new Handler(Looper.getMainLooper());
    public static void setContext(Context mcon){
        con=mcon;
    }
    public static void makeText(final String in){
        uithread.post(new Runnable(){

                @Override
                public void run()
                {
                    Toast.makeText(con,in,5).show();
                }
            });
    }
}
