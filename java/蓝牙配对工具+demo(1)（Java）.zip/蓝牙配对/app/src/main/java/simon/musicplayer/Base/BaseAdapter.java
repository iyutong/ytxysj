package simon.musicplayer.Base;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.content.res.Resources;
import android.view.View;

public abstract class BaseAdapter<VH extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<VH>
{
    public abstract void onViewAttach(VH holder,int position)
    public abstract void onViewDetach(VH holder,int position)
    @Override
    public void onViewAttachedToWindow(VH holder)
    {
        super.onViewAttachedToWindow(holder);
        onViewAttach(holder,holder.getAdapterPosition());
    }
    @Override
    public void onViewDetachedFromWindow(VH holder)
    {
        super.onViewDetachedFromWindow(holder);
        onViewDetach(holder,holder.getAdapterPosition());
    }

    @Override
    public void onBindViewHolder(VH p1, int p2)
    {
    }

   
    
}

    


