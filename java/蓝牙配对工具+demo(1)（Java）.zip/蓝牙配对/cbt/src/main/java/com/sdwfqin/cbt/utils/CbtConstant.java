package com.sdwfqin.cbt.utils;

import java.util.UUID;

/**
 * 描述：
 *
 * @author zhangqin
 * @date 2018/6/2
 */
public class CbtConstant {

    public static UUID CBT_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    public static String CBT_NAME = "sdwfqin_cbt";

}
