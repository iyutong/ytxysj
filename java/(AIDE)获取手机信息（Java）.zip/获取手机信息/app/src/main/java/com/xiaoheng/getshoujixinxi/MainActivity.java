package com.xiaoheng.getshoujixinxi;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.telephony.*;
import android.view.*;
import android.widget.*;
import com.xiaoheng.getshoujixinxi.*;
import android.view.View.*;

public class MainActivity extends Activity 
{
	private TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		//getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.xiaoheng);
		
		text=(TextView)findViewById((R.id.xiaohengTextView1));
		
		StringBuilder phoneInfo = new StringBuilder(); 
		phoneInfo.append( "CPU位数：" + android.os.Build.CPU_ABI); 
		phoneInfo.append( "\n发行版本：" + android.os.Build.TAGS); 
		phoneInfo.append( "\n手机型号：" + android.os.Build.MODEL); 
		phoneInfo.append( "\nSDK：" + android.os.Build.VERSION.SDK); 
		phoneInfo.append( "\n安卓版本：" + android.os.Build.VERSION.RELEASE); 
		phoneInfo.append( "\n手机名称：" + android.os.Build.BRAND); 
		phoneInfo.append( "\n主板信息：" + android.os.Build.BOARD); 
		phoneInfo.append( "\n手机系统信息：" + android.os.Build.FINGERPRINT); 
		phoneInfo.append( "\n版本号：" + android.os.Build.ID); 
		TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
		phoneInfo.append("\nIMEI码：" + tm.getDeviceId()); 
		phoneInfo.append("\n本机手机号码：" + tm.getLine1Number()); 
		phoneInfo.append("\n所在地：" + tm.getNetworkCountryIso()); 
		phoneInfo.append("\n手机卡类型：" + tm.getNetworkOperatorName()); 
		phoneInfo.append("\n手机号码所在地：" + tm.getSimCountryIso()); 
		phoneInfo.append("\n手机卡状态：" + tm.getSimState()); 
		phoneInfo.append("\nIMSI码：" + tm.getSubscriberId()); 
		text.setText(phoneInfo);
		
		final ToggleButton ToggleButton=(ToggleButton)findViewById(R.id.xiaohengToggleButton1);
		ToggleButton.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					if(ToggleButton.isChecked())
					{
						StringBuilder phoneInfo = new StringBuilder(); 
						phoneInfo.append("\nProduct: " + android.os.Build.PRODUCT);
						phoneInfo.append( "\nVERSION_CODES.BASE: " + android.os.Build.VERSION_CODES.BASE);
						phoneInfo.append( "\nDEVICE: " + android.os.Build.DEVICE); 
						phoneInfo.append( "\nDISPLAY: " + android.os.Build.DISPLAY);
						phoneInfo.append( "\nMANUFACTURER: " + android.os.Build.MANUFACTURER); 
						phoneInfo.append( "\nUSER: " + android.os.Build.USER); 
						TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
						phoneInfo.append("\nDeviceSoftwareVersion = " + tm.getDeviceSoftwareVersion());
						phoneInfo.append("\nNetworkOperator = " + tm.getNetworkOperator()); 
						phoneInfo.append("\nNetworkType = " + tm.getNetworkType()); 
						phoneInfo.append("\nPhoneType = " + tm.getPhoneType()); 
						phoneInfo.append("\nSimOperator = " + tm.getSimOperator()); 
						phoneInfo.append("\nSimOperatorName = " + tm.getSimOperatorName()); 
						phoneInfo.append("\nSimSerialNumber = " + tm.getSimSerialNumber());
						phoneInfo.append("\nVoiceMailNumber = " + tm.getVoiceMailNumber()); 
						String list1=text.getText().toString();
						text.setText(list1+phoneInfo);
						
					}
					else
					{
						StringBuilder phoneInfo = new StringBuilder(); 
						phoneInfo.append( "CPU位数：" + android.os.Build.CPU_ABI); 
						phoneInfo.append( "\n发行版本：" + android.os.Build.TAGS); 
						phoneInfo.append( "\n手机型号：" + android.os.Build.MODEL); 
						phoneInfo.append( "\nSDK：" + android.os.Build.VERSION.SDK); 
						phoneInfo.append( "\n安卓版本：" + android.os.Build.VERSION.RELEASE); 
						phoneInfo.append( "\n手机名称：" + android.os.Build.BRAND); 
						phoneInfo.append( "\n主板信息：" + android.os.Build.BOARD); 
						phoneInfo.append( "\n手机系统信息：" + android.os.Build.FINGERPRINT); 
						phoneInfo.append( "\n版本号：" + android.os.Build.ID); 
						TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE); 
						phoneInfo.append("\nIMEI码：" + tm.getDeviceId()); 
						phoneInfo.append("\n本机手机号码：" + tm.getLine1Number()); 
						phoneInfo.append("\n所在地：" + tm.getNetworkCountryIso()); 
						phoneInfo.append("\n手机卡类型：" + tm.getNetworkOperatorName()); 
						phoneInfo.append("\n手机号码所在地：" + tm.getSimCountryIso()); 
						phoneInfo.append("\n手机卡状态：" + tm.getSimState()); 
						phoneInfo.append("\nIMSI码：" + tm.getSubscriberId()); 
						text.setText(phoneInfo);
						
					}
				}
			});
    }
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.xiaohengmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
			case R.id.item:
				String 小亨QQ号= getResources().getString(R.string.小亨QQ);
				try
				{
				startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin="+小亨QQ号)));
				}catch(Exception e)
				{
					Toast.makeText(MainActivity.this, "转跳失败，未安装手Q或当前版本不支持", 1000).show();
				}
		}

		switch(item.getItemId())
		{
			case R.id.menulist1:
				ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				String list1=text.getText().toString();
				manager.setText(list1);
				Toast.makeText(MainActivity.this, "复制成功", Toast.LENGTH_SHORT).show();
		}
		
		switch(item.getItemId())
		{
			case R.id.menulist2:
				String list1=text.getText().toString();
				Intent intent=new Intent(Intent.ACTION_SEND); 
				intent.setType("text/plain");		
				intent.setClassName("com.tencent.mobileqq","com.tencent.mobileqq.activity.JumpActivity"); 
				intent.putExtra(Intent.EXTRA_TEXT,list1);
				intent.putExtra(Intent.EXTRA_TITLE,"分享到QQ");
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
				try{
					startActivity(Intent.createChooser(intent,"分享到QQ")); 
				}catch(Exception e){
					Toast.makeText(MainActivity.this, "未安装手Q或当前版本不支持", 1000).show();
				}
		}
		
		switch(item.getItemId())
		{
			case R.id.menulist3:
				String list1=text.getText().toString();
				 Intent shareIntent = new Intent(); shareIntent.setAction(Intent.ACTION_SEND);
				 shareIntent.putExtra(Intent.EXTRA_TEXT,list1);
				 shareIntent.setType("text/plain");
				 startActivity(Intent.createChooser(shareIntent, "分享到"));
		}
		
		return super.onOptionsItemSelected(item);
	}
	
	
	static boolean Exit; 
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (!Exit) {
				Exit = true;
				Toast.makeText(MainActivity.this,"再按一次退出",Toast.LENGTH_SHORT).show();
				new Thread(new Runnable() {
						@Override
						public void run() {
							try {
								Thread.sleep(1000);
								Exit = false;
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}).start();
			} else {
				MainActivity.this.finish();
			}
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
}}

/****************************************
 *      2017.8.30                       *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/
