package com.mycompany.weixin;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.Button;
import android.view.ViewGroup;

public class MainActivity extends Activity { 
    private String type = "phone";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView(this);
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View account = inflater.inflate(R.layout.frame_reg, null, false);
        TextView switch_button = account.findViewById(R.id.switch_method2);
        final LinearLayout account_lay = account.findViewById(R.id.account_lay);
        StatusBarUtils.StatusBarLightMode(this);
        StatusBarUtils.setStatusBarColor(this, android.R.color.white);
        mSwitch_method.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    if (type.equals("phone")) {
                        type = "account";
                        if (phone_lay.getParent() != null) {
                            ((ViewGroup) phone_lay.getParent()).removeView(phone_lay);
                        }
                        root_lay.addView(account_lay);
                    } else if (type.equals("account")) {
                        type = "phone";
                        if (account_lay.getParent() != null) {
                            ((ViewGroup) account_lay.getParent()).removeView(account_lay);
                        }
                        root_lay.addView(phone_lay);
                    }
                }
            });
        switch_button.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    if (type.equals("phone")) {
                        type = "account";
                        if (phone_lay.getParent() != null) {
                            ((ViewGroup) phone_lay.getParent()).removeView(phone_lay);
                        }
                        root_lay.addView(account_lay);
                    } else if (type.equals("account")) {
                        type = "phone";
                        if (account_lay.getParent() != null) {
                            ((ViewGroup) account_lay.getParent()).removeView(account_lay);
                        }
                        root_lay.addView(phone_lay);
                    }
                }
            });
    }

    private TextView mSwitch_method;
    private LinearLayout root_lay,phone_lay;

    private void initView(Activity activity) {
        root_lay = activity.findViewById(R.id.root_lay);
        phone_lay = activity.findViewById(R.id.phone_lay);
        mSwitch_method = activity.findViewById(R.id.switch_method);
    }

}
