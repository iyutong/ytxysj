
import java.io.*;
import java.text.*;
import java.util.*;
public class VideoFormat
{
	//文件格式转换(mp4文件转va)
	public static void Format(String filePath) throws FileNotFoundException, IOException {

		byte[] buffer=BytesFormat(File2Bytes(filePath));
		//创建目录
		File f=new File("/sdcard/VideoFormat/");
		if(!f.exists()){
			f.mkdirs();
		}
		FileOutputStream fos=new FileOutputStream(new File(f,DateFormat()+".va"));
		fos.write(buffer);
		if(fos!=null){
			fos.close();
		}

	}
    //还原文件
	public static void Reset(String filePath) throws FileNotFoundException, IOException {

		byte[] buffer=ResetBytes(File2Bytes(filePath));
		//创建目录
		File f=new File("/sdcard/VideoFormat/");
		if(!f.exists()){
			f.mkdirs();
		}
		FileOutputStream fos=new FileOutputStream(new File(f,DateFormat()+".mp4"));
		fos.write(buffer);
		if(fos!=null){
			fos.close();
		}

	}
//文件转数组
	private static byte[] File2Bytes(String filePath) {
		int byte_size = 1024*4;
		byte[] b = new byte[byte_size];
		try {
			FileInputStream fileInputStream = new FileInputStream(filePath);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream(
				byte_size);
				//文件写入
			for (int length; (length = fileInputStream.read(b))>0;) {
				outputStream.write(b, 0, length);
			}
			fileInputStream.close();
			outputStream.close();

			return outputStream.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	//对字节数组的处理
    private static byte[] BytesFormat(byte[] b){


		byte[] new_byte=new byte[b.length];
		for(int i=0;i<b.length;i++){
			new_byte[i]=b[i]+=6;
		}
		return new_byte;
	}
	//对字节数组还原
    private static byte[] ResetBytes(byte[] b){


		byte[] new_byte=new byte[b.length];
		for(int i=0;i<b.length;i++){
			new_byte[i]=b[i]-=6;
		}
		return new_byte;
	}
	//格式化时间
	private static String DateFormat(){
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		return df.format(new Date());// new Date()为获取当前系统时间;
	}
	//转换文件方式2
	public static void Format2(String filePath) throws FileNotFoundException, IOException{
		FileInputStream fis=new FileInputStream(filePath);
		//创建目录
		File f=new File("/sdcard/VideoFormat/");
		if(!f.exists()){
			f.mkdirs();
		}
		FileOutputStream fos=new FileOutputStream(new File(f,DateFormat()+".va"));
		byte[] buffer=new byte[1024*4];
		for(int length=0;(length=fis.read(buffer))>0;){
			fos.write(BytesFormat(buffer),0,length);
		}
		
		if(fos!=null){
			fos.close();
		}
		
		if(fis!=null){
			fis.close();
		}
		
		
		
	}
	//还原文件方式二
	public static void Reset2(String filePath) throws FileNotFoundException, IOException{
		FileInputStream fis=new FileInputStream(filePath);
		//创建目录
		File f=new File("/sdcard/VideoFormat/");
		if(!f.exists()){
			f.mkdirs();
		}
		FileOutputStream fos=new FileOutputStream(new File(f,DateFormat()+".mp4"));
		byte[] buffer=new byte[1024*4];
		for(int length=0;(length=fis.read(buffer))>0;){
			fos.write(ResetBytes(buffer),0,length);
		}

		if(fos!=null){
			fos.close();
		}

		if(fis!=null){
			fis.close();
		}



	}
}
