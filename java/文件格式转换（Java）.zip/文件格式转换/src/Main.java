import java.util.*;
import java.io.*;
/**************
使用说明:还原文件reset的值设置为true,转换文件设置为false
       在传入对应的需要还原或者需要转换的文件的绝对路径即可
	   目前只做了mp4和自定义格式va的互转，理论任意格式和va都可以互转
	   修改下源码即可
****************/
public class Main
{
	public static void main(String[] args)
	{
		boolean reset=false;//是否还原文件
		if(reset){//还原
			try
			{
				//注意是文件绝对路径
				VideoFormat.Reset2("/storage/emulated/0/VideoFormat/20180514152347.va");
				System.out.println("reset ok");
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else//转换
		{
			try
			{
				//注意是文件绝对路径
				VideoFormat.Format2("/storage/emulated/0/PPTV/download/阴阳师平安物语(第03集)[流畅].mp4");
				System.out.println("ok");
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		

		
	}
	
}
