import java.io.File;
import java.io.IOException;
import org.eclipse.jdt.internal.compiler.util.Util;
import org.eclipse.jdt.internal.formatter.DefaultCodeFormatter;
import org.eclipse.jdt.internal.formatter.DefaultCodeFormatterOptions;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;

public class Main {
	public static void main(String[] args) throws IOException, MalformedTreeException, BadLocationException {
    DefaultCodeFormatterOptions eclipseDefaultSettings = DefaultCodeFormatterOptions.getJavaConventionsSettings();
    eclipseDefaultSettings.tab_char=DefaultCodeFormatterOptions.SPACE;
    eclipseDefaultSettings.indentation_size=2;
        DefaultCodeFormatter formatter = new DefaultCodeFormatter(
    eclipseDefaultSettings);
          String s = "/storage/emulated/0/AppProjects/formatter/src/Main.java";
    String text = new String(Util.getFileByteContent(new File(s)));
    Document doc = new Document(text);
    TextEdit edit = formatter.format(
      DefaultCodeFormatter.K_COMPILATION_UNIT,
      text,
      0, text.length(),
      0, "\n");
    edit.apply(doc);
    System.out.println(doc.get());
  }
}
