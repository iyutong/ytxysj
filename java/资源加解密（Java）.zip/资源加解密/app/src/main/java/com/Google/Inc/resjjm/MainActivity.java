package com.Google.Inc.resjjm;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import android.widget.LinearLayout.*;
import android.view.*;
import android.graphics.*;
import android.content.pm.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity 
{
	public static Context con;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		/*try{
		FileInputStream fis = new FileInputStream(new File("sdcard/.000000/old.png"));
		byte[] bytearr = new byte[fis.available()];
		fis.read(bytearr);
		int len = bytearr.length;
		for (int i = len - 1; i > 0; i--) {
			bytearr[i] = (byte) (bytearr[i] ^ 255);
		}
		bytearr[0] = (byte) (bytearr[0] ^ 255);
		FileOutputStream fos = new FileOutputStream(new File("sdcard/.000000/new.png"));
		fos.write(bytearr);
		fos.flush();
		}catch(Exception e){}*/
		con = this;
		ByteArrayInputStream byteinput = null;
		try{
		InputStream is = this.getAssets().open("bg.png");
		byte[] bytearr = new byte[is.available()];
		is.read(bytearr);
		for (int i = 0; i < bytearr.length; i++) {
			bytearr[i] = (byte) (bytearr[i] ^ 255);
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream(0);
		bos.write(bytearr);
		bos.flush();
		byteinput = new ByteArrayInputStream(bytearr);
		
		}catch(Exception e){
			Toast.makeText(this,e.toString(),5000).show();
		}
		Bitmap bm = BitmapFactory.decodeStream(byteinput);
		ImageView iv = new ImageView(this);
		LayoutParams ivlp = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		ivlp.gravity = Gravity.CENTER;
		iv.setLayoutParams(ivlp);
		iv.setImageBitmap(bm);
		setContentView(iv);
		ComponentName cn = new ComponentName("com.tencent.mobileqq","cooperation.qzone.QzoneFeedsPluginProxyActivity");
		try{
		Context con = this.createPackageContext("com.tencent.mobileqq",0);
		Intent it = new Intent();
		it.setClassName(con,"cooperation.qzone.QzoneFeedsPluginProxyActivity");
		con.startActivity(it);
		}catch(Exception e){
			Toast.makeText(con,e.toString(),5000).show();
		}
    }
}
