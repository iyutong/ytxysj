package com.xiaoheng.chehua;


import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.support.v4.view.*;
import android.support.v4.widget.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.xiaoheng.chehua.*;

public class Heng extends Activity 
{	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaohenglayout);
		
		final DrawerLayout chehua= (DrawerLayout) findViewById(R.id.xiaohenglayoutDrawerLayout1);
		
		Button button1=(Button)findViewById(R.id.xiaohenglayoutButton1);
		button1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//打开左侧滑
					chehua.openDrawer(GravityCompat.START);
				}
			});
		
			Button button2=(Button)findViewById(R.id.xiaohenglayoutButton2);
		button2.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					//打卡右侧滑
					chehua.openDrawer(GravityCompat.END);
				}
			});
    }
	
	
	public void button(View view)
	{
		//左侧滑中的按钮
		Toast.makeText(Heng.this,"你点击了按钮",Toast.LENGTH_SHORT).show();
	}
	
	
	public void button2(View view)
	{
		//右侧滑中的加小亨按钮
		startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
	}
	
	
	public void button3(View view)
	{
		//右侧滑中的加群按钮
		startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=234257176&card_type=group&source=qrcode")));
	}
	
}




//chehua.closeDrawers()是关闭侧滑代码



    /****************************************
	 *      2017.9.24                       *
	 *                                      *
	 *      微信号：heng1919196455           *
	 *      小亨QQ：1919196455               *
	 *      QQ群聊：234257176                *
	 *                                      *
	 ****************************************/
