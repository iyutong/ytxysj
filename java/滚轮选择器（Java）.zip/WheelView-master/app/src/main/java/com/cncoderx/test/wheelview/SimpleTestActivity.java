package com.cncoderx.test.wheelview;

import android.app.Activity;
import android.os.Bundle;

/**
 * @author cncoderx
 */
public class SimpleTestActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wheel_view_test);
    }
}
