package com.cncoderx.wheelview;

/**
 * @author cncoderx
 */
public interface OnWheelChangedListener {
    void onChanged(WheelView view, int oldIndex, int newIndex);
}
