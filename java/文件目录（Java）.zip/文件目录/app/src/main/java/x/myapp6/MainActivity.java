package x.myapp6;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
public class MainActivity extends Activity { 
    String path="/mnt/sdcard";
    ListView fileList;
    TextView filePatu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //setTheme(android.R.style.Theme_Material);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fileList = findViewById(R.id.activitymainListView1);
        filePatu = findViewById(R.id.activitymainTextView1);

        fileList.setOnItemClickListener(new OnItemClickListener(){
                @Override
                public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {             
                    path = path + "/" + p1.getItemAtPosition(p3).toString();
                    list();
                }
            });
        list();
    }
    public void list() {

        if (!new File(path).canRead()) {
            path = new File(path).getParent();
            Toast.makeText(this, "无法访问!!!", Toast.LENGTH_SHORT).show(); 
            return;
        }
        if (!new File(path).isDirectory()) {
            path = new File(path).getParent();
            Toast.makeText(this, path, Toast.LENGTH_SHORT).show();
            return;
        }
        ListAdapter adapter=new MyAdapter(getApplicationContext(), new File(path).list(), path);
        fileList.setAdapter(adapter);
        filePatu.setText(path);
    }

    @Override
    static boolean isExit; 
    public void onBackPressed() {
        if (!path.equals("/mnt")) {
            path = new File(path).getParent();
            list();
        } else if (!isExit) {
            isExit = true;
            Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
            new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(3000);
                            isExit = false;
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
        } else super.onBackPressed();
    }
} 

