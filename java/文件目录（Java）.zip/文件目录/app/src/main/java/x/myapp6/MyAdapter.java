package x.myapp6;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import android.os.Bundle;

public class MyAdapter extends ArrayAdapter<String> {
    String path=null;
    public MyAdapter(Context context, String[] values, String vpath) {
        super(context, R.layout.filelist, values);
        path = vpath;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=LayoutInflater.from(getContext());
        View view=inflater.inflate(R.layout.filelist, parent, false);

        TextView textView=view.findViewById(R.id.filelistTextView1);   
        ImageView imageView=view.findViewById(R.id.filelistImageView1);

        String str=getItem(position);
        textView.setText(str);

        File file=new File(path + "/" + str);
        if (!file.canRead()) {
            imageView.setImageResource(R.drawable.ic_folder_lock);  
        } else if (file.isFile()) {
            imageView.setImageResource(R.drawable.ic_file);
        } else if (file.isDirectory()) {
            imageView.setImageResource(R.drawable.ic_folder);
        } 
        return view;
    }

}
