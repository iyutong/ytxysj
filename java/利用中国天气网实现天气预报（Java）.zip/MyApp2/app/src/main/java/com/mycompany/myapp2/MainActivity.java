package com.mycompany.myapp2;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.*;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        webView=(WebView)findViewById(R.id.webView1);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("http://www.weather.com.cn");

        Button gz=(Button)findViewById(R.id.gz);
        gz.setOnClickListener(this);
    }

    @Override
    public void onClick(View view){
        switch(view.getId()){

            case R.id.gz:
                openUrl("101280101");
                break;
        }
    }

    private void openUrl(String id){
        webView.loadUrl("http://m.weather.com.cn/mweather/"+id+".shtml");
    }
}
