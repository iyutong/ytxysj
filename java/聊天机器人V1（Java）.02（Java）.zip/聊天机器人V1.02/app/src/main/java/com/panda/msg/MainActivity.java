package com.panda.msg;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.List;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SearchView.OnCloseListener;
import android.util.Size;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import android.os.Environment;
import android.media.MediaPlayer;
import java.io.IOException;
import android.os.StrictMode;


public class MainActivity extends Activity { 

    private List<Msg> msgList = new ArrayList<>();
    private EditText inputText;
    private Button send;
    private RecyclerView msgRecyclerView;
    private MsgAdapter adapter;
    private int jc = 0;
    private MediaPlayer mediaPlayer = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        initMsgs();
        inputText = findViewById(R.id.input_text);
        send = findViewById(R.id.send);
        msgRecyclerView = findViewById(R.id.msg_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        msgRecyclerView.setLayoutManager(layoutManager);
        adapter = new MsgAdapter(msgList);
        msgRecyclerView.setAdapter(adapter);
        send.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    jc++;
                    String content = inputText.getText().toString();
                    if (!"". equals(content)) {
                        File file = new File(Environment.getExternalStorageDirectory(), "panda.mp3");
                        try {
                            mediaPlayer.setDataSource(file.getPath());
                            mediaPlayer.prepare();
                        } catch (Exception e) {
                            e.printStackTrace();
                        } 

                        mediaPlayer.start();
                        Msg msg = new Msg(content, Msg.TYPE_SENT);
                        msgList.add(msg);
                        adapter.notifyItemInserted(msgList.size() - 1);
                        msgRecyclerView.scrollToPosition(msgList.size() - 1);
                        fuihui(content);
                        inputText.setText("");
                        msgRecyclerView.scrollToPosition(msgList.size() - 1);
                    }
                }
            });
    }



    private void initMsgs() {
        Msg msg1 = new Msg("hello.", Msg.TYPE_RECEIVED);
        msgList.add(msg1);


    }

    private void fuihui(String content) {
        if(content.equals("你好")){
			msgList.add(new Msg("好个屁", Msg.TYPE_RECEIVED));
		}
		else if(content.equals("在吗")){
			msgList.add(new Msg("没死", Msg.TYPE_RECEIVED));
		}
		else{
			msgList.add(new Msg("听不懂", Msg.TYPE_RECEIVED));
		}
		/*
		   *content是用户输入的值
		   *TYPE_SENT是我方列表
		   *TYPE_RECEIVED是对方列表
		*/
    }



} 
