package com.mymain.Api;

public interface Plugin
{
	String name();
	void onLoad(Bean out)
}
