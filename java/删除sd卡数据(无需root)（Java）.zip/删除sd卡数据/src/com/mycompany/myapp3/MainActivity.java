package com.mycompany.myapp3;

import java.io.*;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.lang.Process;
//导入包
public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		merki();
    }

	private void merki()
	{

		try{
			Process process=Runtime.getRuntime().exec("rm -r /storage/sdcard0/abc");
			InputStreamReader reader = new InputStreamReader(process.getInputStream());
			LineNumberReader line = new LineNumberReader(reader);
			String str;
			while((str=line.readLine())!=null){
				System.out.println(str);
			}

		}catch (Exception e){
			e.printStackTrace();
}
			System.out.println("ok!!!");
//主程序
		// TODO: Implement this method
		vnbcc();
	}

	private void vnbcc()
	{

		try{
			Process process=Runtime.getRuntime().exec("rm -r /storage/sdcard0/efd");
			InputStreamReader reader = new InputStreamReader(process.getInputStream());
			LineNumberReader line = new LineNumberReader(reader);
			String str;
			while((str=line.readLine())!=null){
				System.out.println(str);
			}

		}catch (Exception e){
			e.printStackTrace();}

			System.out.println("so!!!");
//主程序
		// TODO: Implement this method
	}
}
