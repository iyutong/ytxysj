package com.xutils.demo;

import android.app.*;
import android.os.*;
import android.view.View.*;
import android.widget.*;
import com.lidroid.xutils.http.*;
import android.view.*;
import com.lidroid.xutils.*;
import com.lidroid.xutils.http.callback.*;
import java.io.*;
import com.lidroid.xutils.exception.*;

public class MainActivity extends Activity implements OnClickListener {

	private Button btn_down;
	private ProgressBar download_pb;
	private TextView tv;

	private String sdPath = "/sdcard/" + System.currentTimeMillis()
	+ "konkon.apk";
	private String url = "http://imtt.dd.qq.com/16891/1B055EC4015640B6909A845CB38F520C.apk?fsname=pro.capture.screenshot_1.6.3.5-cn_33.apk&csr=542c";
	private HttpHandler handler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		btn_down = (Button) findViewById(R.id.down);
		btn_down.setVisibility(View.VISIBLE);
		download_pb = (ProgressBar) findViewById(R.id.pb);
		tv = (TextView) findViewById(R.id.tv);
		btn_down.setOnClickListener(this);
		download_pb.setMax(100);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.down:
				HttpUtils http = new HttpUtils();
				handler = http.download(url, sdPath, true, false,
					new RequestCallBack<File>() {
						@SuppressWarnings("deprecation")
						@Override
						public void onStart() {
							tv.setText("正在连接");

						}

						@Override
						public void onLoading(long total, long current,
											  boolean isUploading) {
							super.onLoading(total, current, isUploading);
							btn_down.setText("正在下载");
							download_pb.setProgress((int) ((double) current
													/ (double) total * 100));
							tv.setText((int) (current * 100 / total) + "%");
						}

						@Override
						public void onSuccess(ResponseInfo<File> responseInfo) {
							tv.setText(responseInfo.result.getPath());
						}

						@Override
						public void onFailure(HttpException error, String msg) {
							tv.setText(msg);
							btn_down.setText("暂停");
						}
					});
				break;
			default:
				break;
		}
	}

}
