
import java.lang.reflect.Array;
import java.util.Arrays;public class ArrayMethod {
	
	public static Object sgsz(Object array,Object index){
		return Array.get(array,InternalMethod.objectToInt(index));
	}
	
	public static int sgszl(Object array){
		return Array.getLength(array);
	}
	
	public static void sssz(Object array,Object index,Object value){
		try{
			Array.set(array,index,InternalMethod.forceCast(value,array.getClass().getComponentType()));
		}catch(Exception e){
			if(e instanceof IndexOutOfBoundsException){
				throw (IndexOutOfBoundsException)e;
			}
			throw new IllegalArgumentException();
		}
	}
	
	public static Object nsz(Object size) throws NegativeArraySizeException, ClassNotFoundException{
		return nsz("java.lang.Object",size);
	}
	
	public static Object nsz(Object clazz,Object size) throws NegativeArraySizeException, ClassNotFoundException{
		return Array.newInstance(ReflectMethod.getClass(clazz),InternalMethod.objectToInt(size));
	}
	
	public static void sort(Object array){
		if(array == null||array.getClass().getComponentType()==null){
			return;
		}
		try{
			ReflectMethod.javaxt(null,"java.util.Arrays","sort",array);
		}catch(NoSuchMethodException e){
			throw new IllegalArgumentException("Not primitive type");
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
}
