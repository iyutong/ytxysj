
import java.lang.reflect.InvocationTargetException;

public class InternalMethod{
	
	protected static int objectToInt(Object i){
		if(i instanceof int){
			return (int)i;
		}else if(i instanceof Number){
			return ((Number)i).intValue();
		}else if(i instanceof double||i instanceof float||i instanceof byte||i instanceof char||i instanceof long){
			return new Double(String.valueOf(i)).intValue();
		}else{
			return Integer.parseInt(String.valueOf(i));
		}
	}
	
	protected static long objectToLong(Object i){
		if(i instanceof long){
			return (long)i;
		}else if(i instanceof Number){
			return ((Number)i).longValue();
		}else if(i instanceof double||i instanceof float||i instanceof byte||i instanceof char||i instanceof long){
			return new Double(String.valueOf(i)).longValue();
		}else{
			return Long.parseLong(String.valueOf(i));
		}
	}
	
	protected static Object forceCast(Object arg,Class<?> param) throws IllegalAccessException, IllegalArgumentException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException{
		Object[] objs = new Object[]{arg};
		ReflectMethod.CastArg(objs,new Class<?>[]{param});
		return objs[0];
	}
	
}
