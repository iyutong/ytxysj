
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;
import java.util.List;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class StringMethod {
	
	public static int slg(CharSequence str){
		if(str == null){
			return 0;
		}
		return str.length();
	}
	
	public static int siof(String str,String sub){
		return str.indexOf(sub);
	}
	
	public static int siof(String str,String sub,Object index){
		return str.indexOf(sub,InternalMethod.objectToInt(index));
	}
	
	public static int slof(String str,String sub){
		return str.lastIndexOf(sub);
	}

	public static int slof(String str,String sub,Object index){
		return str.lastIndexOf(sub,InternalMethod.objectToInt(index));
	}
	
	public static String ssg(String str,Object s,Object e){
		return str.substring(InternalMethod.objectToInt(s),InternalMethod.objectToInt(e));
	}
	
	public static String sj(String src,String l,String r){
		return sj(src,l,r,false);
	}
	
	public static String sj(String src,String l,String r,boolean useRegex){
		return useRegex ? sj_regex(src,l,r) : sj_simple(src,l,r);
	}
	
	public static String sj_simple(String a,String b,String c){
		int st,ed;
		if(b==null||b.equals("")){
			st = 0;
		}else{
			st = a.indexOf(b);
			if(st<0){
				return null;
			}
		}
		if(c==null||c.equals("")){
			ed = a.length();
		}else{
			ed = a.indexOf(c,st);
			if(ed<0){
				return null;
			}
		}
		return a.substring(st+slg(a),ed);
	}
	
	public static String sj_regex(String str,String left,String right){
		Pattern lp = Pattern.compile(left);
		Pattern rp = Pattern.compile(right);
		Matcher m = lp.matcher(str);
		if(m.find()){
			int st = m.end(m.groupCount()-1);
			m = rp.matcher(str);
			int ed = -1;
			while(m.find()){
				if(m.start() > st){
					ed = m.start();
					break;
				}
			}
			if(ed == -1){
				return null;
			}
			return str.substring(st,ed);
		}else{
			return null;
		}
	}
	
	public static String supper(String s){
		if(s==null){
			return s;
		}
		return s.toUpperCase();
	}
	
	public static String slower(String s){
		if(s==null){
			return s;
		}
		return s.toLowerCase();
	}
	
	public static Matcher se(CharSequence s,String regex,Object flag){
		return Pattern.compile(regex,InternalMethod.objectToInt(flag)).matcher(s);
	}
	
	public static Object se(Matcher m,String cmd){
		switch(cmd){
			case "ms":
				return m.matches();
			case "find":
				return m.find();
			case "gl":
				return m.groupCount();
			case "start":
				return m.start();
			case "end":
				return m.end();
		}
		throw new IllegalArgumentException();
	}
	
	public static Object se(Matcher m,String cmd,Object arg){
		switch(cmd){
			case "find":
				return m.find(InternalMethod.objectToInt(arg));
			case "start":
				return m.start(InternalMethod.objectToInt(arg));
			case "end":
				return m.end(InternalMethod.objectToInt(arg));
			case "group":
				return m.group(InternalMethod.objectToInt(arg));
			case "srft":
				return m.replaceFirst(String.valueOf(arg));
			case "sral":
				return m.replaceAll(String.valueOf(arg));
		}
		throw new IllegalArgumentException();
	}
	
	public static String[] sl(String src,String exp){
		return sl(src,exp,false);
	}
	
	public static String[] sl(String src,String exp,boolean useRegex){
		return useRegex ? sl_regex(src,exp) : sl_simple(src,exp);
	}
	
	public static String[] sl_simple(String src,String sp){
		List<String> list = new ArrayList<String>();
		int st = 0,cache=0;
		while((cache = src.indexOf(sp,cache))!=-1){
			list.add(src.substring(st,cache));
			cache = st = cache + sp.length();
		}
		list.add(src.substring(st));
		return list.toArray(new String[list.size()]);
	}
	
	public static String[] sl_regex(String src,String sp){
		return Pattern.compile(sp).split(src);
	}
	
	public static String sr(String src,String old,String n){
		return sr(src,old,n,false);
	}
	
	public static String sr(String s,String o,String n,boolean useRegex){
		return useRegex ? s.replaceAll(o,n) : s.replace(o,n);
	}
	
	public static String strim(String s){
		if(s==null){
			return s;
		}
		return s.trim();
	}
	
	public static String ss(Object... args){
		StringBuilder sb = new StringBuilder();
		for(Object s : args){
			sb.append(s);
		}
		return sb.toString();
	}
	
	public static String stobm(String content,String code) throws UnsupportedEncodingException{
		return URLEncoder.encode(content,code);
	}
	
	public static String sutf8to(String content){
		return URLDecoder.decode(content);
	}
	
}
