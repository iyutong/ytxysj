import java.util.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class Main
{
	public static void main(String[] args) throws Throwable
	{
		Class[] cs = new Class[]{ReflectMethod.class,InternalMethod.class,StringMethod.class,BasicMethod.class};
		for(Class c : cs){
			for(Method m : c.getDeclaredMethods()){
				if((m.getModifiers() & Modifier.PUBLIC) != 0 && m.getName().indexOf('_')==-1)
					System.out.println(m);
			}
		}
	}
	
	
}
