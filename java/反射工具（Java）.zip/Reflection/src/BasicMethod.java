
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BasicMethod {

	public static void stop(Object time) throws InterruptedException {
		Thread.sleep(InternalMethod.objectToLong(time));
	}

	public static long sran(Object min, Object max) {
		long a = InternalMethod.objectToLong(min);
		long b = InternalMethod.objectToLong(max);
		long region = Math.abs(b - a);
		long g = Math.abs(new Random().nextLong()) % region + a;
		return g;
	}

	public static String time(Object type) {
		String f = "YYYY-mm-dd HH:MM:SS";
		try {
			int intType = InternalMethod.objectToInt(type);
			switch (intType) {
				case 1:
					f = "YYYY/mm/dd HH:MM:SS";
					break;
				case 2:
					f = "YYYY-mm-dd";
					break;
				case 3:
					f = "HH:MM:SS";
					break;
				case 4:
					return Long.toString(System.currentTimeMillis());
				case 5:
					f = "YYYY年mm月dd日 HH:MM:SS";
					break;
			}
			return new SimpleDateFormat(f).format(new Date());
		} catch (Exception e) {
			return new SimpleDateFormat(String.valueOf(type)).format(new Date());
		}
	}

}
