
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.ArrayList;

public class ReflectMethod {
	
	private final static List<String> loadedPackages = new ArrayList<String>();
	
	private final static Class<?>[] primitiveClasses = new Class<?>[]{int.class,byte.class,char.class,long.class,short.class,double.class,float.class,void.class,boolean.class};

	private final static Class<?>[] numberClasses = new Class<?>[]{int.class,long.class,short.class,double.class,float.class,char.class,byte.class};
	
	private final static Class<?>[] wrapperClasses = new Class<?>[]{Integer.class,Long.class,Short.class,Double.class,Float.class,Character.class,Byte.class};
	
	private final static Class<?>[] integerNumberClasses = new Class<?>[]{Integer.class,Character.class,Byte.class,Long.class,Short.class,int.class,short.class,long.class,char.class,byte.class};
	
	static{
		loadedPackages.add("java.lang");
		loadedPackages.add("android.content");
	}
	
	public static Object java(Object obj, CharSequence desc, Object... args) throws IllegalAccessException, IllegalArgumentException, ClassNotFoundException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException {
		String str = desc.toString();
		int i = str.lastIndexOf('.');
		if (i == -1) {
			throw new IllegalArgumentException();
		}
		return javax(obj, desc.subSequence(0, i), desc.subSequence(i + 1, desc.length()), args);
	}

	public static Object javax(Object obj, Object clazz, Object name, Object... args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
		Class<?> targetClass = getClass(clazz);
		if (name == null) {
			throw new IllegalArgumentException("method name null");
		}
		String method = String.valueOf(name);
		Class[] params = new Class[args.length / 2];
		Object[] passArgs = new Object[args.length / 2];
		if (args.length % 2 != 0) {
			throw new IllegalArgumentException("extra argument");
		}
		for (int i = 0,j = 0;i < args.length;i += 2,j++) {
			params[j] = getClass(args[i]);
		}
		for (int i = 1,j = 0;i < args.length;i += 2,j++) {
			passArgs[j] = args[i];
		}
		Method good = targetClass.getDeclaredMethod(method, params);
		good.setAccessible(true);
		CastArg(passArgs, params);
		return good.invoke(obj, passArgs);
	}

	public static Object javanew(Object clazz, Object... args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InstantiationException, InvocationTargetException {
		Class<?> targetClass = getClass(clazz);
		Class[] params = new Class[args.length / 2];
		Object[] passArgs = new Object[args.length / 2];
		if (args.length % 2 != 0) {
			throw new IllegalArgumentException("extra argument");
		}
		for (int i = 0,j = 0;i < args.length;i += 2,j++) {
			params[j] = getClass(args[i]);
		}
		for (int i = 1,j = 0;i < args.length;i += 2,j++) {
			passArgs[j] = args[i];
		}
		Constructor cons = targetClass.getDeclaredConstructor(params);
		cons.setAccessible(true);
		CastArg(passArgs, params);
		return cons.newInstance(passArgs);
	}

	public static Object javacb(Object clazz, Callback callback) throws ClassNotFoundException {
		return javacb(clazz, callback, false);
	}

	public static Object javacb(Object clazz, Callback callback, boolean wrap) throws ClassNotFoundException {
		Class targetClass = getClass(clazz);
		if (!targetClass.isInterface()) {
			throw new IllegalArgumentException("Not a interface");
		}
		if (callback == null) {
			throw new NullPointerException();
		}
		return Proxy.newProxyInstance(targetClass.getClassLoader(), new Class[]{targetClass}, wrap ? new JavaWrappedCallback(callback) : new JavaCallback(callback));
	}

	public static Class<?> cls(String name) throws ClassNotFoundException {
		return getClass(name);
	}

	public static Class<?> cls(ClassLoader loader, String name) throws ClassNotFoundException {
		return getClassByName(loader,name);
	}

	public static Object[] clssm(Object clazz, Object name) throws ClassNotFoundException {
		String n = String.valueOf(name);
		Class c = getClass(clazz);
		switch (n) {
			case "init":
				return c.getDeclaredConstructors();
			case "field":
				return c.getDeclaredFields();
			case "method":
				return c.getDeclaredMethods();
		}
		return null;
	}

	public static Object javags(Object obj, Object clazz, Object name) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, IllegalArgumentException {
		Class<?> klass = getClass(clazz);
		Field field = klass.getDeclaredField(String.valueOf(name));
		field.setAccessible(true);
		return field.get(obj);
	}

	public static void javass(Object obj, Object clazz, Object name, Object value) throws NoSuchFieldException, ClassNotFoundException, IllegalAccessException, IllegalArgumentException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException {
		Class klass = getClass(clazz);
		Field field = klass.getDeclaredField(String.valueOf(name));
		Object[] arr = new Object[]{value};
		CastArg(arr, new Class[]{field.getType()});
		field.setAccessible(true);
		field.set(obj, arr[0]);
	}
	
	//advanced java()
	//Auto match method
	public static Object javat(Object obj,CharSequence desc,Object... args) throws IllegalAccessException, IllegalArgumentException, ClassNotFoundException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException{
		String str = desc.toString();
		int i = str.lastIndexOf('.');
		if (i == -1) {
			throw new IllegalArgumentException();
		}
		return javaxt(obj, desc.subSequence(0, i), desc.subSequence(i + 1, desc.length()), args);
	}

	//advanced javax()
	//Auto match method
	public static Object javaxt(Object obj, Object clazz, Object name, Object... args) throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InstantiationException, InvocationTargetException, SecurityException {
		Class targetClass = getClass(clazz);
		if (name == null) {
			throw new IllegalArgumentException("null.method name");
		}
		String m_name = String.valueOf(name);
		Method method = null;
		int mark = -1;
		for (Method meth : targetClass.getDeclaredMethods()) {
			if (meth.getName().equals(m_name)) {
				int newMark = getMatchCount(args, meth.getParameterTypes());
				if (newMark > mark) {
					mark = newMark;
					method = meth;
				}
			}
		}
		if (method == null) {
			throw new NoSuchMethodException(m_name);
		}
		method.setAccessible(true);
		CastArg(args,method.getParameterTypes());
		return method.invoke(obj,args);
	}

	//advanced javanew
	//Auto match constructor
	public static Object javanewt(Object clazz,Object... args) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Class targetClass = getClass(clazz);
		Constructor cons = null;
		int mark = -1;
		for(Constructor c : targetClass.getDeclaredConstructors()){
			int newMark = getMatchCount(args,c.getParameterTypes());
			if(newMark > mark){
				cons = c;
				mark = newMark;
			}
		}
		if(cons==null){
			throw new NoSuchMethodException();
		}
		cons.setAccessible(true);
		CastArg(args,cons.getParameterTypes());
		return cons.newInstance(args);
	}
	
	//advanced javanew()
	//Create a instance without call its constructor
	public static Object forceNewInstance(Object clazz) throws ClassNotFoundException, IllegalAccessException, IllegalArgumentException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException{
		Class klass = getClass(clazz);
		return javax(getUnsafe(),"sun.misc.Unsafe","allocateInstance","java.lang.Class",klass);
	}

	//advanced java "throw"
	//throw a Throwable object without checking method declaretions
	public static void forceThrow(Throwable ex) {
		ThrowableContainer con = new ThrowableContainer();
		try {
			Field f = ThrowableContainer.class.getDeclaredField("exception");
			long l = javaxt(getUnsafe(),"sun.misc.Unsafe","objectFieldOffset",f);
			javaxt(getUnsafe(),"sun.misc.Unsafe","putObject",con,l,ex);
		} catch (Exception e) {}
		con.throwNow();
	}
	
	public static void importPackage(String packageName){
		if(packageName==null||loadedPackages.contains(packageName)){
			return;
		}
		loadedPackages.add(packageName);
	}
	
	public static void removeImport(String pkg){
		loadedPackages.remove(pkg);
	}
	
	public static void clearImports(){
		loadedPackages.clear();
	}
	
	protected static Class<?> getClass(Object clazz) throws ClassNotFoundException {
		Class targetClass = null;
		if (clazz == null) {
			return null;
		}
		if (clazz instanceof CharSequence) {
			targetClass = getClassByName(clazz.toString());
		} else if (clazz instanceof Class) {
			targetClass = (Class)clazz;
		} else {
			throw new IllegalArgumentException("Not a valid class description argument");
		}
		return (Class<?>)targetClass;
	}
	
	protected static Class<?> getClassByName(String name) throws ClassNotFoundException {
		return getClassByName(null, name);
	}
	
	protected static Class<?> getClassByName(ClassLoader cl, String name) throws ClassNotFoundException {
		int count = 0;
		while (name.endsWith("[]")) {
			count++;
			name = name.substring(0, name.length() - 2);
		}
		Class<?> klass = null;
		for (int i=0;i < primitiveClasses.length;i++) {
			if (name.equals(primitiveClasses[i].getSimpleName())) {
				klass = primitiveClasses[i];
				break;
			}
		}
		if (klass == null) {
			try {
				klass = (cl != null) ? cl.loadClass(name) : Class.forName(name);
			} catch (ClassNotFoundException e) {
				for (int i=0;i < loadedPackages.size();i++) {
					try {
						klass = (cl != null) ? cl.loadClass(loadedPackages.get(i) + "."  + name) : Class.forName(loadedPackages.get(i) + "." + name);
					} catch (ClassNotFoundException e0) {
					}
					if (klass != null) {
						break;
					}
				}
			}
		}
		if (klass == null) {
			throw new ClassNotFoundException(name);
		}
		while (count > 0) {
			Object obj = Array.newInstance(klass, 0);
			klass = obj.getClass();
			count--;
		}
		return klass;
	}

	protected static boolean isMemberOf(Object[] collection, Object element) {
		if (collection == null) {
			return false;
		}
		for (Object obj : collection) {
			if (obj == element) {
				return true;
			}
		}
		return false;
	}

	protected static boolean isNumberClass(Class c) {
		return isMemberOf(numberClasses, c);
	}

	protected static boolean isWrapperClass(Class c) {
		return isMemberOf(wrapperClasses, c);
	}

	protected static Class<?> getWrapperClass(Class<?> c) {
		if (c == null) {
			return null;
		}
		for (int i=0;i < numberClasses.length;i++) {
			if (numberClasses[i] == c || wrapperClasses[i] == c) {
				return wrapperClasses[i];
			}
		}
		return null;
	}

	protected static String trimIfNeed(String num, Class to) {
		if (isMemberOf(integerNumberClasses, to)) {
			int i = num.indexOf('.');
			if (i != -1) {
				num = num.substring(0, i);
			}
		}
		return num;
	}
	
	protected static void CastArg(Object[] a,Class<?>[] b) throws IllegalAccessException, IllegalArgumentException, NoSuchMethodException, InstantiationException, InvocationTargetException, SecurityException{
		CastArg(a,b,true);
	}

	protected static void CastArg(Object[] objs, Class<?>[] cls, boolean modify) throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException, InstantiationException {
		for (int i=0;i < objs.length && i < cls.length;i++) {
			Object obj = objs[i];
			Class<?> klass = cls[i];
			if (obj == null) {
				if (isNumberClass(klass)) {
					throw new IllegalArgumentException();
				} else {
					continue;
				}
			} else {
				Class<?> objClass = obj.getClass();
				if ((getWrapperClass(objClass) != null || objClass == String.class)) {
					if (isNumberClass(klass)) {
						String str = trimIfNeed(String.valueOf(obj), klass);
						Class<?> wrapper = getWrapperClass(klass);
						if (modify)
							if (klass == char.class) {
								objs[i] = (char) new Double(str).intValue();
							} else if (klass == int.class) {
								objs[i] = Integer.parseInt(str);
							} else {
								objs[i] = wrapper.getMethod("parse" + wrapper.getSimpleName(), String.class).invoke(null, str);
							}
						continue;
					} else if (klass == String.class) {
						if (modify)
							objs[i] = obj.toString();
						continue;
					} else if (isWrapperClass(klass)) {
						String str = trimIfNeed(String.valueOf(obj), klass);
						if (modify)
							if (klass == Character.class) {
								objs[i] = new Character((char)new Double(String.valueOf(obj)).intValue());
							} else {
								objs[i] = getWrapperClass(klass).getConstructor(String.class).newInstance(str);
							}
						continue;
					}
					if (klass == String.class) {
						if (modify)
							objs[i] = String.valueOf(obj);
						continue;
					}
					if (klass == Boolean.class) {
						String str = obj.toString().toLowerCase();
						switch (str) {
							case "true":
								if (modify)
									objs[i] = new Boolean(true);
								continue;
							case "false":
								if (modify)
									objs[i] = new Boolean(false);
								continue;
							default:
								throw new IllegalArgumentException();
						}
					}
					if (klass == boolean.class) {
						String str = obj.toString().toLowerCase();
						switch (str) {
							case "true":
								if (modify)
									objs[i] = true;
								continue;
							case "false":
								if (modify)
									objs[i] = false;
								continue;
							default:
								throw new IllegalArgumentException();
						}
					}
				}
				if (klass.isInstance(obj)) {
					continue;
				} else {
					throw new IllegalArgumentException();
				}
			}
		}
	}
	
	protected static Object getUnsafe(){
		try{
			return javags(null,"sun.misc.Unsafe","theUnsafe");
		}catch(Exception e){
			return null;
		}
	}
	
	private static int getMatchCount(Object[] args, Class[] types) {
		if (args.length != types.length) {
			return -1;
		}
		try {
			CastArg(args, types, false);
		} catch (Exception e) {
			return -1;
		}
		int mark = 0;
		for (int i=0;i < types.length;i++) {
			if (args[i] == null) {
				mark++;
			} else if (args[i].getClass() == types[i]) {
				mark++;
			}
		}
		return mark;
	}
	
	private static class ThrowableContainer{

		private RuntimeException exception;
		
		private ThrowableContainer(){
			
		}

		public void throwNow(){
			if(exception != null){
				throw exception;
			}
		}

	}

	public static class JavaWrappedCallback implements InvocationHandler {

		private Callback cb;

		private JavaWrappedCallback(Callback callback) {
			if (callback == null) {
				throw new NullPointerException();
			}
			cb = callback;
		}

		@Override
		public Object invoke(Object target, Method method, Object[] args) throws Throwable {
			Object rt = cb.onCallMethod(target, method, args);
			if (rt == null) {
				switch (method.getReturnType().getName()) {
					case "boolean":
						rt = false;
						break;
					case "int":
					case "char":
					case "long":
					case "short":
					case "double":
					case "float":
					case "byte":
						rt = 0;
						break;
				}
			} else {
				if (method.getReturnType() == void.class) {
					return null;
				}
				try {
					Object[] obj = new Object[]{rt};
					CastArg(obj, new Class[]{method.getReturnType()});
					rt = obj[0];
				} catch (Throwable t) {
					//无力回天
				}
			}
			return rt;
		}
	}

	private static class JavaCallback implements InvocationHandler {

		private Callback cb;

		private JavaCallback(Callback callback) {
			if (callback == null) {
				throw new NullPointerException();
			}
			cb = callback;
		}

		@Override
		public Object invoke(Object target, Method method, Object[] args) throws Throwable {
			return cb.onCallMethod(target, method, args);
		}

	}

	public interface Callback {

		Object onCallMethod(Object target, Method proxyMethod, Object[] args);

	}

}
