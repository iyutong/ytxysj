package com.note.yi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.WindowCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.Mus.MusEditor.MusEditor;



public class add extends AppCompatActivity
{
	String id;
	MusEditor edit;
	AlertDialog builder;
	String contents;
	Vibrator zdq = null;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
    	super.onCreate(savedInstanceState);
		supportRequestWindowFeature(WindowCompat.FEATURE_ACTION_MODE_OVERLAY);
		setContentView(R.layout.add);
		Toolbar toolbar=findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		toolbar.getOverflowIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
		toolbar.getNavigationIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() 
			{
				@Override
				public void onClick(View view) 
				{
					if(edit.getText().toString().equals(""))
					{
						add.this.finish();
					}
					else
					{
				    	AlertDialog builder = new AlertDialog.Builder(add.this)
						.setTitle("温馨提示")
						.setMessage("是否保存?")
						.setPositiveButton("确定",null)
						.setNegativeButton("取消",null)
						.show();
						builder.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xff000000);
						builder.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xff000000);
						builder.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener()
						{
							@Override
							public void onClick(View p1)
							{
								String text=edit.getText().toString().trim();
								if(text.equals(""))
								{
									tool.toast(add.this,"请不要留空");
								}
								else
								{
									
									String nr=tool.fr("/storage/emulated/0/Yi-Note/note.txt");
									String[] lb=nr.split(";");
									int did=0;
									
									for(String each:lb)
									{
										if(tool.sj(each,"(",")")!=null&&Integer.parseInt(tool.sj(each,"(",")"))>did)
										{
											did=Integer.parseInt(tool.sj(each,"(",")"));
											break;
										}
									}		
									did++;
									tool.fw("/storage/emulated/0/Yi-Note/note.txt","("+did+"){"+tool.otob(text).toString()+"}["+tool.time()+"]"+"\n"+";"+"\n"+tool.fr("/storage/emulated/0/Yi-Note/note.txt"),true);
									tool.toast(add.this,"添加成功");
									add.this.finish();
								}
							}
						});
						builder.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener()
						{
							@Override
							public void onClick(View v)
							{
								add.this.finish();
							}
						});
				}
				}
			});
		//撤销及重做图片着色及单击事件监听
		ImageView tui=findViewById(R.id.tui);
		ImageView jin=findViewById(R.id.jin);
		tui.setColorFilter(Color.parseColor("#000000"),PorterDuff.Mode.SRC_ATOP);
		jin.setColorFilter(Color.parseColor("#000000"),PorterDuff.Mode.SRC_ATOP);
		tui.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p1)
			{
				edit.undo();
			}	
		});
		jin.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p1)
			{
				edit.redo();
			}	
		});
		//fab绘色
		FloatingActionButton fab=findViewById(R.id.baoc);
		fab.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		
		//设置输入法不顶起布局
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		edit=new MusEditor(this);
		LinearLayout li=findViewById(R.id.linear);
		li.addView(edit);
		edit.setText("");
		DrawerLayout drawer=findViewById(R.id.drawerlayout);
		DrawerLayout.DrawerListener drawerListener = new DrawerLayout.DrawerListener() 
		{
			@Override
			public void onDrawerSlide(View p1, float p2){}
			@Override
			public void onDrawerOpened(View p1)
			{
				finish();
			}
			@Override
			public void onDrawerClosed(View p1){}
			@Override
			public void onDrawerStateChanged(int p1){}
		};
		drawer.addDrawerListener(drawerListener);
		drawer.setScrimColor(0x00000000);
	}
	public void baoc(View v)
	{
		
		String text=edit.getText().toString().trim();
		if(text.equals(""))
		{
			tool.toast(this,"请不要留空");
		}
		else
		{
			
			String nr=tool.fr("/storage/emulated/0/Yi-Note/note.txt");
			String[] lb=nr.split(";");
			int did=0;
			for(String each:lb)
			{
				if(tool.sj(each,"(",")")!=null&&Integer.parseInt(tool.sj(each,"(",")"))>did)
				{
					did=Integer.parseInt(tool.sj(each,"(",")"));
					break;
				}
			}
			did++;
			tool.fw("/storage/emulated/0/Yi-Note/note.txt","("+did+"){"+tool.otob(text)+"}["+tool.time()+"]"+"\n"+";"+"\n"+tool.fr("/storage/emulated/0/Yi-Note/note.txt"));
			tool.toast(add.this,"添加成功");
			add.this.finish();
		}
		
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) 
	{
        getMenuInflater().inflate(R.menu.menu_add,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
	{
        int id = item.getItemId();
        if (id == R.id.item1) 
		{
			edit.setText("");
		}
        return super.onOptionsItemSelected(item);
    }

	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event) 
	{
		if (keyCode == KeyEvent.KEYCODE_BACK) 
		{
			if(edit.getText().toString().equals(""))
			{
				add.this.finish();
			}
			else
			{
			builder = new AlertDialog.Builder(add.this)
			.setTitle("温馨提示")
			.setMessage("是否保存?")
			.setPositiveButton("确定",null)
			.setNegativeButton("取消",null).show();
			builder.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xff000000);
			builder.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xff000000);
			builder.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View p1)
				{
					String text=edit.getText().toString().trim();
					if(text.equals(""))
					{
						tool.toast(add.this,"请不要留空");
					}
					else
					{
						
						String nr=tool.fr("/storage/emulated/0/Yi-Note/note.txt");
						String[] lb=nr.split(";");
						int did=0;
						for(String each:lb)
						{
							if(tool.sj(each,"(",")")!=null&&Integer.parseInt(tool.sj(each,"(",")"))>did)
							{
								did=Integer.parseInt(tool.sj(each,"(",")"));
								break;
							}
						}
						did++;
						tool.fw("/storage/emulated/0/Yi-Note/note.txt","("+did+"){"+tool.otob(text)+"}["+tool.time()+"]"+"\n"+";"+"\n"+tool.fr("/storage/emulated/0/Yi-Note/note.txt"));
						tool.toast(add.this,"添加成功");
						add.this.finish();
					}
					}
				});
				builder.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						add.this.finish();
					}
				});
	  		}
			return true;
		}
		else if(keyCode==KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_VOLUME_UP)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_SEARCH)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_MENU)
		{
			return true;
		}
		return super.onKeyDown(keyCode,event);
	}
}
