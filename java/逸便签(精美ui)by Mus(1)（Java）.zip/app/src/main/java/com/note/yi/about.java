package com.note.yi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.MenuItem;
import android.widget.Toast;
import android.view.Menu;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.widget.DrawerLayout;
import android.view.*;
import android.graphics.*;
import android.os.*;

public class about extends AppCompatActivity 
{
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		toolbar.getOverflowIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
		toolbar.getNavigationIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View view) 
			{
			    		finish();
			}
		});
		TextView i=findViewById(R.id.i);
		TextView b=findViewById(R.id.b);
		Typeface typeFace =Typeface.createFromAsset(getAssets(),"fonts/fonta.ttf");
		TextView c = findViewById(R.id.c);
		i.setTypeface(typeFace);
	    b.setTypeface(typeFace);
		c.setTypeface(typeFace);
		DrawerLayout drawer=findViewById(R.id.drawerlayout);
		DrawerLayout.DrawerListener drawerListener = new DrawerLayout.DrawerListener() 
		{
			@Override
			public void onDrawerSlide(View p1, float p2)
			{
				// TODO: Implement this method
			}
			@Override
			public void onDrawerOpened(View p1)
			{
				finish();
			}
			@Override
			public void onDrawerClosed(View p1)
			{
				// TODO: Implement this method
			}
			@Override
			public void onDrawerStateChanged(int p1)
			{
				// TODO: Implement this method
			}
		};
		drawer.addDrawerListener(drawerListener);
		drawer.setScrimColor(0x00000000);
    }

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode==4)
		{
			finish();
		}
		return super.onKeyDown(keyCode,event);
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) 
	{
        getMenuInflater().inflate(R.menu.menu_about,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
	{
        int id = item.getItemId();
        if (id == R.id.item1) 
		{
            if(checkApkExist(this,"com.tencent.mobileqq"))
			{
			    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=2948968121&version=1")));  
			}
			else
			{   
		    	Toast.makeText(this,"请先安装QQ客户端",Toast.LENGTH_SHORT).show();                
			}
		}
		else if(id == R.id.item2)
		{
		    	if(checkApkExist(this,"com.tencent.mobileqq"))
			{
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("mqqwpa://im/chat?chat_type=group&uin=1049774501&version=1")));			
			}
			else
			{   
		    	Toast.makeText(this,"请先安装QQ客户端",Toast.LENGTH_SHORT).show();                
			}
        }
        return super.onOptionsItemSelected(item);
    }
    public void check(View v)
    {
	  tool.toast(this,"请点击右上角");
    }
	public boolean checkApkExist(Context context, String packageName) 
	{
        if (packageName == null || "".equals(packageName))
		{
			return false;
		}
		try 
		{  
            ApplicationInfo info = context.getPackageManager().getApplicationInfo(packageName,PackageManager.GET_UNINSTALLED_PACKAGES);  
            return true;  
        } 
		catch (PackageManager.NameNotFoundException e) 
		{  
            return false;  
        }  
	}
}
