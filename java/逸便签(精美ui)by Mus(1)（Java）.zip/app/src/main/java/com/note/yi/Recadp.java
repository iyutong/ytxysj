package com.note.yi;
import android.content.Intent;
import android.os.Vibrator;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;
import android.support.v7.widget.AppCompatCheckBox;
import android.view.View.OnLongClickListener;


public class Recadp extends RecyclerView.Adapter<Recadp.MyHolder> 
{
    List<String[]> mList;
    Recadp(List<String[]> list) 
	{
        mList = list;
    }
	
	//省略部分代码
	public void setFilter(List<String[]>filterWords)
	{
        mList=filterWords;
        notifyDataSetChanged();
    }
	
    //创建ViewHolder并返回，后续item布局里控件都是从ViewHolder中取出
    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) 
	{
        //将我们自定义的item布局R.layout.item转换为View
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        //将view传递给我们自定义的ViewHolder
        MyHolder holder = new MyHolder(view);
        //返回这个MyHolder实体
        return holder;
    }
    
    //通过方法提供的ViewHolder，将数据绑定到ViewHolder中
    @Override
    public void onBindViewHolder(final MyHolder holder,final int position) 
	{
		holder.title.setText(mList.get(position)[1]);
		holder.content.setText(mList.get(position)[2]);
		holder.time.setText(mList.get(position)[3]);
		checkBox_box.ea[position]=holder.del;
		holder.del.setChecked(false);
		holder.del.setVisibility(8);
		checkBox_box.cheid[position]=mList.get(position)[0];
		holder.click.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(holder.del.getVisibility()==8)
				{
					Intent intent = new Intent(v.getContext(),check.class);
					intent.putExtra("id",mList.get(position)[0]);
					v.getContext().startActivity(intent);
				}
				else
				{
					if(holder.del.isChecked())
					{
						holder.del.setChecked(false);
					}
					else
					{
						holder.del.setChecked(true);
					}
				}
			}
		});
		/*
		holder.click.setOnLongClickListener(new OnLongClickListener()
		{
			@Override
			public boolean onLongClick(View p1)
			{
				
				return false;
			}	
		});
		*/
    }
    
    //获取数据源总的条数
    @Override
    public int getItemCount() 
	{
        return  mList.size();
    }

    /**
     * 自定义的ViewHolder
     */
    class MyHolder extends RecyclerView.ViewHolder 
	{
        TextView title,content,time;
		LinearLayout click;
		AppCompatCheckBox del;
        public MyHolder(View itemView) 
		{
            super(itemView);
            title=itemView.findViewById(R.id.title);
			content=itemView.findViewById(R.id.content);
			click=itemView.findViewById(R.id.click);
			time=itemView.findViewById(R.id.time);
			del=itemView.findViewById(R.id.del);
        }
    }
}
