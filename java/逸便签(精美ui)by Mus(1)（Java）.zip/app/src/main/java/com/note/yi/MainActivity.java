package com.note.yi;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import android.support.v7.widget.AppCompatCheckBox;
import android.widget.ImageView;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity 
{
	File lp;
	boolean duo=false;
	ImageView duox;
	ImageView del;
	DrawerLayout drawer;
	Typeface typeFacec;
	Typeface typeFacex;
	static Calendar calendar;
	Recadp fad;
	EditText edit;
	RecyclerView rec;
	List<String[]> list;
	List<String[]> filterString;
	AlertDialog builder;
	String path;
	LinearLayout wu;
	boolean qx=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) 
	{
	    //Mus开源，转载请注明版权，QQ群676343719，QQ设置禁止添加了
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
		path="/storage/emulated/0/Yi-Note/note.txt";
		String lpath="/storage/emulated/0/Yi-Note/";
		lp=new File(lpath);
		if(!lp.exists()&&pdqx())
		{
			try
			{
				lp.mkdir();
				String tex="欢迎来到逸便签\n这是一款轻量级的便签软件，界面简洁，功能使用\n虽然目前只有搜索功能但以后会不断完善增加功能，它也将会越来越强\n谢谢大家使用！";
				String b = tool.otob(tex);
				tool.fw(path,"(1){"+b+"}["+tool.time()+"]");
				checkBox_box.ea=new AppCompatCheckBox[1];
			}
			catch(Exception e){}
		}
		Toolbar toolbar=findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		drawer=findViewById(R.id.drawerlayout);
		rec=findViewById(R.id.recycleview);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this,drawer,R.string.open,R.string.close);
        drawer.addDrawerListener(drawerListener);
		drawer.addDrawerListener(drawerToggle);
		drawerToggle.syncState();
		toolbar.getNavigationIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
		//给home键设置点击事件(展开侧滑)
		toolbar.setNavigationOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View view) 
			{
				drawer.openDrawer(Gravity.LEFT);
			}
		});
		
		//编辑小笔按钮着色
		duox=findViewById(R.id.duox);
		del=findViewById(R.id.del);
		duox.setColorFilter(0xff000000);
		
		duox.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if(duo==false&&wu.getVisibility()==8)
				{
					del.setVisibility(0);
					for(AppCompatCheckBox ea:checkBox_box.ea)
					{
						if(ea!=null)
						{
							ea.setVisibility(0);
						}
					}
					duo=true;
					duox.setImageResource(R.drawable.close);
				}
				else if(wu.getVisibility()==8)
				{
					del.setVisibility(8);
					for(AppCompatCheckBox ea:checkBox_box.ea)
					{
						if(ea!=null)
						{
							ea.setVisibility(8);
						}
					}
					duo=false;
					duox.setImageResource(R.drawable.duox);
				}
				else
				{
					tool.toast(MainActivity.this,"你还没有添加便签");
				}
			}
		});
		
		del.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				new Thread(new Runnable()
					{
						List<String> delid=new ArrayList<String>();
						String oldn=tool.fr(path);
						@Override
						public void run()
						{
							for(int i=0;i<checkBox_box.ea.length;i++)
							{
								if(checkBox_box.ea[i]!=null&&checkBox_box.ea[i].isChecked())
								{
									delid.add(checkBox_box.cheid[i]);
								}
							}
							for(String each:oldn.split(";"))
							{
								for(int o=0;o<delid.size();o++)
								{
									if(each!=""&&tool.sj(each,"(",")")!=""&&tool.sj(each,"(",")")!=null&&tool.sj(each,"(",")").equals(delid.get(o)))
									{
										oldn=tool.sr(oldn,each,"");
									}
								}
							}
							tool.fw(path,oldn);
							runOnUiThread(new Runnable()
							{
								@Override
								public void run()
								{
									tool.toast(MainActivity.this,"已删除");
									load();
									if(!oldn.contains("(")||!oldn.contains("{"))
									{
										wu.setVisibility(0);
									}
									del.setVisibility(8);
									duo=false;
									duox.setImageResource(R.drawable.duox);
									filterString=filter(list,edit.getText().toString());
									fad.setFilter(filterString);
								}
							});
						}
				}).start();
			}
		});
		
		//fab绘色
		FloatingActionButton fab=findViewById(R.id.fab);
		FloatingActionButton abou=findViewById(R.id.about);
		FloatingActionButton them=findViewById(R.id.theme);
		fab.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		abou.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		them.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		
		//设置侧滑展开后主内容阴影颜色为透明
        drawer.setScrimColor(0x00000000);
		typeFacec=Typeface.createFromAsset(getAssets(),"fonts/fonta.ttf");
		typeFacex=Typeface.createFromAsset(getAssets(),"fonts/font.ttf");	
		edit=findViewById(R.id.edit);
		edit.setTypeface(typeFacec);
		edit.addTextChangedListener(textWatcher);
		edit.setOnTouchListener(new OnTouchListener()
		{
			@Override
			public boolean onTouch(View v,MotionEvent w)
			{
				v.setFocusable(true);
				v.setFocusableInTouchMode(true);
				v.requestFocus();
				v.requestFocusFromTouch();
				return false;
			}
		});
		wu=findViewById(R.id.wu);
		load();
		LinearLayoutManager ma = new LinearLayoutManager(MainActivity.this,LinearLayoutManager.VERTICAL,false);
		fad = new Recadp(list);
		rec.setLayoutManager(ma);
		rec.setAdapter(fad);
		rec.setLayoutManager(new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL));
		if(pdqx()==false)
		{
			utw();
		}
    }
//回调函数，无论用户是否允许都会调用执行此方法
	@Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults) {
        switch(requestCode) 
		{
            case 0:
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
			{
                load();
				load(list);
            } 
			else
			{
                tool.toast(this,"授权失败可能会导致应用部分功能无法使用");
            }
            break;
            default:
            super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
    }
    @Override
    protected void onRestart()
    {
      super.onRestart();
	  duox.setImageResource(R.drawable.duox);
	  del.setVisibility(8);
	  if(!lp.exists()&&pdqx())
	  {
		  try
		  {
			  lp.mkdir();
		  }
		  catch(Exception e){}
	  }
	  if(pdqx()==true)
	  {
		  load();
		  load(list);
	  }
	  else
	  {
		  wu.setVisibility(0);
		  utw();
	  }
    }
    public void load()
    {
		if(pdqx())
		{
        if(new File(path).exists()) 
		{
			String nr=tool.fr(path);
		    list=new ArrayList<String[]>();
			String[] lb=nr.split(";");
			String id;
			String jg;
			String title;
			String content;
			String pd;
			boolean sf=false;
			String ym="";
			String tm;
			for(String dx:lb)
			{
				if(dx.contains("(")&&dx.contains(")")&&dx.contains("{")&&dx.contains("}"))
				{
					id=tool.sj(dx,"(",")");
					pd=tool.sj(dx,"{","}");
					tm=tool.sj(dx,"[","]");
					jg=tool.btoo(pd);
					if(pd!=null&&jg!=null&&id!=null&&id!=""&&pd!=""&&jg.toString().contains("\n"))
					{
						title=tool.sj(jg,null,"\n");
						ym=tool.sj(jg,"\n",null).trim();
						if(ym.contains("\n"))
						{
							content=tool.sj(jg,"\n","\n").trim();
						}
						else
						{
							content=tool.sj(jg,"\n",null).trim();
						}
					}
					else if(pd!=null&&jg!=null)
					{
						title=jg.toString().trim();
						content=jg.toString().trim();
					}
					else
					{
						title=null;
						content=null;
					}		
					if(dx!=null&&dx!=""&&id!=""&&id!=null&&title!=null&&title!="")
					{
						list.add(new String[]{id,title,content,tm});
						checkBox_box.ea=new AppCompatCheckBox[list.size()];
						checkBox_box.cheid=new String[list.size()];
						sf=true;
					}
					
				}
				
			}
			if(sf==true)
			{
				wu.setVisibility(8);
			}
			else
			{
				wu.setVisibility(0);
			}
		} 
		else 
		{	
		    String tex="欢迎来到逸便签\n这是一款轻量级的便签软件，界面简洁，功能使用\n虽然目前只有搜索功能但以后会不断完善增加功能，它也将会越来越强\n谢谢大家使用！";
			String b = tool.otob(tex);
			tool.fw(path,"(1){"+b+"}["+tool.time()+"]");
			list = new ArrayList<String[]>();
			list.add(new String[]{"1","欢迎来到逸便签","这是一款轻量级的便签软件，界面简洁，功能使用\n虽然目前只有搜索功能但以后会不断完善增加功能，它也将会越来越强\n谢谢大家使用！",tool.time()});
			checkBox_box.ea=new AppCompatCheckBox[1];
		}
		}
		else
		{
			list=new ArrayList<String[]>();
			String[] in={"","","",""};
			list.add(in);
		}
    }
	public boolean pdqx()
	{
		try
        {
            int Permission=ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE);
			int Permission2=ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.WRITE_EXTERNAL_STORAGE);
			if(Permission==-1||Permission2==-1)
            {
				return false;
            }
			else
			{
				return true;
			}
        } 
        catch(Exception e) 
        {
            e.printStackTrace();
            tool.toast(this,"未知错误"+e.toString());
			return false;
        }
	}
	
	public void utw()
	{
		ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE},0);
	}
	public void about(View v)
	{
		drawer.closeDrawer(Gravity.LEFT);
		startActivity(new Intent(MainActivity.this,about.class));
	}
	public void theme(View v)
	{
		
		tool.toast(this,"主题切换功能正在开发中");
	}
	public void wu(View v)
	{
	}
	public void add(View v)
	{
		if(pdqx()==true)
		{
			startActivity(new Intent(MainActivity.this,add.class));
		}
		else
		{
			utw();
		}
	}
	DrawerLayout.DrawerListener drawerListener=new DrawerLayout.DrawerListener() 
	{
        @Override
        public void onDrawerSlide(View drawerView,float slideOffset) 
		{
		    View content=drawer.getChildAt(0);
            int offset=(int)(drawerView.getWidth()*slideOffset);
            content.setTranslationX(offset);	
        }
        @Override
        public void onDrawerOpened(View drawerView) {}
        @Override
        public void onDrawerClosed(View drawerView) {}
        @Override
        public void onDrawerStateChanged(int newState) {}
    };
    

	@Override
    public boolean onCreateOptionsMenu(Menu menu) 
	{
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
	{
        int id = item.getItemId();
        if (id == R.id.item1) 
		{
	
            
        }
		else if(id == R.id.item2)
		{
		
            startActivity(new Intent(MainActivity.this,about.class));
        }
		else
		{
	
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
	private TextWatcher textWatcher=new TextWatcher() 
	{
		@Override
		public void onTextChanged(CharSequence s,int start,int before,int count) 
		{
			filterString=filter(list,s.toString());
			fad.setFilter(filterString);
			if((s.toString()).equals(""))
			{
				edit.setTypeface(typeFacec);
			}
			else
			{
				edit.setTypeface(typeFacex);
			}
		}
		@Override
		public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
		@Override
		public void afterTextChanged(Editable s) {}
	};
	
	public void load(final List<String[]> List)
	{
		new Thread(new Runnable()
			{
				@Override
				public void run()
				{
					runOnUiThread(new Runnable()
					{
						@Override
						public void run()
						{
							fad.setFilter(List);
						}
				});
				}
 		}).start();
	}
	public List<String[]> filter(List<String[]>strings,String text)
	{
        filterString=new ArrayList<String[]>();
        for (String[] word:strings)
		{
		    if(word[1]!=null&&word[2]!=null)
			{
            if(word[1].contains(text)||word[2].contains(text))
			{
				filterString.add(word);
			}
			}
        }
        return filterString;
    }
	
	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event) 
	{
		if (keyCode==KeyEvent.KEYCODE_BACK) 
		{
			if(drawer.isDrawerOpen(Gravity.LEFT))
			{
				drawer.closeDrawer(Gravity.LEFT);
			}
			else
			{
				Intent home=new Intent(Intent.ACTION_MAIN);
            	home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            	home.addCategory(Intent.CATEGORY_HOME);
            	startActivity(home);
			}
			return true;
		}
		else if(keyCode==KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_VOLUME_UP)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_SEARCH)
		{
			return true;
		}  
		else if(keyCode==KeyEvent.KEYCODE_MENU)
		{
			return true;
		}
		return super.onKeyDown(keyCode,event);
	}
}
