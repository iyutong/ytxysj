package com.note.yi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.WindowCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.Mus.MusEditor.MusEditor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import org.apache.http.util.EncodingUtils;



public class check extends AppCompatActivity
{
	String id;
	MusEditor edit;
	String contents;
	AlertDialog builder;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
    	super.onCreate(savedInstanceState);
		supportRequestWindowFeature(WindowCompat.FEATURE_ACTION_MODE_OVERLAY);
		setContentView(R.layout.check);
		Intent intent = getIntent();
		id = intent.getStringExtra("id");
		Toolbar toolbar=findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		toolbar.getOverflowIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);
		toolbar.getNavigationIcon().setColorFilter(0xff000000,PorterDuff.Mode.SRC_ATOP);	
        toolbar.setNavigationOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View view) 
			{
			    	builder = new AlertDialog.Builder(check.this)
					.setTitle("温馨提示")
					.setMessage("是否保存?")
					.setPositiveButton("确定",null)
					.setNegativeButton("取消",null).show();
				builder.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xff000000);
				builder.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xff000000);
				builder.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener()
					{
						@Override
						public void onClick(View p1)
						{
						    String text=edit.getText().toString().trim();
							if(text.equals(""))
							{
								tool.toast(check.this,"请不要留空");
							}
							else
							{
								
								String nr=tool.fr("/storage/emulated/0/Yi-Note/note.txt");
								String[] lb=nr.split(";");
								for(String each:lb)
								{
									if(id.equals(tool.sj(each,"(",")")))
									{
										tool.fw("/storage/emulated/0/Yi-Note/note.txt",tool.sr(nr,each,"("+id+"){"+tool.otob(text)+"}["+tool.time()+"]"));
										tool.toast(check.this,"修改成功");
										check.this.finish();
										break;
									}
								}
							}
						}
					});
				builder.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener()
					{
						@Override
						public void onClick(View v)
						{
						    check.this.finish();
						}
					});
			}
		});
		
		//fab绘色
		FloatingActionButton de=findViewById(R.id.delete);
		FloatingActionButton bc=findViewById(R.id.baoc);
		de.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		bc.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
		
		ImageView tui=findViewById(R.id.tui);
		ImageView jin=findViewById(R.id.jin);
		ImageView search=findViewById(R.id.search);
		tui.setColorFilter(Color.parseColor("#000000"),PorterDuff.Mode.SRC_ATOP);
		jin.setColorFilter(Color.parseColor("#000000"),PorterDuff.Mode.SRC_ATOP);
		search.setColorFilter(Color.parseColor("#000000"),PorterDuff.Mode.SRC_ATOP);
		tui.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p1)
			{
				edit.undo();
			}	
		});
		jin.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p1)
			{
				edit.redo();
			}	
		});
		search.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p1)
			{
				edit.search();
			}	
		});
		//设置输入法不顶起布局
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		edit=new MusEditor(this);
		LinearLayout li=findViewById(R.id.linear);
		li.addView(edit);
		edit.setText("");
		edit.setOnTouchListener(new OnTouchListener()
		{
			@Override
			public boolean onTouch(View v,MotionEvent w)
			{
				v.setFocusable(true);
                v.setFocusableInTouchMode(true);
                v.requestFocus();
                v.requestFocusFromTouch();
				return false;
			}
		});
		DrawerLayout drawer=findViewById(R.id.drawerlayout);
		DrawerLayout.DrawerListener drawerListener = new DrawerLayout.DrawerListener() 
		{
			@Override
			public void onDrawerSlide(View p1, float p2){}
			@Override
			public void onDrawerOpened(View p1)
			{
				finish();
			}
			@Override
			public void onDrawerClosed(View p1){}
			@Override
			public void onDrawerStateChanged(int p1){}
		};
		drawer.addDrawerListener(drawerListener);
		drawer.setScrimColor(0x00000000);
		
		String did;
		String nr=fr("/storage/emulated/0/Yi-Note/note.txt");
		if(nr.length()>10)
		{
			String[] lb=nr.split(";");
			for(String each:lb)
			{
				each.trim();
				did=tool.sj(each,"(",")");
				if(did!=null&&did.equals(id))
				{
					contents=tool.btoo(tool.sj(each,"{","}")).toString().trim();
					edit.setText(contents);
					break;
				}
			}
		}
		else
		{
			tool.toast(check.this,"未知错误");
			finish();
		}
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) 
	{
        getMenuInflater().inflate(R.menu.menu_check,menu);
	    return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) 
	{
        int id = item.getItemId();
        if(id == R.id.item1) 
		{
		    tool.sxb(this,contents);
			tool.toast(check.this,"已复制到剪切板");
		}
		else if (id == R.id.item2)
		{
		    Intent share_intent = new Intent();
    	    share_intent.setAction(Intent.ACTION_SEND);
  	        share_intent.setType("text/plain");
  	        share_intent.putExtra(Intent.EXTRA_SUBJECT, "分享便签");
     	    share_intent.putExtra(Intent.EXTRA_TEXT,"内容");
   	        share_intent = Intent.createChooser(share_intent,"分享便签");
    	    startActivity(share_intent);
   	     }
        return super.onOptionsItemSelected(item);
    }
	public void delete(View v)
	{
	    String nr=fr("/storage/emulated/0/Yi-Note/note.txt");
		String[] lb=nr.split(";");
		for(String each:lb)
		{
			if(id.equals(tool.sj(each,"(",")")))
			{
				fw(new File("/storage/emulated/0/Yi-Note/note.txt"),tool.sr(nr,each,""));
				tool.toast(check.this,"删除成功");
				check.this.finish();
				break;
			}
		}
	}
	public void baoc(View v)
	{
	    String text=edit.getText().toString().trim();
		if(text.equals(""))
		{
			tool.toast(check.this,"请不要留空");
		}
		else
		{
			
			String nr=fr("/storage/emulated/0/Yi-Note/note.txt");
			String[] lb=nr.split(";");
			for(String each:lb)
			{
				if(id.equals(tool.sj(each,"(",")")))
				{
					fw(new File("/storage/emulated/0/Yi-Note/note.txt"),tool.sr(nr,each,"("+id+"){"+tool.otob(text)+"}["+tool.time()+"]"));
					tool.toast(check.this,"修改成功");
					check.this.finish();
					break;
				}
			}
		}
	}
	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event) 
	{
		if (keyCode == KeyEvent.KEYCODE_BACK) 
		{
		    	builder = new AlertDialog.Builder(check.this)
				.setTitle("温馨提示")
				.setMessage("是否保存?")
				.setPositiveButton("确定",null)
				.setNegativeButton("取消",null).show();
			builder.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xff000000);
			builder.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xff000000);
			builder.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View p1)
					{
					    String text=edit.getText().toString().trim();
						if(text.equals(""))
						{
							tool.toast(check.this,"请不要留空");
						}
						else
						{
							
							String nr=fr("/storage/emulated/0/Yi-Note/note.txt");
							String[] lb=nr.split(";");
							for(String each:lb)
							{
								if(id.equals(tool.sj(each,"(",")")))
								{
									fw(new File("/storage/emulated/0/Yi-Note/note.txt"),tool.sr(nr,each,"("+id+"){"+tool.otob(text)+"}["+tool.time()+"]"));
									tool.toast(check.this,"修改成功");
									check.this.finish();
									break;
								}
							}
						}
					}
				});
			builder.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
							check.this.finish();
					}
				});
			return true;
		}
		else if(keyCode ==   KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			return   true;
		}  
		else if(keyCode ==   KeyEvent.KEYCODE_VOLUME_UP)
		{
			return   true;
		}  
		else if(keyCode ==   KeyEvent.KEYCODE_SEARCH)
		{
			return   true;
		}  
		else if(keyCode ==   KeyEvent.KEYCODE_MENU)
		{
			return   true;
		}
		return super.onKeyDown(keyCode, event);
	}
    public String fr(String file)
	{
		try
		{
        String result = "";
		InputStream in =new FileInputStream(file);
		int lenght = in.available();
		byte[]  buffer = new byte[lenght];
		in.read(buffer);
		result = EncodingUtils.getString(buffer, "utf-8");
		in.close();
		return result;
		}
		catch(Exception e)
		{
			tool.toast(check.this,"错误"+e.toString());
			return null;
		}
		
    }

	public void fw(File file,String content)
	{
		FileWriter writer=null;
		try
		{
		writer = new FileWriter(file);
	    writer.write(content);
		writer.close();
		}
		catch(Exception e)
		{
			tool.toast(check.this,"错误"+e.toString());
		}
	}
}
