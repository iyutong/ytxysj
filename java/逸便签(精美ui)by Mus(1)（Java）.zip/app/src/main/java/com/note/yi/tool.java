package com.note.yi;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.note.yi.MainActivity;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import org.apache.http.util.EncodingUtils;

public class tool
{
	public static String time()
	{
		MainActivity.calendar=Calendar.getInstance();
		String hour=MainActivity.calendar.get(Calendar.HOUR_OF_DAY)+"";
		String minute=MainActivity.calendar.get(Calendar.MINUTE)+"";
		if(hour.length()==1)
		{
			hour="0"+hour;
		}
		if(minute.length()==1)
		{
			minute="0"+minute;
		}
		String clock=hour+":"+minute;
		return MainActivity.calendar.get(Calendar.YEAR)+"年"+(MainActivity.calendar.get(Calendar.MONTH)+1)+"月"+MainActivity.calendar.get(Calendar.DAY_OF_MONTH)+"日"+clock;
	}
	public static void sxb(Context con,String str)
	{
		ClipboardManager clipboardManager = (ClipboardManager)con.getSystemService(Context.CLIPBOARD_SERVICE);
  		ClipData clipData = ClipData.newPlainText("label",str);  
  	    clipboardManager.setPrimaryClip(clipData); 
	}
	public static String fr(String file)
	{
        String result = "";
		try 
		{
			InputStream in=new FileInputStream(file);
			int lenght=in.available();
			byte[] buffer=new byte[lenght];
			in.read(buffer);
			result=EncodingUtils.getString(buffer,"utf-8");
			in.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	public static void fw(String path,String content)
	{
		FileWriter writer=null;
		try 
		{
			writer=new FileWriter(new File(path));
			writer.write(content);
			writer.flush();
			writer.close();
		} 
		catch (IOException e){}
	}
	public static void fw(String path,String content,boolean sf)
	{
		try 
		{
			BufferedWriter writer=new BufferedWriter(new FileWriter(new File(path)));
			writer.write(content);
			writer.flush();
			writer.close();
		} 
		catch (IOException e){}
	}
    public static void toast(Context con,String i)
	{
		Toast toast= Toast.makeText(con,"",0);
		toast.setGravity(Gravity.CENTER,0,-300);
		LinearLayout ne=new LinearLayout(con);
		LinearLayout ne2=new LinearLayout(con);
		ne2.addView(ne);
		LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) ne.getLayoutParams();  
		params.topMargin=25;
		params.bottomMargin=25;
		params.leftMargin=50;
		params.rightMargin=50;
		ne.setLayoutParams(params);
		ne2.setBackgroundResource(R.drawable.toast);
		ne.setGravity(Gravity.CENTER);
		TextView te=new TextView(con);
		ne.addView(te);
		te.setText(i);
		te.setTextColor(Color.parseColor("#ffffff"));
		toast.setView(ne2);
		toast.show();
	}
	public static String sj(String str,String start,String end)
	{
		if(str==null)
		{
			return null;
		}
		else
		{
			String result="";
			if(start==null&&end!=null&&str.contains(end))
			{
				int h=str.indexOf(end);
				result=str.substring(0,h);
			}
			else if(start!=null&&end==null&&str.contains(start))
			{
				int q=str.indexOf(start)+1;
				result=str.substring(q);
			}
			else if(start!=null&&end!=null&&start!=end&&str.contains(start)&&str.contains(end))
			{
				int q=str.indexOf(start)+1;
				int h=str.indexOf(end);
				result=str.substring(q,h);
			}
			else if(start!=null&&end!=null&&!start.equals(end)&&start.equals(end)&&str.contains(start)&&str.contains(end))
			{
				int q=str.indexOf(start)+1;
				int h=str.indexOf(end);
				result=str.substring(q,h);
			}
			else if(start!=null&&end!=null&&start.equals(end)&&start.equals(end)&&str.contains(start)&&str.contains(end))
			{
				int q=str.indexOf(start)+1;
				result=str.substring(q);
				result=sj(result,null,start);
			}
			else if(start==null&&end==null)
			{
				result=str;
			}
			else
			{
				result=null;
			}
			return result;
		}
	}
	public static String sr(String str,String old,String newo)
	{
		return str.replace(old,newo);
	}
	public static String otob(String str,String coding)
	{
		if(str==null)
		{
			return null;
		}
		else
		{
			try
			{
				byte[] by;
				if(coding==null)
				{
					by=str.getBytes();
				}
				else
				{
					by=str.getBytes(coding);
				}
				String result="";
				for(byte each:by)
				{
					result=result+" "+each;
				}
				return result.trim();
			}
			catch (UnsupportedEncodingException e)
			{
				return "-26 -105 -96 -27 -122 -123 -27 -82 -71";
			}
		}
	}
	public static String btoo(String str,String coding)
	{
		if(str==null)
		{
			return null;
		}
		else
		{
			String[] by=str.trim().split(" ");
			byte[] byt=new byte[by.length];
			for(int i=0;i<by.length;i++)
			{
				byt[i]=(byte)Integer.valueOf(by[i]).intValue();
			}
			if(byt==null)
			{
				return null;
			}
			else
			{
				String result="";
				try
				{
					result=new String(byt,coding);
				}
				catch (UnsupportedEncodingException e)
				{
					result=null;
				}
				return result;
			}
		}
	}
	public static String otob(String str)
	{
		if(str==null)
		{
			return null;
		}
		else
		{
			try
			{
				byte[] by=str.getBytes("utf-8");
				String result="";
				for(byte each:by)
				{
					result=result+" "+each;
				}
				return result.trim();
			}
			catch (UnsupportedEncodingException e)
			{
				return "-26 -105 -96 -27 -122 -123 -27 -82 -71";
			}
		}
	}
	public static String btoo(String str)
	{
		if(str==null)
		{
			return null;
		}
		else
		{
			String[] by=str.trim().split(" ");
			byte[] byt=new byte[by.length];
			for(int i=0;i<by.length;i++)
			{
				byt[i]=(byte)Integer.valueOf(by[i]).intValue();
			}
			if(byt==null)
			{
				return null;
			}
			else
			{
				String result="";
				try
				{
					result=new String(byt,"utf-8");
				}
				catch (UnsupportedEncodingException e)
				{
					result=null;
				}
				return result;
			}
		}
	}
}
