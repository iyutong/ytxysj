package com.note.yi;
import android.support.v7.widget.AppCompatCheckBox;

public class checkBox_box
{
	static AppCompatCheckBox[] ea;
	static String[] cheid;
}
