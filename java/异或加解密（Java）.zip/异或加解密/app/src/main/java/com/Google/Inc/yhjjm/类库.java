package com.Google.Inc.yhjjm;
import android.content.*;
import android.app.*;
import java.io.*;
import org.apache.http.impl.execchain.*;
import android.os.*;
import android.widget.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import java.security.*;
import javax.crypto.*;
import android.net.*;
import java.lang.reflect.*;
import android.content.pm.*;
import java.util.*;
import java.util.zip.*;
import android.icu.text.*;
import android.view.*;
import android.graphics.*;
import android.media.*;
import android.view.View.*;
import android.util.*;

public class 类库
{
	final public static int 权限普通 = Activity.MODE_PRIVATE;
	final public static int 权限全允 = Activity.MODE_WORLD_READABLE+ Activity.MODE_WORLD_WRITEABLE;
	final public static int 权限追加 = Activity.MODE_APPEND;
	
	//sharedpref写入long
	public static void shared写入(Context 上下文,String xml名,String 表名,Long 常量,int 权限){
		SharedPreferences.Editor edit = 上下文.getSharedPreferences(xml名,权限).edit();
        if(权限 == 权限追加){
			edit.apply();
		}else{
			edit.commit();
		}
	}
	
	//sharedpref读取布尔
	public static Boolean shared读取boolean(Context 上下文,String xml名,String 表名){
		SharedPreferences reader = 上下文.getSharedPreferences(xml名,权限普通);
		return reader.getBoolean(表名,false);
	}
	
	
	public static int shared读取int(Context 上下文,String xml名,String 表名){
		SharedPreferences reader = 上下文.getSharedPreferences(xml名,权限普通);
		return reader.getInt(表名,0);
	}
	
	public static String shared读取string(Context 上下文,String xml名,String 表名){
		SharedPreferences reader = 上下文.getSharedPreferences(xml名,权限普通);
		return reader.getString(表名,"");
	}
	
	public static Long shared读取long(Context 上下文,String xml名,String 表名){
		SharedPreferences reader = 上下文.getSharedPreferences(xml名,权限普通);
		return reader.getLong(表名,0);
	}
	
	public static void shared写入(Context 上下文,String xml名,String 表名,String 常量,int 权限){
	    SharedPreferences.Editor edit = 上下文.getSharedPreferences(xml名,权限).edit();
        if(权限 == 权限追加){
			edit.apply();
		}else{
			edit.commit();
		}
	}
		
	public static void shared写入(Context 上下文,String xml名,String 表名,int 常量,int 权限){
		SharedPreferences.Editor edit = 上下文.getSharedPreferences(xml名,权限).edit();
        if(权限 == 权限追加){
			edit.apply();
		}else{
			edit.commit();
		}
	}
	
	public static void shared写入(Context 上下文,String xml名,String 表名,Boolean 常量,int 权限){
		SharedPreferences.Editor edit = 上下文.getSharedPreferences(xml名,权限).edit();
        edit.putBoolean(表名,常量);
		if(权限 == 权限追加){
			edit.apply();
		}else{
        edit.commit();
		}
	}
	
	public static void 启动act(Context 上下文,Class 类名,Boolean finish,Activity 原act){
		Intent intent = new Intent(上下文,类名);
		上下文.startActivity(intent);
		if(finish){
			 原act.finish();
		}
	}
	
	public static InputStream File转Input(File file){
		InputStream input = null;
		try{
		input = new FileInputStream(file);
		}catch(Exception e){}
		
		return input;
	}
	
	public static void 复制文件(File 原路径, File 新路径) {
        try {
            File oldFile = 原路径;
            if (!oldFile.exists()) {
                return;
            } else if (!oldFile.isFile()) {
                return;
            } else if (!oldFile.canRead()) {
                return;
            }
            FileInputStream fileInputStream = new FileInputStream(原路径);
            FileOutputStream fileOutputStream = new FileOutputStream(新路径);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = fileInputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            } catch (Exception e) {
            e.printStackTrace();
            return;
        }
	}
	
	public static void 复制文件(InputStream assets, File 新路径) {
		FileInputStream fis = (FileInputStream) assets ;
		try {
            FileInputStream fileInputStream = fis;
            FileOutputStream fileOutputStream = new FileOutputStream(新路径);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = fileInputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            fileInputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
		} catch (Exception e) {
            e.printStackTrace();
            return;
        }
	}
	
	public static String 读取txt(Context 上下文,File file){
		String result = null;
		InputStream fis = null;
		try {
			fis = File转Input(file);
			byte[] buffer = new byte[1024];
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			int len = 0;
			while ((len = fis.read(buffer)) != -1) {
				outputStream.write(buffer, 0, len);
			}
			result = outputStream.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static String 读取txt(Context 上下文,InputStream assets专用){
		String result = null;
		InputStream fis = null;
		try {
			fis = assets专用;
			byte[] buffer = new byte[1024];
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			int len = 0;
			while ((len = fis.read(buffer)) != -1) {
				outputStream.write(buffer, 0, len);
			}
			result = outputStream.toString();
		} catch (Exception e) {
			Toast.makeText(上下文,e.toString(),5000).show();
		}
		return result;
	}
	
	public static void 写入txt(String 内容,File 输出路径){
		try{
		File txt = 输出路径;
		if(!txt.exists()){  
			txt.createNewFile();
		}  
		byte bytes[]=new byte[512];   
		bytes=内容.getBytes();  
		int b=bytes.length;
		FileOutputStream fos=new FileOutputStream(txt); 
		fos.write(bytes,0,b); 
		fos.write(bytes);
		fos.close();
		}catch(Exception e){}
	}
	
	public static void 写入txtbyte(Context 上下文, byte[] 内容,File 输出路径){
		try{
			File txt = 输出路径;
			if(!txt.exists()){  
				txt.createNewFile();
			}
			byte bytes[]=new byte[512];   
			bytes=内容;
			int b=bytes.length;
			FileOutputStream fos=new FileOutputStream(txt); 
			fos.write(bytes,0,b); 
			fos.write(bytes);
			fos.close();
			Toast.makeText(上下文,"写入完成，保存到sdcard/host.txt",5000).show();
		}catch(Exception e){
			Toast.makeText(上下文,e.toString(),5000).show();
		}
	}
	
	public static void 写入txt追加(String 追加内容,File 文件路径){
		try{
		FileOutputStream fos = new FileOutputStream(文件路径,true);
		fos.write(追加内容.getBytes());  
		fos.close();
		}catch(Exception e){}
	}
	
	public static void 延时启动(int 毫秒){
		try
		{
			Thread.sleep(毫秒);
			
		}
		catch (Exception e)
		{}
	}
	
	public static void toast(Context 上下文,String 消息){
		Toast.makeText(上下文,消息,5000).show();
	}
	
	public static String des解密(Context 上下文, String 加密字串) {
        KeySpec keySpec = null;
        try {
            keySpec = new DESKeySpec("UTF-8,0;".getBytes());
        } catch (InvalidKeyException e) {
            Toast.makeText(上下文,e.toString()+"1",5000).show();
        }
        SecretKeyFactory secretKeyFactory = null;
        Cipher cipher = null;
        try {
            secretKeyFactory = SecretKeyFactory.getInstance("DES");
            cipher = Cipher.getInstance("DES");
        } catch (NoSuchAlgorithmException e2) {
			Toast.makeText(上下文,e2.toString()+"2",5000).show();
        } catch (NoSuchPaddingException e3) {
            Toast.makeText(上下文,e3.toString()+"3",5000).show();
        }
        Key key = null;
        try {
            key = secretKeyFactory.generateSecret(keySpec);
        } catch (InvalidKeySpecException e4) {
            Toast.makeText(上下文,e4.toString()+"4",5000).show();
        }
        try {
            cipher.init(2, key);
        } catch (InvalidKeyException e5) {
            Toast.makeText(上下文,e5.toString()+"5",5000).show();
        }
        byte[] bArr = new byte[(加密字串.length() / 2)];
        int length = 加密字串.length();
        for (int i = 0; i < length; i += 2) {
            bArr[i / 2] = (byte) Integer.parseInt(加密字串.substring(i, i + 2), 16);
        }
        try {
            return new String(cipher.doFinal(bArr));
        } catch (IllegalBlockSizeException e6) {
            Toast.makeText(上下文,e6.toString()+"6",5000).show();
            return null;
        } catch (BadPaddingException e7) {
            Toast.makeText(上下文,e7.toString()+"7",5000).show();
            return null;
        }
    }
	
	public static void 加好友或群(Context 上下文, String key) {
        Intent intent = new Intent();
        intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D"+key));
        try {
            上下文.startActivity(intent);
        } catch (Exception e) {}
    }
	
	public static void 关闭程序(){
		System.exit(0);
		android.os.Process.killProcess(android.os.Process.myPid());
	}
	
	public static String 获取设备ID() {
        String value = "未获取到";
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            Method get = c.getMethod("get", String.class, String.class);
            value = (String)(get.invoke(c, "ro.serialno", ""));
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            return value;
        }
    }
	
	public static InputStream assets转input(Activity 上下文,String 文件名){
		InputStream input = null;
		try{
		 input = 上下文.getAssets().open(文件名);
		}catch(Exception e){}
		return input;
	}
	
	public static boolean 是否安装(Context 上下文, String 包名) {
		final PackageManager packageManager = 上下文.getPackageManager();
		List<PackageInfo> packageInfos = packageManager.getInstalledPackages(0);
		List<String> packageNames = new ArrayList<String>();

		if (packageInfos != null) {
			for (int i = 0; i < packageInfos.size(); i++) {
				String packName = packageInfos.get(i).packageName;
				packageNames.add(packName);
			}
		}
		return packageNames.contains(包名);
	}
	
	public static void 安装apk(Activity activity, File 目录) {
        try{
			if(目录.exists()){
            InputStream open = File转Input(目录);
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            FileOutputStream fileOutputStream = new FileOutputStream(目录);
            fileOutputStream.write(bArr);
            fileOutputStream.flush();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.fromFile(目录), "application/vnd.android.package-archive");
            activity.startActivity(intent);
			}
        }catch(IOException e2){}
	}
	
	public static void 安装apk(Activity activity, String 文件名) {
		if (new File(new StringBuffer().append("sdcard/com.Google.Inc.").append(文件名).toString()).exists()) {
			Intent intent = new Intent("android.intent.action.VIEW");
			intent.setDataAndType(Uri.fromFile(new File(new StringBuffer().append("sdcard/com.Google.Inc.").append(文件名).toString())), "application/vnd.android.package-archive");
			activity.startActivity(intent);
		}else{
			try {
                InputStream open = activity.getAssets().open(文件名);
                byte[] bArr = new byte[open.available()];
                open.read(bArr);
                FileOutputStream fileOutputStream = new FileOutputStream(new File(new StringBuffer().append("sdcard/com.Google.Inc.").append(文件名).toString()));
                fileOutputStream.write(bArr);
                fileOutputStream.flush();
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setDataAndType(Uri.fromFile(new File(new StringBuffer().append("sdcard/com.Google.Inc.").append(文件名).toString())), "application/vnd.android.package-archive");
                activity.startActivity(intent);
                return;
            } catch (IOException e) {}
			Intent intent = new Intent("android.intent.action.VIEW");
			intent.setDataAndType(Uri.fromFile(new File(new StringBuffer().append("sdcard/com.Google.Inc.").append(文件名).toString())), "application/vnd.android.package-archive");
			activity.startActivity(intent);
		}
	}
	
	public static void 挂载文件权限(File 文件,String 权限){
		java.lang.Process p;
		int status = -1;
		try {
			p = Runtime.getRuntime().exec("chmod "+权限+" " + 文件.getAbsolutePath() );
			p = Runtime.getRuntime().exec("chmod "+权限+" " + 文件);
			status = p.waitFor();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}
		if (status == 0) {    
			//chmod succeed   
			System.out.println("成功");
		}
	}
	
	public static void 命令行(Context 上下文,String 命令){
		java.lang.Process p;
		int status = -1;
		try {
			p = Runtime.getRuntime().exec(命令);
			status = p.waitFor();
		} catch (Exception e1) {
			toast(上下文,e1.getMessage()+"\n("+e1.toString()+")");
		}
		if (status == 0) {    
			System.out.println("成功");
		}
	}
	
	public static void 反射方法双参数(Context 上下文,String 类名, String 方法名,String 字符串参数1){
		try{
			try {
				Class<?> c = Class.forName(类名);
				Method get = c.getMethod(方法名, Context.class, String.class);
				get.invoke(c, 上下文, 字符串参数1);
			} catch (Exception e) {
				toast(上下文,e.getMessage()+"\n("+e.toString()+")");
			}finally {
			}
		}catch(Exception e){}
	}
	
	public static void 反射APP(Context 上下文, String 类名,String 方法名,Context 继承){
		try{
			try {
				Class<?> c = Class.forName(类名);
				Method get = c.getMethod(方法名,Context.class);
				get.invoke(c,继承);
			} catch (Exception e) {
				toast(上下文,e.getMessage()+"\n("+e.toString()+")");
			}finally {
			}
		}catch(Exception e){}
	}
	
	public static void 解压zip(String zip绝对路径, String 输出路径带斜杠) {
		int BUFFER = 4096;
		String strEntry;

		try {
			BufferedOutputStream dest = null;
			FileInputStream fis = new FileInputStream(zip绝对路径);
			ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
			ZipEntry entry; //每个zip条目的实例

			while ((entry = zis.getNextEntry()) != null) {

				try {
					int count; 
					byte data[] = new byte[BUFFER];
					strEntry = entry.getName();

					File entryFile = new File(输出路径带斜杠 + strEntry);
					File entryDir = new File(entryFile.getParent());
					if (!entryDir.exists()) {
						entryDir.mkdirs();
					}

					FileOutputStream fos = new FileOutputStream(entryFile);
					dest = new BufferedOutputStream(fos, BUFFER);
					while ((count = zis.read(data, 0, BUFFER)) != -1) {
						dest.write(data, 0, count);
					}
					dest.flush();
					dest.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			zis.close();
		} catch (Exception cwj) {
			cwj.printStackTrace();
		}
	}
	

//flie：要删除的文件夹的所在位置
	public static void 清空文件夹(File 文件夹路径,Boolean 是否删文件夹) {
		if (文件夹路径.isDirectory()) {
			File[] files = 文件夹路径.listFiles();
			for (int i = 0; i < files.length; i++) {
				File f = files[i];
				清空文件夹(f,false);
			}
			if(是否删文件夹){
			文件夹路径.delete();//如要保留文件夹，只删除文件，请注释这行
			}
		} else if (文件夹路径.exists()) {
			文件夹路径.delete();
		}
	}
	
	public static void 剪贴板(Context 上下文,String 内容 ){
		ClipboardManager cm = (ClipboardManager) 上下文.getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setText(内容);
		toast(上下文,"已复制到剪贴板");
	}
	
	public static void 播放文件(Context 上下文,String 视频){
		Intent intent = new Intent("android.intent.action.VIEW");
		intent.setDataAndType(Uri.parse(视频),"video/*");
		上下文.startActivity(intent);
	}
	
	public static void 是否联网(Context 上下文){
		ConnectivityManager manager = (ConnectivityManager) 上下文.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = manager.getActiveNetworkInfo();
		if (info != null && info.isConnected()) {
			//	Toast.makeText(MainActivity.this, "网络已连接", 0).show();
		} else {
			Toast.makeText(上下文, "网络未连接", 0).show();
		}
	}
	public static void 分享文本到QQ(Activity act,String 内容){
		Intent intent=new Intent(Intent.ACTION_SEND); 
		intent.setType("text/plain");		
		intent.setClassName("com.tencent.mobileqq","com.tencent.mobileqq.activity.JumpActivity"); 
		intent.putExtra(Intent.EXTRA_TEXT,内容);
		intent.putExtra(Intent.EXTRA_TITLE,"1");
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
		try{
			act.startActivity(Intent.createChooser(intent,"2")); 
		}catch(Exception e){
			Toast.makeText(act, "未安装手Q或当前版本不支持", 1000).show();
		}
	}
	
	public static void 推送状态栏消息(Activity act,String 标题, String 内容,String 消息 ,String 跳转act ){
		NotificationManager manager=(NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification.Builder builder=new Notification.Builder(act);
		//图标
		builder.setSmallIcon(R.drawable.ic_launcher);
		builder.setContentTitle(标题);
		builder.setContentText(内容);
		//显示预览的滚动信息
		builder.setTicker(消息);
		Notification notification=builder.build();
		Intent intent = new Intent();
		try{
		intent =new Intent (act,Class.forName(跳转act));
		}
		catch(Exception e){}
		PendingIntent pi = PendingIntent.getActivities(act, 0, new Intent[]{intent}, PendingIntent.FLAG_CANCEL_CURRENT);
		builder.setContentIntent(pi);
		//发送通知，第一个参数设置通知ID
		manager.notify(1,notification);
	}
	
	public static void 延时执行(Context 上下文,String 类名, String 方法名,Long 毫秒){
		final Context 上下文2 = 上下文;
		final String 类名2 = 类名;
		final String 方法名2 = 方法名;
		Timer timer=new Timer();
		TimerTask task=new TimerTask()
		{
			@Override
			public void run()
			{	
				try{
					try {
						Class<?> c = Class.forName(类名2);
						Method get = c.getMethod(方法名2);
						get.invoke(c);
					} catch (Exception e) {
						toast(上下文2,e.getMessage()+"\n("+e.toString()+")");
					}finally {
					}
				}catch(Exception e){}
			}
		};
		timer.schedule(task,毫秒);
	}
	
	public static void 分享文本(Context context,String text) { 
		Intent sendIntent = new Intent();
		sendIntent.setAction(Intent.ACTION_SEND);
		sendIntent.putExtra(Intent.EXTRA_TEXT,text);
		sendIntent.setType("text/plain");
		context.startActivity(Intent.createChooser(sendIntent, "分享文本"));  
	}
	
	public static void 分享文件(Context context,Uri urifile) { 
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.putExtra(Intent.EXTRA_STREAM, urifile);
		shareIntent.setType("*/*");
		context.startActivity(Intent.createChooser(shareIntent, "分享文件"));
	}
	
	public static void 播放音视频(Activity act,String 指令,Uri uri地址){
		MediaPlayer mPlayer = MediaPlayer.create(act, uri地址);
		mPlayer.setLooping(true);//是否循环播放，false为不循环
		if(指令.equals("播放")){
		mPlayer.start();//start开始播放，pause暂停，stop停止
		}
		if(指令.equals("停止")){
			mPlayer.stop();
		}
	}
	
	public static void BuShe(Activity 上下文){
		final Activity act = 上下文;
		if(!类库.是否安装(上下文,"包名")){
			AlertDialog.Builder dia = new AlertDialog.Builder(上下文);
			dia.setTitle("很抱歉");
			dia.setMessage("您未安装xxx，点击确定安装");
			dia.setNegativeButton("确定,null",null);
			final AlertDialog dia2 = dia.show();
			dia2.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					类库.安装apk(act,"assets下apk的文件名");
					dia2.dismiss();
				}
			});
		}else{
			AlertDialog.Builder dia3 = new AlertDialog.Builder(上下文);
			dia3.setTitle("提示");
			dia3.setMessage("您已成功安装xxx");
			dia3.setNegativeButton("确定",null);
			final AlertDialog dia4 = dia3.show();
			dia4.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(
			new OnClickListener(){
				@Override
				public void onClick(View p2){
					dia4.dismiss();
				}
			});
		}
	}
	
	public static String 异或加密(String 明文,int key) {
		byte[] bytes = 明文.getBytes();
        if (bytes == null) {
            return null;
        }
        int len = bytes.length;
        for (int i = 0; i < len; i++) {
            bytes[i] = (byte) (bytes[i] ^ key);
        }
        return new String(android.util.Base64.encode(bytes,android.util.Base64.DEFAULT));
    }
	
	public static byte[] 异或加密byte(String 明文,int key) {
		byte[] bytes = 明文.getBytes();
        int len = bytes.length;
        for (int i = len - 1; i > 0; i--) {
            bytes[i] = (byte) (bytes[i] ^ key);
        }
        bytes[0] = (byte) (bytes[0] ^ key);
        return bytes;
    }
	
	public static byte[] 异或解密byte(byte[] bArr,int key) {
        byte[] bArr2 = bArr;
        for (int i = 0; i < bArr2.length; i++) {
            bArr2[i] = (byte) (bArr2[i] ^ key);
        }
        return bArr2;
    }
	
	
	public static String 异或解密(String 密文,int key) {
		byte[] bytes = android.util.Base64.decode(密文.getBytes(),android.util.Base64.DEFAULT);
		/*
		//测试byte和input互换
		try{
		bytes = input转byte(byte转Input(bytes));
		}catch(Exception e){}*/
        if (bytes == null) {
            return null;
        }
        int len = bytes.length;
        for (int i = len - 1; i > 0; i--) {
            bytes[i] = (byte) (bytes[i] ^ key);
        }
        bytes[0] = (byte) (bytes[0] ^ key);
        return new String(bytes);
    }
	
	public static final InputStream byte转Input(byte[] bArr) {
        InputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        return byteArrayInputStream;
    }

    public static final byte[] input转byte(InputStream inputStream) throws IOException {
        InputStream inputStream2 = inputStream;
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        ByteArrayOutputStream byteArrayOutputStream3 = byteArrayOutputStream2;
        byte[] bArr = new byte[100];
        Object obj = null;
        while (true) {
            int read = inputStream2.read(bArr, 0, 100);
            int i = read;
            if (read <= 0) {
                return byteArrayOutputStream3.toByteArray();
            }
            byteArrayOutputStream3.write(bArr, 0, i);
        }
    }
	
	public static String 取反(String 明文,int key) {
		byte[] bytes = 明文.getBytes();
        if (bytes == null) {
            return null;
        }
        int len = bytes.length;
        for (int i = 0; i < len; i++) {
            bytes[i] = (byte) (~bytes[i]);
        }
        return new String(android.util.Base64.encode(bytes,android.util.Base64.DEFAULT));
    }
	
}
