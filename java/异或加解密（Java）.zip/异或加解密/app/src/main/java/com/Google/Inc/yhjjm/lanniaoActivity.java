package com.Google.Inc.yhjjm;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;
import java.io.*;

public class lanniaoActivity extends Activity
{
	private EditText zfc;
	private EditText key;
	private TextView jg;

	@Override
	public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState)
	{
		
		// TODO: Implement this method
		super.onCreate(savedInstanceState, persistentState);
		setContentView(R.layout.main);
		zfc = findViewById(R.id.zfc);
		key = findViewById(R.id.key);
		Button dec = findViewById(R.id.dec);
		Button enc = findViewById(R.id.enc);
		Button copy = findViewById(R.id.copy);
		Button output = findViewById(R.id.output);
		Button test = findViewById(R.id.test);
		jg = findViewById(R.id.jg);

		dec.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					jg.setText(
						类库.异或解密(zfc.getText().toString(),Integer.valueOf(key.getText().toString()).intValue())
					);
				}
			});
		enc.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					jg.setText(
						类库.异或加密(zfc.getText().toString(),Integer.valueOf(key.getText().toString()).intValue())
					);
				}
			});
		copy.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					类库.剪贴板(lanniaoActivity.this,jg.getText().toString());
				}
			});
		output.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					类库.写入txtbyte(lanniaoActivity.this,类库.异或加密byte(zfc.getText().toString(),Integer.valueOf(key.getText().toString()).intValue()),new File("sdcard/host.txt"));
				}
			});
		test.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1){
					jg.setText(
						new String(
							类库.取反(类库.取反(zfc.getText().toString(),Integer.valueOf(key.getText().toString()).intValue()),Integer.valueOf(key.getText().toString()).intValue())));
				}
			});
    }
	
}
