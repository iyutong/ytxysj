/** Automatically generated file. DO NOT MODIFY */
package net.micode.fileexplorer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}