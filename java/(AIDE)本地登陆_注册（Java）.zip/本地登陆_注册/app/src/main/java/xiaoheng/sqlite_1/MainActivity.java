package xiaoheng.sqlite_1;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity 
{
	String aa,bb;
	
	Button btn,btn1,btn2;
	EditText ext1,ext2;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		this.requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.xiaoheng_main);
		
		ty();
		
		btn=(Button)findViewById(R.id.xiaohengmainButton1);
		btn1=(Button)findViewById(R.id.xiaohengmainButton2);
		btn2=(Button)findViewById(R.id.xiaohengmainButton3);
		
		ext1=(EditText)findViewById(R.id.xiaohengmainEditText1);
		ext2=(EditText)findViewById(R.id.xiaohengmainEditText2);
		
		
		btn.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String z=ext1.getText().toString();
					String m=ext2.getText().toString();
					
					if(z.equals(aa)&&m.equals(bb))
					{
						Toast.makeText(MainActivity.this,"登陆成功！",Toast.LENGTH_SHORT).show();
						startActivity(new Intent(MainActivity.this,dengluchenggong.class));
						MainActivity.this.finish();
					}
					else
					{
						Toast.makeText(MainActivity.this,"登陆失败！",Toast.LENGTH_SHORT).show();
					}
				}
			});
			
		btn1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					startActivity(new Intent(MainActivity.this,Zhuche.class));
					//MainActivity.this.finish();
				}
			});
			
		btn2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					ty();
					// TODO: Implement this method
					AlertDialog.Builder a=new AlertDialog.Builder(MainActivity.this);
					a.setIcon(R.drawable.xiaoheng_zhaohuimima);
					a.setCancelable(false);//点击界面其他它地方弹窗不会消失
					a.setTitle("找回密码");//标题
					a.setMessage("账号："+aa+"\n密码："+bb);
					a.setPositiveButton("知道了", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								Toast.makeText(MainActivity.this,"记好咯!",Toast.LENGTH_SHORT).show();
							}
						}).show();
				}
			});
    }
	
	public void ty()
	{
		try
		{
			FileInputStream fi=openFileInput("zhanghao.data");
			byte []b=new byte[fi.available()];
			fi.read(b);
			aa=new String(b);
			//Toast.makeText(MainActivity.this,aa,Toast.LENGTH_LONG).show();
			fi.close();

			FileInputStream fi2=openFileInput("mima.data");
			byte []b1=new byte[fi2.available()];
			fi2.read(b1);
			bb=new String(b1);
			//Toast.makeText(MainActivity.this,bb,Toast.LENGTH_LONG).show();
			fi2.close();
		}
		catch(Exception e)
		{
			Toast.makeText(MainActivity.this,"亲，可能还没注册呢！",Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
	}
	
	
}
