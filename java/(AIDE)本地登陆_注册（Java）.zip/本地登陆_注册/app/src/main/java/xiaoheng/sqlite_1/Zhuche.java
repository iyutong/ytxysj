package xiaoheng.sqlite_1;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;

public class Zhuche extends Activity
{
	private TextView t1,t2;
	private String tx1,tx2;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		this.requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaoheng_zhuche);
					
		Button btn=(Button)findViewById(R.id.xiaohengzhucheButton1);
		t1=(TextView)findViewById(R.id.xiaohengzhucheEditText1);
		t2=(TextView)findViewById(R.id.xiaohengzhucheEditText2);
			
		btn.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
		tx1=t1.getText().toString();
		tx2=t2.getText().toString();
		if(tx1.equals(""))
		{
			Toast.makeText(Zhuche.this,"您忘记输入账号了",Toast.LENGTH_LONG).show();
		}
		else
		{
			if(tx2.equals(""))
			{
				Toast.makeText(Zhuche.this,"您忘记输入密码了",Toast.LENGTH_LONG).show();
			}
			else
			{
				if(tx1.length()>16)
					{
						Toast.makeText(Zhuche.this,"账号不可以超过16个字符串",Toast.LENGTH_SHORT).show();
					}
					else
					{
						if(tx2.length()>16)
						{
							Toast.makeText(Zhuche.this,"密码不可以超过16个字符串",Toast.LENGTH_SHORT).show();
						}
						else
						{
							
							try
							{
								FileOutputStream f=openFileOutput("zhanghao.data",MODE_PRIVATE);
								f.write(tx1.getBytes());
								f.close();
								//写入账号
								
								FileOutputStream f2=openFileOutput("mima.data",MODE_PRIVATE);
								f2.write(tx2.getBytes());
								f2.close();
								//写入密码
								
								Toast.makeText(Zhuche.this,"注册成功！",Toast.LENGTH_SHORT).show();
								//startActivity(new Intent(Zhuche.this,MainActivity.class));
								Zhuche.this.finish();
								
							}
							catch(Exception e)
							{
								Toast.makeText(Zhuche.this,"注册失败",Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}
							
							
						}
					}
			}
		}
		
		}});
		
		
			
	}
}
