package xiaoheng.sqlite_1;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;

public class dengluchenggong extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xiaoheng_dengluchenggong);
	}
	public void jiaqun(View v)
	{
		startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=234257176&card_type=group&source=qrcode")));
	}
	
	public void jiawo(View v)
	{
		startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
	}
}
