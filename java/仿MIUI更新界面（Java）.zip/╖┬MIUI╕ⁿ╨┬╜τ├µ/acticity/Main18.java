package com.example.testproject;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Main18 extends AppCompatActivity {
    private ImageView img2,img1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout8);
        img2=findViewById(R.id.layout8img1);
        img1=findViewById(R.id.layout8img2);

        //获取屏幕宽度
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        final int screenWidth = dm.widthPixels;

        ObjectAnimator animator1=ObjectAnimator.ofFloat(img2,"scaleX",0f, 1f).setDuration(1000);
        ObjectAnimator animator2=ObjectAnimator.ofFloat(img2,"scaleY",0f, 1f).setDuration(1000);
        ObjectAnimator animator3 = ObjectAnimator.ofFloat(img2, "alpha", 0f, 1f).setDuration(1000);

        img2.setPivotX(400);
        img2.setPivotY(0);
        img2.invalidate();
        AnimatorSet animSet1 = new AnimatorSet();
        animSet1.setInterpolator(new LinearInterpolator());
        animSet1.playTogether(animator1,animator2,animator3);//四个动画同时执行
        animSet1.start();




        ObjectAnimator animator4=ObjectAnimator.ofFloat(img1,"translationX",screenWidth-30, 1f).setDuration(1000);
        ObjectAnimator animator5 = ObjectAnimator.ofFloat(img1, "alpha", 0f, 1f).setDuration(1000);

        AnimatorSet animSet2 = new AnimatorSet();
        animSet2.setInterpolator(new LinearInterpolator());
        animSet2.playTogether(animator4,animator5);//四个动画同时执行
        animSet2.start();


    }
}
