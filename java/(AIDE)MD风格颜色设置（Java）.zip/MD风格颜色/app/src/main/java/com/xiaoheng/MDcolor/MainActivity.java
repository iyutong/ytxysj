package com.xiaoheng.MDcolor;import android.content.*;import android.net.*;import android.os.*;import android.support.v7.app.*;import android.view.*;import android.view.View.*;import android.widget.*;public class MainActivity extends AppCompatActivity{@Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);setContentView(R.layout.main);Button button=(Button)findViewById(R.id.mainButton1);button.setOnClickListener(new OnClickListener(){@Override public void onClick(View p1){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));Toast.makeText(MainActivity.this,"正在转跳到小亨QQ名片",Toast.LENGTH_LONG).show();}});}}


/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/