package com.banshouweng.bswBase.ui.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.banshouweng.bswBase.R;

public class LaunchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
    }
}