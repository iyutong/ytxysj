package com.banshouweng.bswBase.utils.rxbus2;

/**
 *
 * Created by gorden on 2016/7/23.
 */
public enum ThreadMode {
    /**
     * current thread
     */
    CURRENT_THREAD,

    /**
     * android main thread
     */
    MAIN,


    /**
     * new thread
     */
    NEW_THREAD
}
