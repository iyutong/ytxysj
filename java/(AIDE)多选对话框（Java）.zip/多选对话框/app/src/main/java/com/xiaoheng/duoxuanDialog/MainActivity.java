package com.xiaoheng.duoxuanDialog;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    
Button button=(Button)findViewById(R.id.mainButton);
button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					final String items[] = {"小亨", "小亨","大帅比", "我爱android", "666"};//列表
					final boolean selected[] = {false, true, false, false,false};//默认选中
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this,0);//0是风格,共四五种
					builder.setTitle("多选");//标题
					builder.setIcon(R.drawable.ic_launcher);//图标
					builder.setMultiChoiceItems(items, selected,new DialogInterface.OnMultiChoiceClickListener() //多选点击事件
					{
							@Override
							public void onClick(DialogInterface dialog, int which,boolean isChecked) 
							{

								Toast.makeText(MainActivity.this,items[which] + isChecked, Toast.LENGTH_SHORT).show();
							}
						});
						
					builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which ) {
								
								String text = "你选择了："; 
								for(int i = 0; i < 5; i++) { 
									text += selected[i]? items[i] + "，" : ""; 
								} 
								Toast.makeText(MainActivity.this, text, 0).show(); 
								dialog.dismiss();//关闭弹窗
								
								/*android会自动根据你选择的改变selected数组的值。
               for (int i = 0; i < selected.length; i++) {
				   Toast.makeText(MainActivity.this,"111:"+selected[i],Toast.LENGTH_LONG).show();
              }*/
							}
						});
						
					builder.setNegativeButton("加小亨QQ", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								try
								{
									startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=1919196455")));
								}catch(Exception xiaoheng)
								{
									Toast.makeText(MainActivity.this,"转跳到小亨QQ异常",Toast.LENGTH_SHORT).show();
								}
								
							}
						});
						
					builder.create().show();//显示弹窗
				
				
		}});
		
		
	}
	
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *      2017.8.10                       *
 ****************************************/
