package com.panda.gethttp;
 
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity { 


	private List<Msg> msgList = new ArrayList<>();
    private RecyclerView msgRecyclerView;
    private static List<String> atitle,amid,aalbum,aicon,aname;

    private MsgAdapter adapter;
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msgRecyclerView = findViewById(R.id.msg_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        msgRecyclerView.setLayoutManager(layoutManager);
        adapter = new MsgAdapter(msgList,this);
		msgRecyclerView.setAdapter(adapter);
        
		
        adapter.setOnItemClickListener(new MsgAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v,String title,String connect) {
                Toast.makeText(MainActivity.this,title+connect, Toast.LENGTH_SHORT).show();
                doDownload(connect,title+System.currentTimeMillis()+".m4a");
            }
        });
        
        Button jiex = findViewById(R.id.jiex);
        jiex.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v) {
                    msgList.clear();
                    adapter.notifyDataSetChanged();
                    new Thread(new Runnable(){
                            @Override
                            public void run()
                            {
                                EditText et = findViewById(R.id.input_text);
                                getMusicConnect(et.getText().toString());
                           
                                for (int i = 0; i < amid.size(); i++) {
                                    Log.d("阿巴",atitle.get(i) + amid.get(i)+aalbum.get(i)+aicon.get(i)+aname.get(i)+getSong(amid.get(i)));
                                    msgList.add(new Msg(atitle.get(i) , amid.get(i),aalbum.get(i),aicon.get(i),aname.get(i),getSong(amid.get(i))));
                                    runOnUiThread(new Runnable(){
                                            @Override
                                            public void run() {
                                                adapter.notifyItemChanged(msgList.size() - 1);
                                                msgRecyclerView.scrollToPosition(msgList.size() - 1);
                                            }
										});
                                }

                            }
                        }).start();
                        
                    adapter.notifyDataSetChanged();
                }
            });
    }
    
    private void doDownload(String downloadUrl, String fileName) {
        // 获取SD卡路径
        String path = "/storage/emulated/0/PandaBox/Download/";
        File file = new File(path);
        // 如果SD卡目录不存在创建
        if (!file.exists()) {
            file.mkdir();
       }
        int threadNum = 5;
        String filepath = path + fileName;
        Log.d("t", "download file  path:" + filepath);
        downloadTask task = new downloadTask(downloadUrl, threadNum, filepath);
        task.start();
    }
    
    class downloadTask extends Thread {
        private String downloadUrl;// 下载链接地址
        private int threadNum;// 开启的线程数
        private String filePath;// 保存文件路径地址
        private int blockSize;// 每一个线程的下载量


        public downloadTask(String downloadUrl, int threadNum, String fileptah) {
            this.downloadUrl = downloadUrl;
            this.threadNum = threadNum;
            this.filePath = fileptah;
        }

        @Override
        public void run() {

            FileDownloadThread[] threads = new FileDownloadThread[threadNum];
            try {
                URL url = new URL(downloadUrl);
                Log.d("t", "download file http path:" + downloadUrl);
                URLConnection conn = url.openConnection();
                // 读取下载文件总大小
                int fileSize = conn.getContentLength();
                if (fileSize <= 0) {
                    System.out.println("读取文件失败");
                    return;
                }
                // 设置ProgressBar最大的长度为文件Size

                // 计算每条线程下载的数据长度
                blockSize = (fileSize % threadNum) == 0 ? fileSize / threadNum
                    : fileSize / threadNum + 1;

                Log.d("t", "fileSize:" + fileSize + "  blockSize:");

                File file = new File(filePath);
                for (int i = 0; i < threads.length; i++) {
                    // 启动线程，分别下载每个线程需要下载的部分
                    threads[i] = new FileDownloadThread(url, file, blockSize,
                                                        (i + 1));
                    threads[i].setName("Thread:" + i);
                    threads[i].start();
                }

                boolean isfinished = false;
                int downloadedAllSize = 0;
                while (!isfinished) {
                    isfinished = true;
                    // 当前所有线程下载总量
                    downloadedAllSize = 0;
                    for (int i = 0; i < threads.length; i++) {
                        downloadedAllSize += threads[i].getDownloadLength();
                        if (!threads[i].isCompleted()) {
                            isfinished = false;
                        }
                    }
                    Thread.sleep(1000);// 休息1秒后再读取下载进度
                }
                Log.d("t", " all of downloadSize:" + downloadedAllSize);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
	}
    
    
    public String getMusicConnect(String name){
        String http= getURLCollection("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w="+name+"&format=json");
        try {
            //System.out.println(http);
            JSONObject js = new JSONObject(http);

            JSONArray ja = js.getJSONObject("data").getJSONObject("song").getJSONArray("list");
            System.out.println(ja);
            atitle = new ArrayList<String>();
            amid = new ArrayList<String>();
            aicon = new ArrayList<String>();
            aalbum = new ArrayList<String>();
            aname = new ArrayList<String>();
            for (int i = 0 ; i < ja.length() ; i++) {
                JSONObject json = ja.getJSONObject(i);
                JSONObject j1 = json.getJSONArray("singer").getJSONObject(0);
                System.out.println(json);
                amid.add(json.get("songmid").toString());
                atitle.add(json.get("songname").toString());
                aicon.add("http://y.gtimg.cn/music/photo_new/T002R180x180M000"+json.get("albummid")+".jpg");
                aalbum.add(json.get("albumname").toString());
                aname.add(j1.get("name").toString());
            }
        } catch(Exception e){
            e.printStackTrace();
        } 
        return null;
    }

    public String getSong(String mid){
        String http= getURLCollection("https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&data=%7B%22req_0%22%3A%7B%22module%22%3A%22vkey.GetVkeyServer%22%2C%22method%22%3A%22CgiGetVkey%22%2C%22param%22%3A%7B%22guid%22%3A%22358840384%22%2C%22songmid%22%3A%5B%22"+mid+"%22%5D%2C%22songtype%22%3A%5B0%5D%2C%22uin%22%3A%221443481947%22%2C%22loginflag%22%3A1%2C%22platform%22%3A%2220%22%7D%7D%2C%22comm%22%3A%7B%22uin%22%3A%2218585073516%22%2C%22format%22%3A%22json%22%2C%22ct%22%3A24%2C%22cv%22%3A0%7D%7D");
        try {
            //System.out.println(http);
            JSONObject js = new JSONObject(http);
            JSONArray ja = js.getJSONObject("req_0").getJSONObject("data").getJSONArray("midurlinfo");
          

            for (int i = 0 ; i < ja.length() ; i++) {
                JSONObject json = ja.getJSONObject(i);
                return "http://aqqmusic.tc.qq.com/amobile.music.tc.qq.com/"+json.get("purl");
            }
        } catch(Exception e){
            e.printStackTrace();
        } 
        return null;
    }

    public String getURLCollection(String address){
        String rtnLine = "";
        try{
            URL url = new URL(address);
            URLConnection conn = url.openConnection();
            conn.connect();
            InputStream in = conn.getInputStream();
            InputStreamReader input = new InputStreamReader(in, "UTF-8");
            BufferedReader buffer = new BufferedReader(input);
            // nextLine = buf.readLine();
            String nextLine = "";
            while(( nextLine = buffer.readLine())!=null){
                rtnLine = rtnLine+nextLine+"\n";

                // System.out.println(nextLine);
            }
            in.close();
        }catch(Exception e){
            e.printStackTrace();

        }
        return rtnLine;
    }
    
    
} 
