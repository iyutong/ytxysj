package com.panda.gethttp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Message;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import android.os.Handler;
import android.widget.Toast;
import android.content.Context;

public class MsgAdapter extends RecyclerView.Adapter<MsgAdapter.ViewHolder> {
    
    private Handler handler;

    private Context mcontext;
    

    @Override
    public int getItemCount() {
        return mMsgList.size();
    }

    private List<Msg> mMsgList;
    
    class ViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        TextView album_author;
        ImageView icon;
        
        public ViewHolder(View view){
            super(view);
            title = view.findViewById(R.id.song_name);
            album_author = view.findViewById(R.id.album_author);
            icon = view.findViewById(R.id.icon);
            view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Toast.makeText(mContext, "当前点击 "+ datas.get(getLayoutPosition()), Toast.LENGTH_SHORT).show();

                        if(onItemClickListener != null){
                            int position = getAdapterPosition();
                            Msg msg = mMsgList.get(position);
                            onItemClickListener.onItemClick(v, msg.getTitle(),msg.getConnect());

                        }

                    }
                });
            
        }
    }
    
    public MsgAdapter(List<Msg> msglist ,Context context){
        mMsgList = msglist;
        mcontext = context;
    }
    
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.msg_item,parent,false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(final ViewHolder holder,int position){
        Msg msg = mMsgList.get(position);
        Log.d("title",msg.getTitle());
        holder.title.setText(msg.getTitle());
		holder.album_author.setText(msg.getAlbumname()+"."+msg.getName());
        
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what){
                    case 1:
                        Bitmap bitmap = (Bitmap) msg.obj;
                        holder.icon.setImageBitmap(bitmap);
                        break;
                    case 2:
                        Toast.makeText(mcontext,"网络连接失败",Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        Toast.makeText(mcontext,"服务器发生错误",Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        
    }
    
    public interface OnItemClickListener{

        /**
         * 当RecyclerView某个被点击的时候回调
         * @param view 点击item的视图
         * @param data 点击得到的数据
         */
        void onItemClick(View view,String title,String mid);

    }

    private OnItemClickListener onItemClickListener;

    /**
     * 设置RecyclerView某个的监听
     * @param onItemClickListener
     */
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
    }
    
    public Bitmap getURLimage(String url) {
        Bitmap bmp = null;
        try {
            URL myurl = new URL(url);
            // 获得连接
            HttpURLConnection conn = (HttpURLConnection) myurl.openConnection();
            conn.setConnectTimeout(6000);//设置超时
            conn.setDoInput(true);
            conn.setUseCaches(false);//不缓存
            conn.connect();
            InputStream is = conn.getInputStream();//获得图片的数据流
            bmp = BitmapFactory.decodeStream(is);
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bmp;
    }
    


    //设置网络图片
    public void setImageURL(final String path) {
        //开启一个线程用于联网
        final Handler handler = new Handler();
        new Thread() {
            @Override
            public void run() {
                try {
                    //把传过来的路径转成URL
                    URL url = new URL(path);
                    //获取连接
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    //使用GET方法访问网络
                    connection.setRequestMethod("GET");
                    //超时时间为10秒
                    connection.setConnectTimeout(10000);
                    //获取返回码
                    int code = connection.getResponseCode();
                    if (code == 200) {
                        InputStream inputStream = connection.getInputStream();
                        //使用工厂把网络的输入流生产Bitmap
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                        //利用Message把图片发给Handler
                        Message msg = Message.obtain();
                        msg.obj = bitmap;
                        msg.what = 1;
                        handler.sendMessage(msg);
                        inputStream.close();
                    }else {
                        //服务启发生错误
                        handler.sendEmptyMessage(3);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    //网络连接错误
                    handler.sendEmptyMessage(2);
                }
            }
        }.start();
       }
    
    
}
