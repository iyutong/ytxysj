package com.panda.gethttp;

public class Msg {
    
    private String title;
    
    private String mid;

    private String albumname;

    private String icon;

    private String name;

    private String connect;
    
    public Msg(String title, String mid,String albumname,String icon,String name,String connect){
        this.title = title;
        this.mid = mid;
        this.albumname = albumname;
        this.icon = icon;
        this.name= name;
        this.connect=connect;
    }
    
    public String getTitle(){
        return this.title;
    }
    
    public String getMid(){
        return this.mid;
    }
    
    public String getAlbumname(){
        return this.albumname;
    }
    
    public String getIcon(){
        return this.icon;
    }

    public String getName(){
        return this.name;
    }
    
    public String getConnect(){
        return this.connect;
    }
    
    
    
    
}
