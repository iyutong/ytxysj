package com.adiout_res;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.guye.baffle.exception.*;
import java.io.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button adiout=(Button)findViewById(R.id.mainButton1);
		final EditText xuthis=(EditText)findViewById(R.id.mainEditText1);
		//绑定id
		adiout.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					String 路径=xuthis.getText().toString();//获取输入框内容
					if(路径.isEmpty()){//判断输入框是否为空
						Toast.makeText(MainActivity.this,"你还没输入路径!",5000).show();
						return;//为空不执行以下事件
					}
					File test= new File("/sdcard/RES混淆");//创建文件夹
					if (!test.exists())//判断是否有文件夹
						test.mkdirs();//没有则创建
					String[] abd=new String[]{路径+"/a.apk",路径+ "/b.apk"};
					try
					{
						com.guye.baffle.obfuscate.Main.main(abd);
						
					}
					catch (BaffleException e)
					{

					}
					catch (IOException e)
					{
						Toast.makeText(MainActivity.this,"混淆失败",5000).show();
					}
					// TODO: Implement this method
				}
			})
		;}}
