package com.mycompany.myapp;

public class Data
{
	String text;


	public void setText(String text)
	{
		this.text = text;
	}

	public String getText()
	{
		return text;
	}}
