package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import java.util.*;
import android.view.*;

public class MainActivity extends AppCompatActivity 
{
	private RecyclerView recyclerview;
	//list作数据源
	private List<String> list = new ArrayList<>();
	//实例化adapter
	HomeAdapter adapter = new HomeAdapter(this, list);
	private List<Integer> hight;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
		toolbar.setTitle("标题");
		setSupportActionBar(toolbar);
		recyclerview = (RecyclerView) findViewById(R.id.recyclerview);
		//布局，垂直线性布局
		//recyclerview.setLayoutManager(new LinearLayoutManager(this));
		//grid布局
		recyclerview.setLayoutManager(new StaggeredGridLayoutManager(4,StaggeredGridLayoutManager.VERTICAL));
		//瀑布流
		
		//添加和删除item的动画
		recyclerview.setItemAnimator(new DefaultItemAnimator());
	    //设置数据
		initData();
	    //添加垂直分割线
		//recyclerview.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
	    //添加横向分割线
		//recyclerview.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));
		//瀑布流高度

		//绑定适配器
		recyclerview.setAdapter(adapter);

    }

	

	private void initData()
	{
		// TODO: Implement this method
		for (int i = 0;i < 100;i++)
		{
			list.add("" + i);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		menu.add(1, 1, 1, "添加");
		menu.add(1, 2, 1, "删除");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		switch (item.getItemId())
		{
			case 1:
				//添加item
				list.add(0, "emmm");
				//刷新列表
				adapter.notifyDataSetChanged();
				break;
			case 2:

				//删除item
				list.remove(0);
				//刷新列表
				adapter.notifyDataSetChanged();
				break;
		}
		return true;
	}


}
