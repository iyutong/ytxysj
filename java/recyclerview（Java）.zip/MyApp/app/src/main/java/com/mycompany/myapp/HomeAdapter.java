package com.mycompany.myapp;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.widget.AdapterView.*;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.MyViewHoder>
{

	private Context context;

	private List<String> list;
	
	private List<Integer> mheight;

	public HomeAdapter(Context context,List<String> list){
		
		this.context = context;
		this.list = list;
		
	}
	
	
	public void setonitemclicklistener(OnItemClickListener monclicklistener){
		
	}
	public void removerData(int position){
		list.remove(position);
		notifyItemRemoved(position);
	}
	
	@Override
	public HomeAdapter.MyViewHoder onCreateViewHolder(ViewGroup p1, int p2)
	{
		// TODO: Implement this method
		MyViewHoder holder = new MyViewHoder(LayoutInflater.from(context).inflate(R.layout.item_recycler,p1,false));
		return holder;
	}

	@Override
	public void onBindViewHolder(HomeAdapter.MyViewHoder p1, final int p2)
	{
		// TODO: Implement this method

		
		//设置瀑布流item随机高度
		mheight = new ArrayList<>();
		for(int i = 0;i<list.size();i++){
			mheight.add((int)(100+Math.random()*300));
		
}
	
		
		//设置文字
		p1.tv.setText(list.get(p2));
	//设置瀑布流
		LayoutParams lp = p1.tv.getLayoutParams();
		lp.height = mheight.get(p2);
		p1.tv.setLayoutParams(lp);
		//设置点击事件
		p1.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(p2 == 0){
						
					Toast.makeText(context, "????", Toast.LENGTH_SHORT).show();
					}
					if(p2==1){
						Toast.makeText(context, "????hhh", Toast.LENGTH_SHORT).show();
					}
				}
			});
		
		
		
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return list.size();
	}
	
	class MyViewHoder extends RecyclerView.ViewHolder implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
		}

		TextView tv;
	
		public MyViewHoder(View view){
			super(view);
			tv = (TextView) view.findViewById(R.id.itemrecyclerTextView1);
		}
	}
}
