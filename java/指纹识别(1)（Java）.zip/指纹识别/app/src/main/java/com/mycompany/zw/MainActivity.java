package com.mycompany.zw;

import android.app.Activity;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;

public class MainActivity extends Activity 
{
	/*
	 欢迎加入AIDE|安卓|java 开发交流，群号码：471542521
	*/

	private FingerprintManager fingerprintManager;

	private TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Button  btnBuy = (Button) findViewById(R.id.btn);
		tv=(TextView)findViewById(R.id.test);
		  fingerprintManager = getSystemService(FingerprintManager.class);
        btnBuy.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					tv.setText("请将手放在指纹模块上面");
					if (fingerprintManager.isHardwareDetected() && fingerprintManager.hasEnrolledFingerprints()) {
					fingerprintManager.authenticate(null, null, 0, callback, null);
					
					}
				}
			});
		}
		
	private FingerprintManager.AuthenticationCallback callback = new FingerprintManager.AuthenticationCallback() {
		@Override
		public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
			//指纹验证成功
		tv.setText("验证成功");
			     }
		@Override
		public void onAuthenticationError(int errorCode, CharSequence errString) {
			//指纹验证失败，不可再验
			tv.setText("频繁，请稍候再试");
			     }
		@Override
		public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
			//指纹验证失败，可再验，可能手指过脏，或者移动过快等原因。
			
		     }
		@Override
		public void onAuthenticationFailed() {
			//指纹验证失败，指纹识别失败，可再验，该指纹不是系统录入的指纹。
			tv.setText("没有找到匹配的指纹信息，请重试");
		
			  }
    };
		
		
}
