package net.fenghuo.wallpaper.sakura;

import net.fenghuo.wallpaper.sakura.R;
import android.app.Activity;
import android.os.Bundle;

public class WallpaperActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}