package net.fenghuo.wallpaper.riverwater;

import android.app.Activity;

public class WallpaperSettingsActivity extends Activity {

}
