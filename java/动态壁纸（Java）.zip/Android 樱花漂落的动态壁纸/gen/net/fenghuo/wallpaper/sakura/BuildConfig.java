/** Automatically generated file. DO NOT MODIFY */
package net.fenghuo.wallpaper.sakura;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}