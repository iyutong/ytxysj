package com.summerain.bmob.example;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.Bmob;

/*
 * 主页面
 * class MainActivity
 * author summerain0
 * date 2019-3-9
 */
public class MainActivity extends Activity implements View.OnClickListener
{
	private EditText mPassword;
	private EditText mUsername;
	private EditText mEmail;
	private Button mLogin;
	private Button mRegister;
	private BmobUser mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		// 这里填上你申请的 Application id
		// 可以放在 Application 初始化
		Bmob.initialize(MainActivity.this, "Your Application ID");

		mLogin = findViewById(R.id.main_bt_login);
		mLogin.setOnClickListener(MainActivity.this);
		mRegister = findViewById(R.id.main_bt_register);
		mRegister.setOnClickListener(MainActivity.this);
		mUsername = findViewById(R.id.main_et_username);
		mPassword = findViewById(R.id.main_et_password);
		mEmail = findViewById(R.id.main_ed_email);
    }

	// 设置点击事件
	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.main_bt_login:
				login();
				break;

			case R.id.main_bt_register:
				register();
				break;
		}
	}

	// 登录代码
	private void login()
	{
		// 获取账号密码
		String username = mUsername.getText().toString();
		String password = mPassword.getText().toString();
		
		//创建实例
		mUser = new BmobUser();
		mUser.setUsername(username);
		mUser.setPassword(password);

		// 开始登录
		mUser.login(new SaveListener<BmobUser>(){
				@Override
				public void done(BmobUser user, BmobException e)
				{
					if (e == null)
					{
						mUser = BmobUser.getCurrentUser();
						Toast.makeText(MainActivity.this, mUser.getUsername() + "登录成功", Toast.LENGTH_LONG).show();
					}
					else
					{
						Toast.makeText(MainActivity.this, "登录失败！" + e.getMessage(), Toast.LENGTH_LONG).show();
					}
				}
			});

	}

	// 注册代码
	private void register()
	{
		// 获取账号密码
		String username = mUsername.getText().toString();
		String password = mPassword.getText().toString();
		String email = mEmail.getText().toString();
		
		// 创建实例
		mUser = new BmobUser();
		mUser.setUsername(username);
		mUser.setPassword(password);
		mUser.setEmail(email);
		
		// 开始注册
		mUser.signUp(new SaveListener<BmobUser>(){
				@Override
				public void done(BmobUser user, BmobException e)
				{
					// e 为空时无错误，反之有错误
					if (e == null)
					{
						mUser = BmobUser.getCurrentUser();
						Toast.makeText(MainActivity.this, mUser.getUsername() + "注册成功", Toast.LENGTH_LONG).show();
					}
					else
					{
						Toast.makeText(MainActivity.this, "注册失败！" + e.getMessage(), Toast.LENGTH_LONG).show();
					}
				}
			});

	}

}
