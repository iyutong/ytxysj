package org.Dex;
import java.io.*;
import java.util.*;
import org.jf.dexlib.*;
import org.jf.dexlib.Code.*;
import org.jf.dexlib.Util.*;
import org.jf.util.*;

public class DexUtils
{
	public void StringReplace(String old, String news)
	{
		List<String> s = new ArrayList();
		try
		{
			read(s);
		}
		catch (IOException e)
		{}
		for (int i =0;i < s.size();i += 1)
		{
			if (s.get(i).equals(old))
				s.set(i, news);
		}
		try
		{
			String[] a=new String[s.size()];
			for (int i=0;i < s.size();i++)
			{
				a[i] = s.get(i).toString();
			}
			write(a);
		}
		catch (IOException e)
		{}
	}


	private ArrayList<StringIdItem> stringIds;

	public void read(List<String> data)throws IOException
	{
		HashMap<StringIdItem,StringIdItem> stringIdsMap=new HashMap<StringIdItem,StringIdItem>();

		List<ClassDefItem> classes=dex.ClassDefsSection.getItems();
		for (ClassDefItem classItem:classes)
		{
			ClassDataItem classData=classItem.getClassData();
			if (classData != null)
			{
				//
				ClassDataItem.EncodedMethod[] methods=classData.getDirectMethods();
				for (ClassDataItem.EncodedMethod method :methods)
				{
					filterString(method, stringIdsMap);
				}
				//virtual methods
				methods = classData.getVirtualMethods();
				for (ClassDataItem.EncodedMethod method :methods)
				{
					filterString(method, stringIdsMap);
				}

			}
		}
		ArrayList<StringIdItem> stringIds=new ArrayList<StringIdItem>();
		for (StringIdItem stringId:stringIdsMap.keySet())
		{
			stringIds.add(stringId);
			data.add(Utf8Utils.escapeString(stringId.getStringValue()));
		}
		this.stringIds = stringIds;
	}
	public static void filterString(ClassDataItem.EncodedMethod method, HashMap<StringIdItem,StringIdItem> stringIdsMap)
	{
		if (method.codeItem != null)
		{
			Instruction[] instructions=method.codeItem.getInstructions();
			for (Instruction instruction:instructions)
			{
				switch (instruction.getFormat())
				{
					case Format21c:
					case Format31c:
						switch (instruction.opcode.referenceType)
						{
							case string:
								InstructionWithReference ref=(InstructionWithReference)instruction;
								stringIdsMap.put((StringIdItem)ref.getReferencedItem(), null);
						}

				}
			}
		}
	}
	public void write(String[] data)throws IOException
	{
		ArrayList<StringIdItem> stringIds=this.stringIds;
		String[] strings=data;
		if (strings.length != stringIds.size())
			throw new IOException("strings length != stringIds length");
		for (int i=0,len=stringIds.size();i < len;i++)
		{
			StringIdItem item=stringIds.get(i);
			item.setStringValue(Utf8Utils.escapeSequence(strings[i]));

		}
		//ClassListActivity.isChanged=true;
	}
	DexFile dex;
	List<ClassDefItem> classes;
	private ArrayList<ClassDataItem.EncodedMethod> methods;
	public ClassDataItem.EncodedMethod  getMethodByName(String fullname) throws Exception
	{
		String[] s= fullname.split("->");

		if (s.length != 2)
		{
			throw new Exception("Use like : LFormatFa/A;->methodname to get");
		}
		ClassDefItem cls= getClassByName(s[0]);
		if (cls == null)
			return null;
		List<ClassDataItem.EncodedMethod> ms=	getMethods(cls);
		for (ClassDataItem.EncodedMethod m:ms)
		{
			if (m.method.methodName.getStringValue().equals(s[1]))
				return m;
		}
		return null;
	}
	public ClassDefItem getClassByName(String path)
	{

		for (ClassDefItem c:classes)
		{
			if (c.getClassType().getTypeDescriptor().equals(path))
			{
				return c;
			}

		}
		return null;
	}
	
	private  void saveDexFile() throws IOException{
        DexFile outDexFile=new DexFile();
		DexFile dex1=new DexFile(FileUtils.readFile("/mnt/sdcard/a.dex"));
		IndexedSection<ClassDefItem> classes=dex1.ClassDefsSection;
		for (ClassDefItem cl: classes.getItems())
		{
            cl.internClassDefItem(outDexFile);
        }
        outDexFile.setSortAllItems(true);
        outDexFile.place();

        //out dex byte array
        byte[] buf=new byte[outDexFile.getFileSize()];
        ByteArrayAnnotatedOutput out=new ByteArrayAnnotatedOutput(buf);
        outDexFile.writeTo(out);

        DexFile.calcSignature(buf);
        DexFile.calcChecksum(buf);
        
		try
		{
			FileOutputStream os=new FileOutputStream(new File("sdcard/vvv.dex"));
			os.write(buf);
		}
		catch (IOException e)
		{}
    }
	
	
	public void save(File outfile) 
	{
		
		try
		{
			//DexFile dex1=new DexFile(FileUtils.readFile("/mnt/sdcard/a.dex"));
			DexFile dex2=new DexFile();
			IndexedSection<ClassDefItem> classes=dex.ClassDefsSection;
			for (ClassDefItem cl: classes.getItems())
			{
				cl.internClassDefItem(dex2);
			}
			dex2.setSortAllItems(true);
			dex2.place();
			byte[] buf=new byte[dex2.getFileSize()];
			ByteArrayAnnotatedOutput out=new ByteArrayAnnotatedOutput(buf);
			dex2.writeTo(out);
			DexFile.calcSignature(buf);
			DexFile.calcChecksum(buf);
			FileOutputStream os=new FileOutputStream(outfile);
			try
			{
				os.write(buf);
			}
			catch (IOException e)
			{}
		}
		catch (IOException e)
		{}
		
		

	}
	public DexUtils(DexFile dex1)
	{
		this.dex = dex1;
		classes = dex1.ClassDefsSection.getItems ( );
	}

	public void setClasses(List<ClassDefItem> classes)
	{
		this.classes = classes;
	}

	public List<ClassDefItem> getClasses()
	{
		return classes;
	}
	org.jf.dexlib.	CodeItem code;
	public void setByteCode(String scode) throws Exception
	{

		Parser parser=new Parser(code);
		parser.parse(dex, scode);
		return;
	}
	public String getByteCode(ClassDataItem.EncodedMethod m)
	{
		code = m.codeItem;
		Parser parser=new Parser(code);
		StringBuilder sb=new StringBuilder(4 * 1024);
		try
		{
			// A new IndentingWriter(sb);
			parser.dump(new org.jf.util.IndentingWriter2(sb));
		}
		catch (IOException e)
		{
			return null;}

		return sb.toString();
	}
	public ClassDefItem getClassDef(String name)
	{
		for (ClassDefItem item:classes)
		{

			if (item.getClassType().getTypeDescriptor().equals(name))
			{
				return item;
			}
		}


		return null;
	}


	public void deleteClasses(String name)
	{


		for (int i =0;i < classes.size();i += 1)
		{
			if (classes.get(i).getClassType().getTypeDescriptor().startsWith(name))
			{
				classes.remove(i);
				i = 0;
			}


		}

	}
	public List<ClassDataItem.EncodedMethod> getMethods(ClassDefItem nowDef)
	{
		methods = new ArrayList<ClassDataItem.EncodedMethod>();



		ClassDataItem.EncodedMethod[] m = 	nowDef.getClassData().getDirectMethods();
		if (m != null)
			for (ClassDataItem.EncodedMethod item:m)
			{
				methods.add(item);
			}
		m = 	nowDef.getClassData().getVirtualMethods();

		if (m != null)
			for (ClassDataItem.EncodedMethod item:m)
			{

				methods.add(item);
			}
		return methods;

	}


	List<Integer> showListOffsets;
	public int getRealOffset(int show)
	{
		return showListOffsets.get(show);
	}
	public List<String> getShowList(String nowPath)
	{
		List<String> result = new ArrayList<String>();
		showListOffsets = new ArrayList<Integer>();
		int off=0;
		for (ClassDefItem item:classes)
		{

			String tempname = item.getClassType().getTypeDescriptor();
			if (tempname.startsWith(nowPath))
			{
				String temp2=tempname.substring(nowPath.length());

				int offset = temp2.indexOf("/");
				if (offset == -1)
				{
					showListOffsets.add(off);
					result.add(temp2);
				}
				else
				{

					//MyData.Log("dir:"+temp2.substring(0,offset+1));
					String dirname=temp2.substring(0, offset + 1);
					if (!result.contains(dirname))
					{showListOffsets.add(off);	result.add(dirname);}

				}

			}

			off += 1;

		}
		return result;
	}
	/*
	 public void StringReplace(String old, String news)
	 {
	 List<String> s= getString(null);
	 for (int i =0;i < s.size();i += 1)
	 {
	 if (s.get(i).equals(old))
	 s.set(i, news);
	 }
	 try
	 {
	 writeString(s);
	 }
	 catch (IOException e)
	 {}
	 }
	 public ArrayList<StringIdItem> stringIds;
	 public List<String> getString(ClassDefItem aim)
	 {
	 List<String> strings=new ArrayList<String>();
	 HashMap<StringIdItem,StringIdItem> stringIdsMap=new HashMap<StringIdItem,StringIdItem>();
	 stringIds = new ArrayList<StringIdItem>();
	 if (aim != null)
	 {
	 for (ClassDataItem.EncodedMethod method:getMethods(aim))
	 {
	 filterString(method, stringIdsMap);

	 }

	 for (StringIdItem stringId:stringIdsMap.keySet())
	 {
	 stringIds.add(stringId);
	 strings.add(org.jf.dexlib.Util. Utf8Utils.escapeString(stringId.getStringValue()));
	 }
	 }



	 else
	 for (ClassDefItem dex:getClasses())
	 {
	 for (ClassDataItem.EncodedMethod method:getMethods(dex))
	 {filterString(method, stringIdsMap);
	 }


	 for (StringIdItem stringId:stringIdsMap.keySet())
	 {
	 stringIds.add(stringId);
	 strings.add(org.jf.dexlib.Util. Utf8Utils.escapeString(stringId.getStringValue()));
	 }
	 }

	 return strings;
	 }
	 public void writeString(List<String> string)throws IOException
	 {

	 for (int i=0,len=stringIds.size();i < len;i++)
	 {
	 StringIdItem item=stringIds.get(i);
	 item.setStringValue(org.jf.dexlib.Util.Utf8Utils.escapeSequence(string.get(i)));

	 }
	 }

	 public  void filterString(ClassDataItem.EncodedMethod method, HashMap<StringIdItem,StringIdItem> stringIdsMap)
	 {
	 if (method.codeItem != null)
	 {
	 Instruction[] instructions=method.codeItem.getInstructions();
	 for (Instruction instruction:instructions)
	 {
	 switch (instruction.getFormat())
	 {
	 case Format21c:
	 case Format31c:
	 switch (instruction.opcode.referenceType)
	 {
	 case string:
	 InstructionWithReference ref=(InstructionWithReference)instruction;
	 stringIdsMap.put((StringIdItem)ref.getReferencedItem(), null);
	 }

	 }
	 }
	 }
	 }
	 */

}
