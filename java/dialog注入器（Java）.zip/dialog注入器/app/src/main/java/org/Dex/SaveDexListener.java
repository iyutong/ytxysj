package org.Dex;

public interface  SaveDexListener
{
	
	public void onProgress(int total,int now);
	
}
