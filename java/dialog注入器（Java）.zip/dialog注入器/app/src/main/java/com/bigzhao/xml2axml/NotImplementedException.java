package com.bigzhao.xml2axml;

/**
 * Created by Roy on 15-10-6.
 */
public class NotImplementedException extends RuntimeException {
}
