package com.test.dex;


import Tool.apkeditor.*;
import android.app.*;
import android.content.res.*;
import android.os.*;
import android.support.v7.widget.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import com.bigzhao.xml2axml.test.*;
import com.github.angads25.filepicker.controller.*;
import com.github.angads25.filepicker.model.*;
import com.github.angads25.filepicker.view.*;
import com.test.dex.*;
import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.Dex.*;
import org.jf.dexlib.*;
import org.jf.dexlib.Util.*;
import org.xml.sax.*;
import org.zeroturnaround.zip.*;

public class MainActivity extends Activity 
    {
        private DialogProperties properties = new DialogProperties ( );
        private String main="";
        private String path;
        private EditText url,ver;
        private Button OK;
        private ProgressDialog dia;
        public RecyclerView recyclerView;
        private MyAdapter adapter;
        private List<FActivityInfo> list = new ArrayList<> ( );
        @Override
        protected void onCreate( Bundle savedInstanceState )
            {
                super.onCreate ( savedInstanceState );
                setContentView ( R.layout.main2 );
                Main.thiz = this;
                recyclerView = (RecyclerView) findViewById ( R.id.recyclerView );
                RecyclerView.LayoutManager layout = new LinearLayoutManager ( this );
                recyclerView.setLayoutManager ( layout );
                adapter = new MyAdapter ( list );
                recyclerView.setHasFixedSize ( true );
                recyclerView.setAdapter ( adapter );
                adapter.setOnItemClickListener ( new MyAdapter.OnItemClickListener ( ) {
                            @Override
                            public void onItemClick( View view, int position )
                                {
                                    Toast.makeText ( MainActivity.this, "当前选择的入口:  " + list.get ( position ).name, Toast.LENGTH_LONG ).show ( );
                                    main = list.get ( position ).name;
                                }
                        } );
                properties.selection_mode = DialogConfigs.SINGLE_MODE;
                properties.selection_type = DialogConfigs.FILE_SELECT;
                properties.root = new File ( DialogConfigs.DEFAULT_DIR );
                properties.error_dir = new File ( DialogConfigs.DEFAULT_DIR );
                properties.offset = new File ( DialogConfigs.DEFAULT_DIR );
                properties.extensions = new String[]{"apk", "APK"};
                FilePickerDialog dialog = new FilePickerDialog ( this, properties );
                dialog.setTitle ( "Select *.APK File" );
                dialog.setDialogSelectionListener ( new DialogSelectionListener ( ) {
                            @Override
                            public void onSelectedFilePaths( String[] files )
                                {
                                    path = files [ 0 ];			                                                                
                                    ZipUtil.unpackEntry ( new File ( path ), "AndroidManifest.xml", new File ( "sdcard/1.xml" ) );
                                    try
                                        {
                                            Main.decode ( "sdcard/1.xml", "sdcard/2.txt" );
                                        }
                                    catch(FileNotFoundException e)
                                        {}
                                    try
                                        {
                                            AndroidManifestRead xml = new AndroidManifestRead ( new File ( "sdcard/2.txt" ) );
                                            for( FActivityInfo info : xml.getActivity ( ) )
                                                {
                                                    FActivityInfo data = new FActivityInfo ( );
                                                    if( info.name.subSequence ( 0, 1 ).equals ( "." ) )
                                                        {
                                                            data.name = xml.getPackage ( ) + info.name;
                                                        }
                                                    else
                                                        {
                                                            data.name = info.name;
                                                        }
                                                    data.lable = info.lable;
                                                    data.isMain = info.isMain;
                                                    list.add ( data );                                                   
                                                }
                                            adapter.notifyDataSetChanged ( );
                                        }
                                    catch(ParserConfigurationException e)
                                        {}
                                    catch(SAXException e)
                                        {}
                                    catch(IOException e)
                                        {}

                                }
                        } );
                dialog.show ( );	
                dia = new ProgressDialog ( MainActivity.this );
                dia.setMessage ( "正在处理...." );
                dia.setCancelable ( false );                            
                url = (EditText) findViewById ( R.id.url );
                ver=(EditText) findViewById(R.id.ver);
                OK = (Button) findViewById ( R.id.Button );
                OK.setOnClickListener ( new OnClickListener ( ){

                            @Override
                            public void onClick( View p1 )
                                {
                                    if( main.isEmpty ( ) )
                                        {
                                            Toast.makeText ( MainActivity.this, "Error", 5000 ).show ( );
                                            return;
                                        }
                                    dia.show ( );
                                    runOnUiThread ( new Runnable ( ){

                                                @Override
                                                public void run( )
                                                    {
                                                        //提取apk的axml和classes
                                                        ZipUtil.unpackEntry ( new File ( path ), "classes.dex", new File ( "sdcard/a.dex" ) );                                                                                                            
                                                        //dex处理
                                                        try
                                                            {
                                                                copy ( getAssets ( ), "test.dex" );
                                                                //copy(getAssets(), "olldbg.db");
                                                            }
                                                        catch(IOException e)
                                                            {}
                                                        try
                                                            {					
                                                                DexUtils utils = new DexUtils ( new DexFile ( FileUtils.readFile ( "/mnt/sdcard/a.dex" ) ) );
                                                                DexUtils dex = new DexUtils ( new DexFile ( FileUtils.readFile ( "/mnt/sdcard/test.dex" ) ) );                                                     
                                                                List<ClassDefItem> l = utils.getClasses ( );
                                                                l.addAll ( dex.getClasses ( ) );
                                                                utils.setClasses ( l );					
                                                                ClassDataItem.EncodedMethod oncreate=utils.getMethodByName ( "L" + main.replace ( ".", "/" ) + ";->onCreate" );		
                                                                String code = 	utils.getByteCode ( oncreate );
                                                                int register = oncreate.codeItem.getRegisterCount ( );
                                                                String in = "invoke-static {寄存器} Lo;->o(Landroid/content/Context;)V\n";		
                                                                code = in.replace ( "寄存器", "v" + ( register - 2 ) ) + code;					
                                                                utils.setByteCode ( code );		
                                                                dex.StringReplace ( "服务器地址", url.getText ( ).toString ( ) );
                                                                dex.StringReplace ( "版本号", ver.getText ( ).toString ( ) );
                                                                utils.save ( new File ( "sdcard/classes.dex" ) );		
                                                                new File ( "sdcard/a.dex" ).delete ( );
                                                                new File ( "sdcard/test.dex" ).delete ( );

                                                                //回填apk
                                                                ZipUtil.replaceEntry ( new File ( path ), "classes.dex", new File ( "sdcard/classes.dex" ) );
                                                                //ZipUtil.replaceEntry(new File(path), "AndroidManifest.xml", new File("sdcard/AndroidManifest.xml"));
                                                                new File ( "sdcard/classes.dex" ).delete ( );
                                                                new File ( "sdcard/1.xml" ).delete ( );
                                                                new File ( "sdcard/2.txt" ).delete ( );
                                                                //ZipUtil.addEntry(new File(path), "assets/olldbg.db", new File("sdcard/olldbg.db"));
                                                                //new File("sdcard/olldbg.db").delete();
                                                                ApkEdirotMain.Apk ( path, "sdcard/Perfume.apk" );
                                                                Toast.makeText ( MainActivity.this, "注入成功!", 5000 ).show ( );
                                                                dia.dismiss ( );
                                                            }
                                                        catch(IOException e)
                                                            {
                                                                dia.dismiss ( );
                                                                Toast.makeText ( MainActivity.this, e.getMessage ( ), 5000 ).show ( );
                                                            }
                                                        catch(Exception e)
                                                            {
                                                                dia.dismiss ( );
                                                                Toast.makeText ( MainActivity.this, e.getMessage ( ), 5000 ).show ( );
                                                            }
                                                    }
                                            } );
                                }
                        } );
            }

        public  void copy( AssetManager assers, String name ) throws IOException
            {
                File out = new File ( "sdcard/", name );
                if( out.exists ( ) )
                    return;
                InputStream is = assers.open ( name );
                OutputStream os = new FileOutputStream ( out );
                copy ( is, os );
            }

        public  void copy( InputStream i, OutputStream o ) throws IOException
            {
                byte[] b = new byte[1024];
                int len;
                while( ( len = i.read ( b ) ) != -1 )
                    {
                        o.write ( b, 0, len );
                    }
                i.close ( );
                o.close ( );
            }

    }
