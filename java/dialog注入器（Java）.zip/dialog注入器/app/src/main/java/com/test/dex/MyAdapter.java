package com.test.dex;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;



import java.util.ArrayList;
import java.util.List;



/**
 * Created by Administrator on 2017/11/13.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> implements View.OnClickListener
    {


        @Override
        public void onClick( View v )
            {
                if( mOnItemClickListener != null )
                    {
                        mOnItemClickListener.onItemClick ( v, (int)v.getTag ( ) );
                    }
            }
        public void setOnItemClickListener( OnItemClickListener listener )
            {
                this.mOnItemClickListener = listener;
            }
        public  interface OnItemClickListener
            {
                void onItemClick( View view , int position );
            }
        private OnItemClickListener mOnItemClickListener = null;

        private List<FActivityInfo> data=new ArrayList<> ( );
        public MyAdapter( List<FActivityInfo> data )
            {
                this.data = data;
            }
        @Override
        public MyAdapter.ViewHolder onCreateViewHolder( ViewGroup viewGroup, int i )
            {
                View itemLayoutView = LayoutInflater.from ( viewGroup.getContext ( ) ).inflate ( R.layout.card, null );
                ViewHolder viewHolder = new ViewHolder ( itemLayoutView );
                itemLayoutView.setOnClickListener ( this );
                return viewHolder;
            }
        @Override
        public void onBindViewHolder( MyAdapter.ViewHolder viewHolder, int i )
            {
                viewHolder.info.setText ( data.get ( i ).name );
                viewHolder.itemView.setTag ( i );
            }
        @Override
        public int getItemCount( )
            {
                return data.size ( );
            }
        public static class ViewHolder extends RecyclerView.ViewHolder
            {
                public TextView info;
                public ViewHolder( View itemLayoutView )
                    {
                        super ( itemLayoutView );
                        info = (TextView) itemLayoutView.findViewById ( R.id.name );
                    }
            }
    }
