package Tool.apkeditor;


import Tool.apkeditor.apksigner.KeyHelper;

import java.io.File;

/**
 * Created by zl on 15/9/8.
 */
public class ApkEdirotMain {


   public static void Apk(String a,String b)
   {
      try
         {
            ApkEditor editor=new ApkEditor(KeyHelper.privateKey,KeyHelper.sigPrefix);
            File unsignFile=new File(a);
            File tempFile = new File(b);
            editor.setOrigFile(unsignFile.getAbsolutePath());
            editor.setOutFile(tempFile.getAbsolutePath());     
            editor.create ( );
            unsignFile.delete();
         }
      catch (Exception e)
         {}
   }
    

}
