package android.text;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by Roy on 15-10-6.
 */
public class TextUtils extends StringUtils{

}
