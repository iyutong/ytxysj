package com.hqwyym.kfl;

import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	private EditText address;
	private Button getbutton;
	private TextView text;
	

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		//版本4.0后需加这个，不然就报错android.os.NetworkOnMainThreadException
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads().detectDiskWrites().detectNetwork()
				.penaltyLog().build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
				.penaltyLog().penaltyDeath().build());
		//
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		//初始化

		address = (EditText) findViewById(R.id.address);
		getbutton = (Button) findViewById(R.id.getbutton);
		text = (TextView) findViewById(R.id.text);
		
			
		
		getbutton.setOnClickListener(new Button.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String url = address.getText().toString();
				getPDAServerData(url);
			}
		});

	}

	public void getPDAServerData(String url) {
		HttpClient client = new DefaultHttpClient();
		HttpPost request;

		try {
			
			request = new HttpPost(url);
			
			//调用HttpClient对象的execute(HttpUriRequest request)发送请求，返回一个HttpResponse
			HttpResponse response = client.execute(request);
			
			//返回响应码为200
			if (response.getStatusLine().getStatusCode() == 200) {
				
				//从响应中获取消息实体
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					String out = EntityUtils.toString(entity);
					text.setText(out);
				}
			}
			
			
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
