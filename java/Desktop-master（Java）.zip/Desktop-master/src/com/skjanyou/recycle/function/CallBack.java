package com.skjanyou.recycle.function;

public interface CallBack {
	public void start();
	public void end();
}
