package com.skjanyou.recycle.function;

/**
 *  �����̵߳Ļص���
 * @author skjanyou
 *
 */
public interface AnimationCallBack {
	public void start();
	public void end();
}
