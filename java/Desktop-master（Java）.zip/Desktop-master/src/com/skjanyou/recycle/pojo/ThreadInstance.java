package com.skjanyou.recycle.pojo;

import com.skjanyou.recycle.thread.Animation;

public class ThreadInstance {
	public static Animation animation;
}
