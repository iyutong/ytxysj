package com.shuibowen;

import android.app.*;
import android.os.*;
import android.content.*;
import com.yanman.yanman.*;
import android.widget.*;
import android.view.*;
import android.widget.RadioGroup.*;
import android.util.*;
import org.xmlpull.v1.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		/*MyRingWave sbw = new MyRingWave(this,null);
		LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		this.addContentView(sbw,lp);*/
    }

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		MyRingWave sbw;
		if(sbw == null)
		/*LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		sbw.setFocusable(true);
		sbw.setFocusableInTouchMode(true);*/
		if(keyCode == event.KEYCODE_VOLUME_UP){
			if(sbw.isShown()){
				sbw.setVisibility(View.GONE);
			}else{
			return true;
			}
		}
		// TODO: Implement this method
		return super.onKeyDown(keyCode, event);
	}
	
}
