package com.mycompany.theme;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.Menu;
import android.content.Intent;

public class MainActivity extends AppCompatActivity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //进入时更换主题
		themeutils.启动后设置主题(this);
		
		setContentView(R.layout.main);
        
		}
		
		
		
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // TODO Auto-generated method stub
menu.add(0, 1, 1, "红");
menu.add(0, 2, 2, "鸭绿");
menu.add(0, 3, 3, "恢复默认");
 return super.onCreateOptionsMenu(menu);
    }






    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();

        }else

		if(item.getItemId() == 1){

			themeutils.更换主题(this,1);
			restartAct();
        }else if(item.getItemId()==2){
			
			themeutils.更换主题(this,2);
			restartAct();

		}else if(item.getItemId()==3){

			themeutils.恢复默认(this);
			restartAct();

		}
        return true;
        //return super.onOptionsItemSelected(item);
    }
		

	/**
     * 重启当前Activity
     */
    private void restartAct() {
        finish();
        Intent _Intent = new Intent(this, MainActivity.class);
        startActivity(_Intent);
        //清除Activity退出和进入的动画
        overridePendingTransition(0, 0);
    }
}
