package com.mycompany.theme;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.SharedPreferences.Editor;

public class themeutils
{

	private static  int themeid ;

	private static SharedPreferences.Editor Edit;
	private static String FILE_NAME="theme";
	
	//更换主题
	public static void 启动后设置主题(Context context){
		
		SharedPreferences theme = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
		boolean canget = theme.getBoolean("canset", false);
		if(canget){
			themeid = theme.getInt("theme", 0);
		//调用更换主题
			设置(context,themeid);
			
			
			}else{
				context.setTheme(R.style.AppTheme);
			}
		
		
	}
	
	public static void 更换主题(Context context,int i){
		
		SharedPreferences SpLocal=context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        Edit=SpLocal.edit();
		Edit.putBoolean("canset",true);
        Edit.putInt("theme",i );
        Edit.apply();
	}
	
	public static void 恢复默认(Context context){
		
		SharedPreferences SpLocal=context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        Edit=SpLocal.edit();
		Edit.putBoolean("canset",false);
		Edit.apply();
		
	}
	
		public static int getthemeid(Context context){
				
				SharedPreferences theme = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
				boolean canget = theme.getBoolean("canset", false);
				if(canget){
				//SharedPreferences theme = context.getSharedPreferences("theme", Context.MODE_PRIVATE);
				themeid = theme.getInt("theme", 0);
				}
				//themeid=themeid;
				return themeid;
				
			}
			
			private static void 设置(Context context,int i){
				
				if(i==1){
					context.setTheme(R.style.AppTheme1);
				}else if(i==2){
					
					context.setTheme(R.style.AppTheme2);
				}
				}
				
				
				
}
