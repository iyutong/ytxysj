appname="AideLuaSample"
theme="Theme_DeviceDefault_Light"
