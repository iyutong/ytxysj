# WheelView
Android滚轮控件,使用自定义ScrollView实现，主要参考此项目：https://github.com/wangjiegulu/WheelView

#Author
Wangjia55 (http://blog.csdn.net/wangjia55)

#效果图
![icon](https://github.com/wangjia55/WheelView/blob/master/screen_shot2.png)
![icon](https://github.com/wangjia55/WheelView/blob/master/screen_shot3.png)

