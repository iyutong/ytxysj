package com.mycompany.myapp;

import android.app.*;
import android.content.*;
import android.net.wifi.*;
import android.os.*;

public class MainActivity extends Activity 
{
	/*
	 所有操作都必须要在权限允许的情况下操作
	 若不给WIFI开启or关闭权限
	 再多代码也是徒劳
	 所有操作都必须要在权限允许的情况下操作
	 若不给WIFI开启or关闭权限
	 再多代码也是徒劳
	 所有操作都必须要在权限允许的情况下操作
	 若不给WIFI开启or关闭权限
	 再多代码也是徒劳
	 QQ2814432475
	 代码来自网络
	 注释我自己加的，不加也十分好懂（有一点JAVA基础的条件下）
	 */
	private WifiManager wifiManager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		//获取WifiManager
		wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
		//判断WIFI状态:开启
		if(wifiManager.isWifiEnabled()) { 
		//则关闭
		wifiManager.setWifiEnabled(false); 
		} else{
		//反之则开启
			wifiManager.setWifiEnabled(true); 
    }
}}
