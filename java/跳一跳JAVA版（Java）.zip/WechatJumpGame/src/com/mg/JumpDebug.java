package com.mg;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.Iterator;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 * debug时的代码，可以再自己优化
 * 微信跳一跳小游戏辅助，参考了别人的代码，但核心代码完全重写优化，没出现过查找目标点失败的情况
 * 自测已跳2千多分，后面的目标点是在太小了
 * 注释全是我自己写的
 * 
 * @author 暮光：城中城
 * @since 2018年1月12日
 */
public class JumpDebug {

	private static String basePath = "D:/weixinJump";// adb、截屏等存放目录
	private static float rate = 1.45f;// 两点间的距离×rate（按压系数）

	public static void main(String[] args) throws Exception {
		while (true) {
			File pic = getScreenPic();// 获取图片
			String res = scanPic(pic);// 获取两点间的距离和按压时长
			exec("shell input swipe " + res);// 执行按压
			Thread.sleep(1000 + new Random().nextInt(500));// 暂停一会，太短了截的屏不行，还没初始完成
		}
	}
	
	/**
	 * 核心代码
	 * 扫描图片，找出坐标
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param pic
	 * @return
	 * @throws Exception
	 */
	private static String scanPic(File pic) throws Exception {
		BufferedImage bi = ImageIO.read(pic);
		int width = bi.getWidth();
		int height = bi.getHeight();
		int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
		// 扫黑棋的底部中心位置，一行一行的找
		for (int i = height - 10; i > height / 3; i--) {
			for (int j = 50; j < width - 50; j++) {
				int flag = 0;
				for (int k = 0; k < width - j; k++) {
					int[] p = getRGB(bi, j + k, i);
					// 这是调试出来的值，黑棋底部的颜色大概在这个范围内
					if (p[0] > 50 && p[0] < 60 && p[1] > 50 && p[1] < 60 && p[2] > 90 && p[2] < 110) {
						flag++;
					} else {
						break;
					}
				}
				if (flag >= 3) {
					x1 = j + (flag / 2);
					y1 = i;
					break;
				}
			}
			if (x1 > 0) {
				break;
			}
		}
		// 扫目标点的中心点坐标，一行一行的找
		for (int i = height / 3; i < height * 3 / 4; i++) {
			int[] p1 = getRGB(bi, 10, i);
			for (int j = 100; j < width; j++) {
				int[] p2 = getRGB(bi, j, i);
				// 如果颜色和之前的颜色差距太大，则应该是找到了目标
				if (Math.abs(p2[0] - p1[0]) > 10 || Math.abs(p2[1] - p1[1]) > 10 || Math.abs(p2[2] - p1[2]) > 10) {
					// 重点！如果当前点和黑棋的点的横坐标中心点在50以内，则表示这个应该是黑棋或顶部的超越什么的，调试出来的经验
					if (Math.abs(x1 - j) <= 50) {
						j += 100;
					} else {
						int flag = 0;
						// 重点！由上往下找中心点
						for (int k = 0; k < width - j; k++) {
							int[] p4 = getRGB(bi, j + k, i);
							flag++;
							if (Math.abs(p4[0] - p2[0]) > 10 || Math.abs(p4[1] - p2[1]) > 10
									|| Math.abs(p4[2] - p2[2]) > 10) {
								x2 = j + (flag / 2);
								y2 = i;
								break;
							}
						}
						break;
					}
				}
			}
			if (y2 > 0) {
				int lastMax = x2;
				System.out.println(lastMax);
				// 找到目标顶点后再往下找中心点
				for (i += 10; i < height * 3 / 4; i++) {
					for (int j = x2; j < width; j++) {
						int[] p4 = getRGB(bi, j, i);
						if (Math.abs(p4[0] - p1[0]) < 10 && Math.abs(p4[1] - p1[1]) < 10
								&& Math.abs(p4[2] - p1[2]) < 10) {
							if (lastMax >= j) {
								y2 = i;
							}
							lastMax = j;
							break;
						}
					}
					if (y2 == i) {
						break;
					}
				}
				System.out.println(lastMax);
				break;
			}
		}
		// 勾股定理（数学终于有用武之地了！），计算两点间距离，别人都不是这样计算了，但我试了这样很精确
		double distance = Math.sqrt(Math.pow(Math.abs(x2 - x1), 2) + Math.pow(Math.abs(y2 - y1), 2));
		if (x1 < 50 || y1 < 50 || x2 < 50 || y2 < 50 || distance < 100) {
			throw new Exception("扫描图片错误，请确定是在游戏中");
		}
		// 剪切图片，主要用于调试试下点找对没
		cutImage(pic.getAbsolutePath(), basePath + "/pic_cut.png", x2, y2, 999, 999);
		distance = (distance < 200) ? 200 : distance;
		// 前面几个是按压点，后面一个是按压时长，主要用的就是按压时长
		return "50 50 50 50" + " " + (int) (distance * rate);
	}
	
	/**
	 * 获取RGB值
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param bi
	 * @param x
	 * @param y
	 * @return
	 */
	private static int[] getRGB(BufferedImage bi, int x, int y) {
		int rgb = bi.getRGB(x, y);
		int[] res = new int[3];
		res[0] = rgb >> 16 & 0xFF;
		res[1] = rgb >> 8 & 0xFF;
		res[2] = rgb & 0xFF;
		return res;
	}

	/**
	 * 获取手机屏幕图片
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @return
	 * @throws Exception
	 */
	private static File getScreenPic() throws Exception {
		File pic = new File(basePath + "/pic.png");
		if (pic.exists()) {// 备份之前的图片
			File back1 = new File(basePath + "/back1.png");
			if (back1.exists()) {// 再次备份之前的图片
				doCopyFile(back1, new File(basePath + "/back2.png"));
			}
			doCopyFile(pic, back1);
		}
		exec("shell screencap -p /sdcard/screen.png");
		exec("pull /sdcard/screen.png " + pic.getAbsolutePath());
		if (!pic.exists()) {
			throw new Exception("获取手机屏幕图片失败");
		}
		return pic;
	}
	
	/**
	 * 让手机执行命令
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param cmd
	 * @throws Exception
	 */
	private static void exec(String cmd) throws Exception {
		Process ps = null;
		try {
			cmd = basePath + "/platform-tools/adb " + cmd;
			System.out.println(cmd);
			ps = Runtime.getRuntime().exec(cmd.split(" "));
			int code = ps.waitFor();
			if (code != 0) {
				throw new Exception("执行命令失败(code=" + code + "): " + cmd);
			}
		} finally {
			if (ps != null) {
				ps.destroy();
			}
		}
	}
	
	/**
	 * 剪切图片
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param src
	 * @param dest
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @throws IOException
	 */
	public static void cutImage(String src, String dest, int x, int y, int w, int h) throws IOException {
		Iterator<?> iterator = ImageIO.getImageReadersByFormatName("png");
		ImageReader reader = (ImageReader) iterator.next();
		InputStream in = new FileInputStream(src);
		ImageInputStream iis = ImageIO.createImageInputStream(in);
		reader.setInput(iis, true);
		ImageReadParam param = reader.getDefaultReadParam();
		Rectangle rect = new Rectangle(x, y, w, h);
		param.setSourceRegion(rect);
		BufferedImage bi = reader.read(0, param);
		ImageIO.write(bi, "png", new File(dest));
	}
	
	/**
	 * 拷贝文件
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param srcFile
	 * @param destFile
	 * @throws IOException
	 */
	private static void doCopyFile(File srcFile, File destFile) throws IOException {
		if (destFile.exists() && destFile.isDirectory()) {
			return;
		}
		FileInputStream fis = null;
		FileOutputStream fos = null;
		FileChannel input = null;
		FileChannel output = null;
		try {
			fis = new FileInputStream(srcFile);
			fos = new FileOutputStream(destFile);
			input = fis.getChannel();
			output = fos.getChannel();
			long size = input.size(), pos = 0, count = 0;
			while (pos < size) {
				count = size - pos > 31457280 ? 31457280 : size - pos;
				pos += output.transferFrom(input, pos, count);
			}
		} finally {
			closeQuietly(output);
			closeQuietly(fos);
			closeQuietly(input);
			closeQuietly(fis);
		}
	}
	
	/**
	 * 关闭资源
	 * @author 暮光：城中城
	 * @since 2018年1月12日
	 * @param closeable
	 */
	public static void closeQuietly(Closeable closeable) {
		try {
			if (closeable != null) {
				closeable.close();
			}
		} catch (IOException ioe) {
		}
	}
}
