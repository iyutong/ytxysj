package com.mg;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;

import javax.imageio.ImageIO;

/**
 * 去掉了自测时的代码版本
 * 微信跳一跳小游戏辅助，参考了别人的代码，但核心代码完全重写优化
 * 自测已跳2千多分，后面的目标点是在太小了
 * 
 * @author 暮光：城中城
 * @since 2018年1月12日
 */
public class Jump {

	private static String basePath = "D:/weixinJump";// adb、截屏等存放目录
	private static float rate = 1.45f;// 两点间的距离×rate（按压系数）

	public static void main(String[] args) throws Exception {
		while (true) {
			File pic = getScreenPic();// 获取图片
			String res = scanPic(pic);// 获取两点间的距离和按压时长
			exec("shell input swipe " + res);// 执行按压
			Thread.sleep(1000 + new Random().nextInt(500));// 暂停一会，太短了截的屏不行，还没初始完成
		}
	}

	private static String scanPic(File pic) throws Exception {
		BufferedImage bi = ImageIO.read(pic);
		int width = bi.getWidth();
		int height = bi.getHeight();
		int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
		for (int i = height - 10; i > height / 3; i--) {
			for (int j = 50; j < width - 50; j++) {
				int flag = 0;
				for (int k = 0; k < width - j; k++) {
					int[] p = getRGB(bi, j + k, i);
					if (p[0] > 50 && p[0] < 60 && p[1] > 50 && p[1] < 60 && p[2] > 90 && p[2] < 110) {
						flag++;
					} else {
						break;
					}
				}
				if (flag >= 3) {
					x1 = j + (flag / 2);
					y1 = i;
					break;
				}
			}
			if (x1 > 0) {
				break;
			}
		}
		for (int i = height / 3; i < height * 3 / 4; i++) {
			int[] p1 = getRGB(bi, 10, i);
			for (int j = 100; j < width; j++) {
				int[] p2 = getRGB(bi, j, i);
				if (Math.abs(p2[0] - p1[0]) > 10 || Math.abs(p2[1] - p1[1]) > 10 || Math.abs(p2[2] - p1[2]) > 10) {
					if (Math.abs(x1 - j) <= 50) {
						j += 100;
					} else {
						int flag = 0;
						for (int k = 0; k < width - j; k++) {
							int[] p4 = getRGB(bi, j + k, i);
							flag++;
							if (Math.abs(p4[0] - p2[0]) > 10 || Math.abs(p4[1] - p2[1]) > 10
									|| Math.abs(p4[2] - p2[2]) > 10) {
								x2 = j + (flag / 2);
								y2 = i;
								break;
							}
						}
						break;
					}
				}
			}
			if (y2 > 0) {
				int lastMax = x2;
				for (i += 10; i < height * 3 / 4; i++) {
					for (int j = x2; j < width; j++) {
						int[] p4 = getRGB(bi, j, i);
						if (Math.abs(p4[0] - p1[0]) < 10 && Math.abs(p4[1] - p1[1]) < 10
								&& Math.abs(p4[2] - p1[2]) < 10) {
							if (lastMax >= j) {
								y2 = i;
							}
							lastMax = j;
							break;
						}
					}
					if (y2 == i) {
						break;
					}
				}
				break;
			}
		}
		double distance = Math.sqrt(Math.pow(Math.abs(x2 - x1), 2) + Math.pow(Math.abs(y2 - y1), 2));
		if (x1 < 50 || y1 < 50 || x2 < 50 || y2 < 50 || distance < 100) {
			throw new Exception("扫描图片错误，请确定是在游戏中");
		}
		distance = (distance < 200) ? 200 : distance;
		return "50 50 50 50" + " " + (int) (distance * rate);
	}

	private static int[] getRGB(BufferedImage bi, int x, int y) {
		int rgb = bi.getRGB(x, y);
		int[] res = new int[3];
		res[0] = rgb >> 16 & 0xFF;
		res[1] = rgb >> 8 & 0xFF;
		res[2] = rgb & 0xFF;
		return res;
	}

	private static File getScreenPic() throws Exception {
		File pic = new File(basePath + "/pic.png");
		exec("shell screencap -p /sdcard/screen.png");
		exec("pull /sdcard/screen.png " + pic.getAbsolutePath());
		if (!pic.exists()) {
			throw new Exception("获取手机屏幕图片失败");
		}
		return pic;
	}

	private static void exec(String cmd) throws Exception {
		Process ps = null;
		try {
			cmd = basePath + "/platform-tools/adb " + cmd;
			System.out.println(cmd);
			ps = Runtime.getRuntime().exec(cmd.split(" "));
			int code = ps.waitFor();
			if (code != 0) {
				throw new Exception("执行命令失败(code=" + code + "): " + cmd);
			}
		} finally {
			if (ps != null) {
				ps.destroy();
			}
		}
	}
}
