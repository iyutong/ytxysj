package com.wuma.gaoqing;//这个是什么，这个就是这个应用的包名，应该发现了吧
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.webkit.*;//这里就是了

public class qidongtu extends Activity {
    private final int SPLASH_DISPLAY_LENGHT = 500; //这里声明了一个int变量，值为400，这个是个时间运行时间，当时间为4秒回执行一段代码
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
		requestWindowFeature ( Window.FEATURE_NO_TITLE );//取消标题
		getWindow ( ).setFlags ( WindowManager.LayoutParams.FLAG_FULLSCREEN, 
								WindowManager.LayoutParams.FLAG_FULLSCREEN );//设置全屏
        setContentView(R.layout.qidongtu);//这里就是运行这个java后跳转的一个布局，名称叫qidongtu
		//如果没有这个代码 那么运行这个软件后就不会有布局
        new Handler().postDelayed(new Runnable() {
                public void run() {
                   /*就是这段了*/ Intent mainIntent = new Intent(qidongtu.this,MainActivity.class);//java还有一个别称，就是class了，这里就是时间是4时，运行MainActivity.java了
                    qidongtu.this.startActivity(mainIntent);
                    qidongtu.this.finish();
                }
            }, SPLASH_DISPLAY_LENGHT);
			

		
		
			
			
			
    }
}

