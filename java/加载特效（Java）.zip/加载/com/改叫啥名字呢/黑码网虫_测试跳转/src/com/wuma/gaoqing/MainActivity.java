package com.wuma.gaoqing;

import android.app.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.view.View.*;
import android.content.*;

public class MainActivity/*前面的蓝色字要和这个java的名称相同，否则就不成立*/ extends Activity//这里就是了
{//在java中，如果一个java没有被其他的java激活 这个java就相对于没有添加
	Button tz,tz1;//现在讲的是跳转了当然也可以这样button tz;   button tz1;也可以分这声明
	//我上面生名了两个按钮(button)变量一个叫tz一个叫tz1
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);//还是这个代码 就是运行这个java后会跳转到main这个布局
		tz=(Button) findViewById/*蓝字是读取id*/(R.id.tz)/*读取的id是tz*/;//这里就是对应了 这个就是tz的属性了
		tz1=(Button) findViewById(R.id.tz1);
		
		tz.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent tz=new Intent();
					tz.setClass(MainActivity.this,q.class);//就是运行一个叫q的java
					startActivity(tz);
					// TODO: Implement this method
				}//点击后会执行这个
			});
		tz1.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Intent tz1=new Intent();
					tz1.setClass(MainActivity.this,qq.class);//这个点击tz1运行的就是qq.java了，原理一样，我们实验一下
					startActivity(tz1);
					// TODO: Implement this method当然还可以直接跳转，直接运行跳转代码，不运行java
				}//这个就不实验了，现在实验权限
				
			});

			
			
		
			
			
			
			
			}
	
	
    
}
