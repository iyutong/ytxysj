package com.wuma.gaoqing;

import android.app.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class q /*都是这样的*/extends Activity
{
	
	public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.q);
		//运行后，这个java会跳转一个q.xml布局
	

}}
