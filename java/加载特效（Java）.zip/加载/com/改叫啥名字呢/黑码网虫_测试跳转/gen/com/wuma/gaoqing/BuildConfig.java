/** Automatically generated file. DO NOT MODIFY */
package com.wuma.gaoqing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}