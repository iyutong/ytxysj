
已停止维护，慎用！！！！！！！！！


[Version 1.3详情](https://weavey.github.io/2016/09/07/%E7%9B%B4%E6%8E%A5%E6%8B%BF%E5%8E%BB%E7%94%A8%E4%B9%8BDialog/)

Version 1.3引用
> compile 'com.lai.weavey:dialog:1.3'

[Version 2.0详情](https://weavey.github.io/2016/12/28/%E7%9B%B4%E6%8E%A5%E6%8B%BF%E5%8E%BB%E7%94%A8%E4%B9%8BDialog2/)

Version 2.0引用
> compile 'com.lai.weavey:dialog:2.0.1'




