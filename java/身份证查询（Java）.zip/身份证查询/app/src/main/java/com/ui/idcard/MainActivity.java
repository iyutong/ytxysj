package com.ui.idcard;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.net.*;
import java.io.*;
import org.json.*;
import android.view.*;

public class MainActivity extends Activity 
{
	private EditText input_id;
    TextView show_area,show_sex,show_bitrhday,show_reason;
    public static final String LOG_TAG = MainActivity.class.getSimpleName();
    public static final String INFO_URL ="http://apis.juhe.cn/idcard/index?cardno=";
    public static final String INPUT_URL_M="&dtype=json&key=ce51f9256e1280e5885ca20e4ac50b29";
    String area;
    String sex;
    String birthday;
    int resultcode;
    String reason;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		input_id = (EditText)findViewById(R.id.input_id);
        show_area = (TextView)findViewById(R.id.show_area);
        show_sex = (TextView)findViewById(R.id.show_sex);
        show_bitrhday = (TextView)findViewById(R.id.show_birthday);
        show_reason= (TextView)findViewById(R.id.show_reason);

    }

    public void search(View view){
        makeHttpRequest();
        show_area.setText("");
        show_sex.setText("");
        show_reason.setText("");
        show_bitrhday.setText("");
    }

    //网络连接
    private void makeHttpRequest(){
        //开启线程来发起网络请求
        new Thread(new Runnable() {
				@Override
				public void run() {
					HttpURLConnection connection = null;
					BufferedReader reader = null;
					String id = input_id.getText().toString();
					try {
						URL url = new URL(INFO_URL+id+INPUT_URL_M);
						connection = (HttpURLConnection) url.openConnection();
						connection.setRequestMethod("GET");
						connection.setReadTimeout(8000);
						connection.setConnectTimeout(8000);
						InputStream in = connection.getInputStream();
						reader = new BufferedReader(new InputStreamReader(in));
						StringBuilder response  = new StringBuilder();
						String line;
						while ((line =reader.readLine())!=null){
							response.append(line);
						}
						showResponse(response.toString());
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (reader!=null){
							try {
								reader.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						if (connection!=null){
							connection.disconnect();
						}
					}
				}
			}).start();
    }

    private void showResponse(final String s) {
        runOnUiThread(new Runnable() {
				@Override
				public void run() {
					FunctionJson(s);
				}
			});
    }

    /**
     * 解析JSON数据
     * @param data
     */
    private void FunctionJson(String data){
        try {
            JSONObject jsonObject = new JSONObject(data);
            resultcode = jsonObject.optInt("resultcode");
            JSONObject jsonObject2 = jsonObject.getJSONObject("result");
            area = jsonObject2.optString("area").toString();
            sex = jsonObject2.optString("sex").toString();
            birthday = jsonObject2.optString("birthday").toString();
            reason = jsonObject.optString("reason").toString();

        } catch (JSONException e) {
            e.printStackTrace();
        }

		if (resultcode==200){

			show_area .setText("户籍："+area);
			show_sex.setText("性别："+sex);
			show_bitrhday.setText("出生年月："+birthday);
			show_reason.setText("查询成功");

		}else{
			show_reason.setText("查询失败,请输入正确的身份证号");
		}


    }

}
