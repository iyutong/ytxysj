package com.example.testproject;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Dialog_Activity extends AppCompatActivity {
    private Button button1,button2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_layout);

        button1=findViewById(R.id.dialog1);
        button2=findViewById(R.id.dialog2);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewGroup view=(ViewGroup) getLayoutInflater().inflate(R.layout.dialog01,null);
                AlertDialog.Builder dialog=new AlertDialog.Builder(Dialog_Activity.this, R.style.transparentBgDialog);
                dialog.setView(view);
                AlertDialog dia=dialog.show();
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewGroup view=(ViewGroup) getLayoutInflater().inflate(R.layout.dialog02,null);
                AlertDialog.Builder dialog=new AlertDialog.Builder(Dialog_Activity.this, R.style.transparentBgDialog);
                dialog.setView(view);
                AlertDialog dia=dialog.show();
            }
        });
    }
}
