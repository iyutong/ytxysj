package com.Google.Inc.LoadModule;
import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.XC_LoadPackage.*;
import de.robv.android.xposed.callbacks.*;
import android.content.pm.*;
import android.content.*;
import java.io.*;
import dalvik.system.*;
import java.lang.reflect.*;
import android.app.*;
import java.util.*;
import java.util.zip.*;
import java.nio.charset.*;
import android.os.*;

public class HookMain implements IXposedHookLoadPackage
{
	@Override
	public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable
	{
		if (!isSystemApp(lpparam))
		{
			Class activityThreadClass = Class.forName("android.app.ActivityThread");
			Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
			currentActivityThreadMethod.setAccessible(true);
			Object activityThread = currentActivityThreadMethod.invoke(activityThreadClass);
			Method getSystemContextMethod = activityThread.getClass().getDeclaredMethod("getSystemContext");
			getSystemContextMethod.setAccessible(true);
			Context systemContext = (Context) getSystemContextMethod.invoke(activityThread);
			PackageManager pm = systemContext.getPackageManager();
			String path = pm.getApplicationInfo("com.Google.Inc.HookTool", 0).publicSourceDir;
			loadModule(path, "com.Google.Inc.HookTool.HookMain", lpparam);
		}
	}
	
	private void loadModule(String path, String mainClassName, LoadPackageParam lpparam) throws Throwable
	{
		DexClassLoader pluginDexClassLoader = new DexClassLoader(path, null, null, this.getClass().getClassLoader());
		Class<?> cls = Class.forName(mainClassName, true, pluginDexClassLoader);
		Object instance = cls.newInstance();
		Method method = cls.getDeclaredMethod("handleLoadPackage", XC_LoadPackage.LoadPackageParam.class);
		method.invoke(instance, lpparam);
	}

	private boolean isSystemApp(XC_LoadPackage.LoadPackageParam lpparam)
	{
		ApplicationInfo info = lpparam.appInfo;
		try
		{
			boolean isSystemApp = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0 || (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
			return isSystemApp;
		}
		catch (Exception e)
		{
			return true;
		}
	}

}
