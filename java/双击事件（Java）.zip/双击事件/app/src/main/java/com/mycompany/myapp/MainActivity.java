package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;

public class MainActivity extends Activity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Button view=(Button)findViewById(R.id.a);
		view.setOnTouchListener(new OnDoubleClickListener(new OnDoubleClickListener.DoubleClickCallback() {
										 @Override
										 public void onDoubleClick() {
											 //处理双击事件
											 Toast.makeText(MainActivity.this, "双击事件", Toast.LENGTH_SHORT).show();
											 
										 }
									 }));
}
}
