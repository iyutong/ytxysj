package xmg.test.testwechat.common;

/**
 * Created by xmg on 2016/11/28.
 */

public class Config {
    public static final String APP_ID = "wxe636157f64365f78";
    public static final String APP_SERECET = "4d4877eef3cdead76ef17b3205db2b12";
}
