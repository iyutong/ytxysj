package com.example.testproject;

import android.os.Bundle;
import android.view.Window;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class Mian7 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main12);

        ImageView imageView1=findViewById(R.id.main12card1);
        ImageView imageView2=findViewById(R.id.main12card2);
        ImageView imageView3=findViewById(R.id.main12card3);
        Glide.with(Mian7.this).load("https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2262724073,2289875277&fm=26&gp=0.jpg").into(imageView3);
        Glide.with(Mian7.this).load("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1596041326508&di=0691ac00ce7228908988dc58eecd8bb9&imgtype=0&src=http%3A%2F%2Fimg4.imgtn.bdimg.com%2Fit%2Fu%3D1825741109%2C1713505834%26fm%3D214%26gp%3D0.jpg").into(imageView2);
        Glide.with(Mian7.this).load("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1596041349518&di=d95233ef44df6fbfde031a44c18bd14c&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201606%2F26%2F20160626151937_Q5HKB.jpeg").into(imageView1);
    }
}
