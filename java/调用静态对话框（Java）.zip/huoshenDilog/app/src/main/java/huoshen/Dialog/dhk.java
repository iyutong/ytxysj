package huoshen.Dialog;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface.OnClickListener;
import android.content.*;

public class dhk
{


	public static void dialog(Activity Activity)
	{
		Builder huoshen = new
		Builder (Activity);
		huoshen.setTitle("");
		huoshen.setMessage("");
		huoshen.setNegativeButton("", new OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
				}
			});
		huoshen.setPositiveButton("", new OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
				}
			});
		huoshen.setNeutralButton("", new OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
				}
			}).show();
		// TODO: Implement this method
	}}
