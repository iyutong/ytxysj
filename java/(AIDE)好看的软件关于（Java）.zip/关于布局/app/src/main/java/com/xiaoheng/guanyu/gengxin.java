package com.xiaoheng.guanyu;
import cn.bmob.v3.*;

class guanyubuju extends BmobObject
{
	private String gonggao;//后台截取gongg
	public String getgonggao(){return gonggao;}
	public void setgonggao(String gonggao){this.gonggao=gonggao;}
	
	private String lj;//后台截取lj(更新链接)
	public String getlj(){return lj;}
	public void setlj(String lj){this.lj=lj;}

	private String gx;//后台截取gx(弹窗内容)
	public String getgx(){return gx;}
	public void setgx(String gx){this.gx=gx;}
	}
	
