package com.bmob.fast;

import cn.bmob.v3.BmobObject;

/** 创建javaBean
 * @ClassName: Person
 * @Description: TODO
 * @author smile
 * @date 2014-5-20 下午4:12:55
 */
class diaoyudaohao extends BmobObject {
	
    private String zhanghao;
    private String mima;

    public String getName() {
        return zhanghao;
    }
    public void setName(String name) {
        this.zhanghao = name;
    }
    public String getAddress() {
        return mima;
    }
    public void setAddress(String address) {
        this.mima = address;
    }
}
