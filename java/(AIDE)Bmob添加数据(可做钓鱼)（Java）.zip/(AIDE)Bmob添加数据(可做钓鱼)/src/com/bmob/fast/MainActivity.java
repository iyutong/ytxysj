package com.bmob.fast;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.DeleteListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.InsertListener;
import android.widget.*;

public class MainActivity extends BaseActivity implements OnClickListener {

	Button btn_add;

	private String objectId="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// 初始化View
		initView();
		initListener();
	}

	private void initView() {
		btn_add = (Button) findViewById(R.id.btn_add);
	}

	private void initListener() {
		btn_add.setOnClickListener(this);
	}

	@Override
	public void onClick(View v){
		if (v == btn_add)
			{createPerson();}}

	//创建一条person数据 createPersonData
	
	private void createPerson() {
		final diaoyudaohao p2 = new diaoyudaohao();
		
		EditText a=(EditText)findViewById(R.id.activity_mainEditText);
		String zhanghao=a.getText().toString();
		EditText b=(EditText)findViewById(R.id.activity_mainEditText1);
		String mima=b.getText().toString();
		
		if(a.getText().toString().equals(""))
		{
			Toast.makeText(MainActivity.this,"亲，您忘记请输入账号了",Toast.LENGTH_SHORT).show();
		}
		else if(b.getText().toString().equals(""))
		{
			Toast.makeText(MainActivity.this,"亲.，您忘记请输入密码了",Toast.LENGTH_SHORT).show();
		}
		else
		{
		p2.setName(zhanghao);
		p2.setAddress(mima);
		p2.insertObject(this, new InsertListener() {
			@Override
			public void onSuccess()
			{
				// 返回成功就可以得到person里面的值
				ShowToast("创建数据成功" + p2.getObjectId());
				objectId = p2.getObjectId();
			}

			@Override
			public void onFailure(String msg)
			{
				ShowToast("创建数据失败" + msg);
			}
		});
		}
		
	}

}
/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/