package com.example.SpeedDialog.listener;

import android.app.Dialog;

/**
 * <pre>
 *     author : 残渊
 *     time   : 2019/07/12
 *     desc   : 底部子项点击回调
 * </pre>
 */

public interface OnMenuItemClickListener {
    void onClick(Dialog dialog, int position);
}
