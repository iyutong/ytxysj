package com.example.SpeedDialog.listener;

import android.app.Dialog;

/**
 * <pre>
 *     author : 残渊
 *     time   : 2019/07/11
 *     desc   :
 * </pre>
 */

public interface OnInputDialogButtonClickListener {
    void onClick(Dialog dialog, String inputText);
}
