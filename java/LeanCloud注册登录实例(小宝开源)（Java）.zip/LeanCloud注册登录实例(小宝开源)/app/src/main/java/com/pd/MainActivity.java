package com.pd;

import android.app.*;
import android.os.*;
import android.widget.*;
import com.avos.avoscloud.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
	//本源码由小宝开源，一个缓存用户信息和注册登录的实例
	//代码比较简单，所以大家可以学到更多的技术！
	//有任何不明白的地方可以加群：欢迎加入Poetic Dream网络交流，群聊号码：735344201
	//小宝QQ:892167508--813094866
	//更多源码开源请加群获取即可！！

	private EditText zh;

	private EditText mm;

	private Button zc;

	private Button dl;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		AVOSCloud.initialize(this, "mPf1QJWppz7fSeLvnUym2380-gzGzoHsz",
							 "auVSRW2fTwGcJrBHnclzWqfU");//配置id和key
		zh=(EditText)findViewById(R.id.zh);
		mm=(EditText)findViewById(R.id.mm);
		zc=(Button)findViewById(R.id.zc);
		dl=(Button)findViewById(R.id.dl);
		
		zr();
		jc();
    }

	private void jc()//加载用户信息
	
	{    	AVUser currentUser = AVUser.getCurrentUser();
        if (currentUser != null) {
			 AVUser t = AVUser.getCurrentUser();

			
			
			          Toast.makeText(MainActivity.this,"欢迎回来："+t.getUsername(),Toast.LENGTH_SHORT).show();
        } else {
         Toast.makeText(MainActivity.this,"未登录账号，请登录账号。",Toast.LENGTH_SHORT).show();
        }
		
		// TODO: Implement this method
	}

	private void zr()//载入的登录注册事件
	{
		dl.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(zh.getText().toString().equals("")||mm.getText().toString().equals("")){

						Toast.makeText(MainActivity.this,"输入账号密码后再登录",Toast.LENGTH_SHORT).show();

					}else{
						AVUser.logInInBackground(""+zh.getText().toString(), ""+mm.getText().toString(), new LogInCallback<AVUser>() {
								@Override
								public void done(AVUser avUser, AVException e) {
									if (e == null) {
										Toast.makeText(MainActivity.this,"登录成功",Toast.LENGTH_SHORT).show();
										// 注册成功
									} else {
										Toast.makeText(MainActivity.this,"登录失败\n失败原因："+e,Toast.LENGTH_SHORT).show();

										// 失败的原因可能有多种，常见的是用户名已经存在。
									}
								}
							});
						
					}
					
					// TODO: Implement this method
				}
			});
		zc.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					
					if(zh.getText().toString().equals("")||mm.getText().toString().equals("")){
						
						Toast.makeText(MainActivity.this,"输入账号密码后再点击注册",Toast.LENGTH_SHORT).show();
						
					}else{
					AVUser user = new AVUser();// 新建 AVUser 对象实例
					user.setUsername(""+zh.getText().toString());// 设置用户名
					user.setPassword(""+mm.getText().toString());// 设置密码
					//user.setEmail("tom@leancloud.cn");// 设置邮箱
					user.signUpInBackground(new SignUpCallback() {
							@Override
							public void done(AVException e) {
								if (e == null) {
									Toast.makeText(MainActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
									// 注册成功
								} else {
									Toast.makeText(MainActivity.this,"注册失败\n失败原因："+e,Toast.LENGTH_SHORT).show();
									
									// 失败的原因可能有多种，常见的是用户名已经存在。
								}
							}
						});
				}}
			});
	}
}
