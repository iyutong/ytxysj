package com.badlogic.gdx.physics.box2d;

public interface DestructionListener {

}
