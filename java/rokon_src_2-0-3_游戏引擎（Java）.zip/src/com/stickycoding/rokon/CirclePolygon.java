package com.stickycoding.rokon;

public class CirclePolygon extends Polygon {

}
