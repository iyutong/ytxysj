package com.dream.fzb;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import io.reactivex.*;
import io.reactivex.android.schedulers.*;
import io.reactivex.disposables.*;
import io.reactivex.schedulers.*;
import java.io.*;
import java.net.*;
import java.util.*;

import io.reactivex.Observable;
import io.reactivex.Observer;

public class MainActivity extends Activity {
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		final TextView tv=findViewById(R.id.mainTextView1);
		//判断是否使用了VPN
		if (isVpnUsed()) {
			new AlertDialog.Builder(this)
				.setTitle("警告")
				.setMessage("当前为不安全的网络环境，请切换后重试")
				.setPositiveButton("知道了", new DialogInterface.OnClickListener(){

					@Override
					public void onClick(DialogInterface p1, int p2) {
						// TODO: Implement this method
						finish();
					}
				}).show();
		} else {
			Observable.create(new ObservableOnSubscribe<String>(){

					@Override
					public void subscribe(ObservableEmitter<String> p1) throws Exception {
						// TODO: Implement this method
						HttpURLConnection conn=null;
						BufferedReader reader=null;
						URL url=new URL("http://www.huluxia.com");
						conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
						conn.setRequestMethod("GET");
						conn.setConnectTimeout(8000);
						conn.setReadTimeout(8000);
						if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
							InputStream is=conn.getInputStream();
							reader = new BufferedReader(new InputStreamReader(is));
							StringBuilder result=new StringBuilder();
							String line;
							while ((line = reader.readLine()) != null) {
								result.append(line);
							}
							p1.onNext(result.toString());
						}
						if (reader != null) {
							reader.close();
						}
						if (conn != null) {
							conn.disconnect();
						}
						p1.onComplete();
					}
				}).subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(new Observer<String>(){
					private Disposable dis;
					@Override
					public void onSubscribe(Disposable p1) {
						// TODO: Implement this method
						dis = p1;
					}

					@Override
					public void onNext(String p1) {
						// TODO: Implement this method
						tv.setText(p1);
					}

					@Override
					public void onError(Throwable p1) {
						// TODO: Implement this method
						p1.printStackTrace();
					}

					@Override
					public void onComplete() {
						// TODO: Implement this method
						dis.dispose();
					}
				});
		}
	}

	/**
	 * 是否正在使用VPN

	 return true 已开启VPN
	 return false 已关闭VPN
	 */
	public static boolean isVpnUsed() {
		try {
			//获取本机的所有网络接口信息
			Enumeration<NetworkInterface> niList = NetworkInterface.getNetworkInterfaces();
			if (niList != null) {
				for (NetworkInterface intf : Collections.list(niList)) {
					/*
					 isUp 返回网络接口是否已开启并运行
					 getInterfaceAddresses 获取接口地址
					 */
					if (!intf.isUp() || intf.getInterfaceAddresses().size() == 0) {
						continue;//结束当前循环
					}
					/*
					 getName 获取此网络接口的名称
					 */
					if (intf.getName().equals("tun0") || intf.getName().equals("ppp0")) {
						return true; //VPN已开启
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
