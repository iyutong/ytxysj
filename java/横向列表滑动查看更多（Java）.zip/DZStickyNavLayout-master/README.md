# DZStickyNavLayout
仿饿了么横向列表滑动释放查看更多

饿了么效果
![饿了么效果](https://github.com/eatdefecat/DZStickyNavLayout/blob/master/img/1.png)

我们的效果
![我们的效果](https://github.com/eatdefecat/DZStickyNavLayout/blob/master/img/2.png)
