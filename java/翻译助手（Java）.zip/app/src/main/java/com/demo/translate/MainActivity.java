package com.demo.translate;

import android.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.widget.LinearLayout.*;
import android.widget.*;
import com.demo.easytranslate.*;
import android.content.res.*;
import java.util.*;

public class MainActivity extends Activity 
{
	private String type = "";
	
	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			TextView result = (TextView) findViewById(R.id.result);
			result.setText((String) msg.obj);
		}
	};
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		final HashMap map = new HashMap();
		map.put("自动检查",Translate.AUTO);
		
		map.put("中译英",Translate.ZH_CN2EN);
		map.put("中译日",Translate.ZH_CN2JA);
		map.put("中译韩",Translate.ZH_CN2KR);
		map.put("中译法",Translate.ZH_CN2FR);
		map.put("中译俄",Translate.ZH_CN2RU);
		map.put("中译西",Translate.ZH_CN2SP);
		
		map.put("英译中",Translate.EN2ZH_CN);
		map.put("日译中",Translate.JA2ZH_CN);
		map.put("韩译中",Translate.KR2ZH_CN);
		map.put("法译中",Translate.FR2ZH_CN);
		map.put("俄译中",Translate.RU2ZH_CN);
		map.put("西译中",Translate.SP2ZH_CN);
		
		final Spinner language = (Spinner) findViewById(R.id.language);
		
		language.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onNothingSelected(AdapterView<?> p1){
				Toast.makeText(getApplicationContext(),"No thing",0).show();
			}

			@Override
			public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4) {
				String option = (String) language.getItemAtPosition(p3);
				type = (String) map.get(option);
			}
		});
		
		Button btn = (Button) findViewById(R.id.btn);
		
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View p1) {
				EditText translatementText = (EditText) findViewById(R.id.translatemet);
				String translatement = translatementText.getText().toString();
				
				translate(translatement,type);
			}
		});
    }
	
	private void translate(final String translatement,final String type) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				String result = new Translate(translatement).translate(type);
				Message msg = Message.obtain();
				msg.obj = result;
				handler.sendMessage(msg);
			}
		}).start();
	}
}
