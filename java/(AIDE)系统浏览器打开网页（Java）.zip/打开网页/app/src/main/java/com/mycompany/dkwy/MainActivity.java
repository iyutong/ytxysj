package com.mycompany.dkwy;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button button=(Button)findViewById(R.id.mainButton);
		button.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View p)
			{
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("这里写完整的链接")));
			}
		}
		);
    }
}

/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/