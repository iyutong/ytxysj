# ViewDragHelperTest
使用ViewDragHelper实现QQ5.X侧滑酷炫效果以及沉浸式状态实现
# 效果掩饰如下
<img src="https://github.com/jiangqqlmj/ViewDragHelperTest/blob/master/pull_1.gif"/></br>
这边为模拟器的效果,所以沉浸式状态的效果不是特别明显，不过在真机的时候效果还是不错的。</br>
#关于沉浸式状态栏的实现以及ViewDragHelper讲解博客地址如下:
<a href="http://blog.csdn.net/developer_jiangqq/article/details/49446855" target="_blank">【FastDev4Android框架开发】Android实现沉浸式状态栏(六)</a></br>
<a href="http://blog.csdn.net/developer_jiangqq/article/details/50033453" target="_blank">【FastDev4Android框架开发】神器ViewGragHelper完全解析,妈妈再也不担心我自定义ViewGroup滑动View操作啦~(三十三)</a></br>
<a href="http://blog.csdn.net/developer_jiangqq/article/details/50043159" target="_blank">【FastDev4Android框架开发】神器ViewGragHelper完全解析之详解实现QQ5.X侧滑酷炫效果(三十四)</a></br>
