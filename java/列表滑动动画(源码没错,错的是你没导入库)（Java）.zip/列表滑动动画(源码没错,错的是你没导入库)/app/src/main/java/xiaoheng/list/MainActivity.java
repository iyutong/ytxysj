package xiaoheng.list;

import android.os.*;
import android.support.v7.app.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.widget.AbsListView.*;
import java.util.*;

public class MainActivity extends AppCompatActivity 
{
	private int aaaa,bbbb,cccc,eeee,hhhh;
	
	ArrayList <HashMap<String,Object>>list=new ArrayList<HashMap<String,Object>>();
	
	//int tupian[]={R.raw.i,R.raw.b,R.raw.r,R.raw.t,R.raw.l,R.raw.e};
	String b[] ={"小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","000","....0,7580555","55585225555222233332225888888000/storage/emulate😏😏😉d/0/.aide/android_m2repository_r15.zip/m2repository/000小白工程师","getWindow()","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","000","....0,7580555","55585225555222233332225888888000/storage/emulate😏😏😉d/0/.aide/android_m2repository_r15.zip/m2repository/000小白工程师","getWindow(|"};
	String c[] ={"小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","000","....0,7580555","55585225555222233332225888888000/storage/emulate😏😏😉d/0/.aide/android_m2repository_r15.zip/m2repository/000小白工程师","getWindow()","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","小亨","小亨","小亨","小亨","小亨","小亨","qqqq","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","qqqq","522","2222","3333","33222","3355","58877","恩没看看","啊啦啦啦啦","000","😝😳😁😁😁😁😁|","000","....0,7580555","55585225555222233332225888888000/storage/emulate😏😏😉d/0/.aide/android_m2repository_r15.zip/m2repository/000小白工程师","getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)this.requestWindowFeature( Window.FEATURE_NO_TITLE);","",""};
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		for(int i=0;i<b.length;i++)
		{
			HashMap<String,Object>map =new HashMap<String,Object>();
			
			map.put("b",b[i]);
			
			map.put("a",c[i].substring(0,1));
			
			map.put("c",c[i]);
			
			list.add(map);
			
			}
		
		
		ListView ww=(ListView)findViewById(R.id.mainListView);
		
		ww.setAdapter(new SimpleAdapter(this,list,R.layout.xiaohenglist_two,new String[]{"a","b","c"},new int[]{R.id.xiaohenglistTextView1,R.id.xiaohenglistTextView2,R.id.xiaohenglistTextView3}));
		ww.setOnScrollListener(new OnScrollListener()
		{
				@Override
				public void onScrollStateChanged(AbsListView p1, int p2)
				{
					// 待办事项：实现这个方法
				}

				@Override
				public void onScroll(AbsListView p1, int p2, int p3, int p4)
				{
					// 待办事项：实现这个方法
					
					boolean shouldAnimate = (aaaa != -1) && (bbbb != -1);
					eeee = p2 + p3-1;
					if(shouldAnimate)
					{
						hhhh =0;
						while(p2 + hhhh < aaaa)
						{
							//列表向上滑动事件
							View animateView = p1.getChildAt(hhhh);//获取item对应的view
							doAnimate(animateView, false);
							hhhh ++;
						}

						cccc = 0;
						while(eeee - cccc > bbbb)
						{
							//列表向下滑动事件
							View animateView = p1.getChildAt(eeee - cccc - p2);
							doAnimate(animateView, true);
							cccc ++;
						}
					}

					aaaa = p2;
					bbbb = eeee;
					
				}
			});
			
    }
	
	private void doAnimate(View view, boolean scrollDown)
	{
		Animation b=AnimationUtils.loadAnimation(MainActivity. this,R.anim.push_left_in);
		view.startAnimation(b);
	}
	
}
