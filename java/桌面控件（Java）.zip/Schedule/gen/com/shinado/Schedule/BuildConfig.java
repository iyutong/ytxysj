/** Automatically generated file. DO NOT MODIFY */
package com.shinado.Schedule;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}