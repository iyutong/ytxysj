package com.shinado.Schedule;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class LastPage extends Activity{
 
	private Button lastBt;
	@Override 
 	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);  
	 	setContentView(R.layout.lastlayout);
	 	lastBt = (Button) findViewById(R.id.lastdone);
	 	lastBt.setOnClickListener(new Button.OnClickListener()
	 	{
 			public void onClick(View arg0) {
				
				LastPage.this.finish();
	 		}
	 	});
	}
}
