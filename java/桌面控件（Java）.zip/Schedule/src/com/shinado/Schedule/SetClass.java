package com.shinado.Schedule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class SetClass extends Activity{

	//ListView������
 	private List<Map<String, Object>> list;
 	private SimpleAdapter adapter ;
 	private ListView detailView;
 	
 	private String theclass;//ĳ�ڿεı�ʶ�������޸����ݿ⣬��"1-2"
 	private String theweek;//���ڵı�ʶ�������޸����ݿ⣬��"Mon"
 	private String className = "";//����
 	private String classPlace = "";//�Ͽεص�
 	private int weekTime = 0;//�Ͽε��ܴ�
 	
 	private ScheduleDAO sd;
 	
 	@Override 
 	public void onCreate(Bundle savedInstanceState) {  
 		super.onCreate(savedInstanceState);  
	 	setContentView(R.layout.setclasslayout);
	 	detailView = (ListView) findViewById(R.id.listview3);
	 	Button doneBt = (Button) findViewById(R.id.donebutton);
	 	Button cancelBt = (Button) findViewById(R.id.cancelbutton);
	 	
	 	setTitle("�趨����");

	 	/*
	 	 * ��ȡ��SetDay�����Ĳ�����������ת��
	 	 */
		Intent intent = this.getIntent();
		Bundle bundle = intent.getExtras();
		//ת����ʱ��ֵ����0 -> "1-2"
		theclass = TipUtil.getTheClass(bundle.getInt("theclass"));
		int w = bundle.getInt("theweek");
		//ת�����ڵ�ֵ����0 -> "Mon"
		theweek = TipUtil.getTheWeek(w);
			
		String information = "";
		sd = new ScheduleDAO(this);
		
		/*
		 * select * from Schedule where Class = theclass
		 * ����ClassΪtheclass��ÿһ��
		 * ��theclassΪ"1-2"ʱ���ͷ���ÿһ���1-2�ڿε��Ͽ���Ϣ
		 */
		Cursor c = sd.getValue("Class", theclass);
		if(c.moveToNext())
		{
			//��ȡĳһ���ĳ�ڿε��Ͽ���Ϣ
			information = c.getString(w);
		}
			
		list = new ArrayList<Map<String, Object>>(); 
		adapter = new SimpleAdapter(this,getData(information),R.layout.setclasslist,  
				new String[]{"tip","editcontent"},  
				new int[]{R.id.tip,R.id.editcontent}); 
		detailView.setAdapter(adapter);
	 	
	 	MyListener ml = new MyListener();
	 	detailView.setOnItemClickListener(ml);
	 	
	 	MyButtonListener bl = new MyButtonListener();
	 	doneBt.setOnClickListener(bl);
	 	cancelBt.setOnClickListener(bl);
 	}
 	@Override 
 	public void onDestroy()
 	{
 		super.onDestroy();
 		sd.closeDB();
 	}
 	
 	private List<Map<String, Object>> getData(String information) {   
 		
 		SClass sc = SClass.getInformation(information);

 	 	className = sc.getTheclass();
 	 	classPlace = sc.getTheplace();
 	 	weekTime = sc.getWeekTime();
 	 	
 		Map<String, Object> map = new HashMap<String, Object>();  
 		map.put("tip", "����");  
 		map.put("editcontent", "  "+className);  
 		list.add(map);  
 		
 		map = new HashMap<String, Object>();  
 		map.put("tip", "�ص�");  
 		map.put("editcontent", "  "+classPlace);  
 		list.add(map);  
 		
 		map = new HashMap<String, Object>(); 
 		map.put("tip", "�ܴ�");  
 		map.put("editcontent", "  "+SClass.getWeek(weekTime));  
 		list.add(map);  
 		return list;  
 	}
 	class MyListener implements AdapterView.OnItemClickListener
 	{
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
 			switch(position)
 			{
 			case 0:
 				showClassNameDialog(position);
 				break;
 			case 1:
 				showClassPlaceDialog(position);
 				break;
 			case 2:
 				showWeekPickerDialog(position); 
 				break;
 			}
 		}
 	}
 	private void showClassNameDialog(final int position)
 	{
		final EditText editText = new EditText(SetClass.this);
 		new AlertDialog.Builder(SetClass.this)
			.setTitle("���������")
			.setIcon(android.R.drawable.ic_dialog_info)
			.setView(editText)
			.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
	            
	            public void onClick(DialogInterface dialog, int which) {
	 				className = "  "+editText.getText().toString();
	 				updateListView(new String[]{"tip", "editcontent"}, new String[]{"����", className}, position);
	            }
	        })
 		.setNegativeButton("ȡ��", null)
 		.show();
 	}
 	private void showClassPlaceDialog(final int position)
 	{
		final EditText editText = new EditText(SetClass.this);
 		new AlertDialog.Builder(SetClass.this)
			.setTitle("������ص�")
			.setIcon(android.R.drawable.ic_dialog_info)
			.setView(editText)
			.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int which) {
	 				classPlace = "  "+editText.getText().toString();
	 				//�����б�����ʾ
	 				updateListView(new String[]{"tip", "editcontent"}, new String[]{"�ص�", classPlace}, position);
	            }
	        })
		 	.setNegativeButton("ȡ��", null)
		 	.show();
 	}
 	private void showWeekPickerDialog(final int position)
 	{
 		new AlertDialog.Builder(SetClass.this)  
			.setTitle("��ѡ���ܴ�")  
			.setSingleChoiceItems(new String[] {"����","˫��","ȫ��","ѡ��"}, 0, 
				new DialogInterface.OnClickListener() {  
					public void onClick(DialogInterface dialog, int which) {  
						String value = "";
						switch(which)
						{
						case 0:
							value = "  ����";
							weekTime = 1;
							break;
						case 1:
							value = "  ˫��";
							weekTime = 2;
							break;
						case 2:
							value = "  ȫ��";
							weekTime = 0;
							break;
						case 3:
							//ѡ��ʼ�ܴκͽ����ܴ�
							showWeekDetailPickerDialog(position);
							break;
						}
						updateListView(new String[]{"tip", "editcontent"}, new String[]{"�ܴ�", value}, position);
						dialog.dismiss();  
					}  
				}  
			)  
			.setPositiveButton("ȷ��", null)    
			.setNegativeButton("ȡ��", null)  
			.show();
 	}
 	private void showWeekDetailPickerDialog(final int position)
 	{
 	    final HashSet<Integer> choice = new HashSet<Integer>();
 		final String[] values = {"1","2","3","4","5","6","7","8","9","10","11","12",
				"13","14","15","16","17","18","19","20","21","22","23","24","25"};
 		new AlertDialog.Builder(SetClass.this)
		.setTitle("��ѡ��ѡ��ʼ�ܴκͽ����ܴ�")
		.setMultiChoiceItems(values, null, new OnMultiChoiceClickListener(){
			public void onClick(DialogInterface dialog, int which, boolean isChecked) {
				if(isChecked)
				{
					choice.add(which+1);
				}
				else
				{
					choice.remove(which+1);
				}
			}
		})
		.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int which) {
	            	if(choice.size() == 2)
	            	{
	            		//ѡ��2��
	            		Object object[] = choice.toArray();
	            		//������ʾ
	            		String value = Math.min((Integer)object[0],(Integer)object[1])+"-"+Math.max((Integer)object[0],(Integer)object[1]);
						updateListView(new String[]{"tip", "editcontent"}, new String[]{"�ܴ�", value}, position);
						//���ڴ������ݿ�
						weekTime = Math.min((Integer)object[0],(Integer)object[1])*1000+Math.max((Integer)object[0],(Integer)object[1]);
						dialog.dismiss();  
	            	}
	            	else
	            	{
	            		new AlertDialog.Builder(SetClass.this)
						.setTitle("ע��")
						.setMessage("��ѡ������ѡ��")
						.setPositiveButton("ȷ��",null)
						.show();
	            	}
	            	choice.clear();
	            }
	        })
		.setNegativeButton("ȡ��", null).show();
 	}
 	class MyButtonListener implements Button.OnClickListener
 	{
 		public void onClick(View arg0) {
 			int source = arg0.getId();
 			switch (source)
 			{
 			case R.id.donebutton:
 				//����ȷ�����������ݿ��б�����Ϣ
 				String message = SClass.getInformationBack(new SClass(className,classPlace,weekTime));
 				sd.updateValue(theweek, theclass, message);
 				
 				//������Ϣ��SetDay
 				Intent intent = SetClass.this.getIntent();
 				intent.putExtra("information", message);
 				SetClass.this.setResult(1, intent);
 		 		intent.setClass(SetClass.this,SetDay.class);
 				SetClass.this.finish();
 				break;
 			case R.id.cancelbutton:
 				SetClass.this.finish();
 				break;
 			}
 		}
 	}

 	private void updateListView(String[] key, String[] value, int position)
 	{
		Map<String, Object> map = new HashMap<String, Object>();  
		for(int i=0; i<key.length; i++)
		{
			map.put(key[i], value[i]);
		}
		list.set(position, map);
		adapter.notifyDataSetChanged();
 	}
}
