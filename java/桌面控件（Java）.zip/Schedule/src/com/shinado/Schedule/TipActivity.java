package com.shinado.Schedule;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class TipActivity extends Activity{

	private TextView tipnameTv;
	private TextView tipplaceTv;
	private TextView tiptimeTv;
	private Button doneBt;
 	@Override 
 	public void onCreate(Bundle savedInstanceState) {  
 		super.onCreate(savedInstanceState);  
	 	setContentView(R.layout.tiplayout);
	 	
	 	tipnameTv = (TextView) findViewById(R.id.tipname);
	 	tipplaceTv = (TextView) findViewById(R.id.tipplace);
	 	tiptimeTv = (TextView) findViewById(R.id.tiptime);
	 	doneBt = (Button) findViewById(R.id.tipdone);
	 	
	 	Intent intent = this.getIntent();
		
		Bundle bundle = intent.getExtras();
		tipnameTv.setText(bundle.getString("name"));
		tipplaceTv.setText(bundle.getString("place"));
		tiptimeTv.setText(bundle.getString("time"));
		
		doneBt.setOnClickListener(new OnClickListener()
		{
			public void onClick(View arg0) {
				TipActivity.this.finish();
			}
		});
 	}
}
