package com.shinado.Schedule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.GestureDetector.OnGestureListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class SetDay extends Activity implements OnTouchListener,OnGestureListener{

	private List<Map<String, Object>> list;
 	private SimpleAdapter adapter ;
 	private TextView tiptext;//��ʾ����Ϊ���ڼ�
 	
	private int week = 0;//���ڼ�
	private String weektip = "";//��������������ʾ
	private ScheduleDAO sd;
	
	private int theclass = 0;
	
	private GestureDetector mGestureDetector;//����ʶ��
	
	public void onCreate(Bundle savedInstanceState) { 

	 	super.onCreate(savedInstanceState);  
	 	setContentView(R.layout.setdaylayout);
	 	
	 	Toast.makeText(SetDay.this, "���һ�����������", Toast.LENGTH_SHORT).show();
	 	
	 	ListView timeView = (ListView) findViewById(R.id.listview);
	 	Button returnBt = (Button) findViewById(R.id.returnbutton);
	 	Button doneBt = (Button) findViewById(R.id.finishbutton);
	 	tiptext = (TextView) findViewById(R.id.tiptext);

	 	sd = new ScheduleDAO(this);
 		list = new ArrayList<Map<String, Object>>();
 		
 		//��ȡ����һ�Ŀ�
		getData("Mon"); 
		
	 	adapter = new SimpleAdapter(this,list,R.layout.setdaylist,  
	 			new String[]{"tip","classname","classplace"},  
	 			new int[]{R.id.tip,R.id.classname,R.id.classplace});  
	 	timeView.setAdapter(adapter);
	 	
	 	week = 1;
	 	weektip = "����һ";
	 	
	 	setTitle("�趨�α�");
	 	tiptext.setText(weektip);
	 	
	 	MyListener ml = new MyListener();
	 	timeView.setOnItemClickListener(ml);
	 	mGestureDetector = new GestureDetector(this);
	 	timeView.setOnTouchListener(this);
	 	MyButtonListener bl = new MyButtonListener();
	 	returnBt.setOnClickListener(bl);
	 	doneBt.setOnClickListener(bl);
 	}
 	public void onDestroy()
 	{
 		super.onDestroy();
 		sd.closeDB();
 	}
 	
 	private void getData(String day) {   

		list.clear();
 		ArrayList<String> classlist = new ArrayList<String>();
 		Cursor c = sd.getWeekValue(day);
		while(c.moveToNext())
		{
			classlist.add(c.getString(0));
		}
 		Map<String, Object> map;
 		SClass classInfo;

 		for(int i=0; i<6; i++)
 		{
 	 		map = new HashMap<String, Object>();
 	 		classInfo = SClass.getInformation(classlist.get(i));
 	 		map.put("tip", TipUtil.getTipWithFormate(i));  
 	 		map.put("classname", classInfo.getTheclass());  
 	 		map.put("classplace", classInfo.getTheplace());  
 	 		list.add(map); 
 		} 
 		classlist.clear();
 	} 
	
 	class MyListener implements AdapterView.OnItemClickListener
 	{
		public void onItemClick(AdapterView<?> arg0, View arg1, final int position,
				long arg3) {
			// TODO Auto-generated method stub
 			
			//��ת��SetClass������������
 			Bundle bundle = new Bundle();
 			//�û������λ�ã���Ӧ��һ���е�ĳ�ڿ�
 			bundle.putInt("theclass", position);
 			theclass = position;
 			//���ڼ�
 			bundle.putInt("theweek", week);
 			
 			Intent intent = new Intent();
 			intent.setClass(SetDay.this,SetClass.class);
 			
 			intent.putExtras(bundle);
 			
 			//�ȴ����ݷ���
 			startActivityForResult(intent,0);
 		}
 	}
 	protected void onActivityResult(int requestCode,int resultCode,Intent data)
 	{
 		switch(resultCode)
 		{
 		case 1:
 			//����ListView����ʾ��Ϣ
 			Bundle bundle = data.getExtras();
 			String information = bundle.getString("information");
 			Map<String, Object> map = new HashMap<String, Object>();
 			
 			String tip = TipUtil.getTipWithFormate(theclass);
 	 	 	map.put("tip", tip);  
 	 	 	
 	 	 	SClass classInfo = SClass.getInformation(information);
 	 	 	
 	 	 	map.put("classname", classInfo.getTheclass());  
 	 	 	map.put("classplace", classInfo.getTheplace());  
			list.set(theclass, map);
		 	adapter.notifyDataSetChanged();
 		}
 	}

 	class MyButtonListener implements Button.OnClickListener
 	{
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			int source = arg0.getId();
			Intent intent;
			switch (source)
			{
			case R.id.returnbutton:
				//����
 				intent = new Intent();
 				intent.setClass(SetDay.this, SetTime.class);
 				startActivity(intent);
 				SetDay.this.finish();
				break;
			case R.id.finishbutton:
				//��һ��
				intent = new Intent();
 				intent.setClass(SetDay.this, LastPage.class);
 				startActivity(intent);
				SetDay.this.finish();
				break;
			}
		}
	}
	public void setWeek(int week)
	{
		this.week = week;
	 	String day = "";
		switch(week)
		{
		case 0:
			this.week = 6;
			weektip = "������";
			day = "Sar";
			break;
		case 1:
			weektip = "����һ";
			day = "Mon";
			break;
		case 2:
			weektip = "���ڶ�";
			day = "Tue";
			break;
		case 3:
			weektip = "������";
			day = "Wed";
			break;
		case 4:
			weektip = "������";
			day = "Thu";
			break;
		case 5:
			weektip = "������";
			day = "Fri";
			break;
		case 6:
			weektip = "������";
			day = "Sar";
			break;
		case 7:
			this.week = 1;
			weektip = "����һ";
			day = "Mon";
			break;
		}
		getData(day); 
		for(int i=0; i<list.size(); i++)
		{
			Log.e("data", list.get(i).get("tip").toString());
		}
 		adapter.notifyDataSetChanged();
	}
 	/*
 	 * e1 ǰһ��MotionEvent
 	 * e2 ��һ��MotionEvent
 	 * velocityX ��ָ��x�᷽���ϵ��ƶ��ٶȣ���λ ����/�룩
 	 * velocityX ��ָ��y�᷽���ϵ��ƶ��ٶȣ���λ ����/�룩
 	 */
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,float velocityY) 
	{  
		 if (e1.getX() - e2.getX() > 100 && Math.abs(velocityX) > 200) {  
			 	setWeek(week + 1);
			 	tiptext.setText(weektip);
		 } 
		 else if (e2.getX() - e1.getX() > 100 && Math.abs(velocityX) > 200) {  
				setWeek(week - 1);
				tiptext.setText(weektip);
		 } 
		 return false;
	}

	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		return mGestureDetector.onTouchEvent(event); 

	}
}
