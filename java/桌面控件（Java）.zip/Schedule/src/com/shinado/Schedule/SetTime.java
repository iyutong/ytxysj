package com.shinado.Schedule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TimePicker;
import android.widget.Button;

public class SetTime extends Activity {  
 
 	protected List<Map<String, Object>> list;//���ListView���ݵ�List
 	protected SimpleAdapter adapter;//ListView������
 	protected ListView timeView;
 	private ArrayList<String> timelist;//�Ͽ�ʱ��List
 	private String data;//��ѧ����
 	private String tiptime;//����ʱ��
 	private String theme;//����
 	private ScheduleDAO sd;//���ݿ����
 	
 	@Override 
 	public void onCreate(Bundle savedInstanceState) {  
 		super.onCreate(savedInstanceState);  
	 	setContentView(R.layout.settimelayout);
	 	setTitle("�趨ʱ��");
	    
	 	timeView = (ListView) findViewById(R.id.listview);
	 	Button nextBt = (Button) findViewById(R.id.nextbutton);
	 	
 		list = new ArrayList<Map<String, Object>>(); 
 		sd= new ScheduleDAO(this);	
 		
 		//��ʼ������
 		iniDatas();
 
	 	//����ListView
 		adapter = new SimpleAdapter(this,getData(),R.layout.settimelist,  
	 			new String[]{"tip","time"},  
	 			new int[]{R.id.tip,R.id.time});  
	 	timeView.setAdapter(adapter);
	 	
	 	//�����¼�����
	 	MyListener ml = new MyListener();
	 	timeView.setOnItemClickListener(ml);
	 	MyButtonListener bl = new MyButtonListener();
	 	nextBt.setOnClickListener(bl);
 	}
 	public void onDestroy()
 	{
 		super.onDestroy();
 		sd.closeDB();
 	}
 	/*
 	 * ��ȡʱ�䡢��ѧ���ڡ����⡢����ʱ��
 	 */
 	private void iniDatas()
 	{
 		Cursor c = sd.getWeekValue("Time");
 		timelist = new ArrayList<String>();
 		//��ȡ�Ͽ�ʱ��
 		while(c.moveToNext())
 		{
 			timelist.add(c.getString(0));
 		}
 		Cursor cc = sd.getWeekValue("Data");
 		if(cc.moveToNext())
 		{
 			//��ȡ��ѧ����
 			data = cc.getString(0);
 			//��ȡ����
 			if(cc.moveToNext()){
 				switch(Integer.parseInt(cc.getString(0)))
 				{
 				case 0:
 					theme = "����";
 					break;
 				case 1:
 					theme = "dota";
 					break;
 				}
 				//��ȡ����ʱ��
 	 			if(cc.moveToNext())
 	 			{
 	 				tiptime = cc.getString(0);
 	 			}
 			}
 		}
 	}
 	/*
 	 * ��ȡListView�ĳ�ʼ����
 	 */
 	protected List<Map<String, Object>> getData() {   
 		
 		Map<String, Object> map;
 		for(int i=0; i<6 ;i++)
 		{
 	 		map = new HashMap<String, Object>();  
 	 		map.put("tip", TipUtil.getTipWithFormate(i));  
 	 		map.put("time", timelist.get(i));  
 	 		list.add(map);  
 		}
 		
 		map = new HashMap<String, Object>();  
 		map.put("tip", "��ѧ����");  
 		map.put("time", data);  
 		list.add(map);  
 		map = new HashMap<String, Object>();  
 		map.put("tip", "����ʱ��");  
 		map.put("time", tiptime);  
 		list.add(map);  
 		map = new HashMap<String, Object>();  
 		map.put("tip", "�������");  
 		map.put("time", theme);  
 		list.add(map);  
 		
 		return list;  
 	} 
 	class MyButtonListener implements Button.OnClickListener
 	{
 		public void onClick(View arg0) {
 			// TODO Auto-generated method stub
 			int source = arg0.getId();
 			switch (source)
 			{
 			case R.id.nextbutton:
 				Intent intent = new Intent();
 				intent.setClass(SetTime.this, SetDay.class);
 				startActivity(intent);
 				SetTime.this.finish();
 				break;
 			}
 		}
 	}
 	class MyListener implements AdapterView.OnItemClickListener
 	{
		public void onItemClick(AdapterView<?> arg0, View arg1, final int position,
				long arg3) {
			// TODO Auto-generated method stub
			if(position <= 5)
	 		{
				setTime(position);
	 		}
	 		else if(position == 6)
	 		{
	 			setDate(position);
	 		}
	 		else if(position == 7)
	 		{
	 			setTipTime(position);
	 		}
	 		else if(position == 8)
	 		{
	 			setTheTheme(position);
	 		}
		}
 	}
 	/*
 	 * �����Ͽ�ʱ��
 	 */
 	private void setTime(final int position)
 	{
 		//���캯��ΪTimePickerDialog(Context context, TimePickerDialog.OnTimeSetListener listener, int hour, int minutes, boolean is24HourView)
 		new TimePickerDialog(SetTime.this, new TimePickerDialog.OnTimeSetListener() {
			//���ú�ʱ�䰴��"ȷ��"��ť
			public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
				
				//���ó�ʼ��
				String thetime = STime.getTimeBack(new STime(hourOfDay,minute));
		 		String tip = TipUtil.getTipWithFormate(position);
			 	updateListView(new String[]{"tip", "time"}, new String[]{tip, thetime}, position);
			 	
				String theclass = TipUtil.getTheClass(position);
				sd.updateValue("Time", theclass, thetime);
				//����timelist
				timelist.set(position, thetime);
			}
		}, STime.getTime(timelist.get(position)).getHour(), STime.getTime(timelist.get(position)).getMinutes(), true).show();
 	}
 	private void setDate(final int position)
 	{
 		//���캯��ΪDatePickerDialog(Context context, DatePickerDialog.OnDateSetListener listener, int year, int month, int day)
 		new DatePickerDialog(SetTime.this,new DatePickerDialog.OnDateSetListener() {
			
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {

				String thedata = SDate.getDateBack(new SDate(year,monthOfYear+1,dayOfMonth));
			 	updateListView(new String[]{"tip", "time"}, new String[]{"��ѧ����", thedata}, position);
			 	
				sd.updateValue("Data", "1-2", thedata);
				data = thedata;
			}
		},SDate.getDate(data).getYear(),SDate.getDate(data).getMonth(), SDate.getDate(data).getDay()).show();
 	}
 	
 	private void setTipTime(final int position)
 	{
 		new AlertDialog.Builder(SetTime.this)  
			.setTitle("��ѡ������ʱ��")  
			.setSingleChoiceItems(new String[] {"5����","10����","15����","20����","������"}, 0, 
				new DialogInterface.OnClickListener() {  
					public void onClick(DialogInterface dialog, int which) {  
						String valueTip = "";
						switch(which)
						{
						case 0:
						case 1:
						case 2:
						case 3:
							valueTip = (which+1)*5+"";
							break;
						case 4:
							valueTip = "������";
							break;
						}
					 	updateListView(new String[]{"tip", "time"}, new String[]{"����ʱ��", valueTip}, position);
						
						sd.updateValue("Data", "5-6", valueTip);
						dialog.dismiss();  
					}  
				}  
			) 
			.show(); 
 	}
 	private void setTheTheme(final int position)
 	{
 		new AlertDialog.Builder(SetTime.this)  
		.setTitle("��ѡ��������")  
		.setSingleChoiceItems(new String[] {"����","dota"}, 0, 
			new DialogInterface.OnClickListener() {  
				public void onClick(DialogInterface dialog, int which) {  
					String valueTip = "";
					switch(which)
					{
					case 0:
						valueTip = "����";
						break;
					case 1:
						valueTip = "dota";
						break;
					}
					updateListView(new String[]{"tip", "time"}, new String[]{"������", valueTip}, position);
		 		 		
					sd.updateValue("Data", "3-4", which+"");
					dialog.dismiss();  
				}  
			}  
		)  
		.show(); 
 	}
 	private void updateListView(String[] key, String[] value, int position)
 	{
		Map<String, Object> map = new HashMap<String, Object>();  
		for(int i=0; i<key.length; i++)
		{
			map.put(key[i], value[i]);
		}
		list.set(position, map);
		adapter.notifyDataSetChanged();
 	}
} 
