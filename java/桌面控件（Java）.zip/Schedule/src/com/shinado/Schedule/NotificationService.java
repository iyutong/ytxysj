package com.shinado.Schedule;

import java.util.Timer;
import java.util.TimerTask;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.os.IBinder;
import android.util.Log;

public class NotificationService extends Service{

	private NotificationManager myNotiManager;
	private int tipTime;
	private String classTime;
	
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	@Override
    public void onCreate() {
        //���д���
		Log.e("text","text");
	    myNotiManager=
	        (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new MyTime(R.drawable.schedule), 0, 60000);//1 mins 
        super.onCreate();
    }
	public class MyTime extends TimerTask{

    	private int iconId;
    	
    	public MyTime(int iconId){
    		this.iconId = iconId;
    	}
    	@Override 
    	public void run() {
    		//���n���Ӻ��пΣ��򷵻ظýڿε���Ϣ
    		SClass sclass = getNextClass();
    		try {
				if(sclass != null)
				{
					setNotiType(iconId, sclass);
				}
			} catch (Exception e) {
				Log.e("error1", e.getMessage());
			}
    	}
    }
	private void setNotiType(int iconId,SClass sclass)
	{
	    /* �����µ�Intent����Ϊ���Notification������ʱ��
	     * �����е�Activity */ 
	    Intent notifyIntent=new Intent(this,TipActivity.class);  
	    notifyIntent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK);

		Log.e("sclass", sclass.getTheclass());
		Log.e("place", sclass.getTheplace());
		Log.e("classtime", classTime+"");
	    notifyIntent.putExtra("name", sclass.getTheclass());
	    notifyIntent.putExtra("place", sclass.getTheplace());
	    notifyIntent.putExtra("time", classTime);
	    
	    /* ����PendingIntent��Ϊ���õ������е�Activity */ 
	    PendingIntent appIntent=PendingIntent.getActivity(NotificationService.this,
	                            0,notifyIntent,0); 
	    
	    /* ����Notication����������ز��� */ 
	    Notification noti=new Notification();
	    /* ����statusbar��ʾ��icon */
	    noti.icon=iconId;
	    /* ����statusbar��ʾ��������Ϣ */
	    noti.tickerText=sclass.getTheclass();
	    /* ����notification����ʱͬʱ����Ĭ������ */
	    noti.defaults=Notification.DEFAULT_SOUND;
	    noti.flags = Notification.FLAG_AUTO_CANCEL;
	    /* ����Notification�������Ĳ��� */
	    noti.setLatestEventInfo(NotificationService.this,"�½ڿν���"+tipTime+"���Ӻ�ʼ",
	    		sclass.getTheclass(),appIntent);
	    /* �ͳ�Notification */
	    myNotiManager.notify(0,noti);
	}
	private SClass getNextClass()
	{
		Log.e("aa","alive");
		ScheduleDAO schedule = new ScheduleDAO(getBaseContext());
		Cursor ccursor = schedule.getWeekValue(SClass.getWeekOfToday());
		Cursor tcursor = schedule.getWeekValue("Time");
		Cursor dcursor = schedule.getWeekValue("Data");
		TimeUtil timeManage = new TimeUtil(ccursor,tcursor);
		String startWeek = "";
		//��ȡ����ʱ��
		if(dcursor.moveToNext())
		{ 
			startWeek = dcursor.getString(0);
			if(dcursor.move(2))
			{
				tipTime = Integer.parseInt(dcursor.getString(0));
				if(tipTime  == 0)
				{
					return null;
				}
			}
		} 
		//��ȡ�½ڿε��Ͽ���Ϣ
		SClass sclass = SClass.getInformation(timeManage.getNextClassPrecisely(tipTime));
		if(sclass.getTheclass().equals(""))
		{
			return null;
		}
		//�����Ƿ��п�
		boolean isClass = SClass.ifClass(sclass.getWeekTime(),timeManage.getWeekOfToday(startWeek));
		if(isClass)
		{
			classTime = timeManage.getTheTime();
			schedule.closeDB();
			return sclass;
		}
		else
		{
			schedule.closeDB();
			return null;
		}
	}
}
