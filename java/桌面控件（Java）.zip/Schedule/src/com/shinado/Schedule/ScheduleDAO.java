package com.shinado.Schedule;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ScheduleDAO extends SQLiteOpenHelper{
	
	private SQLiteDatabase db;
	public ScheduleDAO(Context context)
	{
		super(context,"database_db",null,1);
	}
	private String insertValue(SQLiteDatabase db)
	{
		String aaa="";
		try
		{
			String sql = "insert into Schedule values ('1-2',' ',' ',' ',' ',' ',' ',' ','08:00','2011.8.29')";
			db.execSQL(sql);
			sql = "insert into Schedule values ('3-4',' ',' ',' ',' ',' ',' ',' ','10:00','0')";
			db.execSQL(sql);
			sql = "insert into Schedule values ('5-6',' ',' ',' ',' ',' ',' ',' ','13:20','5')";
			db.execSQL(sql);
			sql = "insert into Schedule values ('7-8',' ',' ',' ',' ',' ',' ',' ','15:20',' ')";
			db.execSQL(sql);
			sql = "insert into Schedule values ('9-10',' ',' ',' ',' ',' ',' ',' ','18:00',' ')";
			db.execSQL(sql);
			sql = "insert into Schedule values ('11-12',' ',' ',' ',' ',' ',' ',' ','20:00',' ')";
			db.execSQL(sql);
		}
		catch(Exception e)
		{
			aaa=e.getMessage();
		}
		return aaa;
	}
	public Cursor getValue(String key,String value)
	{
		db = this.getReadableDatabase();
		Cursor c = db.query("Schedule",new String[]{"Class","Mon","Tue","Wed" ,"Thu", "Fri","Sar","Sun","Time","Data"},key+" = ?",new String[]{value},null,null,   
                null); 
		//select * from Schedule where key = value
		return c;
	}
	public Cursor getWeekValue(String week)
	{
		db = this.getReadableDatabase();
		Cursor c = db.query("Schedule",new String[]{week},null,null,null,null,null); 
		return c;
	}
	/*
	 * set week = value where Class = theclass
	 */
	public String updateValue(String week,String theclass,String value)
	{
		String aaa="";
		try
		{
			db = this.getWritableDatabase();
			String sql = "UPDATE Schedule SET "+week+" = '"+value+"' WHERE Class = '"+ theclass + "'";
			db.execSQL(sql);
		}
		catch (Exception e)
		{
			aaa=e.getMessage();
		}
		return aaa;
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		Log.e("onCreate", "create");
		String sql = "CREATE TABLE IF NOT EXISTS Schedule(Class text,Mon text,Tue text,Wed text,Thu text, Fri text,Sar text,Sun text,Time text,Data text);";   
        db.execSQL(sql);
		insertValue(db);
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		String sql = "DROP TABLE IF EXISTS Schedule";
		db.execSQL(sql);
		onCreate(db);
	}
	public void closeDB()
	{
		if(db != null)
		{
			db.close();
		}
	}
}
