package com.s1243808733.signatureinfo.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Util {
    
    public static String formatTime(long time){
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time); 
        return cal.getTime().toLocaleString();
    }

    public static String formatTime(long time, String format){
        return new SimpleDateFormat(format).format(time);
    }
    
    
}
