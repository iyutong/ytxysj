package com.s1243808733.signatureinfo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import com.s1243808733.signatureinfo.data.AppInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SearchApplicationAdapter extends ApplicationAdapter {

    public static final int STATUS_SEARCHING = 1;

    public static final int STATUS_FINISH = 2;

    private DataBackup mDataBackup;

    private boolean searchMode;

    private SearchTask mSearchTask;

    private Map<AppInfo,TextHighlights> mAppInfoHighlightMaps = new HashMap<>();

    public SearchApplicationAdapter(Context context) {
        super(context);
    }

    public void search(String content) {
        if (mSearchTask != null) {
            if (mSearchTask.status != STATUS_FINISH) {
                mSearchTask.cancel();
            }
        }
        mSearchTask = new SearchTask();
        mSearchTask.execute(content);
    }

    public void setSearchMode(boolean searchMode) {
        if (this.searchMode == searchMode)return;
        this.searchMode = searchMode;
        if (searchMode) {
            backupData: {
                mDataBackup = new DataBackup();
                mDataBackup.appInfos = getAppInfos();
            }
            List<AppInfo> appInfos = new ArrayList<>();
            setAppInfos(appInfos);
            notifyDataSetInvalidated();
        } else {
            List<AppInfo> appInfos = mDataBackup.appInfos;
            setAppInfos(appInfos);
            mAppInfoHighlightMaps.clear();
            notifyDataSetChanged();
        }
    }

    public boolean isSearchMode() {
        return searchMode;
    }

    @Override
    protected CharSequence getMainTitle(AppInfo appInfo, int position) {
        CharSequence text=super.getMainTitle(appInfo, position);
        if (isSearchMode() && mAppInfoHighlightMaps.containsKey(appInfo)) {
            return makeHighlightText(text, mAppInfoHighlightMaps.get(appInfo).title);
        }
        return text;
    }

    @Override
    protected CharSequence getMainSubTitle(AppInfo appInfo, int position) {
        CharSequence text=super.getMainSubTitle(appInfo, position);
        if (isSearchMode() && mAppInfoHighlightMaps.containsKey(appInfo)) {
            return makeHighlightText(text, mAppInfoHighlightMaps.get(appInfo).subtitle);
        }
        return text;
    }

    private CharSequence makeHighlightText(CharSequence text, TextHighlight textHighlight) {
        if (textHighlight == null) return text;
        return makeHighlightText(text, textHighlight.start, textHighlight.end);
    } 

    private CharSequence makeHighlightText(CharSequence text, int start, int end) {
        SpannableString ss=new SpannableString(text);
        ss.setSpan(new BackgroundColorSpan(getThemeStyledAttributes().colorAccent), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new ForegroundColorSpan(Color.WHITE), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return ss;
    }

    private class DataBackup {
        public List<AppInfo> appInfos = new ArrayList<>();
    }

    private class TextHighlights {
        public TextHighlight title;
        public TextHighlight subtitle;
    }

    private class TextHighlight {
        public int start;
        public int end;
    }

    private class SearchResult {
        public Map<AppInfo,TextHighlights> appInfoHighlightMaps;
        public List<AppInfo> appInfos;
    }

    private class SearchTask extends AsyncTask<String,AppInfo,SearchResult> {

        public int status;

        private boolean cancel;

        public SearchTask() {

        }

        public void cancel() {
            this.cancel = true;
            status = STATUS_FINISH;
            cancel(true);
        }

        public boolean isCancel() {
            return cancel;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            status = STATUS_SEARCHING;
        }

        @Override
        protected SearchResult doInBackground(String[] args) {
            final String searchContent=args[0].toLowerCase(Locale.ENGLISH);

            final List<AppInfo> appinfos=new ArrayList<>();
            Map<AppInfo,TextHighlights> appInfoHighlightMaps = new HashMap<>();

            List<AppInfo> appInfosBackup = mDataBackup.appInfos;

            for (int i=0;searchContent.length() != 0 && i < appInfosBackup.size();i++) {
                AppInfo appInfo=appInfosBackup.get(i);
                String label=appInfo.getLabel().toString().toLowerCase(Locale.ENGLISH);
                String packageName=appInfo.packageName.toLowerCase(Locale.ENGLISH);

                int labelIndex=label.indexOf(searchContent);
                int packageNameIndex = packageName.indexOf(searchContent);

                if (labelIndex != -1 || packageNameIndex != -1) {

                    TextHighlights textHighlights=new TextHighlights();

                    if (labelIndex != -1) {
                        textHighlights.title = new TextHighlight();
                        textHighlights.title.start = labelIndex;
                        textHighlights.title.end = labelIndex + searchContent.length();
                    }

                    if (packageNameIndex != -1) {
                        textHighlights.subtitle = new TextHighlight();
                        textHighlights.subtitle.start = packageNameIndex;
                        textHighlights.subtitle.end = packageNameIndex + searchContent.length();
                    }

                    appInfoHighlightMaps.put(appInfo, textHighlights);

                    appinfos.add(appInfo);
                }

            }

            SearchResult result=new SearchResult();
            result.appInfoHighlightMaps = appInfoHighlightMaps;
            result.appInfos = appinfos;
            return result;
        }

        @Override
        protected void onProgressUpdate(AppInfo[] values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(SearchResult result) {
            super.onPostExecute(result);
            status = STATUS_FINISH;

            mAppInfoHighlightMaps = result.appInfoHighlightMaps;
            setAppInfos(result.appInfos);
            notifyDataSetChanged();
        }

    }

}
