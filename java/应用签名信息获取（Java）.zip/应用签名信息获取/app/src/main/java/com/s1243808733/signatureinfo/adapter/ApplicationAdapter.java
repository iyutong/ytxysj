package com.s1243808733.signatureinfo.adapter;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import com.s1243808733.signatureinfo.R;
import com.s1243808733.signatureinfo.base.BaseAdapter;
import com.s1243808733.signatureinfo.data.AppInfo;
import java.util.ArrayList;
import java.util.List;

public class ApplicationAdapter extends BaseAdapter<AppInfo,AppViewHolder> {

    private final Context context;

    private List<AppInfo> appInfos = new ArrayList<>();

    private ListView mListView;

    private final ThemeStyledAttributes themeStyledAttributes;

    public ApplicationAdapter(Context context) {
        this.context = context;
        themeStyledAttributes = new ThemeStyledAttributes(context);
    }

    @Override
    public AppViewHolder onCreateViewHolder(LayoutInflater inflater, ViewGroup parent, int position) {
        View inflate=inflater.inflate(R.layout.list_item_app, parent, false);
        AppViewHolder holder=new AppViewHolder(inflate);
        return holder;
    }

    @Override
    public void onBindViewHolder(AppViewHolder convertHolder, int position) {
        AppInfo appInfo=getItem(position);

        setIcon: {
            final ImageView icon=convertHolder.icon;
            icon.setTag(appInfo);
            if (appInfo.getIcon() == null) {
                icon.setImageDrawable(null);
                LoadApplicationIconTask task=new LoadApplicationIconTask(appInfo);
                task.execute();
            } else {
                icon.setImageDrawable(appInfo.getIcon());
            }
        }

        setTitle: {
            convertHolder.title.setText(getTitle(appInfo, position));
        }

        setSubTitle: {
            convertHolder.subtitle.setText(getSubTitle(appInfo, position));
        }

    }

    protected CharSequence getTitle(AppInfo appInfo, int position) {
        SpannableStringBuilder sb=new SpannableStringBuilder();
        sb.append(String.format("%d. ", position + 1));
        sb.append(getMainTitle(appInfo, position));
        
        appendVersion:{
            SpannableString ss =new SpannableString(String.format(" v%s(%d)", appInfo.versionName, appInfo.versionCode));
            ss.setSpan(new ForegroundColorSpan(themeStyledAttributes.textColorTertiary),0,ss.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append(ss);
        }
       
        return sb;
    }

    protected CharSequence getMainTitle(AppInfo appInfo, int position) {
        SpannableStringBuilder sb=new SpannableStringBuilder();
        sb.append(appInfo.getLabel());
        return sb;
    }

    protected CharSequence getSubTitle(AppInfo appInfo, int position) {
        SpannableStringBuilder sb=new SpannableStringBuilder();
        sb.append(getMainSubTitle(appInfo, position));
        return sb;
    }

    protected CharSequence getMainSubTitle(AppInfo appInfo, int position) {
        SpannableStringBuilder sb=new SpannableStringBuilder();
        sb.append(appInfo.packageName);
        return sb;
    }

    @Override
    public void notifyDataSetChanged() {
        if (getCount() == 0) {
            notifyDataSetInvalidated();
            return;
        }
        super.notifyDataSetChanged();
    }

    public Context getContext() {
        return context;
    }

    public void setAppInfos(List<AppInfo> appInfos) {
        this.appInfos = appInfos;
    }

    public List<AppInfo> getAppInfos() {
        return appInfos;
    }

    public ThemeStyledAttributes getThemeStyledAttributes() {
        return themeStyledAttributes;
    }

    public void setListView(ListView listView) {
        mListView = listView;
    }

    @Override
    public int getCount() {
        return appInfos.size();
    }

    @Override
    public AppInfo getItem(int position) {
        return appInfos.get(position);
    }

    public static class ThemeStyledAttributes {

        private final Context context;

        public final int textColorPrimary;

        public final int textColorTertiary;

        public final int colorAccent;

        public ThemeStyledAttributes(Context context) {
            this.context = context;
            int[] attrs = {
                android.R.attr.textColorPrimary,
                android.R.attr.textColorTertiary,
            };
            int[] colors=getColors(attrs);
            textColorPrimary = colors[0];
            textColorTertiary = colors[1];

            int holo_blue_dark = context.getResources().getColor(android.R.color.holo_blue_dark);
            if (Build.VERSION.SDK_INT >= 21) {
                colorAccent = getColor(android.R.attr.colorAccent, holo_blue_dark);
            } else {
                colorAccent = holo_blue_dark;
            }

        }

        public int getColor(int attrs, int def) {
            return getColors(new int[]{attrs}, new int[]{def})[0];
        }

        public int[] getColors(int[] attrs) {
            return getColors(attrs, null);
        }

        public int[] getColors(int[] attrs, int[] defs) {
            int[] colors=new int[attrs.length];
            TypedArray a = context.getTheme().obtainStyledAttributes(attrs);
            for (int i=0;i < colors.length;i++) {
                int def = defs == null ?Color.BLACK: defs[i];
                colors[i] = a.getColor(i, def);
            }
            a.recycle();
            return colors;
        }

    }

    private class LoadApplicationIconTask extends AsyncTask<Void,Void,Drawable> {

        private final AppInfo appInfo;

        public LoadApplicationIconTask(AppInfo appInfo) {
            this.appInfo = appInfo;
        }

        @Override
        protected Drawable doInBackground(Void[] args) {
            return appInfo.loadIcon();
        }

        @Override
        protected void onPostExecute(Drawable result) {
            super.onPostExecute(result);
            ImageView view = mListView.findViewWithTag(appInfo);
            if (view != null) {
                view.setImageDrawable(result);
            }
        }

    }

}
