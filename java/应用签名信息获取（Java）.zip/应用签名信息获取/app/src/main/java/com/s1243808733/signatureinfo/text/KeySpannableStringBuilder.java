package com.s1243808733.signatureinfo.text;

import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import java.util.stream.IntStream;

public class KeySpannableStringBuilder extends SpannableStringBuilder {

    public static final int STYLE_SINGLENESS = 1;

    int style;

    private int keyColor;

    private int valueColor;    

    public KeySpannableStringBuilder() {
        this(0);
    }

    public KeySpannableStringBuilder(int style) {
        super();
        this.style = style;
    }

    public KeySpannableStringBuilder setKeyColor(int keyColor) {
        this.keyColor = keyColor;
        return this;
    }

    public KeySpannableStringBuilder setValueColor(int valueColor) {
        this.valueColor = valueColor;
        return this;
    }

    public SpannableStringBuilder appendLine() {
        return append("\n");
    }

    public SpannableStringBuilder append(CharSequence key, long value) {
        return append(key, String.valueOf(value));
    }

    public SpannableStringBuilder append(CharSequence key, CharSequence value) {
        return append(key, value, true);
    }

    public SpannableStringBuilder append(CharSequence key, CharSequence value, boolean tint) {
        if (style == STYLE_SINGLENESS) {

            if (tint) {
                if (keyColor != 0) {
                    SpannableString ss=new SpannableString(key);
                    ss.setSpan(new ForegroundColorSpan(keyColor), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    key = ss;
                }

                if (valueColor != 0) {
                    SpannableString ss=new SpannableString(value);
                    ss.setSpan(new ForegroundColorSpan(valueColor), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    value = ss;
                }
            }

            if (length() != 0) {
                appendLine();
            }
            append(key);
            append(" = ");
            append(value);
            return this;
        }

        key = new SpannableStringBuilder()
            .append("[").append(key).append("]");


        if (tint) {
            if (keyColor != 0) {
                SpannableString ss=new SpannableString(key);
                ss.setSpan(new ForegroundColorSpan(keyColor), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                key = ss;
            }

            if (valueColor != 0) {
                SpannableString ss=new SpannableString(value);
                ss.setSpan(new ForegroundColorSpan(valueColor), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                value = ss;
            }
        }
        if (length() != 0) {
            appendLine();
        }
        append(key);
        appendLine();
        append(value);

        return this;
    }

    @Override
    public IntStream chars() {
        return null;
    }

    @Override
    public IntStream codePoints() {
        return null;
    }

}
