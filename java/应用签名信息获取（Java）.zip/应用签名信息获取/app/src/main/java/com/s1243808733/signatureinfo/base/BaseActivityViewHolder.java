package com.s1243808733.signatureinfo.base;
import android.app.Activity;

public class BaseActivityViewHolder {
    
    public final Activity activity;

    public BaseActivityViewHolder(Activity activity) {
        this.activity = activity;
    }
    
}
