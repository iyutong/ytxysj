package com.s1243808733.signatureinfo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.s1243808733.signatureinfo.adapter.AppViewHolder;
import com.s1243808733.signatureinfo.adapter.SearchApplicationAdapter;
import com.s1243808733.signatureinfo.base.BaseActivity;
import com.s1243808733.signatureinfo.base.BaseActivityViewHolder;
import com.s1243808733.signatureinfo.data.AppInfo;
import com.s1243808733.signatureinfo.text.KeySpannableStringBuilder;
import com.s1243808733.signatureinfo.util.EncryptUtils;
import com.s1243808733.signatureinfo.util.Util;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends BaseActivity implements AdapterView.OnItemClickListener { 

    private ActivityViewHolder mViewHolder;

    private SearchApplicationAdapter mAppAdapter;

    private MenuItem mSearchMenuItem;

    private SearchMenuItemManager mSearchManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView(savedInstanceState);
        loadApp();
    }

    private void initView(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        mViewHolder = new ActivityViewHolder(this);

        mAppAdapter = new SearchApplicationAdapter(this);
        mAppAdapter.setListView(mViewHolder.listView);
        mViewHolder.listView.setAdapter(mAppAdapter);

        mViewHolder.listView.setOnItemClickListener(this);

    }

    private void loadApp() {
        LoadApplicationTask task= new LoadApplicationTask();
        task.execute();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long itemId) {
        AppInfo appInfo=mAppAdapter.getItem(position);
        AppViewHolder holder=(AppViewHolder) view.getTag(R.id.tag_holder);

        final KeySpannableStringBuilder sb=new KeySpannableStringBuilder();
        int[] attrs = {
            android.R.attr.textColorPrimary,
            android.R.attr.textColorTertiary,
        };
        TypedArray a=getTheme().obtainStyledAttributes(attrs);
        int textColorPrimary=a.getColor(0, Color.RED);
        int textColorTertiary=a.getColor(1, Color.RED);
        sb.setKeyColor(textColorPrimary);
        sb.setValueColor(textColorTertiary);
        a.recycle();

        try {
            PackageInfo packageInfo= getPackageManager().getPackageInfo(appInfo.packageName, PackageManager.GET_SIGNATURES);
            Signature[] signatures=packageInfo.signatures;
            Signature signature=signatures[0];
            X509Certificate certificate=getX509Certificate(signatures);
            int hashCode=signature.hashCode();
            CharSequence issuerDN=certificate.getIssuerDN().toString().replaceAll(", ", "\n");
            
            sb.append("签名信息", issuerDN);
            sb.appendLine();

            if (hashCode == -672009692) {
                sb.append("(这是一个Android Debug签名)");
                sb.appendLine();
            }
            {
                KeySpannableStringBuilder fingerprint=new KeySpannableStringBuilder(KeySpannableStringBuilder.STYLE_SINGLENESS);
                fingerprint.setKeyColor(textColorPrimary);
                fingerprint.setValueColor(textColorTertiary);

                fingerprint.append("MD5", EncryptUtils.bytes2HexString(EncryptUtils.encryptMD5(signature.toByteArray())).replaceAll("(?<=[0-9A-F]{2})[0-9A-F]{2}", ":$0"));
                fingerprint.appendLine();
                fingerprint.append("SHA1", EncryptUtils.bytes2HexString(EncryptUtils.encryptSHA1(signature.toByteArray())).replaceAll("(?<=[0-9A-F]{2})[0-9A-F]{2}", ":$0"));
                fingerprint.appendLine();
                fingerprint.append("SHA256", EncryptUtils.bytes2HexString(EncryptUtils.encryptSHA256(signature.toByteArray())).replaceAll("(?<=[0-9A-F]{2})[0-9A-F]{2}", ":$0"));

                sb.append("签名指纹", fingerprint, false);
                sb.appendLine();
            }
            sb.append("哈希代码", hashCode);
            sb.appendLine();


            sb.append("签名创建时间", Util.formatTime(certificate.getNotBefore().getTime()));
            sb.appendLine();
            sb.append("签名失效时间", Util.formatTime(certificate.getNotAfter().getTime()));

        } catch (PackageManager.NameNotFoundException e) {}

        AlertDialog dialog=new AlertDialog.Builder(this)
            .setIcon(appInfo.getIcon())
            .setTitle(appInfo.getLabel())
            .setMessage(sb)
            .setPositiveButton(android.R.string.copy, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dia, int which) {
                    ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setText(sb.toString());
                    Toast.makeText(MainActivity.this, R.string.message_copied_to_clipboard, Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton(android.R.string.cancel, null)
            .create();
        dialog.show();

        final TextView message=dialog.findViewById(android.R.id.message);
        message.post(new Runnable(){

                @Override
                public void run() {
                    message.setTextIsSelectable(true);
                }
            });
    }

    private X509Certificate getX509Certificate(Signature[] signature) {
        ByteArrayInputStream is=null;
        try {
            is = new ByteArrayInputStream(signature[0].toByteArray());
            CertificateFactory instance = CertificateFactory.getInstance("X.509");
            return (X509Certificate) instance.generateCertificate(is);
        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {}
            }
        }
        return null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_main, menu);

        handleSearchMenuItem: {
            mSearchManager = new SearchMenuItemManager();
            mSearchMenuItem = menu.findItem(R.id.searchMenuItem);
            mSearchMenuItem.setOnActionExpandListener(mSearchManager);
            mSearchMenuItem.setEnabled(false);

            View actionView=mSearchMenuItem.getActionView();
            SearchView searchView=(SearchView)actionView;
            searchView.setOnQueryTextListener(mSearchManager);

        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (mAppAdapter.isSearchMode()) {
            mSearchMenuItem.collapseActionView();
            return;
        }
        super.onBackPressed();
    }

    private class SearchMenuItemManager implements MenuItem.OnActionExpandListener,SearchView.OnQueryTextListener {

        private Bundle savedState;

        private int expandCount;

        @Override
        public boolean onMenuItemActionExpand(MenuItem item) {
            expandCount++;
            mAppAdapter.setSearchMode(true);

            //保存非搜索模式下的状态
            savedState = new Bundle();
            savedState.putInt("firstVisiblePosition", mViewHolder.listView.getFirstVisiblePosition());

            return true;
        }

        @Override
        public boolean onMenuItemActionCollapse(MenuItem item) {
            mAppAdapter.setSearchMode(false);

            //恢复
            mViewHolder.listView.setSelection(savedState.getInt("firstVisiblePosition", 0));
            return true;
        }

        @Override
        public boolean onQueryTextSubmit(String query) {
            return false;
        }

        /**
         * 第一次伸展/关闭都会清空输入并调用这个方法
         */
        private boolean firstQueryTextChange =true;

        @Override
        public boolean onQueryTextChange(String newText) {
            if (firstQueryTextChange && expandCount == 1) {
                firstQueryTextChange = false;
                return true;
            }
            search(newText);
            return true;
        }

        public void search(String content) {
            if (!mAppAdapter.isSearchMode())return;
            mAppAdapter.search(content);
        }

    }

    private class LoadApplicationTask extends AsyncTask<Void,AppInfo,List<AppInfo>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected List<AppInfo> doInBackground(Void[] args) {
            final List<AppInfo> result = new ArrayList<>();
            PackageManager packageManager=getPackageManager();

            final int flags=0; //只加载基本数据
            //flags |= PackageManager.GET_SIGNATURES | PackageManager.GET_ACTIVITIES;

            List<PackageInfo> installedPackages=packageManager.getInstalledPackages(flags);

            for (int i = 0;installedPackages != null && i < installedPackages.size();i++) {
                PackageInfo packageInfo=installedPackages.get(i);
                AppInfo appInfo=new AppInfo(packageInfo);
                if (i < 15) {
                    appInfo.loadIcon();
                }
                result.add(appInfo);
            }
            Collections.sort(result);
            return result;
        }

        @Override
        protected void onProgressUpdate(AppInfo[] values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(List<AppInfo> result) {
            super.onPostExecute(result);
            mAppAdapter.setAppInfos(result);
            mAppAdapter.notifyDataSetChanged();
            mSearchMenuItem.setEnabled(true);

        }

    }

    private class ActivityViewHolder extends BaseActivityViewHolder {

        public final ListView listView;

        public ActivityViewHolder(Activity activity) {
            super(activity);
            this.listView = activity.findViewById(R.id.listView);
        }

    }

} 
