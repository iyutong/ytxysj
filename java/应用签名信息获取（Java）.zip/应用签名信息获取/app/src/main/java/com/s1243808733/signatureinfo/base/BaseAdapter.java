package com.s1243808733.signatureinfo.base;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.s1243808733.signatureinfo.R;

public abstract class BaseAdapter<Item,VH extends BaseAdapter.ViewHolder> extends android.widget.BaseAdapter {

    private LayoutInflater mLayoutInflater;

    public BaseAdapter() {
    }

    @Override
    public final View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            if (this.mLayoutInflater == null) {
                this.mLayoutInflater = LayoutInflater.from(parent.getContext());
            }
            VH holder = onCreateViewHolder(mLayoutInflater, parent, position);
            convertView = holder.itemView;
            convertView.setTag(R.id.tag_holder, holder);
        }
        onBindViewHolder((VH)convertView.getTag(R.id.tag_holder), position);   
        return convertView;
    }

    public abstract VH onCreateViewHolder(LayoutInflater inflater, ViewGroup parent, int position);

    public abstract void onBindViewHolder(VH convertHolder, int position);

    @Override
    public abstract int getCount()

    @Override
    public abstract Item getItem(int position) 

    @Override
    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder {

        public final View itemView;

        public ViewHolder(View itemView) {
            this.itemView = itemView;
        }

        public Context getContext() {
            return itemView.getContext();
        }

    }

}
