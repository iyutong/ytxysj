package com.s1243808733.signatureinfo.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.s1243808733.signatureinfo.R;

public class AppViewHolder extends ApplicationAdapter.ViewHolder {

    public final ImageView icon;

    public final TextView title;

    public final TextView subtitle;

    public AppViewHolder(View itemView) {
        super(itemView);
        icon = itemView.findViewById(R.id.icon);
        title = itemView.findViewById(R.id.title);
        subtitle = itemView.findViewById(R.id.subtitle);

    }

}
