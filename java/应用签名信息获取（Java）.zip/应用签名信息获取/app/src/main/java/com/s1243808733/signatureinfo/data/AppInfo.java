package com.s1243808733.signatureinfo.data;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import com.s1243808733.signatureinfo.App;

public class AppInfo implements Comparable<AppInfo>,Parcelable {

    public final Context context;

    public final PackageManager packageManager;

    public final PackageInfo packageInfo;

    public final ApplicationInfo applicationInfo;

    public final String packageName;

    public final long versionCode;

    public final String versionName;

    private Drawable icon;

    private CharSequence label;

    protected AppInfo(final Parcel in) {
        context = App.getApp().getApplicationContext();
        packageManager = context.getPackageManager();

        ClassLoader classLoader = getClass().getClassLoader();
        packageInfo = in.readParcelable(classLoader);
        applicationInfo = packageInfo.applicationInfo;

        packageName = in.readString();
        versionCode = in.readLong();
        versionName = in.readString();
        
    }

    public AppInfo(PackageInfo packageInfo) {

        context = App.getApp().getApplicationContext();
        packageManager = context.getPackageManager();

        this.packageInfo = packageInfo;
        applicationInfo = packageInfo.applicationInfo;
        if (Build.VERSION.SDK_INT >= 24) {
            versionCode = packageInfo.getLongVersionCode();
        } else {
            versionCode = packageInfo.versionCode;
        }
        versionName = packageInfo.versionName;
        packageName = packageInfo.packageName;
    }

    public Drawable getIcon() {
        return icon;
    }

    public Drawable loadIcon() {
        if (icon == null) {
            icon = applicationInfo.loadIcon(packageManager);
        }
        return icon;
    }

    public CharSequence getLabel() {
        if (label == null) {
            label = applicationInfo.loadLabel(packageManager);
        }
        return label;
    }

    public Context getContext() {
        return context;
    }

    @Override
    public int compareTo(AppInfo appInfo) {
        return getLabel().toString()
            .compareTo(appInfo.getLabel().toString());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(packageInfo, flags);
        dest.writeString(packageName);
        dest.writeLong(versionCode);
        dest.writeString(versionName);

    }

    public static final Creator<AppInfo> CREATOR = new AppInfoCreator();

    public static final class AppInfoCreator implements Creator<AppInfo> {

        @Override
        public AppInfo createFromParcel(Parcel source) {
            return new AppInfo(source);
        }

        @Override
        public AppInfo[] newArray(int size) {
            return new AppInfo[size];
        }

    }

}
