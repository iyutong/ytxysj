package com.s1243808733.signatureinfo;
import android.app.Application;

public class App extends Application {

    private static Application sApp;

    @Override
    public void onCreate() {
        super.onCreate();
        App.sApp = this;
    }

    public static Application getApp() {
        return sApp;
    }
}
