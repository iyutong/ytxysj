package com.s1243808733.signatureinfo.base;

import android.app.Activity;
import android.os.Bundle;
import android.widget.BaseAdapter;

public class BaseActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       
    }
    
}
