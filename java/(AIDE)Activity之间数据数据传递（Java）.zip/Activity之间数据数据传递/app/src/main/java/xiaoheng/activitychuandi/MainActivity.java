package xiaoheng.activitychuandi;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private EditText edittext1,edittext2;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		edittext1=(EditText)findViewById(R.id.mainEditText1);
		edittext2=(EditText)findViewById(R.id.mainEditText2);
		Button button=(Button)findViewById(R.id.mainButton1);
		
		button.setOnClickListener(new OnClickListener()
		{
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Intent intent = new Intent(MainActivity.this,Jieshouqi.class);
					intent.putExtra("biaoti","标题："+edittext1.getText().toString());
					intent.putExtra("neirong","内容："+edittext2.getText().toString());
					startActivity(intent);
				}
			});
		
		
		
    }
}
