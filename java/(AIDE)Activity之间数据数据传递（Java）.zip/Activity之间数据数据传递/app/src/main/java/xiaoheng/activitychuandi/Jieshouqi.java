package xiaoheng.activitychuandi;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class Jieshouqi extends Activity
{
	private String getbiaoti,getneirong;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jieshouqi);
		
        Intent intent=getIntent();
        getbiaoti=intent.getStringExtra("biaoti");
		getneirong=intent.getStringExtra("neirong");
		
		TextView text=(TextView)findViewById(R.id.jieshouqiTextView1);
		TextView text1=(TextView)findViewById(R.id.jieshouqiTextView2);
		
		text.setText(getbiaoti);
		text1.setText(getneirong);
	}
}
