package com.hightlight.test;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.text.*;
import android.text.style.*;

public class MainActivity extends Activity 
{
	TextView tx;
	String str="<font color=#66ccff>123456</font>";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		tx=(TextView)findViewById(R.id.mainTextView1);
		tx.setText(Html.fromHtml(str));
		
		SpannableString spanablestr=new SpannableString("fuck");
		spanablestr.setSpan(new ForegroundColorSpan(0xffff66cc),0,spanablestr.length(),Spannable.SPAN_EXCLUSIVE_INCLUSIVE);  
		tx.append(spanablestr);
    }
}
