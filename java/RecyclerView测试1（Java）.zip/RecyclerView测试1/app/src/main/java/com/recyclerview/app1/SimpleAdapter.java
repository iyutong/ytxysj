package com.recyclerview.app1;
import android.support.v7.widget.*;
import android.view.*;
import android.content.*;
import java.util.*;
import org.w3c.dom.*;
import android.widget.*;

public class SimpleAdapter extends RecyclerView.Adapter<MyViewHolder>
{
	private LayoutInflater mInflater;
	private Context mContext;
	private List<String> mData;
	
	
   public SimpleAdapter(Context context,List<String> data){
	   this.mContext=context;
	    this.mData=data; 
	   mInflater=LayoutInflater.from(context);
	 //  赋值
   }
	
	
	
	@Override
	public MyViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
		//创建ViewHolder
		View view=mInflater.inflate(R.layout.item_recycler,p1,false);
		//-1，item布局
		MyViewHolder ViewHolder=new MyViewHolder(view);
		return null;
	}

	@Override
	public void onBindViewHolder(MyViewHolder p1, int p2)
	{
		p1.tv.setText(mData.get(p2));
		//绑定ViewHolder
		
	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return mData.size();
	}
	
}



class MyViewHolder extends RecyclerView.ViewHolder

{
	TextView tv;
	public MyViewHolder(View p1){
		super(p1);
		
		
		
		tv=(TextView)p1.findViewById(R.id.tv_item);
	}
	
	
	
}
