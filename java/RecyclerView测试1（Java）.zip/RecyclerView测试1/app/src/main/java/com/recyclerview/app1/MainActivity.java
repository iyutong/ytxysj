package com.recyclerview.app1;

import android.app.*;
import android.os.*;
import android.view.View;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView.Adapter;
import java.util.*;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity 
{
	private RecyclerView rv;
	private List<String> mDatas;
	private SimpleAdapter Myadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		intDatas();
		intView();
         Myadapter=new SimpleAdapter(this,mDatas);
		 rv.setAdapter(Myadapter);
		 
		 LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
		rv.setLayoutManager(linearLayoutManager);
    }

	private void intView()
	{
		rv=(RecyclerView) findViewById(R.id.rv);

		
		 
	}

	private void intDatas()
	{
		mDatas=new ArrayList<String>();
		for(int i='A';i<='z';i++){
			mDatas.add(""+(char)i);


		}
		
		
		
	}

	
}
