# Kongzue Dialog V3(AndroidX)
献给要求安卓照着苹果设计稿做开发的产品们（手动滑稽

使用方法和更新日志详见： https://github.com/kongzue/DialogV3/