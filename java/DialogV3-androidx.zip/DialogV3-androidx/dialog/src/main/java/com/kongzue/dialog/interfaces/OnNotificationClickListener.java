package com.kongzue.dialog.interfaces;

/**
 * Author: @Kongzue
 * Github: https://github.com/kongzue/
 * Homepage: http://kongzue.com/
 * Mail: myzcxhh@live.cn
 * CreateTime: 2019/4/10 20:24
 */
public interface OnNotificationClickListener {
    
    void onClick();
    
}
