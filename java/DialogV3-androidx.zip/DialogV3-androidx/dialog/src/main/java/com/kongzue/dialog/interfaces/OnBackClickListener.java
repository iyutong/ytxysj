package com.kongzue.dialog.interfaces;

/**
 * @author: Kongzue
 * @github: https://github.com/kongzue/
 * @homepage: http://kongzue.com/
 * @mail: myzcxhh@live.cn
 * @createTime: 2019/11/15 15:31
 */
public interface OnBackClickListener {
    boolean onBackClick();
}
