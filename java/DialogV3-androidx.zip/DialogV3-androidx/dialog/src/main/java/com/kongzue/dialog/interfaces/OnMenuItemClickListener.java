package com.kongzue.dialog.interfaces;

public interface OnMenuItemClickListener {

    void onClick(String text, int index);

}
