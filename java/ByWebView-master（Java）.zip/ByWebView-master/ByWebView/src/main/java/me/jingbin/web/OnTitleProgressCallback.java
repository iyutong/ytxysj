package me.jingbin.web;

/**
 * Created by jingbin on 2020/6/30.
 */
public abstract class OnTitleProgressCallback {

    public void onReceivedTitle(String title) {

    }

    public void onProgressChanged(int newProgress) {

    }

}
