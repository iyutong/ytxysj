package com.mycompany.myapp;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity 
{

	MyService mMyService;

	ServiceConnection conn = new ServiceConnection() {
		@Override
		public void onServiceDisconnected(ComponentName name)
		{

		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service)
		{
			//返回一个MyService对象
			mMyService = ((MyService.MsgBinder)service).getService();

		}
	};


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		//绑定Service
		Intent intent = new Intent(MainActivity.this, MyService.class);
		bindService(intent, conn, Context.BIND_AUTO_CREATE);

		Button button = findViewById(R.id.mainButton1);
		button.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					mMyService.showToast();
				}
			});


    }

	//关闭时必须解绑
	@Override
	protected void onDestroy()
	{
		unbindService(conn);
		super.onDestroy();
	}

}
