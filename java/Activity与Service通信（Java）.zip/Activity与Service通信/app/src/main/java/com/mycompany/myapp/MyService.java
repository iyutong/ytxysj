package com.mycompany.myapp;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

public class MyService extends Service
{
	
	//重写方法，返回一个Bind对象
	@Override
	public IBinder onBind(Intent mBind)
	{
		return new MsgBinder();
	}

	//提供一个方法供Activity调用
	public void showToast()
	{
		Toast.makeText(MyService.this, "我是从Service发出的！", Toast.LENGTH_LONG).show();
	}

	public class MsgBinder extends Binder
	{
		/**
		 * 获取当前Service的实例
		 * @return
		 */
		public MyService getService()
		{
			return MyService.this;
		}
	}

}
