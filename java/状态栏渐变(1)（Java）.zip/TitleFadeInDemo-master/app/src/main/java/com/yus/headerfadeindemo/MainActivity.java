package com.yus.headerfadeindemo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements YusScrollView.ScrollViewListener {

    private YusScrollView yusSv;
    private TextView tvHeader;
    private ImageView iv;
    private LinearLayout llHeader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        setTranslucentWindows(this);
        yusSv = (YusScrollView) findViewById(R.id.sv);
        tvHeader = (TextView) findViewById(R.id.tvHeader);
        iv = (ImageView) findViewById(R.id.iv);
        llHeader = (LinearLayout) findViewById(R.id.llHeadr);
//        tvHeader.setAlpha(0);

        yusSv.setScrollViewListener(this);

    }

    @Override
    public void onScrollChanged(YusScrollView scrollView, int x, int y, int oldx, int oldy) {
//        Log.d("alan","oldy--->"+oldy);
        Log.d("alan", "y---->" + y);
        int tvHeight = tvHeader.getHeight();
        int ivHeight = iv.getHeight();

        Log.d("alan", "tvHeight--->" + tvHeight);
        if (y <= 0) {
            llHeader.setBackgroundColor(Color.TRANSPARENT);
            tvHeader.setVisibility(View.INVISIBLE);

        } else if (y < ivHeight) {
            float scale = (float) y / (float) ivHeight;
            float alpha = 255 * scale;
            // TODO: 2016/9/3 注释里面的方法也可以实现
//            llHeader.setBackgroundColor(Color.argb((int) alpha, 144, 151, 166));
//            tvHeader.setVisibility(View.INVISIBLE);


            //先设置一个背景，然后在让背景乘以透明度
            llHeader.setBackgroundColor(getResources().getColor(R.color.base));
            llHeader.getBackground().setAlpha((int)alpha);
            tvHeader.setVisibility(View.INVISIBLE);

        } else if (y >= ivHeight) {
//            llHeader.setAlpha(1);
//            llHeader.setBackgroundColor(Color.argb((int) 255, 144, 151, 166));
//            tvHeader.setVisibility(View.VISIBLE);


            llHeader.setBackgroundColor(getResources().getColor(R.color.base));
            tvHeader.setVisibility(View.VISIBLE);
        }

    }

    /**
     * 设置透明状态栏
     */
    private void setTranslucentWindows(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }
}
