# TitleFadeInDemo
标题栏渐变以及透明状态栏的Demo


-  效果图
![效果图](https://github.com/gnehsuy/TitleFadeInDemo/blob/master/titleFadeIn.gif)
