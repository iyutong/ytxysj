package com.FMJJ.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.webkit.WebView;

public class MainActivity extends Activity 
{
    Button b1,b2;
    ImageButton ib1;
    ViewPager v1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        b1 = findViewById(R.id.activitymainButton1);
        b1.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    v1.zoom();
                }
            });
        b2 = findViewById(R.id.activitymainButton2);
        b2.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    WebView webview = new WebView(getApplicationContext());
                    webview.loadUrl("https://www.baidu.com");
                    v1.addView(webview);
                    v1.TouchBottom();
                }
            });
        ib1 = findViewById(R.id.activitymainImageButton1);
        ib1.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    //  Toast.makeText(getApplicationContext(),"666",Toast.LENGTH_SHORT);
                    //    v1.addView(new WebView(getApplicationContext()));
                /*    Log.e(v1.getChildCount() + "size", "");
                    for (int i = 0;i < v1.getChildCount();i++)
                    {
                        Log.e("" + i, "" + v1.getChildAt(i).getClass());
                    }*/
              //      v1.TouchBottom();
                }
            });
        v1 = findViewById(R.id.mainViewPager1);
    }
}
