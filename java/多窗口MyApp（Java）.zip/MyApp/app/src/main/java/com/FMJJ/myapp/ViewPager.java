package com.FMJJ.myapp;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Scroller;

public class ViewPager extends ViewGroup
{
    private Context mContext;
    private GestureDetector mGestureDetector;
    private Scroller mScroller;
    private int position;

    private int scrollX;
    private int startX;
    private int startY;

    private int windows = 1;

    private boolean lock = true;

    private boolean zoom = false;

    public ViewPager(Context context)
    {
        super(context);
        this.mContext = context;
        init();
    }

    public ViewPager(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        this.mContext = context;
        init();
    }

    public ViewPager(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        init();
    }

    private void init()
    {
        for (int i = 0; i < windows; i++)
        {
            WebView webview = new WebView(getContext());
            webview.loadUrl("https://www.baidu.com");
            this.addView(webview);
        }
        mGestureDetector = new GestureDetector(new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
                {
                    //相对滑动：X方向滑动多少距离，view就跟着滑动多少距离
                    scrollBy((int) distanceX, 0);
                    return super.onScroll(e1, e2, distanceX, distanceY);
                }
            });
        mScroller = new Scroller(mContext);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        for (int i = 0; i < getChildCount(); i++)
        {
            getChildAt(i).measure(widthMeasureSpec, heightMeasureSpec);
        }
    }


    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev)
    {
        switch (ev.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                startX = (int) ev.getX();
                startY = (int) ev.getY();
                mGestureDetector.onTouchEvent(ev);
                break;
            case MotionEvent.ACTION_MOVE:
                int endX = (int) ev.getX();
                int endY = (int) ev.getY();
                int dx = endX - startX;
                int dy = endY - startY;
                if (Math.abs(dx) > Math.abs(dy))
                {
                    // 左右滑动
                    return lock;// 中断事件传递
                }

                break;
            default:
                break;
        }
        return false;
    }

    public void zoom(boolean p0)
    {
        if (p0)
        {
            PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat("scaleX", 1f, 0.8f);
            PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat("scaleY", 1f, 0.8f);
            ObjectAnimator scale = ObjectAnimator.ofPropertyValuesHolder(this, pvhX, pvhY);
            scale.setDuration(300);
            scale.start();
        }
        else
        {
            PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat("scaleX", 0.8f, 1f);
            PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat("scaleY", 0.8f, 1f);
            ObjectAnimator scale = ObjectAnimator.ofPropertyValuesHolder(this, pvhX, pvhY);
            scale.setDuration(300);
            scale.start();
        }
        zoom = p0;
        lock = p0;
        zoomed();
    }

    public void zoom()
    {
        zoom(!zoom);
    }

    public void setLock(boolean p0)
    {
        this.lock = p0;
    }

    public void zoomed()
    {

    }

    public int getPosion()
    {
        return position = (getScrollX() + getWidth() / 2) / getWidth();
    }

    public void TouchTop(){
        scrollBy(0,getWidth()*(this.getChildCount() - getPosion() - 1)); 
    }
    
    public void TouchBottom(){
        scrollBy(getWidth()*(this.getChildCount() - getPosion() - 1), 0); 
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        mGestureDetector.onTouchEvent(event);
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                scrollX = getScrollX();
                position = getPosion();
              //  Log.e("pos", position + "");
                if (position >= this.getChildCount())
                {
                    position = position - 1;
                }
                if (position < 0)
                {
                    position = 0;
                }
                if (mOnPageScrollListener != null)
                {
                    mOnPageScrollListener.onPageScrolled((float) (getScrollX() * 1.0 / (getWidth())), position);
                }
                break;
            case MotionEvent.ACTION_UP:
                mScroller.startScroll(scrollX, 0, -(scrollX - position * getWidth()), 0);
                invalidate();
                if (mOnPageScrollListener != null)
                {
                    mOnPageScrollListener.onPageSelected(position);
                }
                break;
        }
        return true;
    }


    @Override
    public void computeScroll()
    {
        if (mScroller.computeScrollOffset())
        {
            scrollTo(mScroller.getCurrX(), 0);
            postInvalidate();
            if (mOnPageScrollListener != null)
            {
                mOnPageScrollListener.onPageScrolled((float) (mScroller.getCurrX() * 1.0 / ((1) * getWidth())), position);
            }
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b)
    {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++)
        {
            View childView = getChildAt(i);
            childView.layout(i * getWidth(), t, (i + 1) * getWidth(), b);
        }
    }

    public interface OnPageScrollListener
    {   
        void onPageScrolled(float offsetPercent, int position);

        void onPageSelected(int position);
    }

    private OnPageScrollListener mOnPageScrollListener;

    public void setOnPageScrollListener(OnPageScrollListener onPageScrollListener)
    {
        this.mOnPageScrollListener = onPageScrollListener;
    }
}
