package xiaoheng.daojishi;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity 
{
	private TextView t;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		t=(TextView)findViewById(R.id.mainTextView1);
		
		
		//倒计时
		CountDownTimer timer=new CountDownTimer(6000,10)
		{
			public void onTick(long millisUntilFinished)
			{
				t.setText(millisUntilFinished/1000+"秒");
			}
			public void onFinish()
			{
				t.setText("倒计时完成\n\nBy.小亨\n2017.12.17");
			}
		};
		timer.start();
		
	
		
    }
}
