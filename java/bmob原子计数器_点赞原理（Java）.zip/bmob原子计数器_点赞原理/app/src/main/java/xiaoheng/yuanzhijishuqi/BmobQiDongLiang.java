package xiaoheng.yuanzhijishuqi;

import cn.bmob.v3.*;

public class BmobQiDongLiang extends BmobObject
{
	public static String Bmob_APPID="3d419d044dae97419b6daefd12511a06";
	private Integer QiDongLiang;

	public Integer getDianZhanShu()
	{
		return QiDongLiang;
	}
	public void setDianZhanShu(Integer dianzhanshu)
	{
		this.QiDongLiang=dianzhanshu;
	}
}
