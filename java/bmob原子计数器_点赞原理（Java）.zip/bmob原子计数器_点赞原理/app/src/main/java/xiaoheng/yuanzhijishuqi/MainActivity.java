package xiaoheng.yuanzhijishuqi;

import android.app.*;
import android.os.*;
import android.view.*;
import cn.bmob.v3.*;
import cn.bmob.v3.exception.*;
import cn.bmob.v3.listener.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Bmob.initialize(this,BmobQiDongLiang.Bmob_APPID);
		
		BmobQuery<BmobQiDongLiang> getdjl=new BmobQuery<BmobQiDongLiang>();
		getdjl.getObject("hQvY666G", new QueryListener<BmobQiDongLiang>()
			{
				@Override
				public void done(BmobQiDongLiang p1, BmobException p2)
				{
					// TODO: Implement this method
					if (p2 == null)
					{
						//获取总启动量数据并显示
						Toast.makeText(MainActivity.this,"获取成功:"+p1.getDianZhanShu(),Toast.LENGTH_SHORT).show();
					}
					else
					{
						System.out.println("获取失败" + p2);
					}
				}
			});
		
    }
	
	public void dianzhan(View view)
	{
		BmobQiDongLiang bmob=new BmobQiDongLiang();
		bmob.increment("QiDongLiang");
		bmob.update("hQvY666G", new UpdateListener()
		{
				@Override
				public void done(BmobException p1)
				{
					// 待办事项：实现这个方法
					if(p1==null)
					{
						Toast.makeText(MainActivity.this,"点赞成功！",Toast.LENGTH_LONG).show();
					}
				}
			});
	}
	
}
