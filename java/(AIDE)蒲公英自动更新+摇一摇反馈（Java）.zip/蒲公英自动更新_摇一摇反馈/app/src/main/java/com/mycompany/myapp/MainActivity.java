package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import com.pgyersdk.activity.*;
import com.pgyersdk.crash.*;
import com.pgyersdk.feedback.*;
import com.pgyersdk.update.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		PgyUpdateManager.register(this);
		
		try 
		{} 
		catch (Exception e) 
		{
			PgyCrashManager.reportCaughtException(MainActivity.this, e);            
		}
		
		
    }
	
	@Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();

        // 自定义摇一摇的灵敏度，默认为950，数值越小灵敏度越高。
        PgyFeedbackShakeManager.setShakingThreshold(1000);

        // 以对话框的形式弹出
        PgyFeedbackShakeManager.register(MainActivity.this);

        // 以Activity的形式打开，这种情况下必须在AndroidManifest.xml配置FeedbackActivity
        // 打开沉浸式,默认为false
         FeedbackActivity.setBarImmersive(true);
        PgyFeedbackShakeManager.register(MainActivity.this, true);

    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        PgyFeedbackShakeManager.unregister();
    }
	
	
}
