# AZBarrage
Android弹幕效果，随机颜色，大小，高度，内容

博文教程地址：http://blog.csdn.net/XieYupeng520/article/details/49232925

![](https://github.com/Xieyupeng520/AZBarrage/blob/master/app/src/main/res/raw/show.gif)

![](https://github.com/Xieyupeng520/AZBarrage/blob/master/app/src/main/res/raw/show2.gif)
