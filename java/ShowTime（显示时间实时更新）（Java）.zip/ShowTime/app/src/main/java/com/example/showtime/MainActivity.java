package com.example.showtime;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import java.lang.ref.*;

public class MainActivity extends Activity {
	private Timer mTimer;
	private TextView mTvShow;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// 用于显示时间的 TextView
		mTvShow = findViewById(R.id.tv);
	}

	private MyHandler mHandler = new MyHandler(this);

	private static class MyHandler extends Handler {
		// 使用弱引用
		WeakReference<MainActivity> weakReference;

		public MyHandler(MainActivity mainActivity) {
			weakReference = new WeakReference<MainActivity>(mainActivity);
		}

        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
				if (weakReference.get() != null) {
					// 获取普通制日期
					SimpleDateFormat sdf_date = new SimpleDateFormat("yyyy年MM月dd日E");
					String date = sdf_date.format(new java.util.Date());

					// 获取公元制日期
					// SimpleDateFormat sdf_date_g = new SimpleDateFormat("Gyyyy年MM月dd日E");
					// String date_g = sdf_date_g.format(new java.util.Date());

					// 获取24小时制时间
					SimpleDateFormat sdf_time24 = new SimpleDateFormat("HH时mm分ss秒SSS毫秒");
					String time24 = sdf_time24.format(new java.util.Date());

					// 获取12小时制时间
					// SimpleDateFormat sdf_time12 = new SimpleDateFormat("ahh时mm分ss秒SSS毫秒");
					// String time12 = sdf_time12.format(new java.util.Date());

					// 获取时区信息
					SimpleDateFormat sdf_time_zone = new SimpleDateFormat("ZZZZ zzzz");
					String time_zone = sdf_time_zone.format(new java.util.Date());

					// 获取年份中的周数
					// SimpleDateFormat sdf_week_of_year = new SimpleDateFormat("现在是yyyy年的第w周");
					// String week_of_year = sdf_week_of_year.format(new java.util.Date());

					// 获取年份中的天数
					// SimpleDateFormat sdf_day_of_year = new SimpleDateFormat("现在是yyyy年的第D天");
					// String day_of_year = sdf_day_of_year.format(new java.util.Date());

					// 获取月份中的周数
					// SimpleDateFormat sdf_weeks_of_month = new SimpleDateFormat("现在是MM月的第W周");
					// String weeks_of_month = sdf_weeks_of_month.format(new java.util.Date());

					// 获取月份中的第几个星期几
					// SimpleDateFormat sdf_week_of_month = new SimpleDateFormat("现在是MM月的第F个E");
					// String week_of_month = sdf_week_of_month.format(new java.util.Date());

					weakReference.get().mTvShow.setText(date + "\n" + time24 + "\n" + time_zone);
				}
			}
		}
	};

	public void click(View v) {
		// 每隔一毫秒向 Hander 发送一条消息
		mTimer = new Timer();
		mTimer.schedule(new TimerTask() {
				@Override
				public void run() {
					Message message=new Message();
					message.what = 0;
					mHandler.sendMessage(message);
				}
			}, 0, 1);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mTimer != null) {
			mTimer.cancel();
		}
		mHandler.removeCallbacksAndMessages(null);
	}
}
