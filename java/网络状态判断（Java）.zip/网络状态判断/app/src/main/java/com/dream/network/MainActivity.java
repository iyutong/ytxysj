package com.dream.network;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.util.*;
import android.widget.*;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		TextView tv=findViewById(R.id.mainTextView1);
		int netWorkType=getAPNType(this);
		if (netWorkType == -1) {
			tv.setText("未连接网络");
		} else if (netWorkType == 1) {
			tv.setText("wifi网络");
		} else if (netWorkType == 2) {
			tv.setText("移动网络");
		}
    }

	/**

	 * 获取当前的网络状态  -1：没有网络  1：WIFI网络 2：移动网络  
	 * @param context  
	 * @return
	 */ 
	public static int getAPNType(Context context) {  
		int netType = -1;  
		ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);  
		NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();  
		if (networkInfo == null) {  
			return netType;  
		}  
		int nType = networkInfo.getType();  
		if (nType == ConnectivityManager.TYPE_MOBILE) {  
			netType = 2;  
		} else if (nType == ConnectivityManager.TYPE_WIFI) {  
			netType = 1;  
		}  
		return netType;  
	} 
}
