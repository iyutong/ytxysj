# Pt

[![License](https://img.shields.io/github/license/pansong291/Pt.svg)](LICENSE)
[![Latest Release](https://img.shields.io/github/release/pansong291/Pt.svg)](../../releases)
[![All Releases Download](https://img.shields.io/github/downloads/pansong291/Pt/total.svg)](../../releases)

获取图片上某点的颜色值

[download/下载](https://github.com/pansong291/Pt/releases)
