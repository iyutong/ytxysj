package com.xiayu.bmob.demo;
import cn.bmob.v3.BmobObject;

public class update extends BmobObject
{
	private String banben;
	private String title;
	private String message;
	private String downloadlink;
	
	//版本号
	public void setbanben (String banben){
		this.banben = banben;
	}
	
	public String getbanben(){
		return banben;
	}
	
	
	//标题
	public void settitle (String title){
		this.title = title;
	}

	public String gettitle(){
		return title;
	}
	
	
	//更新内容
	public void setmeessage (String message){
		this.message = message;
	}

	public String getmessage(){
		return message;
	}
	
	
	//新版本下载链接
	public void setdownloadlink (String downloadlink){
		this.downloadlink = downloadlink;
	}

	public String getdownloadlink(){
		return downloadlink;
	}
	
	
}
