package com.xiayu.bmob.demo;

import android.app.*;
import android.os.*;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.FindListener;
import java.util.List;
import android.content.DialogInterface;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.view.Window;
import android.view.WindowManager;
import android.view.Display;
import android.widget.TextView;
import com.xiayu.bmob.demo.Download;
import com.xiayu.bmob.demo.AutoInstall;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;



/*
 Demo来自过客网夏雨提供
 转截请注明来源，谢谢合作
 不懂可以加入我们交流群询问
 欢迎加入过客网程序缘-开发中，群号码：629232802
 或者加我QQ2500836773
 */




public class MainActivity extends Activity 
{
	
	private TextView jd;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		Button Button= (Button)findViewById(R.id.mainButton);
		Button.setOnClickListener(new OnClickListener(){

			
				@Override
				public void onClick(View p1)
				{
					final AlertDialog dia = new AlertDialog.Builder(MainActivity.this).create();  
					dia.show();  
					dia.setCancelable(false);
					Window window = dia.getWindow();  
					window.setContentView(R.layout.xiazai); 
					WindowManager m = MainActivity.this.getWindowManager();
					Display d = m.getDefaultDisplay(); // 获取屏幕宽、高度
					WindowManager.LayoutParams params = window.getAttributes();  
					params.width = (int) (d.getWidth() * 0.8);
					window.setAttributes(params);//此句代码一定要放在show()后面，否则不起作用  
					dia.setCanceledOnTouchOutside(false); 
					jd = (TextView)window.findViewById(R.id.jd);
					Download down=new Download();
					down.setondown(new Download.ondown()
						{
							@Override
							public void downing(int len, int oklen)
							{
								jd.setText("下载进度：" + (int)(((double)oklen / (double)len) * 100) + "%");
							}
							@Override
							public void downok(String ruest)
							{
								dia.dismiss();
								//下载完成，安装apk
								AutoInstall.setUrl(Environment.getExternalStorageDirectory()
												   + "/SRDownload/bmob文件上传工具.apk");
								AutoInstall.install(MainActivity.this);
							}
						});

					down.dowmFile("http://bmob-cdn-12101.b0.upaiyun.com/2017/10/11/ae7b94d5ddf24578a06ede7221b75859.apk", "/mnt/sdcard/SRDownload/" + "bmob文件上传工具.apk");
					
				}
			});
		
		
		//初始化bmobkey
		Bmob.initialize(MainActivity.this, "your APP id");



		//获取bmob数据
		BmobQuery<update>up = new BmobQuery<update>();//new 一个对象
		//获取update表数据
		up.findObjects(MainActivity.this, new FindListener<update>(){
//获取版本号(版本号是工程目录下的build文件中的versionName的版本号
				private String getAppVersion()
				{
					try
					{
						PackageManager pack = getPackageManager() ;
						PackageInfo info = pack.getPackageInfo(getPackageName(), 0) ;
						return info.versionName ;
					}
					catch (PackageManager.NameNotFoundException e)
					{
						e.printStackTrace();
					}

					return null;
				}

				@Override
				public void onSuccess(List<update> p1)
				{
					for (update ups:p1)
					{
						//获取版本号
						String banbens = ups.getbanben();
						//获取标题
						String titles = ups.gettitle();
						//获取更新内容
						String messages = ups.getmessage();
						//获取下载链接
						final String downloadlinks = ups.getdownloadlink();

						String appversionNaAPP = getAppVersion();
						String appversion= (appversionNaAPP);


						//这里使用if else判断，如果表数据banben列中数据等于这个版本号1.0，那么就提示更新，else不更新
						if (banbens.equals(appversion))
						{
							//使用一个dialog来提示用户更新
							AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
							dialog.setTitle(titles);
							dialog.setMessage(messages);
							dialog.setNegativeButton("更新", new DialogInterface.OnClickListener(){

									

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										/*这里就是下载新版本的事件了，至于跳转浏览器下载，还是调用软件内下载就看自己项目需求了
										 我建议调用软件内下载用户体验更佳，但是比较麻烦，我现在录着视频，视频太大了，就后面补上
										 */

										/*
										 //跳转浏览器下载
										 Intent intent = new Intent();
										 intent.setData(Uri.parse(downloadlinks));
										 intent.setAction(Intent.ACTION_VIEW);
										 startActivity(intent);
										 */

										//软件内下载
										final AlertDialog dia = new AlertDialog.Builder(MainActivity.this).create();  
										dia.show();  
										dia.setCancelable(false);
										Window window = dia.getWindow();  
										window.setContentView(R.layout.xiazai); 
										WindowManager m = MainActivity.this.getWindowManager();
										Display d = m.getDefaultDisplay(); // 获取屏幕宽、高度
										WindowManager.LayoutParams params = window.getAttributes();  
										params.width = (int) (d.getWidth() * 0.8);
										window.setAttributes(params);//此句代码一定要放在show()后面，否则不起作用  
										dia.setCanceledOnTouchOutside(false); 
										jd = (TextView)window.findViewById(R.id.jd);
										Download down=new Download();
										down.setondown(new Download.ondown()
											{
												@Override
												public void downing(int len, int oklen)
												{
													jd.setText("下载进度：" + (int)(((double)oklen / (double)len) * 100) + "%");
												}
												@Override
												public void downok(String ruest)
												{
													dia.dismiss();
													//下载完成，安装apk
													AutoInstall.setUrl(Environment.getExternalStorageDirectory()
																	   + "/SRDownload/新版本APP.apk");
													AutoInstall.install(MainActivity.this);
												}
											});

										down.dowmFile(downloadlinks, "/mnt/sdcard/SRDownload/" + "新版本APP.apk");


									}});

						}
						else
						{
							toast("已经是最新版本");
						}
					}
				}

				@Override
				public void onError(int p1, String p2)
				{
					toast("检测更新失败");
				}


			});

    }

	private void toast(String p0)
	{
		Toast.makeText(MainActivity.this, p0, Toast.LENGTH_SHORT).show();
	}
}
