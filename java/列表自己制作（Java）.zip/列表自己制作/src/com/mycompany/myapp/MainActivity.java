package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.view.View.*;
import android.widget.AdapterView.*;

public class MainActivity extends Activity
{
	private ListView lt;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		lt=(ListView) findViewById(R.id.mainListView);
		lt.setAdapter(new ArrayAdapter<String>
		(this,android.R.layout.simple_expandable_list_item_1,
		new String[]{"按钮1","按钮2","按钮3"}));
		lt.setOnItemClickListener((new OnItemClickListener(){

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
			 {
				 if(p3==0){
					 Toast.makeText(MainActivity.this,"点击了按钮1",Toast.LENGTH_SHORT).show();
					 	 }
			else if(p3==1){
				Toast.makeText(MainActivity.this,"点击了按钮2",Toast.LENGTH_SHORT).show();	
			}
			else if(p3==2){
				Toast.makeText(MainActivity.this,"点击了按钮3",Toast.LENGTH_SHORT).show();
					 	 
			}
				 
				 
										  // TODO: Implement this method
				  }
				  }));
		
		
		
    }
}
