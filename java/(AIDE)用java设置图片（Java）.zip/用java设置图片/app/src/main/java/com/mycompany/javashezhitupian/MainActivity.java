package com.mycompany.javashezhitupian;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		ImageView a=(ImageView)findViewById(R.id.mainImageView);
		
		a.setImageResource(R.raw.aa);
		
		
    }
}


/****************************************
 *                                      *
 *                                      *
 *      微信号：heng1919196455           *
 *      小亨QQ：1919196455               *
 *      QQ群聊：234257176                *
 *                                      *
 ****************************************/