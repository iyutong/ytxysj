package com.scienjus.smartqq;

import com.scienjus.smartqq.Application;

public class TestApplication {
    public static void run() {
        String[] args = {};
        Application.main(args);
    }
}
