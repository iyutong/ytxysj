package com.mycompany.myapp2;

import android.app.*;
import android.os.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		setTheme(R.style.Blue);
        setContentView(R.layout.main);
		getActionBar().hide();//隐藏标题栏
    }
	
	public void green(View v)
	{
		//切换为绿色
		runOnUiThread(new Runnable()
			{

				@Override
				public void run()
				{
					// TODO: Implement this method
					setTheme(R.style.Green);
					setContentView(R.layout.main);
				}
			
		});
	}
	
	public void blue(View v)
	{
		runOnUiThread(new Runnable()
			{

				@Override
				public void run()
				{
					// TODO: Implement this method
					setTheme(R.style.Blue);
					setContentView(R.layout.main);
				}
			
		});
	}
	
}
