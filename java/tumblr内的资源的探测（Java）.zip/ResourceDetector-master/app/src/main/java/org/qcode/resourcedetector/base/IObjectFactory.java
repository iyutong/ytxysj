package org.qcode.resourcedetector.base;

/**
 * author
 * 2016/12/2.
 */

public interface IObjectFactory<T> {

    T createObject();
}
