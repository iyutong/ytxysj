package org.qcode.resourcedetector.detect.entities;

/***
 * author: author
 * created at 2017/7/30
 */
public interface ResourceType {
    String PIC = "pic";
    String VIDEO = "video";
}
