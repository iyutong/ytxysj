package org.qcode.resourcedetector.common;

/**
 * author
 * 2016/12/5.
 */

public class DetectErrorCode {
    public static final int OK = 0;

    public static final int ILLEGAL_PARAM = -1;

    public static final int URL_EXCLUDED = -2;

}
