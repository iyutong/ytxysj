package org.qcode.resourcedetector.detect.tumblr;

import org.qcode.resourcedetector.detect.AbsDetectHandler;

/***
 * author: author
 * created at 2017/7/30
 */
public class TumblrDetectHelper {

    public void detectResource() {

    }
}
