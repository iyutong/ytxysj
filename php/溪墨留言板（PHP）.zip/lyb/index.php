<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
<title>溪墨留言板</title>

<link rel="stylesheet" href="css/style.css" type="text/css" />

</head>
<body>

<div id="bt">
<center>
<div id="x">
<font size="+2" color="#FFFFFF">
<strong>溪墨留言板</strong>
</font>
</div>
</center>
</div>

<div>
<form action="fb.php" method="post">
<input type="text" id="nr" name="ys">

</input>
<font color="#FFFFFF">
<input type="submit" id="an" value="发表留言" style="color:#FFFFFF;font-size:20px">
</input>
</form>
</div>

<?php
$path = "lylb/";
 $dh = opendir($path);
 while(($d = readdir($dh)) != false){
 if($d=='.' || $d == '..'){
 continue;
 }
 
$ljtz = "lylb/".$d."/wz.txt";
$n = file_get_contents($ljtz); 
$u = date("Y-m-d H:i:s");

echo <<<abc
<center>
<div id="tw">

<font color="#FFFFFF">
<br>
<h4>$n<br>$d</h4>
<br>
</font>

</div>
</center>
abc;
}

?>

</body>
</html>
