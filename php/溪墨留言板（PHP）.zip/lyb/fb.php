<?php
$ys = $_POST["ys"];
$t = date("Y-m-d H:i:s");
$wjj = "lylb/".$t;
mkdir($wjj);

$wj = "lylb/".$t."/wz.txt";
$myfile = fopen($wj, "w");
fwrite($myfile,$ys); 
fclose($myfile); 

?>

<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />

<script language="javascript"> 
alert("发表成功！请返回刷新！"); 
</script>

<link rel="stylesheet" href="css/style.css" type="text/css" />
<title>发表成功</title>
</head>
<body>
</body>
</html>
