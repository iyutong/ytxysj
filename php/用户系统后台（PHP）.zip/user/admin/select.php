<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('../conn.php');

$sql="select * from tb_user";
$result=mysqli_query($link,$sql);
$num=mysqli_num_rows($result);
if($num>0){
    while($row=mysqli_fetch_array($result)){
        $list=$row['username'].'|'.$list;
    }
   $substr=substr($list, 0, -1);
    echo "{'code':'0','msg':'查询成功！','list':'$substr'}";
}else{
    exit('{"code":"1","msg":"暂无用户！"}');
}

/*
后台用户列表
提交网址:你的域名admin/select.php

返回
code=结果  0成功  1失败
msg=成功失败提示
username=用户账号
分割符 |
*/
?>