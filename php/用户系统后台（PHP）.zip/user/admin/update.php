<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷



use PhpMyAdmin\Server\Status;

require('../conn.php');

$username=$_POST['username'];
$password=$_POST['password'];
$integral=$_POST['integral'];
$status=$_POST['status'];
$name=$_POST['name'];
$qq=$_POST['qq'];

$sqli="select * from tb_user where username='".$username."'";
$results=mysqli_query($link,$sqli);
$nums=mysqli_num_rows($results);
if($nums>0){
    $row=mysqli_fetch_array($results);
        $sql="update tb_user set password='$password',integral='$integral',name='$name',qq='$qq' where username='".$username."'";
        $result=mysqli_query($link,$sql);
        if($result){
            echo '{"code":"0","msg":"修改成功！"}';
        }
        else{
            exit('{"code":"1","msg":"修改失败！"}');
        }
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}
/*
后台修改用户信息
提交网址:你的域名admin/update.php
username=用户账号
password=用户密码
integral=积分数量
status=状态 0正常 1封号(只能填两个值0,或1)
name=昵称
qq=qq

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>