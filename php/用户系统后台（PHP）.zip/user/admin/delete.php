<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('../conn.php');

$username=$_POST['username'];

$sql="delete from tb_user where username='".$username."'";
$result=mysqli_query($link,$sql);
if($result){
    echo'{"code":"0","msg":"删除成功！"}';
}else{
    exit('{"code":"1","msg":"删除失败！"}');
}

/*
后台删除用户
提交网址:你的域名admin/delete.php
username=用户账号

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>