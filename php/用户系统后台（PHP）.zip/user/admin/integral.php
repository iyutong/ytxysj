<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('../conn.php');

$username=$_POST['username'];
$integral=$_POST['integral'];
$sql="select * from tb_user where username='".$username."'";
$result=mysqli_query($link,$sql);
$num=mysqli_num_rows($result);
if($num>0){
    $row=mysqli_fetch_array($result);
    if(strpos($integral,'-')===false){
        $inte=$row['integral'] +=str_replace("+","",$integral);
        $sqlis="update tb_user set integral='$inte' where username='".$username."'";
        $results=mysqli_query($link,$sqlis);
        if($results){
            echo'{"code":"0","msg":"增加积分成功！"}';
        }else{
            exit('{"code":"1","msg":"增加积分失败！"}');
        }
    }else{
        $inte=$row['integral'] -=str_replace("-","",$integral);
        $sqlis="update tb_user set integral='$inte' where username='".$username."'";
        $results=mysqli_query($link,$sqlis);
        if($results){
            echo'{"code":"0","msg":"扣除积分成功！"}';
        }else{
            exit('{"code":"1","msg":"扣除积分失败！"}');
        }
    }
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}

/*
后台增减积分
提交网址:你的域名admin/integral.php
username=用户账号
integral=增减积分数量  正数为加分 负数为减分

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>