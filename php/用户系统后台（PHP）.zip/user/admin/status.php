<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷



require('../conn.php');

$username=$_POST['username'];

$sqli="select * from tb_user where username='".$username."'";
$results=mysqli_query($link,$sqli);
$nums=mysqli_num_rows($results);
if($nums>0){
    $row=mysqli_fetch_array($results);
        if($row['status']==0){
            $status=1;
            $sql="update tb_user set status='$status' where username='".$username."'";
            $result=mysqli_query($link,$sql);
            if($result){
                echo '{"code":"0","msg":"禁封成功！"}';
            }
            else{
                exit('{"code":"1","msg":"禁封失败！"}');
            }
        }else if($row['status']==1){
            $status=0;
            $sql="update tb_user set status='$status' where username='".$username."'";
            $result=mysqli_query($link,$sql);
            if($result){
                echo '{"code":"0","msg":"解封成功！"}';
            }
            else{
                exit('{"code":"1","msg":"解封失败！"}');
            }
        }
       
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}

/*
后台禁封/解封账号
提交网址:你的域名admin/status.php
username=用户账号

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>