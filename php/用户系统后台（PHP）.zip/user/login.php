<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('conn.php');
$username=$_POST['username'];
$password=$_POST['password'];

$sql="select * from tb_user where username='".$username."'";
$result=mysqli_query($link,$sql);
$num=mysqli_num_rows($result);
if($num>0){
    $row=mysqli_fetch_array($result);
    if($password==$row['password']){
        if($row['status']==0){
            $content=json_encode(array(
                "code"=>"0",
                "msg"=>"登录成功！",
                "username"=>$row['username'],
                "qq"=>$row['qq'],
                "name"=>$row['name'],
                "integral"=>$row['integral'],
                "sign_time"=>$row['sign_time'],
                "status"=>$row['status']
    ),JSON_UNESCAPED_UNICODE);
    echo $content;
        }else{
            exit('{"code":"1","msg":"账号异常！"}');
        }
    }else{
        exit('{"code":"1","msg":"密码错误！"}');
    }
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}

/*
登录
提交网址:你的域名/login.php
username=用户账号
password=用户密码

返回
code=结果  0成功  1失败
msg=成功失败提示
username=用户名
qq=qq
name=昵称
integral=积分
sign_time=签到时间
status=状态  0正常 1封号
*/
?>