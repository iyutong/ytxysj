<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('conn.php');
$username=$_POST['username'];
$password=$_POST['password'];
$qq=$_POST['qq'];
$name=$_POST['name'];

$sqli="select * from tb_user where username='".$username."'";
$results=mysqli_query($link,$sqli);
$nums=mysqli_num_rows($results);
if($nums>0){
    exit('{"code":"1","msg":"该账号已存在！"}');
}else{
$sql="insert into tb_user(username,password,name,qq) value('$username','$password','$name','$qq')";
$result=mysqli_query($link,$sql);
if($result){
    echo'{"code":"0","msg":"注册成功！"}';
}else{
    exit('{"code":"1","msg":"注册失败！"}');
}
}

/*
注册
提交网址:你的域名/register.php
username=用户账号
password=用户密码
qq=QQ号
$name=昵称

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>