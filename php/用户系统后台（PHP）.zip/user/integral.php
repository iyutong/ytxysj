<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷

require('conn.php');

$username=$_POST['username'];
$integral=$_POST['integral'];

$sql="select * from tb_user where username='$username'";
$result=mysqli_query($link,$sql);
$num=mysqli_num_rows($result);
if($num==0){
    exit('{"code":"1","msg":"账号不存在！"}');
}

$row=mysqli_fetch_array($result);
if($row['integral']-$integral<=-1){
    exit('{"code":"1","msg":"积分不足！"}');
}

$sqli="update tb_user set integral=integral-$integral where username='$username'";
$results=mysqli_query($link,$sqli);
if($results){
    echo '{"code":"0","msg":"扣除成功!"}';
}else{
    exit('{"code":"1","msg":"扣除失败！"}');
}

/*
使用积分
提交网址:你的域名/integral.php
username=用户账号
integral=积分数量

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>

