<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


$host="localhost";
$user=""; //数据库账号
$password=""; //数据库密码
$mysql=""; //数据库名

$link=mysqli_connect($host,$user,$password);

mysqli_select_db($link,$mysql);
mysqli_set_charset($link,'utf-8');
?>