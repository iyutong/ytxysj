<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('conn.php');

$username=$_POST['username'];
$password=$_POST['password'];
$newpassword=$_POST['newpassword'];
$name=$_POST['name'];

$sqli="select * from tb_user where username='".$username."'";
$results=mysqli_query($link,$sqli);
$nums=mysqli_num_rows($results);
if($nums>0){
    $row=mysqli_fetch_array($results);
    if($row['password']==$password){
        $sql="update tb_user set password='$newpassword',name='$name' where username='".$username."'";
        $result=mysqli_query($link,$sql);
        if($result){
            echo '{"code":"0","msg":"修改成功！"}';
        }
        else{
            exit('{"code":"1","msg":"修改失败！"}');
        }
    }else{
        exit('{"code":"1","msg":"原密码错误！"}');
    }
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}

/*
前台修改用户信息
提交网址:你的域名/update.php
username=用户账号
password=用户密码
newpassword=新密码

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>