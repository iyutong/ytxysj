<?php

//会沉QQ:913508228  简单用户系统，大佬勿喷


require('conn.php');

$username=$_POST['username'];
$password=$_POST['password'];
$integral=$_POST['integral'];

$sql="select * from tb_user where username='".$username."'";
$result=mysqli_query($link,$sql);
$num=mysqli_num_rows($result);
if($num>0){
    $row=mysqli_fetch_array($result);
    if($row['password']==$password){
        $sign_time=$row['sign_time'];
        $int=date('Y-m-d');
        if($sign_time!=$int){
            $sqli="update tb_user set integral=integral+$integral,sign_time='$int' where username='".$username."'";
            $results=mysqli_query($link,$sqli);
            if($results){
                  $content=json_encode(array(
                    "code"=>"0",
                    "msg"=>"签到成功！增加积分".$integral."！"
               ),JSON_UNESCAPED_UNICODE);
               echo $content;
            }else{
                exit('{"code":"1","msg":"签到失败！"}');
            }
        }else{
            exit('{"code":"1","msg":"今日已签到！"}');
        }
    }else{
        exit('{"code":"1","msg":"密码错误！"}');
    }
}else{
    exit('{"code":"1","msg":"账号不存在！"}');
}

/*
签到
提交网址:你的域名/sign.php
username=用户账号
password=用户密码
integral=签到赠送积分数量

返回
code=结果  0成功  1失败
msg=成功失败提示
*/
?>