<?php
header('Content-type:text/html;charset=utf-8');
require_once 'api.data.class.php';

$test = array(
    'a' => '可',
    'b' => '可',
    'c' => '有',
    'd' => '病',
);

Data::echoData(200, '提示', $test, 'xml');

//Data::echoData(200, '提示', $test, 'json');
//xml数据支持多维数组，注意数组的键名不得为数字。
//如果第四个参数不传值的话默认为json