<?php
class Data{
    /**
     * 输出格式化数据
     * param string $type 数据格式
     * param int $code 状态码
     * param string $message 提示信息
     * param array $data 数据内容
     */
    public static function echoData($code='', $message='', $data=array(), $type='json') {
        if ($type == 'json') {  //json方式
            echo self::json($code, $message, $data);
        } else if ($type == 'xml') {  //xml格式
            echo self::xml($code, $message, $data);
        } else {  //其他方式
            
        }
    }
    /**
     * 按json方式格式化数据
     * param array $data 预格式化的数据
     * return string 
     */
    public static function json($code, $message, $data) {
        if (is_array($data)) {
            $result = array(
                'code' => $code,
                'message' => $message,
                'data' => $data
            );
            return json_encode($result);
        } else {
            return null;
        }
    }
    /**
     * 按xml方式格式化数据
     * param array $data 预格式化的数据
     * return string 
     */
     public static function xml($code, $message, $data) {
         $content = array(
             'code' => $code,
             'message' => $message,
             'data' => $data,
         );
         header('Content-type:text/xml;charset=utf-8');
         $xml = '<?xml version="1.0" encoding="utf-8" standalone="yes" ?>';
         $xml .= "<root>";
         $xml .= self::toXml($content);
         $xml .= "</root>";
         echo $xml;
      }
      /**
       * 按xml方式格式化数据
       * param array $arr 预格式化的数据
       * return string 
       */
      public static function toXml($arr) {
         $result = '';
         foreach($arr as $key=>$value){
             $result .= "<{$key}>";
             $result .= is_array($value) ? self::toXml($value) : $value;
             $result .= "</{$key}>";
         }
         return $result;
     }
}