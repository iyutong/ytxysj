require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "PretendEditText"
activity.setContentView(loadlayout("layout"))

function apo.onClick()
取消焦点(app)
取消焦点(ap47p)
end

