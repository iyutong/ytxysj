require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.graphics.Color"
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "layout"
import "soosh"
activity.setTitle("MyApp")
--(1activity.setTheme(R.Theme_Google)
activity.setContentView(loadlayout(layout))
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0x00000000);
--activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
local mLayoutParams=ViewGroup.LayoutParams(-1,-1)
activity.Window.DecorView.addView(loadlayout(soosh),mLayoutParams)
hsn=this.getResources().getDimensionPixelSize( luajava.bindClass("com.android.internal.R$dimen")().status_bar_height )--获取状态栏高
linearParams = bbtn.getLayoutParams()
linearParams.height=hsn
bbtn.setLayoutParams(linearParams)
local lastX=0
local lastY=0
local vx=0
local vy=0
task(10,function()
  mpen.setY(-peg.getHeight()+hsn)
  mpes.onClick=function()
    acw=-peg.getHeight()+hsn
    mpes.setClickable(false)
    bbt.setVisibility(View.GONE) 
    ObjectAnimator().ofFloat(mcg,"rotation",{0,-45}).setDuration(300).start()
    ObjectAnimator.ofInt(mpes,"backgroundColor",{0xAF000000,0x00000000}).setDuration(300).setEvaluator(ArgbEvaluator()).start()
    ObjectAnimator().ofFloat(mpen,"Y",{0,acw,acw+100,acw,acw+50,acw+10,acw}).setDuration(500).start()
  end
  mpes.setClickable(false)
end)
mcg.onTouch=function(v,e) 
  local ry=e.getRawY()--获取触摸绝对Y位置    
  local rx=e.getRawX()--获取触摸绝对X位置
  if e.getAction() == MotionEvent.ACTION_DOWN then 
    local vy=ry-e.getY()--获取视图的Y位置      
    local vx=rx-e.getX()--获取视图的X位置           
    local lastY=ry--记录按下的Y位置         
    local lastX=rx--获取视图的X位置
    p=0
    uy,ux=mpen.getY(),e.getX()
  elseif e.getAction() == MotionEvent.ACTION_MOVE then 
    if math.abs(e.rawY-uy)>=2 then
      vs=math.abs((vy-e.rawY)/(os.clock()-p)/1000)
    end
    p=os.clock()
    vbg.setRotation(-((vx+(rx-lastX)-bvs.getWidth())/activity.getWidth())*90)
    vbg.setRotation(vbg.getRotation()+64)
    vbg.setPivotY(0)
    cgh.setRotation(vy+(ry-lastY))


    --y轴位置限制
    if vy+(ry-lastY)<=mpen.getHeight()-hsn then 
      bbt.setVisibility(View.GONE)
      mpen.setY((vy+(ry-lastY))-mpen.getHeight()+hsn)--移动的相对位置
      alpha = (150+(150 * ((vy+(ry-lastY))/peg.getHeight())));
      mpes.setBackgroundColor(Color.argb(alpha,0,0,0))
      if vy+(ry-lastY)<=peg.getHeight() then
        mpes.setBackgroundColor(Color.argb(0,0,0,0))
        mpen.setY(-(peg.getHeight()-hsn))
      end 
    else
      bbt.setVisibility(View.VISIBLE)
      mpen.setY((vy+(ry-lastY)-(mpen.getHeight()-hsn))/3)--移动的相对位置
      mpes.setBackgroundColor(Color.argb(180,0,0,0))
      --mpen.setY(0)
    end

  elseif e.getAction() == MotionEvent.ACTION_UP then 
    if vbg.getRotation()<0 then
      ObjectAnimator().ofFloat(vbg,"rotation",{vbg.getRotation(),vbg.getRotation()/4,-vbg.getRotation()/6,vbg.getRotation()/8,0}).setDuration(1000).start()
    else
      ObjectAnimator().ofFloat(vbg,"rotation",{vbg.getRotation(),vbg.getRotation()/3,-vbg.getRotation()/3,vbg.getRotation()/10,-vbg.getRotation()/15,vbg.getRotation()/20,0}).setDuration(1000).start()
    end
    if mpen.getY()~=0 and mpen.getY()~=-peg.getHeight()+hsn then
      if mpen.getY()<=-peg.getHeight()/3 then
        backgrounds = mpes.getBackground(); 
        mpes.setClickable(false)
        ObjectAnimator().ofFloat(mcg,"rotation",{0,45}).setDuration(500).start()
        ObjectAnimator.ofInt(mpes,"backgroundColor",{backgrounds.getColor(),0x00000000}).setDuration(vs).setEvaluator(ArgbEvaluator()).start()
        ObjectAnimator().ofFloat(mpen,"Y",{mpen.getY(),-peg.getHeight()+hsn}).setDuration(vs).start()
      else
        mpes.setClickable(true)
        background = mpes.getBackground();
        ObjectAnimator().ofFloat(mcg,"rotation",{45,0}).setDuration(500).start()
        ObjectAnimator.ofInt(mpes,"backgroundColor",{background.getColor(),0xAF000000}).setDuration(vs).setEvaluator(ArgbEvaluator()).start()
        ObjectAnimator().ofFloat(mpen,"Y",{mpen.getY(),0,-200,0,-50,0,-30,0}).setDuration(vs*2).start()
      end
    else
      if mpen.getY()<=-peg.getHeight()+hsn then
        mpen.setClickable(false)
        ObjectAnimator().ofFloat(mcg,"rotation",{0,45}).setDuration(500).start()
      else
        mpes.setClickable(true)
        ObjectAnimator().ofFloat(mcg,"rotation",{45,0}).setDuration(500).start()
      end

      if ux==e.getX() then
        if mpen.getY()==0 then
          acw=-peg.getHeight()+hsn
          backgrounds = mpes.getBackground(); 
          bbt.setVisibility(View.GONE)
          mpes.setClickable(false)
          ObjectAnimator().ofFloat(mcg,"rotation",{45,0}).setDuration(300).start()
          ObjectAnimator.ofInt(mpes,"backgroundColor",{0xAF000000,0x00000000}).setDuration(300).setEvaluator(ArgbEvaluator()).start()
          ObjectAnimator().ofFloat(mpen,"Y",{0,acw,acw+100,acw,acw+50,acw+10,acw}).setDuration(500).start()
        else
          bbt.setVisibility(View.GONE)
          mpes.setClickable(true)
          ObjectAnimator().ofFloat(mcg,"rotation",{45,0}).setDuration(300).start()
          ObjectAnimator.ofInt(mpes,"backgroundColor",{0x00000000,0xAF000000}).setDuration(300).setEvaluator(ArgbEvaluator()).start()
          ObjectAnimator().ofFloat(mpen,"Y",{-peg.getHeight()+hsn,0,-300,0,-100,0,-50,0,-30,0}).setDuration(800).start()
        end
      end

    end
  end

end





function onCreateOptionsMenu(menu)
  menu.add("设置").onMenuItemClick=function(a)
  end
  menu.add("退出").onMenuItemClick=function(a)
  end
  menu.add("系统数据备份").onMenuItemClick=function(a)
  end
end