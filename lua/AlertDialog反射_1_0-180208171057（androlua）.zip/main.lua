require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
--[[
By_炫明：3510088586
QQ群：241449466
]]
alert=AlertDialog.Builder(this)
.setTitle("title")
.setMessage("message")
alert=alert.show()

field=Class.forName("android.app.AlertDialog").getDeclaredField("mAlert")
field.setAccessible(true)
field2=field.get(alert)
field3=field2.getClass().getDeclaredField("mTitleView")
field3.setAccessible(true)
tv=field3.get(field2)
import "android.graphics.Color"
tv.setText("反射")
tv.setTextColor(Color.RED)
tv.setTextSize(35)
tv.setBackgroundColor(Color.BLACK)
field=Class.forName("android.app.AlertDialog").getDeclaredField("mAlert")
field.setAccessible(true)
field2=field.get(alert)
field3=field2.getClass().getDeclaredField("mMessageView")
field3.setAccessible(true)
tv=field3.get(field2)
tv.setText("一个反射AlertDialog的例子")
tv.setTextColor(Color.WHITE)
tv.setBackgroundColor(Color.BLUE)