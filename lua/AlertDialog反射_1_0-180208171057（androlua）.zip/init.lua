appname="AlertDialog反射"
appver="1.0"
packagename="com.androlua.demo"
theme="Theme_DeviceDefault_Light_NoActionBar"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
