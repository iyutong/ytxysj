require "import"
import "java.security.MessageDigest"
import "android.util.Base64"
import"android.media.MediaPlayer"

--作者：星乂尘 1416165041
--api接口由某个不愿透露姓名的老铁提供

--id,key去讯飞平台申请，语音合成WebAPI
--需要把服务器ip添加到白名单
id=""
key=""

api="http://z.cx5l.com"
per="xiaoyan" --发音人 aisjiuxu,aisbabyxu……
spd=50 --音速 0-100
pit=50 --音频 0-100
txt="测试讯飞文字转语音"
path="/sdcard/AndroLua/s2v.mp3"

--这里有个巨坑，java的base64居然有换行，坑死我了
function base64(a)
  a=String(a).getBytes()
  a=Base64.encodeToString(a,Base64.DEFAULT)
  a=a:gsub("\n","")
  return a
end

function md5(s)
  local class=MessageDigest.getInstance("md5")
  local s,bs="",luajava.astable(class.digest(String(s).getBytes()))
  for _,v in ipairs(bs) do
    s=s..string.format("%02x",v&255)
  end
  return s
end

function play(pa)
  local music_m=MediaPlayer()
  music_m.reset()
  music_m.setDataSource(pa)
  music_m.prepare()
  music_m.start()
end

curTime=tostring(os.time())
param=string.format([[{"auf":"audio/L16;rate=8000",
"voice_name":"%s","speed":"%s","volume":"100","pitch":"%s","aue":"lame"}]],
per,spd,pit)
param=base64(param)
checkSum=md5(key..curTime..param)

data={s=txt,t=curTime,p=param,c=checkSum,i=id}

Http.post(api,data,function(e,f)
  if e==200 then
    if #f>1024 then
      fs=io.open(path,"w")
      fs:write(f)
      fs:close()
      print"转换成功"
      play(path)
     else
      code=f:match'"code":"(%d+)",'
      if code=="-1" then
        print"api异常…"
       elseif code=="10105" then
        print("禁用的ip:",f)
       elseif code=="11201" then
        print"今日api调用次数已达上限…"
       else
        print("Error：",f)
      end
    end
   elseif e==-1 then
    print"没联网？"
   else
    print("服务器挂了：",e,f)
  end
end)





