require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')


--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))


h.onClick=function(v)
  

import "android.content.Intent"
local intent= Intent(Intent.ACTION_PICK)
intent.setType("image/*")
this.startActivityForResult(intent, 1)
-------

--回调
function onActivityResult(requestCode,resultCode,intent)
  if intent then

    local cursor =this.getContentResolver ().query(intent.getData(), nil, nil, nil, nil)
    cursor.moveToFirst()
    import "android.provider.MediaStore"
    local idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
    fileSrc = cursor.getString(idx)
    bit=nil
    --fileSrc回调路径路径
    import "android.graphics.BitmapFactory"
    bit =BitmapFactory.decodeFile(fileSrc)
    --bit
    import "com.nirenr.Color"
    import "android.graphics.Color"
    import "android.graphics.Shader"
    import "android.graphics.LinearGradient"
    import "android.graphics.BitmapShader"
    shader = BitmapShader(
    bit,
    Shader.TileMode.REPEAT,
    Shader.TileMode.REPEAT);
    a.getPaint().setShader(shader);

  end
end

end




