require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.song.refreshview.PullToRefreshView"
import "com.song.refreshview.PullToRefreshView$OnRefreshListener"
import "android.graphics.Color"
import "android.view.animation.LinearInterpolator"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))

pull.setColorSchemeColors({0xffff0000,0xff00CB00,0xff0000ff});
pull.setSmileStrokeWidth(10);
pull.setSmileInterpolator(LinearInterpolator());
pull.setSmileAnimationDuration(2500);

pull.onRefresh=function()
  pull.setRefreshing(true)
  task(8000,function()
  pull.setRefreshing(false)
  end)
end

