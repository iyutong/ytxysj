appname="微笑下拉刷新"
appver="1.0"
packagename="com.happy"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
