require "import"
import "android.*"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

activity.setContentView(loadlayout("layout"))
activity.setTitle("Hello world")

--工程目录导入文件
import "two.vpn.out.kill"
ti=Ticker()
ti.Period=1000
ti.onTick=function()
    --判断当前是否使用VPN
if(kill.isVpnUsed())then
  --结束程序
  --os.exit()
  zt.setText("您正在使用VPN")
 else
  zt.setText("您没有在使用VPN")
end
end
--启动Ticker定时器
ti.start()

function onDestroy()
  --退出时停止定时器
  ti.stop()
end