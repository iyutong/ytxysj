require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "android.graphics.Color"
import "android.graphics.drawable.*"

activity.setContentView(loadlayout"layout")
--状态选择器
stateListDrawable = StateListDrawable()
--按下时的效果
pressedDrawable = GradientDrawable();
--也可以自定义
pressedDrawable.setColor(Color.parseColor("#ff27003a"));
--pressedDrawable.setColor(Color.DKGRAY);
pressedDrawable.setShape(GradientDrawable.RECTANGLE);
--给状态选择器添加状态
stateListDrawable.addState({android.R.attr.state_pressed},pressedDrawable)
grid.setSelector(stateListDrawable)
--LuaAdapter(Lua适配器)
--创建自定义项目视图
item={
  LinearLayout;
  gravity="center";
  layout_width="130dp";
  layout_height="130dp";
  {
    CardView;
    radius="5dp";
    CardElevation="2dp";
    layout_width="100dp";
    layout_height="100dp";
    {
      LinearLayout;
      gravity="center";
      orientation="vertical";
      layout_width="fill";
      layout_height="fill";
      {
        ImageView;
        id="img";
        layout_width="50dp";
        scaleType="fitXY";
        layout_height="50dp";
      };
      {
        TextView;
        id="bt";
        text="标题内容";
      };
    };
  };
};




--创建项目数组
data={}

--创建适配器
adp=LuaAdapter(activity,data,item)

--添加数据
adp.add{img="gaoxiao.png",bt="搞笑短视频"}
adp.add{img="kuaishou.png",bt="快手视频解析"}
adp.add{img="gengduo.png",bt="更多功能"}
adp.add{img="gaoxiao.png",bt="搞笑短视频"}
adp.add{img="kuaishou.png",bt="快手视频解析"}
adp.add{img="gengduo.png",bt="更多功能"}

--设置适配器
grid.Adapter=adp

--项目被单击
grid.onItemClick=function(l,v,p,i)
  print(v.Tag.bt.Text)
end