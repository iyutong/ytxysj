require"import"
import "module"
import "android.os.*"
import "android.app.*"
import "android.view.*"
import "android.net.Uri"
import "android.widget.*"
import "android.content.Intent"

--工程链接写在 init.lua 的projecturl里，必须以/结尾
--工程布局文件必须放layout文件夹里，lua文件和layout目录在根目录，像下面这样
--[[
  根目录：
       main.lua
       main2.lua
layout目录：
       main.aly
       main2.aly
]]
--网络工程中的setContentView和newActivity必须用this.不能用activity.
this.setContentView(loadlayout("main"))
