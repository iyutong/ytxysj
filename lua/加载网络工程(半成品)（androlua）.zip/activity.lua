require"import"
import "module"
import "android.os.*"
import "android.app.*"
import "android.view.*"
import "android.net.Uri"
import "android.widget.*"
import "android.content.Intent"


this.setContentView(loadlayout(...))
