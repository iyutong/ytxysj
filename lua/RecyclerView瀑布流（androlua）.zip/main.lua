require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.support.v7.widget.*"




--请使用 androlua+ Supper版,本群内有,否则报错


layout={
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    RecyclerView,
    layout_height="fill",
    layout_width="fill",
    background="#000000",
    id="rv",
  },
}

activity.setContentView(loadlayout(layout))



data={
  "http://cdn.u1.huluxia.com/g3/M00/DA/55/wKgBOVs-1x2AU756AAAYwFUWLs0981.png",
  "http://cdn.u1.huluxia.com/g3/M02/B5/8A/wKgBOVrdjQyALmvSAAAoZUokr5c002.png",
  "http://cdn.u1.huluxia.com/g3/M03/5F/D9/wKgBOVtfKpaANYdQAAANge7bEZE019.png",
  "http://cdn.u1.huluxia.com/g3/M02/B3/58/wKgBOVtyTNGAAoJMAAAV73mPOfU422.png",
  "http://cdn.u1.huluxia.com/g3/M02/26/B2/wKgBOVqyGLmAXcK-AAAXuJYa3VU143.png",
  "http://cdn.u1.huluxia.com/g3/M03/FA/6B/wKgBOVtHK3SAeLQiAAAa3kZLOOA424.jpg",
  "http://cdn.u1.huluxia.com/g3/M02/BA/A3/wKgBOVtz936AdN_1AABDI_WGThg843.png",
  "http://cdn.u1.huluxia.com/g3/M03/3A/C5/wKgBOVtW5MiAcCW3AAAK8yboJ5A683.png",
  "http://cdn.u1.huluxia.com/g3/M02/BB/25/wKgBOVs16NeAZfHCAAAYjAxFfrc997.jpg",
  "http://cdn.u1.huluxia.com/g1/M00/AF/9F/wKgBB1aeB_OAGC81AAAfmwXAwIQ24.jpeg",
  "http://cdn.u1.huluxia.com/g1/M00/AF/BD/wKgBB1aeCzeAUCF0AAAbEQQKV9A26.jpeg",
  "http://cdn.u1.huluxia.com/g3/M03/E1/17/wKgBOVrrF32AfIxbAAAdcQaTpio762.png",
  "http://cdn.u1.huluxia.com/g1/M00/97/43/wKgBB1b6Ll6ATWbYAAAR8LH_9kQ635.jpg",
  "http://cdn.u1.huluxia.com/g3/M03/03/77/wKgBOVqnN7GACA8HAAAMMn05mWE996.png",
  "http://cdn.u1.huluxia.com/g3/M00/D3/30/wKgBOVs8rvuADGd-AAAfmpNQqso363.png",
  "http://cdn.u1.huluxia.com/g3/M00/AF/63/wKgBOVtxRhCAJkUvAABCcwZdqnA049.png",
  "http://cdn.u1.huluxia.com/g3/M02/BF/01/wKgBOVt1CEmAGK-dAABDBIHhB0s823.png",
  "http://cdn.u1.huluxia.com/g1/M00/97/40/wKgBB1b6LY-AYUqjAAAcj22j2yw440.jpg",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E4/wKgBB1c0MOmAV3jmAAAeoUQvIw0976.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/B9/BE/wKgBOVre8jmAOMfiAABvS4AtfBw835.jpg",
  "http://cdn.u1.huluxia.com/g2/M01/B2/E2/wKgBa1iCBS6AJZRtAAAOuPVAvrY183.png",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E8/wKgBB1c0Mg2AEQrrAABo9azt0hQ392.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/9A/DA/wKgBOVsrSsmAFo3oAAAdJj2_ggU887.png",
  "http://cdn.u1.huluxia.com/g3/M03/A9/2B/wKgBOVtv1oSAdNs9AAAs6UtPuto575.png",
  "http://cdn.u1.huluxia.com/g3/M01/CC/78/wKgBOVt4MnqAWq-GAAAjecad6kE215.png",
  "http://cdn.u1.huluxia.com/g3/M02/4C/19/wKgBOVq951yAbYgOAABrK5EZUEc599.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/0C/6B/wKgBOVr5Qj2AbInXAAAXDX6IMww236.png",
  "http://cdn.u1.huluxia.com/g3/M02/47/BF/wKgBOVtZx3SAHv6HAAAihxXV3KU721.png",
  "http://cdn.u1.huluxia.com/g3/M03/A2/FE/wKgBOVoAJPGAEyIbAAAlf6rCHfA527.png",
  "http://cdn.u1.huluxia.com/g3/M00/B8/BF/wKgBOVreov-AbDH9AAA0m_Y5Ty0163.png",
  "http://cdn.u1.huluxia.com/g3/M00/B9/FD/wKgBOVs1ni-AIiAEAAAiulPnPf4659.png",
  "http://cdn.u1.huluxia.com/g2/M02/6A/89/wKgBa1klahyAK9kxAAAlsgRlxuI523.png",
  "http://cdn.u1.huluxia.com/g2/M03/9F/AC/wKgBa1mOa2uAe9Y1AAAjhiBeWMU473.png",
  "http://cdn.u1.huluxia.com/g3/M03/B4/B6/wKgBOVszo_qAbw2VAAA1uDZlgQc848.png",
  "http://cdn.u1.huluxia.com/g3/M02/9F/94/wKgBOVss3LWAHx4oAAAu77VGHNs034.png",
  "http://cdn.u1.huluxia.com/g3/M02/6D/EC/wKgBOVo87-CAC62JAABadr5NNQ8422.jpg",
  "http://cdn.u1.huluxia.com/g2/M02/72/5C/wKgBa1h0ql2AZdb8AABKLGGd4hE924.png",
  "http://cdn.u1.huluxia.com/g3/M03/41/A6/wKgBOVovilyABgbyAAAzZMkyJX0097.png",
  "http://cdn.u1.huluxia.com/g2/M01/B0/D8/wKgBa1nkYDqATeXwAAAcbX-QqV8784.png",
  "http://cdn.u1.huluxia.com/g3/M00/16/0D/wKgBOVpsRJqAN5QHAAAnxcWgBUk878.png",
  "http://cdn.u1.huluxia.com/g3/M02/55/54/wKgBOVsTl8yAKAI7AABmFRDLaQA589.png",
  "http://cdn.u1.huluxia.com/g2/M03/58/08/wKgBa1iiujOAd-cGAAApn4AsS28646.png",
  "http://cdn.u1.huluxia.com/g3/M03/48/5F/wKgBOVsPazOATvNtAAAkLy6yynU051.png",
  "http://cdn.u1.huluxia.com/g3/M03/EA/DB/wKgBOVoWwXeAVnTvAABe8mmSSy0027.png",
  "http://cdn.u1.huluxia.com/g2/M01/B2/E2/wKgBa1iCBS6AJZRtAAAOuPVAvrY183.png",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E8/wKgBB1c0Mg2AEQrrAABo9azt0hQ392.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/9A/DA/wKgBOVsrSsmAFo3oAAAdJj2_ggU887.png",
  "http://cdn.u1.huluxia.com/g3/M03/A9/2B/wKgBOVtv1oSAdNs9AAAs6UtPuto575.png",
  "http://cdn.u1.huluxia.com/g3/M01/CC/78/wKgBOVt4MnqAWq-GAAAjecad6kE215.png",
  "http://cdn.u1.huluxia.com/g3/M02/4C/19/wKgBOVq951yAbYgOAABrK5EZUEc599.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/0C/6B/wKgBOVr5Qj2AbInXAAAXDX6IMww236.png",
  "http://cdn.u1.huluxia.com/g3/M02/47/BF/wKgBOVtZx3SAHv6HAAAihxXV3KU721.png",
  "http://cdn.u1.huluxia.com/g3/M03/A2/FE/wKgBOVoAJPGAEyIbAAAlf6rCHfA527.png",
  "http://cdn.u1.huluxia.com/g3/M00/B8/BF/wKgBOVreov-AbDH9AAA0m_Y5Ty0163.png",
  "http://cdn.u1.huluxia.com/g3/M00/B9/FD/wKgBOVs1ni-AIiAEAAAiulPnPf4659.png",
  "http://cdn.u1.huluxia.com/g2/M02/6A/89/wKgBa1klahyAK9kxAAAlsgRlxuI523.png",
  "http://cdn.u1.huluxia.com/g2/M03/9F/AC/wKgBa1mOa2uAe9Y1AAAjhiBeWMU473.png",
  "http://cdn.u1.huluxia.com/g3/M03/B4/B6/wKgBOVszo_qAbw2VAAA1uDZlgQc848.png",
  "http://cdn.u1.huluxia.com/g3/M02/9F/94/wKgBOVss3LWAHx4oAAAu77VGHNs034.png",
  "http://cdn.u1.huluxia.com/g3/M02/6D/EC/wKgBOVo87-CAC62JAABadr5NNQ8422.jpg",
  "http://cdn.u1.huluxia.com/g2/M02/72/5C/wKgBa1h0ql2AZdb8AABKLGGd4hE924.png",
  "http://cdn.u1.huluxia.com/g3/M03/41/A6/wKgBOVovilyABgbyAAAzZMkyJX0097.png",
  "http://cdn.u1.huluxia.com/g2/M01/B0/D8/wKgBa1nkYDqATeXwAAAcbX-QqV8784.png",
  "http://cdn.u1.huluxia.com/g3/M00/16/0D/wKgBOVpsRJqAN5QHAAAnxcWgBUk878.png",
  "http://cdn.u1.huluxia.com/g3/M02/55/54/wKgBOVsTl8yAKAI7AABmFRDLaQA589.png",
  "http://cdn.u1.huluxia.com/g2/M03/58/08/wKgBa1iiujOAd-cGAAApn4AsS28646.png",
  "http://cdn.u1.huluxia.com/g3/M03/48/5F/wKgBOVsPazOATvNtAAAkLy6yynU051.png",
  "http://cdn.u1.huluxia.com/g3/M03/EA/DB/wKgBOVoWwXeAVnTvAABe8mmSSy0027.png",
  "http://cdn.u1.huluxia.com/g3/M00/DA/55/wKgBOVs-1x2AU756AAAYwFUWLs0981.png",
  "http://cdn.u1.huluxia.com/g3/M02/B5/8A/wKgBOVrdjQyALmvSAAAoZUokr5c002.png",
  "http://cdn.u1.huluxia.com/g3/M03/5F/D9/wKgBOVtfKpaANYdQAAANge7bEZE019.png",
  "http://cdn.u1.huluxia.com/g3/M02/B3/58/wKgBOVtyTNGAAoJMAAAV73mPOfU422.png",
  "http://cdn.u1.huluxia.com/g3/M02/26/B2/wKgBOVqyGLmAXcK-AAAXuJYa3VU143.png",
  "http://cdn.u1.huluxia.com/g3/M03/FA/6B/wKgBOVtHK3SAeLQiAAAa3kZLOOA424.jpg",
  "http://cdn.u1.huluxia.com/g3/M02/BA/A3/wKgBOVtz936AdN_1AABDI_WGThg843.png",
  "http://cdn.u1.huluxia.com/g3/M03/3A/C5/wKgBOVtW5MiAcCW3AAAK8yboJ5A683.png",
  "http://cdn.u1.huluxia.com/g3/M02/BB/25/wKgBOVs16NeAZfHCAAAYjAxFfrc997.jpg",
  "http://cdn.u1.huluxia.com/g1/M00/AF/9F/wKgBB1aeB_OAGC81AAAfmwXAwIQ24.jpeg",
  "http://cdn.u1.huluxia.com/g1/M00/AF/BD/wKgBB1aeCzeAUCF0AAAbEQQKV9A26.jpeg",
  "http://cdn.u1.huluxia.com/g3/M03/E1/17/wKgBOVrrF32AfIxbAAAdcQaTpio762.png",
  "http://cdn.u1.huluxia.com/g1/M00/97/43/wKgBB1b6Ll6ATWbYAAAR8LH_9kQ635.jpg",
  "http://cdn.u1.huluxia.com/g3/M03/03/77/wKgBOVqnN7GACA8HAAAMMn05mWE996.png",
  "http://cdn.u1.huluxia.com/g3/M00/D3/30/wKgBOVs8rvuADGd-AAAfmpNQqso363.png",
  "http://cdn.u1.huluxia.com/g3/M00/AF/63/wKgBOVtxRhCAJkUvAABCcwZdqnA049.png",
  "http://cdn.u1.huluxia.com/g3/M02/BF/01/wKgBOVt1CEmAGK-dAABDBIHhB0s823.png",
  "http://cdn.u1.huluxia.com/g1/M00/97/40/wKgBB1b6LY-AYUqjAAAcj22j2yw440.jpg",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E4/wKgBB1c0MOmAV3jmAAAeoUQvIw0976.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/B9/BE/wKgBOVre8jmAOMfiAABvS4AtfBw835.jpg",
  "http://cdn.u1.huluxia.com/g2/M01/B2/E2/wKgBa1iCBS6AJZRtAAAOuPVAvrY183.png",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E8/wKgBB1c0Mg2AEQrrAABo9azt0hQ392.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/9A/DA/wKgBOVsrSsmAFo3oAAAdJj2_ggU887.png",
  "http://cdn.u1.huluxia.com/g3/M03/A9/2B/wKgBOVtv1oSAdNs9AAAs6UtPuto575.png",
  "http://cdn.u1.huluxia.com/g3/M01/CC/78/wKgBOVt4MnqAWq-GAAAjecad6kE215.png",
  "http://cdn.u1.huluxia.com/g3/M02/4C/19/wKgBOVq951yAbYgOAABrK5EZUEc599.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/0C/6B/wKgBOVr5Qj2AbInXAAAXDX6IMww236.png",
  "http://cdn.u1.huluxia.com/g3/M02/47/BF/wKgBOVtZx3SAHv6HAAAihxXV3KU721.png",
  "http://cdn.u1.huluxia.com/g3/M03/A2/FE/wKgBOVoAJPGAEyIbAAAlf6rCHfA527.png",
  "http://cdn.u1.huluxia.com/g3/M00/B8/BF/wKgBOVreov-AbDH9AAA0m_Y5Ty0163.png",
  "http://cdn.u1.huluxia.com/g3/M00/B9/FD/wKgBOVs1ni-AIiAEAAAiulPnPf4659.png",
  "http://cdn.u1.huluxia.com/g2/M02/6A/89/wKgBa1klahyAK9kxAAAlsgRlxuI523.png",
  "http://cdn.u1.huluxia.com/g2/M03/9F/AC/wKgBa1mOa2uAe9Y1AAAjhiBeWMU473.png",
  "http://cdn.u1.huluxia.com/g3/M03/B4/B6/wKgBOVszo_qAbw2VAAA1uDZlgQc848.png",
  "http://cdn.u1.huluxia.com/g3/M02/9F/94/wKgBOVss3LWAHx4oAAAu77VGHNs034.png",
  "http://cdn.u1.huluxia.com/g3/M02/6D/EC/wKgBOVo87-CAC62JAABadr5NNQ8422.jpg",
  "http://cdn.u1.huluxia.com/g2/M02/72/5C/wKgBa1h0ql2AZdb8AABKLGGd4hE924.png",
  "http://cdn.u1.huluxia.com/g3/M03/41/A6/wKgBOVovilyABgbyAAAzZMkyJX0097.png",
  "http://cdn.u1.huluxia.com/g2/M01/B0/D8/wKgBa1nkYDqATeXwAAAcbX-QqV8784.png",
  "http://cdn.u1.huluxia.com/g3/M00/16/0D/wKgBOVpsRJqAN5QHAAAnxcWgBUk878.png",
  "http://cdn.u1.huluxia.com/g3/M02/55/54/wKgBOVsTl8yAKAI7AABmFRDLaQA589.png",
  "http://cdn.u1.huluxia.com/g2/M03/58/08/wKgBa1iiujOAd-cGAAApn4AsS28646.png",
  "http://cdn.u1.huluxia.com/g3/M03/48/5F/wKgBOVsPazOATvNtAAAkLy6yynU051.png",
  "http://cdn.u1.huluxia.com/g3/M03/EA/DB/wKgBOVoWwXeAVnTvAABe8mmSSy0027.png",
  "http://cdn.u1.huluxia.com/g2/M01/B2/E2/wKgBa1iCBS6AJZRtAAAOuPVAvrY183.png",
  "http://cdn.u1.huluxia.com/g1/M00/B9/E8/wKgBB1c0Mg2AEQrrAABo9azt0hQ392.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/9A/DA/wKgBOVsrSsmAFo3oAAAdJj2_ggU887.png",
  "http://cdn.u1.huluxia.com/g3/M03/A9/2B/wKgBOVtv1oSAdNs9AAAs6UtPuto575.png",
  "http://cdn.u1.huluxia.com/g3/M01/CC/78/wKgBOVt4MnqAWq-GAAAjecad6kE215.png",
  "http://cdn.u1.huluxia.com/g3/M02/4C/19/wKgBOVq951yAbYgOAABrK5EZUEc599.jpg",
  "http://cdn.u1.huluxia.com/g3/M00/0C/6B/wKgBOVr5Qj2AbInXAAAXDX6IMww236.png",
  "http://cdn.u1.huluxia.com/g3/M02/47/BF/wKgBOVtZx3SAHv6HAAAihxXV3KU721.png",
  "http://cdn.u1.huluxia.com/g3/M03/A2/FE/wKgBOVoAJPGAEyIbAAAlf6rCHfA527.png",
  "http://cdn.u1.huluxia.com/g3/M00/B8/BF/wKgBOVreov-AbDH9AAA0m_Y5Ty0163.png",
  "http://cdn.u1.huluxia.com/g3/M00/B9/FD/wKgBOVs1ni-AIiAEAAAiulPnPf4659.png",
  "http://cdn.u1.huluxia.com/g2/M02/6A/89/wKgBa1klahyAK9kxAAAlsgRlxuI523.png",
  "http://cdn.u1.huluxia.com/g2/M03/9F/AC/wKgBa1mOa2uAe9Y1AAAjhiBeWMU473.png",
  "http://cdn.u1.huluxia.com/g3/M03/B4/B6/wKgBOVszo_qAbw2VAAA1uDZlgQc848.png",
  "http://cdn.u1.huluxia.com/g3/M02/9F/94/wKgBOVss3LWAHx4oAAAu77VGHNs034.png",
  "http://cdn.u1.huluxia.com/g3/M02/6D/EC/wKgBOVo87-CAC62JAABadr5NNQ8422.jpg",
  "http://cdn.u1.huluxia.com/g2/M02/72/5C/wKgBa1h0ql2AZdb8AABKLGGd4hE924.png",
  "http://cdn.u1.huluxia.com/g3/M03/41/A6/wKgBOVovilyABgbyAAAzZMkyJX0097.png",
  "http://cdn.u1.huluxia.com/g2/M01/B0/D8/wKgBa1nkYDqATeXwAAAcbX-QqV8784.png",
  "http://cdn.u1.huluxia.com/g3/M00/16/0D/wKgBOVpsRJqAN5QHAAAnxcWgBUk878.png",
  "http://cdn.u1.huluxia.com/g3/M02/55/54/wKgBOVsTl8yAKAI7AABmFRDLaQA589.png",
  "http://cdn.u1.huluxia.com/g2/M03/58/08/wKgBa1iiujOAd-cGAAApn4AsS28646.png",
  "http://cdn.u1.huluxia.com/g3/M03/48/5F/wKgBOVsPazOATvNtAAAkLy6yynU051.png",
  "http://cdn.u1.huluxia.com/g3/M03/EA/DB/wKgBOVoWwXeAVnTvAABe8mmSSy0027.png"
}





--对于瀑布流的item,高度不能写死(自适应),不写

item={
  LinearLayout,
  layout_width="50%w",
  padding="20",
  {
    CardView,
    radius="15",
    {
      LinearLayout,
      orientation="vertical",
      Gravity="center",
      {
        ImageView;
        paddingTop="20",
        id="iv",
      };
      {
        TextView,
        paddingTop="20",
        Gravity="center",
        id="tv",
      },
    },
  },
}



adp=LuaRecycleAdapter(activity,item)
rv.setAdapter(adp)


--瀑布流管理器(第一个参数:几行,第二个参数:方向)
rv.setLayoutManager(StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL))



for k,v in pairs(data) do

  adp.add({iv=v,tv=v})

end




adp.setOnItemClickListener(LuaRecycleAdapter.OnItemClickListener({
  onItemClick=function(v,p)
    print("点击了第"..p.."个")
  end
}))





adp.setOnItemLongClickListener(LuaRecycleAdapter.OnItemLongClickListener{
  onItemLongClick=function(v,p)
    print("长按了第"..p.."个")
  end
})

