require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.a520wcf.yllistview.YLListView"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
--ttp.setFinalBottomHeight(100);
ttp.setFinalTopHeight(600);

sdr={
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    ImageView,
    scaleType="centerCrop";
    layout_width="fill",
    layout_height="fill",
    src="cfd.jpg",
  },
}
ttp.addHeaderView(loadlayout(sdr));
