appname="弹性列表"
appver="1.0"
packagename="com.YListView"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
