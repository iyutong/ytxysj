require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
import "android.content.*" 
import "android.net.*" 
function inapk(path)
intent = Intent(Intent.ACTION_VIEW); 
intent.setDataAndType(Uri.parse("file:///"..path), "application/vnd.android.package-archive")
intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
activity.startActivity(intent); 
end

function down(url,path)
  local tt=Ticker()
  tt.start()
   Http.download(url,path,function(code,data,cookie,header) 
    tt.stop() 
    jdv.Width=activity.Width
    jd.Text="100%"
    print("下载完成")
    inapk(path)
  end)
  function tt.onTick() 
  local f=io.open(path,"r")
    if f~=nil then
      local len=f:read("a")
      local s=#len/lens
      local w=activity.Width*s
      jdv.Width=w
     jd.Text=math.ceil(s*100).."%"
    end
  end
end


function big(url,path)
  import "java.net.URL"
    realUrl = URL(url)
  -- 打开和URL之间的连接
  con = realUrl.openConnection();
  -- 设置通用的请求属性
  con.setRequestProperty("accept", "*/*");
  con.setRequestProperty("connection", "Keep-Alive");
  con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
  lens=con.getContentLength()
  jd.Text="0%"
  down(url,path)
end



function ok.onClick()  
--local url="http://ucdl.25pp.com/fs08/2017/06/14/7/106_1a1b7bf0f26ce34d010ca3c9107dc994.apk?sf=22794465&vh=da9d353691491d2a61fa204e72c2f71d&sh=10&cc=1176080163&appid=6597754&packageid=300317412&md5=6555be3986aee3383cffb66362b8d536&apprd=6597754&pkg=com.bkl.activity&vcode=31&fname=%E6%88%92%E5%AE%A2&iconUrl=http%3A%2F%2Fandroid%2Dartworks%2E25pp%2Ecom%2Ffs08%2F2016%2F09%2F14%2F3%2F106%5F1d8666f0ec5641db05aa7e0057db5830%5Fcon%2Epng"
  local url="http://ucdl.25pp.com/fs08/2017/08/06/4/106_3b1e73772e2be1338784a0efa59f35d7.apk?sf=7836875&vh=32056ccc9e402e30f569a509702aa129&sh=10&cc=1149572909&appid=5976295&packageid=800520801&md5=5146c51ffec31e773208c3393a82f1bc&apprd=5976295&pkg=com.quwei.jieseba&vcode=61&fname=%E6%88%92%E6%92%B8%E5%90%A7&iconUrl=http%3A%2F%2Fandroid%2Dartworks%2E25pp%2Ecom%2Ffs08%2F2016%2F06%2F21%2F5%2F2%5F1410601977821c709afd0857981950df%5Fcon%2Epng"
  local path="/sdcard/AndroLua/pag.apk"
  big(url,path) 
end
