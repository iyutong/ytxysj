appname="下载文件进度条"
appver="1.0"
packagename="com.androlua.demo"
theme="Theme_DeviceDefault_Light_NoActionBar"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
