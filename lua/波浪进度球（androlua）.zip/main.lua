require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "com.myren.wave.WaveView"

import "layout"
--activity.setTitle('AndroLua+')
activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))

gay.setProgress(50, 10000)

--[[
// API三选一即可

        // 设置当前进度条，1~100之间
        gay.setProgress(80);
        
        // 在10秒钟内将进度条增长到50%
        gay.setProgress(50, 10000);
        
        // 自动增长进度从0到100
        gay.startIncrease();
]]



