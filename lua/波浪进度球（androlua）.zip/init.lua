appname="波浪进度球"
appver="1.0"
packagename="com.myren.wave"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
