require "import"
import "android.widget.*"
import "android.view.*"
--activity.setTitle("ALua+")

activity.setTheme(android.R.style.Theme_Material_Light_NoActionBar)

local function dialog(t)
  local dia=LuaDialog(activity)
  local view,b,b1,b2,b3=t.view,t.button,t.button1,t.button2,t.button3
  if view then
    dia.setView(loadlayout(view))
  end
  if b then
    dia.setButton(b[1],b[2])
   else
    if b1 then
      dia.setPositiveButton(b1[1],b1[2])
    end
    if b2 then
      dia.setNegativeButton(b2[1],b2[2])
    end
    if b3 then
      dia.setNeutralButton(b3[1],b3[2])
    end
  end
  t.view,t.button,t.button1,t.button2,t.button3=nil

  for k,v in pairs(t) do
    local k="set"..k:sub(1,1):upper()..k:sub(2,-1)
    dia[k](v)
  end
  return dia
end


dialog{
  title="标题",
  view={EditText,
    text="输入内容",
  },
  cancelable=false,
  button1={"确定",function(d) print(d.view.text) end},
  button2={"取消",function(d) print(d.view.text) end},
  button3={"其他",function(d) print(d.view.text) end},
}.show()




