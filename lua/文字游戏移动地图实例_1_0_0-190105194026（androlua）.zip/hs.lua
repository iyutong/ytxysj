function 移动(坐标)
坐标1=地图[坐标]
中.setText(坐标1)
  位置.setText("当前位置："..坐标1.."，坐标："..坐标)
  上坐标=地图[坐标-6]
  下坐标=地图[坐标+6]
  左坐标=地图[坐标-1]
  右坐标=地图[坐标+1]
  
  if 上坐标==nil then
       上.setText("") 
      else  
  上.setText(上坐标)
  end
  if 下坐标==nil then
     下.setText("")   
      else  
  下.setText(下坐标)
  end

  if 左坐标==nil then
        左.setText("")
      else  
  左.setText(左坐标)
  end
  if 右坐标==nil then
        右.setText("")
      else  
 右.setText(右坐标)
  end


  
  end