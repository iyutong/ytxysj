require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "hs"
activity.setTitle("MyApp")
--activity.setTheme(R.Theme_Google)
activity.setContentView(loadlayout"layout")
--流云：我就试试😂
地图={
  "村口","小路","小路","小路","小路",""
  ,"谁家","小路","小路","小路","小路","小路",""
  ,"小路","小明家","小路","小路",""}
--使用""分割y坐标
坐标=1
移动(坐标)
上.onClick=function()
if 上.getText()=="" then
 
 print("没路了")
 else
 
坐标=坐标-6
  移动(坐标)
  end
end

下.onClick=function()
if 下.getText()=="" then
 
 print("没路了")
 else
 
坐标=坐标+6
  移动(坐标)
  end
end

左.onClick=function()
if 左.getText()=="" then
 
 print("没路了")
 else
 
坐标=坐标-1
  移动(坐标)
  end
end

右.onClick=function()
if 右.getText()=="" then
 
 print("没路了")
 else
 
坐标=坐标+1
  移动(坐标)
  end
end

