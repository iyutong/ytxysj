require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "QQ"
import "dgh"
mainui=
--文件开始
--节点[LinearLayout]开始
{
LinearLayout;
layout_width="fill_parent";
layout_height="fill_parent";
orientation="vertical";
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="55dp";
layout_width="match_parent";
orientation="horizontal";
background="#00BDFF";
--节点[TextView]开始
{
TextView;
layout_height="wrap_content";
--textAppearance="?android:attr/textAppearanceMedium";
layout_width="wrap_content";
text="添加或注册账号";
textColor="#FFFFFF";
layout_gravity="center";
layout_marginLeft="120dp";
};
--节点[TextView]结束
--节点[TextView]开始
{
TextView;
layout_height="wrap_content";
--textAppearance="?android:attr/textAppearanceMedium";
layout_width="wrap_content";
text="取消";
layout_gravity="center";
layout_marginLeft="100dp";
textColor="#FEF8F8";
onClick="onqxButtonClick";
};
--节点[TextView]结束
};
--节点[LinearLayout]结束
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="wrap_content";
layout_width="match_parent";
orientation="vertical";
layout_marginTop="20dp";
background="#DADADA";
--节点[RelativeLayout]开始
{
RelativeLayout;
layout_height="wrap_content";
layout_width="wrap_content";
background="#F6F6F6F6";
--节点[EditText]开始
{
EditText;
layout_height="45dp";
layout_width="match_parent";
ems="10";
background="#F6F6F6F6";
hint="QQ号/手机号/邮箱";
--textColorHint="#B4B4B4";
id="@+id/zh";
lines="1";
layout_marginLeft="15dp";
textSize="16sp";
};
--节点[EditText]结束
};
--节点[RelativeLayout]结束
--节点[RelativeLayout]开始
{
RelativeLayout;
layout_height="wrap_content";
layout_width="wrap_content";
background="#F6F6F6F6";
layout_marginTop="0.5dp";
--节点[EditText]开始
{
EditText;
layout_height="45dp";
inputType="textPassword";
layout_width="match_parent";
ems="10";
background="#F6F6F6F6";
hint="密码";
--textColorHint="#B4B4B4";
id="@+id/mm";
lines="1";
layout_marginLeft="15dp";
textSize="16sp";
};
--节点[EditText]结束
};
--节点[RelativeLayout]结束
};
--节点[LinearLayout]结束
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="wrap_content";
layout_width="match_parent";
orientation="horizontal";
layout_marginTop="25dp";
--节点[Button]开始
{
Button;
layout_height="50dp";
layout_width="match_parent";
text="登陆";
layout_marginLeft="20dp";
layout_marginRight="20dp";
textColor="#FFF7F7";
id="dl";
background="#1fbaf3";
};
--节点[Button]结束
};
--节点[LinearLayout]结束
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="wrap_content";
layout_width="match_parent";
orientation="horizontal";
layout_marginTop="25dp";
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="wrap_content";
layout_width="wrap_content";
orientation="horizontal";
--节点[TextView]开始
{
TextView;
layout_height="wrap_content";
--textAppearance="?android:attr/textAppearanceSmall";
layout_width="wrap_content";
text="忘记密码？";
layout_marginLeft="20dp";
textColor="#00BDFF";
onClick="onwjmmButtonClick";
};
--节点[TextView]结束
};
--节点[LinearLayout]结束
--节点[LinearLayout]开始
{
LinearLayout;
layout_height="wrap_content";
layout_width="match_parent";
orientation="horizontal";
gravity="right";
--节点[TextView]开始
{
TextView;
layout_height="wrap_content";
--textAppearance="?android:attr/textAppearanceSmall";
layout_width="wrap_content";
text="新用户注册";
layout_marginRight="20dp";
textColor="#00BDFF";
onClick="onzcButtonClick";
};
--节点[TextView]结束
};
--节点[LinearLayout]结束
};
--节点[LinearLayout]结束
};
--节点[LinearLayout]结束
--文件结束
activity.setContentView(loadlayout(mainui))
function CircleButton(view,InsideColor,radiu)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable() 
  drawable.setShape(GradientDrawable.RECTANGLE) 
  drawable.setColor(InsideColor)
  drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu});
  view.setBackgroundDrawable(drawable)
end
jd=10
Id=dl
ys=0xFF1FBAF3
CircleButton(Id,ys,jd)
dgh("检测病毒中……")

a=0
while a~=100 do
a=a+1
  task(1000,function()
    local dl=AlertDialog.Builder(activity)
  .setView(loadlayout(QQ))
  
  dl.show()
  
  end)
    
  

end








