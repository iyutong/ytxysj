function dgh(np)
  f={
    LinearLayout;
    {

      CardView;
      radius="5dp";
      CardElevation="2dp";
      -- gravity="center";
      layout_margin="5dp";
      layout_width="fill";
      layout_height="30dp";
      background="#E1272727";
      {
        LinearLayout;
        layout_width="320dp";
        layout_gravity="center";
      };
      
      {
        TextView;
        text="text";
        layout_marginRight="10dp";
        layout_marginLeft="3dp";
        textSize="12dp";
        textColor="#FFFFFF";
        layout_gravity="center";
        id="nr";
      };
      {
        LinearLayout;
        layout_width="320dp";
        layout_gravity="center";
      };
    };
  };

  out=loadlayout(f)
  nr.Text=np
  local toast=Toast.makeText(activity,"text",Toast.LENGTH_SHORT).setView(out).setGravity(Gravity.TOP, 0, 20).show()
end