require "import"
import "android.widget.Button"
import "android.widget.ListView"
import "android.widget.LinearLayout"
import "android.support.design.widget.*"
import "android.support.v7.widget.*"
import "android.support.v4.view.*"
import "android.support.v4.widget.*"

swipeLayout={
  LinearLayout,
  layout_width="fill",
  layout_height="fill",
  orientation="vertical",
  {
    Toolbar,
    id="tb",
    title="SwipeRefreshLayout",
    titleTextColor="#FFFFFF",
    background="#2196f3",
    layout_width="fill",
    layout_height="54dp",
    },
  {
    SwipeRefreshLayout,
    layout_width="fill",
    layout_height="fill",
    id="srl",
  {
    ListView,
    layout_width="fill",
    layout_height="fill",
    id="lv",
    items={
      "1";
      "2";
    };
    },
  },
  }

activity.setTheme(R.style.BlueTheme)
activity.setContentView(loadlayout(swipeLayout))
--声明Toolbar是标题栏
activity.setSupportActionBar(tb)

Snackbar.make(lv,"下拉即刷新",600).show()

--添加菜单
function onCreateOptionsMenu(menu)
  menu.add("菜单1")
  menu.add("菜单2")
end

adp=lv.Adapter
function 加载列表()
  adp.clear()
  for i=1,50 do
    adp.add("项目"..i)
    end
  end

加载列表()

--设置SwipeRefreshLayout下拉刷新颜色
srl.setColorSchemeColors({0xff2196f3,0xff000000,0xff607d8b,0xFFFF5722,0xFF4CAF50})

--设置SwipeRefreshLayout刷新事件
srl.setOnRefreshListener(SwipeRefreshLayout.OnRefreshListener({
  onRefresh=function()
    task(1000,function()
      加载列表()
      print("刷新成功")
      srl.setRefreshing(false)
      end)
    end
  }))

