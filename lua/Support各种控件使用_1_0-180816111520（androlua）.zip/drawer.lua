require "import"
import "android.widget.Button"
import "android.widget.LinearLayout"
import "android.support.design.widget.*"
import "android.support.v4.view.*"
import "android.support.v4.widget.DrawerLayout"
import "android.support.v7.app.ActionBarDrawerToggle"
import "android.support.v7.widget.Toolbar"


drawerLayout={
  LinearLayout,
  layout_width="-1",
  layout_height="-1",
  {
    DrawerLayout,
    layout_width="-1",
    layout_height="-1",
    background="#ffffff",
    id="ok",
    {
      LinearLayout,
      layout_width="-1",
      layout_height="-1",
      orientation="vertical",
      {
        AppBarLayout,
        layout_width="-1",
        background="#fffffd",
        {
          Toolbar,
          title="App Beta",
          titleTextColor="#666666",
          background="?attr/colorPrimary",
          id="mdzz",
          layout_width="fill",
        },
        {
          TabLayout,
          id="tab",
          layout_width="-1",
        },
      },
    {
      Button,
      },
    },
    {
      NavigationView,
      layout_height="-1",
      layout_width="280dp",
      background="#ffffff",
      layout_gravity="left",
      id="nav",
    },
  },
}
--使用没有标题栏的AppCompat.Light主题,即NoActionBarTheme1
--[[
内置主题还有
AppTheme,即AppCompat.Light主题
DarkTheme,即AppCompat主题
NoActionBarTheme2,即没有标题栏的AppCompat主题
GrayBlueTheme
BlueTheme
BrownTheme
RedTheme
GreyTheme
PinkTheme
GreenTheme
OrangeTheme
TealTheme
PurpleTheme
]]
activity.setTheme(R.style.NoActionBarTheme1)
activity.setContentView(loadlayout(drawerLayout))
--[[设置状态栏颜色
function setStatusBarColor(color)
  if Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP then
    window = activity.getWindow();
    window.setStatusBarColor(color);
  end
end
setStatusBarColor(0xff1976D2)]]

--声明Toolbar是标题栏
activity.setSupportActionBar(mdzz)
--设置返回键可用
activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true)
--添加菜单
function onCreateOptionsMenu(menu)
  menu.add("菜单1")
  menu.add("菜单2")
end

--菜单选择事件
function onOptionsItemSelected(item)
  print(item.Title)
end

--关联返回键和侧滑
md=ActionBarDrawerToggle(activity,ok,mdzz,0,0)
--增加侧滑监听动画
ok.addDrawerListener(md)
md.syncState()

--添加侧滑菜单
la={
  LinearLayout,
  layout_height="160dp",
  layout_width="-1",
  background="#2196f3",
}
--设置侧滑头布局
nav.addHeaderView(loadlayout(la))
--添加侧滑第一个组id，第二个是itemid，第三个是顺序
nav.getMenu().add(0,0,1,"个人信息")
nav.getMenu().add(0,0,2,"账户")
nav.getMenu().add(0,0,3,"商城")

nav.getMenu().add(1,0,4,"设置")
nav.getMenu().add(1,0,4,"帮助")
nav.getMenu().add(1,0,4,"文档")

--设置NavigationView点击事件
nav.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener({
  onNavigationItemSelected=function(item)
    print(item.Title)
    end
  }))

--设置TabLayout项目
p1=tab.newTab().setText("项目一")
p2=tab.newTab().setText("项目二")
p3=tab.newTab().setText("项目三")
p4=tab.newTab().setText("项目四")
tab.addTab(p1)
tab.addTab(p2)
tab.addTab(p3)
tab.addTab(p4)
--设置项目二被选中
p2.select()
--设置Tab颜色,第一个参数时没选中时颜色,第二个参数是选中时颜色
tab.setTabTextColors(0xff666666,0xff000000)
--设置选中项下划线的颜色
tab.setSelectedTabIndicatorColor(0xff2196f3)
--设置选中项下划线的高度
--tab.setSelectedTabIndicatorHeight(4)
tab.addOnTabSelectedListener({
  --Tab被点击时
  onTabSelected=function(tabs)
    print(tabs.getText())
  end,
  --Tab没被点击时
  onTabUnselected=function(tabs)
  end,
  --Tab被重新点击时
  onTabReselected=function(tabs)
    --print "该Tab被重新点击"
  end})