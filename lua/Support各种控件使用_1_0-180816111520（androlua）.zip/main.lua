require "import"
import "android.widget.LinearLayout"
import "android.support.design.widget.*"
import "android.support.v4.widget.*"
import "android.support.v7.widget.*"
import "android.widget.Button"
import "com.androlua.support.*"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(R.style.OrangeTheme)
activity.setContentView(loadlayout(layout))

--设置FloatingActionButton属性
fab.setRippleColor(0x90000000)
--fab.setBackgroundColor(0xff2196f3)
--fab.setCompatElevation(10)
fab.setImageResource(R.drawable.search)

fab.onClick=function(v)
  print "点击了按钮"
  end

drawer.onClick=function(v)
  activity.newActivity("drawer")
  end

swipe.onClick=function(v)
  activity.newActivity("swipe")
  end
--Snackbar
sb.onClick=function(v)
  --第一个参数随便填个控件id就行，不管填哪个，都是在屏幕底边显示
  s=Snackbar.make(fab,"确定",1500)
  s.setAction("确定",function(v)
    print("点击了确定")
    end)
  s.show()
  end