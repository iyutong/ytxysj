appname="文件监听变化"
appver="1.0"
packagename="com.LuaFileObserver.demo"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
