require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))

lfo=LuaFileObserver(path).startWatching()
--创建文件监听并开始监听 
--LuaFileObserver(路径,监听类型) 
--当填了监听类型则只能监听你填的类型 不填则是全部类型
--多个监听类型用|隔开

lfo.onEvent=function(e,p)-- e 监听事件的类型  p 被改动的文件名称
  if e==LuaFileObserver.ACCESS then
    print(p.."文件被访问")
    elseif e==LuaFileObserver.MODIFY then
  print(p.."文件被改动")
  else
  lfo.stopWatching()--关闭监听
    end
end



--[[二. 监听的事件类型：

（1）ACCESS，即文件被访问。
（2）MODIFY，文件被修改。
（3）ATTRIB，文件属性被修改，如 chmod、chown、touch 等。
（4）CLOSE_WRITE，可写文件被 close。
（5）CLOSE_NOWRITE，不可写文件被 close。
（6）OPEN，文件被 open。
（7）MOVED_FROM，文件被移走,如 mv。
（8）MOVED_TO，文件被移来，如 mv、cp。
（9）CREATE，创建新文件。
（10）DELETE，文件被删除，如 rm。
（11）DELETE_SELF，自删除，即一个可执行文件在执行时删除自己。
（12）MOVE_SELF，自移动，即一个可执行文件在执行时移动自己。
（13）CLOSE，文件被关闭，等同于(IN_CLOSE_WRITE | IN_CLOSE_NOWRITE)。
（14）ALL_EVENTS，包括上面的所有事件。
]]