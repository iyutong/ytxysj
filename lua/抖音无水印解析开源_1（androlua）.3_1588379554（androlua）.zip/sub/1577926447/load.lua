
require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.support.*"
import "android.content.Intent"
import "android.net.Uri"

--修复软件漏洞
local hh={};webView.addJavascriptInterface(hh,'JsInterface');
local dump=nil;webView.addJavascriptInterface({},'JsInterface')

--文件缓存路径
下载目录=Environment.getExternalStorageDirectory().toString().."/Download/"

function xdc(url,path)
  require"import"
  import"java.net.URL"
  local ur =URL(url)
  import"java.io.File"
  file =File(path);
  local con = ur.openConnection();
  --con.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; U; Android 6.0.1; zh-cn; OPPO R9s Plus Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.134 Mobile Safari/537.36 OppoBrowser/4.9.3")
  --con.setRequestProperty("Host","streamoc.music.tc.qq.com")
  --con.setRequestProperty("Connection","keep-alive")
  --con.setRequestProperty("Accept-Encoding","gzip, deflate")
  local co = con.getContentLength();
  local is = con.getInputStream();
  local bs = byte[1024]
  local len,read=0,0
  import"java.io.FileOutputStream"
  local wj= FileOutputStream(path);
  len = is.read(bs)
  while len~=-1 do
    wj.write(bs, 0, len);
    read=read+len
    pcall(call,"ding",read,co)
    len = is.read(bs)
  end
  wj.close();
  is.close();
  pcall(call,"dstop",co)

end
function appDownload(url,path)
  thread(xdc,url,path)
end

function 软件内下载(title,url,path)
  local ts=true
  local wl=activity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE).getActiveNetworkInfo();
  if wl== nil then
    print("无法连接到服务器，请检查网络")
  else
    appDownload(url,path)
  end
  local layout={
    LinearLayout;
    layout_height="fill";
    layout_width="fill";
    orientation="vertical";
    {
      LinearLayout;
      layout_height="5dp";
      layout_width="fill";
      background="#FF3C8BDA";
    },
    {
      LinearLayout;
      orientation='vertical';--纵向或横向
      layout_width="fill";
      layout_height="fill";
      layout_gravity="center";--重力属性
      ScrollView,--纵向滑动
      VerticalScrollBarEnabled=false;--隐藏纵向滑条
      layout_marginTop="0dp",
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="28dp";
      orientation="horizontal";
      gravity="center";
      {
        TextView;
        textSize="18sp";
        text="提示";
        gravity="center";
        textStyle="bold";
        layout_width="fill";
        layout_height="wrap";
      };
    };
    {
      LinearLayout;
      layout_height="fill";
      layout_width="fill";
      gravity="center",
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="-1";--宽度
        layout_height="1dp";
        backgroundColor="#FFF3F3F3";--背景色
      };
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="wrap";
      orientation="vertical";
      {
        TextView;
        text="文件名称："..title;
        layout_width="fill";
        layout_height="wrap";
        layout_marginTop="5dp";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
        textSize="15sp";
      };
      {
        TextView;
        id="appdowninfo";
        text="已经下载：0MB/0MB\n\n下载状态：准备下载...";
        layout_width="fill";
        layout_height="wrap";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
        textSize="15sp";
      };
      {
        ProgressBar;
        id="进度条";
        progress=0,
        style="?android:attr/progressBarStyleHorizontal";
        layout_width="fill";
        layout_height="wrap";
        layout_marginRight="15dp";
        layout_marginLeft="15dp";
        layout_marginBottom="15dp";
      };
    };
    {
      LinearLayout;
      layout_height="fill";
      layout_width="fill";
      gravity="center",
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="-1";--宽度
        layout_height="1dp";
        backgroundColor="#FFF3F3F3";--背景色
      };
    };
    {
      LinearLayout;
      layout_width="fill";
      layout_height="wrap";
      orientation="horizontal";
      {
        FrameLayout;
        layout_width="fill";
        layout_height="wrap";
        layout_weight="1";
        id="openfile";
        visibility=0,
        {
          TextView;
          id="打开文件";
          text="";
          textColor="#FF3C8BDA";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap";
          layout_height="wrap";
          gravity="center";
          layout_gravity="center";
        };
      };
      {
        TextView;--钮扣
        text="";--文本
        textSize="15";--文本大小
        textColor="#FF000000";
        layout_width="1dp";--宽度
        layout_height="-1";
        backgroundColor="#FFF3F3F3";--背景色
      };
      {
        FrameLayout;
        layout_width="fill";
        layout_height="wrap";
        layout_weight="1";
        {
          TextView;
          id="后台下载";
          text="后台下载";
          textColor="#FF3C8BDA";
          style="?android:attr/buttonBarButtonStyle";
          layout_width="wrap";
          layout_height="wrap";
          gravity="center";
          layout_gravity="center";
        };
      };
    };
  };


  dldown=LuaDialog(this)
  --.setTitle("标题")

  dldown.setView(loadlayout(layout))
  --.setPositiveButton("确定",{onClick=function(v) print(edit.Text)end})
  --.setNegativeButton("取消",nil)
  .setCanceledOnTouchOutside(false)
  .setCancelable(true)
  dldown.show()
  import "android.graphics.drawable.ColorDrawable"
  --dialog1.getWindow().setBackgroundDrawable(ColorDrawable(0x00000000));


  进度条.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFF3C8BDA,PorterDuff.Mode.SRC_ATOP))

  function ding(a,b)--已下载，总长度(byte)
    appdowninfo.Text="下载进度："..string.format("%0.2f",a/1024/1024).."MB/"..string.format("%0.2f",b/1024/1024).."MB".."\n\n下载状态：正在下载..."
    进度条.progress=(a/b*100)
  end

  function dstop(c)--总长度
    if ts then
      appdowninfo.Text="文件大小："..string.format("%0.2f",c/1024/1024).."MB".."\n\n下载目录："..下载目录
      后台下载.setText("下载完成")
      luajava.clear(ts)
    else
      print(title.."已下载")
      luajava.clear(ts)
    end
  end

  后台下载.onClick=function()
    dldown.dismiss()
    luajava.clear(dldown,布局)
    ts=nil
    if 后台下载.getText()=="后台下载" then
      print("正在下载...")
    end
  end
  
打开文件.setVisibility(View.GONE)


end
  
  