require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"


activity.setTitle('高斯模糊')
activity.setTheme(android.R.style.Theme_Material_Light_DarkActionBar)



--r=a(1-sinθ)
--偷的java代码改装的，原理我一窍不通



layout={
  LinearLayout;
  layout_width="fill";
  gravity="center";
  layout_height="fill";
  orientation="vertical";
  {
    ImageView;
    layout_width="200dp";
    layout_height="200dp";
    src="https://ws1.sinaimg.cn/large/006EqqThgy1fvw3rqgq7mj31xg143hdt.jpg";
  };
  {
    ImageView;
    layout_width="fill";
    layout_gravity="center";
    layout_height="fill";
    id="imageView";
  };
};

activity.setContentView(loadlayout(layout))


import "android.graphics.Matrix"
import "android.graphics.Bitmap"
import "android.renderscript.Allocation"
import "android.renderscript.Element"
import "android.renderscript.ScriptIntrinsicBlur"
import "android.renderscript.RenderScript"


function blur( context, bitmap, blurRadius)
  renderScript = RenderScript.create(context);
  blurScript = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
  inAllocation = Allocation.createFromBitmap(renderScript, bitmap);
  outputBitmap = bitmap;
  outAllocation = Allocation.createTyped(renderScript, inAllocation.getType());
  blurScript.setRadius(blurRadius);
  blurScript.setInput(inAllocation);
  blurScript.forEach(outAllocation);
  outAllocation.copyTo(outputBitmap);
  inAllocation.destroy();
  outAllocation.destroy();
  renderScript.destroy();
  blurScript.destroy();
  return outputBitmap;
end
bitmap=loadbitmap("https://ws1.sinaimg.cn/large/006EqqThgy1fvw3rqgq7mj31xg143hdt.jpg")
--Gaussian = blur(activity,bitmap,25) --模糊度 0 ~ 25
--imageView.setImageBitmap(Gaussian)



--高斯模糊加深
function blurAndZoom(context,bitmap,blurRadius,scale)
  return zoomBitmap(blur(context,zoomBitmap(bitmap, 1 / scale), blurRadius), scale);
end

function zoomBitmap(bitmap,scale)
  w = bitmap.getWidth();
  h = bitmap.getHeight();
  matrix = Matrix();
  matrix.postScale(scale, scale);
  bitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);
  return bitmap;
end


加深后的图片=blurAndZoom(activity,bitmap,25,4)
imageView.setImageBitmap(加深后的图片)
