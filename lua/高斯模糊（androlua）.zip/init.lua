appname="高斯模糊"
appver="1.0"
packagename="com.Gaussian.Blur"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
