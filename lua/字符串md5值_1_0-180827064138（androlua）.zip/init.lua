appname="字符串md5值"
appver="1.0"
packagename="com.androlua.dhk"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
