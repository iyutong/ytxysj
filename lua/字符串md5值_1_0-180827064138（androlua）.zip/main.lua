require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')
activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
--小绵羊233:1935528751
--[[
本来只是随便研究一下,没想到弄出来了
]]
function 字符md5值(str)
import "java.security.MessageDigest"
import "android.text.TextUtils"
import "java.lang.StringBuffer"
sb=StringBuffer();
import "java.lang.Byte"
md5=MessageDigest.getInstance("md5")
import "java.lang.Byte"
bytes =md5.digest(String(str).getBytes())
result=""
by=luajava.astable(bytes)
for k,n in ipairs(by) do 
  import "java.lang.Integer"
  temp = Integer.toHexString(n & 255);

  if #temp == 1 then
   sb.append("0")
  end
  sb.append(temp);
end
return sb
end
print(字符md5值("a"))
