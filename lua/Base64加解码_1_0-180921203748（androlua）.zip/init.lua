appname="Base64加解码"
appver="1.0"
packagename="com.androlua.demo"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
