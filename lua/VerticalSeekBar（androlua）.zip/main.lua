require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "com.yuxuan.widget.*"

import "layout"
activity.setContentView(loadlayout(layout))
