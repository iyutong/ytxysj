appname="圆形进度条"
appver="1.0"
packagename="com.myren.circleprogress"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
