appname="检查root权限"
appver="1.0"
packagename="com.six.checkroot"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
