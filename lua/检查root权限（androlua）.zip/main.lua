require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))

--检查root权限
function checkRoot() 
local root,exit,numb=os.execute("su")
if root==true then
  -- 已授予root权限
  return true
else
  -- 未授予root权限或者没有root权限
  return false
end
end

print(checkRoot())  




