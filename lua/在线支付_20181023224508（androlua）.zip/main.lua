require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "pay"

activity.setTheme(R.AndLua2)
activity.setTitle('在线支付')
activity.setContentView(loadlayout(layout))

ddh.setText(tostring(math.random(100000000000000,99999999999999999)))

wx.onClick=function()
  pay(ddh.Text,mc.Text,je.Text,"wx")
end

zfb.onClick=function()
  pay(ddh.Text,mc.Text,je.Text,"zfb")
end

qq.onClick=function()
  pay(ddh.Text,mc.Text,je.Text,"qq")
end