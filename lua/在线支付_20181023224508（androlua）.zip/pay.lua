function pay(ddh,mc,je,fs)
  llq.getSettings().setJavaScriptEnabled(true)
  if fs=="zfb" then
    dialog5= ProgressDialog(this)
    dialog5.setProgressStyle(ProgressDialog.STYLE_SPINNER)
    dialog5.setMessage("正在加载中")
    dialog5.setCancelable(true)
    dialog5.setCanceledOnTouchOutside(false)
    dialog5.show()
    a=0
    llq.setWebViewClient{
      shouldOverrideUrlLoading=function(view,url)
      end,
      onPageStarted=function(view,url,favicon)
      end,
      onPageFinished=function(view,url)
        a=a+1
        if a==4 then
          print("正在跳转支付宝")
          dialog5.hide()
        end
      end}
    llq.loadUrl("http://52ll.net/pay/epayapi.php?ddh="..ddh.."&mc="..mc.."&je="..je.."&fs=alipay")
   elseif fs=="qq" then
    dialog5= ProgressDialog(this)
    dialog5.setProgressStyle(ProgressDialog.STYLE_SPINNER)
    dialog5.setMessage("正在加载中")
    dialog5.setCancelable(true)
    dialog5.setCanceledOnTouchOutside(false)
    dialog5.show()
    a=0
    llq.setWebViewClient{
      shouldOverrideUrlLoading=function(view,url)
      end,
      onPageStarted=function(view,url,favicon)
      end,
      onPageFinished=function(view,url)
        a=a+1
        if a==4 then
          print("正在跳转QQ")
          dialog5.hide()
        end
      end}
    llq.loadUrl("http://52ll.net/pay/epayapi.php?ddh="..ddh.."&mc="..mc.."&je="..je.."&fs=qqpay")
   elseif fs=="wx" then
    print("我也不知道为什么微信支付会报错")
  end
end

function onKeyDown(c,e)
  if c==4 then
    activity.finish()
  end
end