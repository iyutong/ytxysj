require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"

activity.setContentView(loadlayout(layout))
if Build.VERSION.SDK_INT >= 19 then
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
end
--图片上色
img1.setColorFilter(0xffffffff)
RippleHelper(btn3).RippleColor=0x1CFFFFFF

function 复制文本(文本) --先导入包
  import "android.content.*"
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(文本)
end


video.setOnCompletionListener({
  onCompletion=function( p1)
    video.start();
  end});--这里感谢一下小明同学


btn3.onClick=function()
  --pop
  pop=PopupMenu(activity,fg)
  menu=pop.Menu

  menu.add("说明").onMenuItemClick=function(a)
    print"说明"
  end
  menu.add("退出").onMenuItemClick=function(a)
    activity.finish()
  end
  pop.show()
end
--渐变
import "android.graphics.drawable.GradientDrawable"
function 渐变(left_jb,right_jb,id)
  drawable = GradientDrawable(GradientDrawable.Orientation.TR_BL,{
    right_jb,--右色
    left_jb,--左色
  });
  id.setBackgroundDrawable(drawable)
end
--调用渐变函数
渐变(0xFFe55d87,0xff5fc3e4,menus)
渐变(0xFFe55d87,0xff5fc3e4,but)

--悬浮球
img1.onClick=function()
  --调用第三方应用选择视频
  import "android.content.Intent"
  local intent= Intent(Intent.ACTION_PICK)
  intent.setType("video/*")--格式视频
  this.startActivityForResult(intent, 1)
  -------
  --回调
  function onActivityResult(requestCode,resultCode,intent)
    if intent then
      local cursor =this.getContentResolver ().query(intent.getData(), nil, nil, nil, nil)
      cursor.moveToFirst()
      import "android.provider.MediaStore"
      local idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
      fileSrc = cursor.getString(idx)--回调视频路径
      bj.setVisibility(View.INVISIBLE)--控件不可视
      video.setVideoPath(fileSrc)--播放视频路径
      video.start();--播放视频
    end
  end--nirenr
end
