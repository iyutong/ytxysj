appname="仿一个木函搜索框"
appver="1.0"
packagename="小绵羊233.仿一个木函"
theme="Theme_DeviceDefault_Light_NoActionBar"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
