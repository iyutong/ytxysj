require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
import "android.view.Window"
import "android.view.WindowManager"
import "android.graphics.Color"
import "android.graphics.drawable.GradientDrawable"
--[[
GradientDrawable.Orientation.LEFT_RIGHT 渐变属性
LEFT_RIGHT 左往右
RIGHT_LEFT 右往左
TOP_BOTTOM 上往下
BOTTOM_TOP 下往上
]]
grad = GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT,{0xFF2EC4B6, 0xffffffff});
a.setBackground
(grad)

