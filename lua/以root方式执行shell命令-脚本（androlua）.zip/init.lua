appname="lua以root方式执行shell命令"
appver="1.0"
packagename="com.six.shell"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
