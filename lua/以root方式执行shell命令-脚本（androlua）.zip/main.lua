require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))



function exec(cmd,sh,su)
  cmd=tostring(cmd)
  if sh==true then
    cmd=io.open(cmd):read("*a")
  end
  if su==0 then
    p=io.popen(string.format('%s',cmd))
   else
    p=io.popen(string.format('%s',"su -c "..cmd))
  end
  local s=p:read("*a")
  p:close()
  return s
end


--exec("路径或者命令",true,0)
--传入第一个变量是sh脚本路径或者shell命令
--如果第一个变量是sh脚本路径，那么第二个传入true，如果不是，则传入false
--第三个变量代表是否以root权限执行，传入0，代表不以root权限执行





--返回信息=exec("ps",false)  --以root权限执行ps命令
返回信息=exec(activity.getLuaDir("shell.sh"),true,0)  --不以root权限执行工作目录下的shell.sh文件

tv.Text=返回信息  --返回的信息用文本控件显示出来


--丁小六 