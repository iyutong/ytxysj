require "import"
import "com.androlua.*"
import "android.text.*"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
--activity.setTitle('AndroLua+')
activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
import "Axs_plus"--导入模块
要高亮的代码={
  print=0xff0000ff,
  tw=0xff388E3C,
}
编辑框行数(edit,行数)
代码高亮(edit,要高亮的代码)
--[[------Android鑫少原创（编辑框行数非本人原创，我修复了一些bug）-----]]
--[[------╰Android_编程社╯群号：324065021-----]]
--[[------Android鑫少制作扣扣407944061-----]]
--[[------Android鑫少制作扣扣407944061-----]]