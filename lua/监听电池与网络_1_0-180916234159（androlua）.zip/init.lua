appname="监听电池与网络"
appver="1.0"
packagename="com.androlua.flili"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
