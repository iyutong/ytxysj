require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "android.content.Intent"
import "android.content.IntentFilter"
import "android.net.ConnectivityManager"
import "android.content.Context"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))

function isPlugged(intent)
  switch intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_UNKNOWN)
   case BatteryManager.BATTERY_STATUS_CHARGING
    if intent.getIntExtra("plugged",0)==BatteryManager.BATTERY_PLUGGED_AC then
      return "正在通过充电器充电中"
     else
      return "正在通过Usb接口充电中"
    end
   case BatteryManager.BATTERY_STATUS_DISCHARGING
    return "电池放电中"
   case BatteryManager.BATTERY_STATUS_NOT_CHARGING
    return "手机未充电"
   case BatteryManager.BATTERY_STATUS_FULL
    return "电池已充满"
  end
end

function isHealthy(intent)
  switch intent.getIntExtra("health", BatteryManager.BATTERY_HEALTH_UNKNOWN)
   case BatteryManager.BATTERY_HEALTH_GOOD
    return "电池良好"
   case BatteryManager.BATTERY_HEALTH_OVERHEAT
    return "电池过热"
   case BatteryManager.BATTERY_HEALTH_DEAD
    return "电量过低"
   case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE
    return "电压过高"
   default
    return "未知错误"
  end
end

onReceive=function(c,intent)
  --网络监听
  if intent.getAction()==ConnectivityManager.CONNECTIVITY_ACTION then
    cm =this.getSystemService(Context.CONNECTIVITY_SERVICE)
    info=cm.getActiveNetworkInfo()
    if info~=nil then
      types=info.getType()
      switch types
       case 0 --移动网络
        print("移动网络")
       case 1 --wifi
        print("wifi环境")
      end
     else
      print("无网络")
    end
  end
  --电量监听
  if intent.getAction()==Intent.ACTION_BATTERY_CHANGED then
    --剩余电量
    level=intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
    --总容量
    scale=intent.getIntExtra(BatteryManager.EXTRA_SCALE,0);
    levelPercent = ((level / scale) * 100);--取得电量百分比
    tv.Text="剩余电量："..Integer.toString(levelPercent).."%"..
    "\n最大电量："..scale..
    "\n剩余电量："..level..
    "\n电池电压："..intent.getIntExtra("voltage",0)/1000 .."v"..
    "\n电池温度："..intent.getIntExtra("temperature", 0)/10 .."℃"..
    "\n电池状态："..isPlugged(intent)..
    "\n健康状态："..isHealthy(intent)
  end
end
filter=IntentFilter() ;
filter.addAction(Intent.ACTION_BATTERY_CHANGED);
filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
this.registerReceiver(filter) ;
