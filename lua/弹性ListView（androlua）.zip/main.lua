require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import"com.isoftstone.listviewdemo.*"


import "layout"
activity.setContentView(loadlayout(layout))


--数据
数据={"a","b","c","d","e","f","g"}

--创建适配器对象
--将数据装到适配器,参数:上下文,提供好的模板,数据表
--[[
模板:
simple_list_item_1     单独的一行文本
simple_list_item_checked    选中的文本
simple_list_item_multiple_choice   带复选框的文本
simple_list_item_single_choice    带单选按钮的文本

]]
adapter=ArrayAdapter(activity,android.R.layout.simple_list_item_1,数据)

--拿到适配器所有数据,并显示GUI
lv.setAdapter(adapter)

--注意，好像不能用lua适配器，我也不知道怎么回事
