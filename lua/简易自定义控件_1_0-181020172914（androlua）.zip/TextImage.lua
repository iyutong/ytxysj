require "import"
import "android.widget.*"
import "android.view.*"
function TextImageView(view)--v是获取自己控件的信息
TextImageView=loadlayout{
    Button,--控件源
    background=view.src,
    Height=(view.height),
    Width=(view.width),
    id=view.id,  
    TextColor=view.textcolor,
    TextSize=view.size,    
    text=view.text,
    AllCaps=false,--关闭按钮英文自动变大写
      } 
    
   return function()
    return TextImageView 
  end
  end

