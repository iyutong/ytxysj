require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "TextImage"--在导入布局之前导入控件文件
import "layout"
activity.setTitle('自定义简易控件')
--小绵羊233
--1935528751
--( '▿ ' )
activity.setContentView(loadlayout(layout))
Toast.makeText(activity,"小绵羊233",Toast.LENGTH_SHORT).show()
tiview.onLongClick=function(v)
  Toast.makeText(activity,v.Text,Toast.LENGTH_SHORT).show()
return true
 end
tiview.onClick=function(v)
Toast.makeText(activity,"我是控件",Toast.LENGTH_SHORT).show()
 end
