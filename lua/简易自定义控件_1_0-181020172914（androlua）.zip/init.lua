appname="简易自定义控件"
appver="1.0"
packagename="com.小绵羊233.myview"
theme="Theme_DeviceDefault_Light_NoActionBar"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
