require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
activity.setTitle("MyApp")
--activity.setTheme(R.Theme_Google)
activity.setContentView(loadlayout"layout")

地图={
  [1]={"●","◇","●","●","●","●","●","●","●","●",},
  [2]={"●","●","●","●","●","●","●","●","●","●",},
  [3]={"●","●","●","●","●","●","●","●","●","●",},
  [4]={"●","●","●","●","●","●","●","●","●","●",},
  [5]={"●","●","●","●","●","●","●","●","●","●",},
  [6]={"●","●","●","●","●","●","●","●","●","●",},
  [7]={"●","●","●","●","●","●","●","●","●","●",},
  [8]={"●","●","●","●","●","●","●","●","●","●",},
  [9]={"●","●","●","●","●","●","●","●","●","●",},
  [10]={"●","●","●","●","●","●","●","●","●","●",},
}

x=5
y=2
function 地图画布()
  文本=""
  for i=1,5 do
    for m=1,5 do
      if i==y and m==x then
        文本=文本.."○"
        if i==1 and m==2 then
          print"这是隔壁老王家"
        end
      else
        文本=文本..地图[i][m]
      end
    end
    文本=文本.."\n"
  end
  地图id.text=文本
end

地图画布()
左.onClick=function()
  x=x-1
  地图画布()
end
右.onClick=function()
  x=x+1
  地图画布()
end
上.onClick=function()
  y=y-1
  地图画布()
end
下.onClick=function()
  y=y+1
  地图画布()
end

