require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.net.*"
import "android.app.AlertDialog"
import "android.graphics.drawable.BitmapDrawable"
import "org.json.JSONObject"
import "org.json.JSONArray"
import "java.io.File"
activity.setContentView("layout")

adp=LuaArrayAdapter(activity,{
  TextView,
  id="tv",
  textSize="14",
  paddingLeft="10dp",
  paddingRight="10dp",
  paddingTop="4dp",
  paddingBottom="4dp",
  layout_height="wrap",
})

list.adapter=adp

for n=1,0
  adp.add({tv="标签"..n})
end

list.onItemClick=function(l,v,i,p)
print(list)
--print(page)
  list.setSelection(i)
  page.showPage(i)
end

page.onPageChange=function(v,i)
  list.setSelection(i)
end

padp=ArrayPageAdapter()
for n=1,0
  padp.add(LuaEditor(){text="页面"..n})
end

page.adapter=(padp)


function create_open_dlg()
  if open_dlg then
    return
  end
  open_dlg = LuaDialog(activity)
  open_dlg.setTitle("打开")
  open_title = TextView(activity)
  listview = open_dlg.ListView
  listview.FastScrollEnabled = true

  listview.addHeaderView(open_title)
  listview.onItemClick = function(parent, v, pos, id)
    open(v.Text)
  end

  --open_dlg.setItems{"空"}
  --open_dlg.setContentView(listview)
end

function read(path)
  editor=LuaEditor()
  local f = io.open(path, "r")
  if f == nil then
    --Toast.makeText(activity, "打开文件出错."..path, Toast.LENGTH_LONG ).show()
    error()
    return
  end
  local str = f:read("*all")
  f:close()
  if string.byte(str) == 0x1b then
    Toast.makeText(activity, "不能打开已编译文件." .. path, Toast.LENGTH_LONG ).show()
    return
  end

  editor.setText(str)
  padp.add(editor)
  adp.add(path:match("[^/]+$"))
  task(200,function()
  page.showPage(padp.count-1)
  list.setSelection(adp.count-1)
  
  end)
end

luadir=activity.getLuaDir().."/"
function open(p)
  print(p)
  if p == luadir then
    return nil
  end
  if p:find("%.%./") then
    luadir = luadir:match("(.-)[^/]+/$")
    list_file(listview, luadir)
   elseif p:find("/") then
    luadir = luadir .. p
    list_file(listview, luadir)
   elseif p:find("%.alp$") then
    imports(luadir .. p)
    open_dlg.hide()
   else
    read(luadir .. p)
    open_dlg.hide()
  end
end

function sort(a, b)
  if string.lower(a) < string.lower(b) then
    return true
   else
    return false
  end
end

function adapter(t)
  return ArrayListAdapter(activity, android.R.layout.simple_list_item_1, String(t))
end

function list_file(v, p)
  local f = File(p)
  if not f then
    open_title.setText(p)
    local adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1, String {})
    v.setAdapter(adapter)
    return
  end

  local fs = f.listFiles()
  fs = fs or String[0]
  Arrays.sort(fs)
  local t = {}
  local td = {}
  local tf = {}
  if p ~= "/" then
    table.insert(td, "../")
  end
  for n = 0, #fs - 1 do
    local name = fs[n].getName()
    if fs[n].isDirectory() then
      table.insert(td, name .. "/")
     elseif name:find("%.lua$") or name:find("%.aly$") or name:find("%.alp$") then
      table.insert(tf, name)
    end
  end
  table.sort(td, sort)
  table.sort(tf, sort)
  for k, v in ipairs(tf) do
    table.insert(td, v)
  end
  open_title.setText(p)
  --local adapter=ArrayAdapter(activity,android.R.layout.simple_list_item_1, String(td))
  --v.setAdapter(adapter)
  open_dlg.setItems(td)
end

function onCreateOptionsMenu(menu)
  menu.add("打开").setShowAsAction(1)
end

function onOptionsItemSelected()
  create_open_dlg()
  list_file(listview, luadir)
  open_dlg.show()
end
read(activity.getLuaPath())
