appname="demo"
appver="1.0"
packagename="com.androlua.demo"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
