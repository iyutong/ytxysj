require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "android.support.v7.widget.*"
layout={
  LinearLayout,
  Orientation=1,
  {
    RecyclerView,
    id="recy",
    layout_height="wrap",
    layout_width="fill",
  },
  {
    Button,
    text="h",
    id="h",
  }
}
item={
  LinearLayout,
  layout_width="fill",
  {
    TextView,id="t",
    gravity="center",
    layout_height="80dp",
    layout_width="fill",
  }
}
activity.setContentView(loadlayout(layout))
import "com.LuaRecyclerAdapter"
import "com.LuaRecyclerHolder"
import "com.AdapterCreator"
data={}
adapter=LuaRecyclerAdapter(AdapterCreator({
  getItemCount = function()
    return #data
  end,
  getItemViewType = function(position) return 0 end,
  onCreateViewHolder = function(parent, viewType)
    local views={}
    holder=LuaRecyclerHolder(loadlayout(item,views))
    holder.view.setTag(views)
    views.t.onClick=function(v)
      adapter.notifyItemRemoved(tointeger(v.getTag()))
      table.remove(data,tointeger(v.getTag()))
    end
    return holder
  end,
  onBindViewHolder = function(holder, position)
    view=holder.view.getTag()
    view.t.Text=data[position+1]
    view.t.setTag(position)
  end,
}))
recy.setLayoutManager(GridLayoutManager(activity, 5))
recy.setAdapter(adapter)

data={"a"}

h.onClick=function(v)
  data={"a","b","c","d","e","f","g"}
  adapter.notifyDataSetChanged()
end


