require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('AndroLua+')

--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))


--文字渐变
import "com.nirenr.Color"
import "android.graphics.Color"
import "android.graphics.Shader"
import "android.graphics.LinearGradient"
shader = LinearGradient(
0, 0, 0, a.getTextSize(),
0xffff0000, 0xff00ff00,
Shader.TileMode.CLAMP);
a.getPaint().setShader(shader);






