require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
activity.setTitle('摩斯电码+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
import "android.graphics.PorterDuffColorFilter"
import "android.graphics.PorterDuff"

--修改按钮颜色
fy.getBackground().setColorFilter(PorterDuffColorFilter(0xFFFFFFFF,PorterDuff.Mode.SRC_ATOP))
电码表={
  ["A"]=".-",
  ["B"]="-...",
  ["C"]="-.-.",
  ["D"]="-..",
  ["E"]=".",
  ["F"]="..-.",
  ["G"]="--.",
  ["H"]="....",
  ["I"]="..",
  ["J"]=".---",
  ["K"]="-.-",
  ["L"]=".-..",
  ["M"]="--",
  ["N"]="-.",
  ["O"]="---",
  ["P"]=".--.",
  ["Q"]="--.-",
  ["R"]=".-.",
  ["S"]="...",
  ["T"]="-",
  ["U"]="..-",
  ["V"]="...-",
  ["W"]=".--",
  ["X"]="-..-",
  ["Y"]="-.--",
  ["Z"]="--..",
  ["1"]=".----",
  ["2"]="..---",
  ["3"]="...--",
  ["4"]="....-",
  ["5"]=".....",
  ["6"]="-....",
  ["7"]="--...",
  ["8"]="---..",
  ["9"]="----.",
  ["0"]="-----",
  ["."]=".-.-.-",
  [":"]="---...",
  [","]="--..--",
  [";"]="-.-.-.",
  ["?"]="..--..",
  ["="]="-...-",
  [" "]="..--.--",
  ["'"]=".----.",
  ["/"]="-..-.",
  ["!"]="-.-.--",
  ["-"]="-....-",
  ["_"]="..--.-",
  ['"']=".-..-.",
  ["("]="-.--.",
  ["%"]="..-.....",
  [")"]="-.--.-",
  ["+"]="..--.--",
}

function slg(str)
  return(utf8.len(str))
end

--按位置截取字符,-2表示倒数第二个
function sgg(s,i,j)
  i,j=tonumber(i),tonumber(j)
  i=utf8.offset(s,i)
  j=((j or -1)==-1 and -1) or utf8.offset(s,j+1)-1
  return string.sub(s,i,j)
end

--**********************************
import "java.net.URLEncoder"

function utf8_ms(s)
  s=URLEncoder.encode(s,"UTF8")
  s=string.upper(s)
  str=""
  str=电码表[sgg(s,1,1)]
  for n=2,slg(s) do
    str=str.." "..(电码表[sgg(s,n,n)] or "")
  end
  return str
end

function ms_utf8(s)
  import "java.net.URLDecoder"
  转化表={}
  zhstr=""
  for k,v in pairs(电码表) do 
    转化表[v]=k
  end
  s=string.gsub(s," ","。。")
  s="。"..s.."。"

  for v in s:gmatch("。(.-)。") do 
    zhstr=zhstr..(转化表[v] or "")
  end
  return string.lower(URLDecoder.decode(tostring(zhstr),"UTF8"))
end

uty=true

fy.onClick=function(v)
  if slg(utf.Text)<1 then
    Toast.makeText(activity,"你好懒啊",Toast.LENGTH_SHORT).show()
  else
    if uty then
     msdm.Text=utf8_ms(utf.Text)
     else
     msdm.Text=ms_utf8(utf.Text)
    end
  end
end

zh.onClick=function(v)
if uty then
  uty=false
  zh.Text="→"
  else
  uty=true
  zh.Text="←"
  end
--return true
 end

close.onClick=function(v)
utf.Text=""
 end

paste.onClick=function(v)
import "android.content.Context" 
--导入类

utf.Text=activity.getSystemService(Context.CLIPBOARD_SERVICE).getText() 
--获取剪贴板
 end

msdm.onLongClick=function(v)
import "android.content.Context"
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(v.Text) 
  Toast.makeText(activity,"已复制内容到粘贴板.",Toast.LENGTH_SHORT).show()
return true
 end