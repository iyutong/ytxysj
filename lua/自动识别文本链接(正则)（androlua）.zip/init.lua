appname="自动识别文本链接"
appver="1.0"
packagename="com.myren.texthtml"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
