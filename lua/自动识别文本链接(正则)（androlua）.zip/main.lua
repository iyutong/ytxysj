require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
--activity.setTitle('AndroLua+')
activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))


--使用正则表达式来识别链接，比以前写的那个效率好多了😅
--可能某些网址有识别不出的特殊字符，加一下正则表达式即可


--[[
Matcher类中常用的方法：
boolean matches()  //是否匹配成功
boolean find()  //查找匹配的下一个子序列
int start()  //返回以前匹配的初始索引
int end()  //返回最后匹配字符之后的偏移量
Matcher reset()  //重置匹配器
String group()  //返回由以前匹配操作所匹配的输入子序列
]]

--正则表达式的构造摘要：
--1.字符类 
--[abc]        //a、b 或 c（简单类） 
--[^abc]       //任何字符，除了 a、b 或 c（否定） 
--[a-zA-Z]     //a 到 z 或 A 到 Z，两头的字母包括在内（范围） 
--[a-d[m-p]]   //a 到 d 或 m 到 p：[a-dm-p]（并集） 
--[a-z&&[def]] //d、e 或 f（交集） 
--[[
2.预定义字符类 
.    //任何字符
\d   //数字：[0-9] 
\D   //非数字： [^0-9] 
\s   //空白字符：[ \t\n\x0B\f\r] 
\S   //非空白字符：[^\s] 
\w   //单词字符：[a-zA-Z_0-9] 
\W   //非单词字符：[^\w] 

3.边界匹配器 
^   //行的开头 
$   //行的结尾 
\b  //单词边界 
\B  //非单词边界 

4.Greedy 数量词 
X?       //X，一次或一次也没有 
X*       //X，零次或多次 
X+       //X，一次或多次 
X{n}     //X，恰好 n 次 
X{n,}    //X，至少 n 次 
X{n,m}   //X，至少 n 次，但是不超过 m 次 
]]



--导入包
import "java.util.regex.*"
import "android.text.Html"
import "android.text.method.LinkMovementMethod"

--使TextView支持点击超链接
text.setMovementMethod(LinkMovementMethod.getInstance())

text2=[[
这是百度https://www.baidu.com
这是下载http://androlua.cn/app/down/sp.apk
http://t.cn/2135.html
https://lol.qq.com
http://qq.com/login/
]]

pk=Pattern.compile("http(s)?://(www.)?[a-zA-Z_0-9]*.?[a-z]*(/[a-zA-Z_0-9]*)*[.]?[a-zA-Z_0-9]*");

while(true)
do
	nm=pk.matcher(text2)
	find=nm.find()
	if find==false then
	  break
    end
	--start=nm.start()
	host = nm.group()
	--oend=start+string.len(host)
	LUAstart,LUAend=string.find(text2,host)
	pending=string.gsub(host,"http","ht`tp")
	html='<a href="'..pending..'">'..pending..'</a>'
	text2=string.gsub(text2,host,html)
end

oktext=string.gsub(text2,"ht`tp","http")
oktext=string.gsub(oktext,"\n","<br />")
strend=Html.fromHtml(oktext)
text.Text=strend

