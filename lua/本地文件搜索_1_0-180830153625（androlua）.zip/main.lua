require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "java.io.*"
activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

--源码由炫明编写
--QQ3510088586
--感谢星尘，泥人，大表哥
layouts={
  LinearLayout;
  layout_height="-2";
  layout_width="-1";
  gravity="left";
  orientation="horizontal";
  {
    LinearLayout;
    layout_height="-2";
    layout_weight="1";
    gravity="center|left";
    orientation="vertical";
    {
      TextView;
      text="文件名：";
      id="wenjianmingpp";
      textSize="18sp";
    };
    {
      TextView;
      text="大小：";
      id="daxiaopp";
      textSize="18sp";
    };
    {
      TextView;
      text="路径：";
      id="lujingpp";
      textSize="18sp";
    };
  };
  {
    LinearLayout;
    layout_width="100dp";
    layout_height="100dp";
    orientation="vertical";
    {
      TextView;
      text="预览图：";
      layout_width="-1";
    };
    {
      ImageView;
      src="hg.png";
      layout_width="-1";
      layout_weight="1";
      id="yulantupp";
    };
  };
};

function gxg(wjm,dx,lj)
  adp.add{wenjianmingpp="文件名："..wjm,daxiaopp="大小："..tostring(dx).."MB",lujingpp="路径："..tostring(lj),yulantupp=tostring(lj)}
end

function qc()
  adp.clear()
  end

adp=LuaAdapter(activity,layouts)
liebiaoset.Adapter=adp

function xcxcxc(lj,wjm,dx)
  require "import"
  import "java.io.*"
  import "mk"

  function findf(lj,wjm,dx)

    local llj=File(tostring(lj)).listFiles()
    wwjm=tostring(wjm)
    ddx=tonumber(dx)

    for cishu=0,#llj-1 do
      ft=llj[cishu]
      if ft.isDirectory() then
        findf(ft,wjm,dx)
      else
        ghg=ft.Name

        if ghg:find(wwjm) then
          if ddx ~= 0 then
            if size(ft) >= ddx * 1024 then
              
              call("gxg",ghg,size(ft)/1024/1024,ft)
              print(size(ft))
              end
            else
            
            call("gxg",ghg,size(ft)/1024/1024,ft)
            end
        end
      end
    end
  end

  findf(lj,wjm,dx)
end

function sousuoset.onClick()
  a=lujingset.Text
  b=wenjianmingset.Text
  c=guolvdaxiaoset.Text
  
 if  a == "" then
    print("请填写好内容")
    elseif b == "" then
    print("请填写好内容")
    elseif c == "" then
    print("请填写好内容")
    else
    adp.clear()
    thread(xcxcxc,a,b,c)
    end
end

