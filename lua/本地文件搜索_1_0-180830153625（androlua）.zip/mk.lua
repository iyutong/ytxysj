require "import"
import "android.widget.*"
import "android.view.*"

function size(path)
  local f=io.open(tostring(path))
  local s=f:seek("end")
  f:close()
  return s
end
