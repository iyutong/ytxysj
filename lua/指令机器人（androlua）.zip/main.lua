require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "java.io.File"
import "layout"
--activity.setTitle('AndroLua+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))


--[[
by:逗孤荒
]]






function xwj(路径,内容)
  import "java.io.File"
  f=File(tostring(File(tostring(路径)).getParentFile())).mkdirs()
  io.open(tostring(路径),"w"):write(tostring(内容)):close()
end
function dwj(路径)
  文件内容=io.open(路径):read("*a")
  return 文件内容--return用来返回值
end
function sj(str,str1,str2)
  str1=str1:gsub("%p",function(s) return("%"..s) end)
  return(str:match(str1 .. "(.-)"..str2))
end
function strSplit(delimeter, str)
  local find, sub, insert = string.find, string.sub, table.insert
  local res = {}
  local start, start_pos, end_pos = 1, 1, 1
  while true do
    start_pos, end_pos = find(str, delimeter, start, true)
    if not start_pos then
      break
    end
    insert(res, sub(str, start, start_pos - 1))
    start = end_pos + 1
  end
  insert(res, sub(str,start))
  return res
end



layout={
  LinearLayout,
  layout_width="-1",
  layout_height="-1",
  id="db",
  orientation="vertical",
  {
    LinearLayout;
    orientation="vertical";
    id="s",
    layout_height="50dp";
    gravity="center";
    layout_width="fill";
    {
      Button;
      id="iop";
     -- layout_gravity="right|center";
      text="点击查看使用帮助";
    };
  };
  {
    LinearLayout,
    layout_width="-1",
    layout_height="-1",
    orientation="vertical",
    layout_weight="1",
    {
      ScrollView,
      layout_width="-1",
      layout_height="-1",
      fillViewport="true",
      id="scrollView",
      {
        LinearLayout,
        layout_width="-1",
        layout_height="-1",
        background="#00000000",
        orientation="vertical",
        paddingLeft="30dp",
        paddingRight="30dp",
        id="lt",
      },
    },
  },

  {
    LinearLayout,
    layout_width="100%w",
    layout_height="50dp",
    orientation="horizontal",
    {
      EditText,
      layout_width="80%w",
      layout_height="50dp",
      textSize="15sp",
      TextColor="#FFFFFF";
      hint="指令";
      id="et",
    },
    {
      Button,
      layout_width="20%w",
      layout_height="50dp",
      text="发送",
      textSize="13sp";
      textColor="#FFFFFF";
      onClick="jll",
      id="fs",
    },
  },
}

activity.setContentView(loadlayout(layout))



function jll()

  a=tostring(et.getText())
  arr = strSplit(" ",a);
  MeLayout={
    TextView,
    layout_width="-1",
    layout_height="50dp",
    Gravity="center|right",
    textSize="18sp",
    TextColor="#FFFFFF";
    text=a,
  }

  lt.addView(loadlayout(MeLayout))


  if #arr == 3 and arr[1]=="发短信" then
    RobotLayout=
    {
      TextView,
      layout_width="50%w",
      layout_height="-2",
      Gravity="center|left",
      textSize="18sp",
      text="发送中\n发送号码:"..arr[2].."\n发送内容:"..arr[3],
    }
    require "import"
    import "android.telephony.*"
    SmsManager.getDefault().sendTextMessage(tostring(arr[1]), nil, tostring(arr[2]), nil, nil)

    lt.addView(loadlayout(RobotLayout))

  end


  if #arr == 2 and arr[1]=="提示" then
    RobotLayout=
    
    {
      TextView,
      layout_width="50%w",
      layout_height="-2",
      Gravity="center|left",
      textSize="18sp",
      text="以提示:"..arr[2],
    }
    print(arr[2])
    lt.addView(loadlayout(RobotLayout))

  end

  if a=="获取IMEI" then
    import "android.content.Context"
    imei=activity.getSystemService(Context.TELEPHONY_SERVICE).getDeviceId()
    RobotLayout={
      TextView,
      layout_width="50%w",
      layout_height="-2",
      Gravity="center|left",
      textSize="18sp",
      text="本机imei为:"..imei,
    }


    lt.addView(loadlayout(RobotLayout))

  end

  if a=="获取设备识别码" then
    import "android.provider.Settings$Secure"
    android_id = Secure.getString(activity.getContentResolver(), Secure.ANDROID_ID)
     RobotLayout={
      TextView,
      layout_width="50%w",
      layout_height="-2",
      Gravity="center|left",
      textSize="18sp",
      text="本机id为:"..android_id,
    }


    lt.addView(loadlayout(RobotLayout))

  end



  if #arr == 3 and arr[1]=="弹出窗口" then
    RobotLayout={
      TextView,
      layout_width="50%w",
      layout_height="-2",
      Gravity="center|left",
      textSize="18sp",
      text="以弹出",
    }
    AlertDialog.Builder(this)
    .setTitle(arr[2])
    .setMessage(arr[3])
    .setPositiveButton("确定",nil)
    .setNeutralButton("取消",nil)

    .show()

    lt.addView(loadlayout(RobotLayout))

  end






  local nmj="/storage/sdcard0/onClick_OC/List.xml"
  local plkok=File(nmj).exists()
  --print(pdwjhl)
  if plkok==true then
    local yy = dwj("/storage/sdcard0/onClick_OC/List.xml")
    local time = os.date("%Y-%m-%d")
    local xz = yy.."["..a.."]".."<"..time..">@"
    xwj("/storage/sdcard0/onClick_OC/List.xml",xz)

   else
    local time = os.date("%Y-%m-%d")
    local xz = "["..a.."]".."<"..time..">"
    xwj("/storage/sdcard0/onClick_OC/List.xml",xz)

  end

  et.setText("")

  scrollView.fullScroll(ScrollView.FOCUS_DOWN);

end




iop.onClick=function(v)
  AlertDialog.Builder(this)
.setTitle("使用帮助")
.setMessage("指令如下:\n\n发送短信[空格]电话号码[空格]发送内容\n\n获取IMEI\n\n获取设备识别码\n\n弹出窗口[空格]标题[空格]内容\n\n提示[空格]内容\n\n在下方编辑框输入指令点击发送即可\n\n巨无霸无聊写的垃圾东西")
.setPositiveButton("积极",{onClick=function(v) print"点击了积极按钮"end})
.setNeutralButton("中立",nil)
.setNegativeButton("否认",nil)
.show()
end


view=db
color1 = 0xffFF8080;
color2 = 0xff8080FF;
color3 = 0xff80ffff;
color4 = 0xff80ff80;
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "android.animation.ValueAnimator"
import "android.graphics.Color"
colorAnim = ObjectAnimator.ofInt(view,"backgroundColor",{color1, color2, color3,color4})
colorAnim.setDuration(3000)
colorAnim.setEvaluator(ArgbEvaluator())
colorAnim.setRepeatCount(ValueAnimator.INFINITE)
colorAnim.setRepeatMode(ValueAnimator.REVERSE)
colorAnim.start()

view=s
color1 = 0xffFF8690;
color2 = 0xf06080FF;
color3 = 0xff80ffff;
color4 = 0xff899f80;
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "android.animation.ValueAnimator"
import "android.graphics.Color"
colorAnim = ObjectAnimator.ofInt(view,"backgroundColor",{color1, color2, color3,color4})
colorAnim.setDuration(3000)
colorAnim.setEvaluator(ArgbEvaluator())
colorAnim.setRepeatCount(ValueAnimator.INFINITE)
colorAnim.setRepeatMode(ValueAnimator.REVERSE)
colorAnim.start()


view=et
color1 = 0xffFF6680;
color2 = 0xff8069FF;
color3 = 0xff80f66f;
color4 = 0xff803580;
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "android.animation.ValueAnimator"
import "android.graphics.Color"
colorAnim = ObjectAnimator.ofInt(view,"backgroundColor",{color1, color2, color3,color4})
colorAnim.setDuration(3000)
colorAnim.setEvaluator(ArgbEvaluator())
colorAnim.setRepeatCount(ValueAnimator.INFINITE)
colorAnim.setRepeatMode(ValueAnimator.REVERSE)
colorAnim.start()

view=fs
color1 = 0xffFF1580;
color2 = 0xff8069FF;
color3 = 0xff8058ff;
color4 = 0xff874f80;
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "android.animation.ValueAnimator"
import "android.graphics.Color"
colorAnim = ObjectAnimator.ofInt(view,"backgroundColor",{color1, color2, color3,color4})
colorAnim.setDuration(3000)
colorAnim.setEvaluator(ArgbEvaluator())
colorAnim.setRepeatCount(ValueAnimator.INFINITE)
colorAnim.setRepeatMode(ValueAnimator.REVERSE)
colorAnim.start()