require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "android.view.animation.*"
import "java.lang.Math"
import "android.view.*"
import "com.androlua.Ticker"

import "android.graphics.Color"
import "layout"

activity.setContentView(loadlayout(layout))


--yuxuan高仿寒歌一个木寒启动动画



--分割状态栏，去除阴影效果,若想改颜色必用此效果
activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
--设置状态栏背景颜色
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xff1d8ae7);
--修改导航栏颜色
activity.getWindow().setNavigationBarColor(Color.parseColor("#ff1d8ae7"));

function 启动动画(显示时间,动画时间)

  dh1=Ticker()
  dh1.Period=显示时间
  dh1.start()
  dh1.onTick=function()
    dh1.stop()
    import "android.animation.AnimatorSet"
    animatorSet = AnimatorSet()
    animator1 = ViewAnimationUtils.createCircularReveal(qdt,activity.getWidth(),0,Math.hypot(activity.getWidth(),activity.getHeight())/2,0);
    animator2 = ViewAnimationUtils.createCircularReveal(qdy,0,activity.getHeight(),Math.hypot(activity.getWidth(),activity.getHeight())/2,0);
    animatorSet.setDuration(动画时间)
    animatorSet.playTogether({animator1,animator2})--两个动画同时开始
    animatorSet.start();
  end

  dh2=Ticker()
  dh2.Period=显示时间+动画时间
  dh2.start()
  dh2.onTick=function()
    dh2.stop()
    qdt.setVisibility(View.GONE)
    qdy.setVisibility(View.GONE)
  end
end


--接口
启动动画(1000,1000)

