require"import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
activity.setTitle("MyApp")
--activity.setTheme(R.Theme_Google)
activity.setContentView(loadlayout"layout")
layout={
  LinearLayout;
  {
    ImageView;
    id="iv";
    layout_width="50sp";
    layout_height="50sp";
    src="1.png";
  };
  {
    LinearLayout;
    {
      TextView;
      text="你好";
      layout_marginLeft="20sp";
      textSize="20sp";
      id="tv";
    };
    {
      TextView;
      layout_marginLeft="20sp";
      id="tv1";
      textSize="15sp";
      textColor="#ff777777";
      text="你好";
    };
    orientation="vertical";
  };
  layout_width="-1";
  orientation="horizontal";
  gravity="center|left";
};


adp=LuaAdapter(activity,layout)


import "android.content.pm.PackageManager"
pm = activity.getPackageManager();
applist=pm.getInstalledPackages(0);--获取本机所有安装程序信息table
--循环操作
a=0
while a~=#applist do
  app=tostring(applist[a])--读取table
  包名=app:match(" (.-)}")--截取包名
  pkg=pm.getApplicationInfo(tostring(包名),0)
  uid=pkg.uid --获取程序uid
  pkg1=pm.getPackageInfo(tostring(包名),0); 
  应用名称=pkg1.applicationInfo.loadLabel(activity.getPackageManager())--获取应用名称
  图标=pkg.loadIcon(pm);  --获取程序图标
  --获取更多应用信息请参考手册
  adp.add{iv=图标,tv="名称:"..应用名称.." UID:"..uid,tv1="包名:"..包名}--添加到列表
  a=a+1
end
listview.Adapter=adp--显示在列表

listview.onItemClick=function(parent, v, pos,id)--列表点击事件

end







