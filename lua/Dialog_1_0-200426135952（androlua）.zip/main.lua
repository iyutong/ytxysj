require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"

activity.setTheme(android.R.style.Theme_DeviceDefault_Light)
activity.setContentView(loadlayout(layout))

--[[  /**
 * Author:    Likefr
 * Version    V?.0
 * Date:      20/04/20 下午6:00
 * Description:
 * Modification  History:
 * Date     	Author   	Version        	Description
 * -----------------------------------------------------------------------------------
 * 20/4/24      Likefr        1.0               1.0
 Bug:   ~
 * Why & What is modified:
 *  *
 *@酷安Likefr
 * https://beautify.design
]]
--如需使用请保留以上所有信息  谢谢合作


import "Dialog"--导入

btn.onClick = function()
    Dialike()
            .setGravity("bottom|center")-- 设置对话框位置
    --.setWidth("fill","wrap")--第1个为宽度 第2个为高度。一般不用设置 他会自适应
            .setTitle("标题")
    --.setTitleColor(0xffff0000)
            .setMessage("退出")
    --.setMessageColor(0xffff0000)
            .setMessageSize("15dp")
           .setElevation("6dp")
            .setRadius("15dp")
            .setOutsideTouchable(false)--false设置外部区域不可点击。
            .setFocusable(true)--false 返回键直接终止该程序。默认为true 即允许返回键关闭对话框
            .setOutsideTouchable(false)--设置外部区域不可点击。
    --.setBackground(0xffff8080)--设置对话框底层背景
            .setCardBackground("#ffffffff")--设置对话框背景
            .setButtonSize(3, 20)--第1个参数为按钮 一共三个值分别 1-2-3  第2个为字体大小) 可重载
            .setPositiveButton("好的", function()
        this.finish() end)
            .setNegativeButton("取消", function()
        print("取消")
    end)
            .show()
end


--所有API都通用

ok.onClick = function()
    Dialike("toast", Ok)--
            .setGravity("bottom|center")
            .setMessage("正确对话框")
    --.setMessageColor(0xffffffff)
            .setMessageSize("15sp")
            .setRadius("3dp")
            .setElevation("10dp")
            .setFocusable(false)-- false为返回键直接终止该程序, true即允许返回键关闭对话框 默认为true false
            .setOutsideTouchable(true)--开启后可点击任意区域取消对话框。
    --.setImage("") --设置图片 不设置则默认。
            .show()
end

warning.onClick = function()
    Dialike("toast", Warning)
            .setGravity("bottom|center")
            .setMessage("警告对话框警告对话框警告对话框警告对话框警告对话框警告对话框警告对话框警告对话框")
    --.setMessageColor(0xffffffff)
            .setMessageSize("15sp")
            .setRadius("3dp")
            .setElevation("20dp")
    --以下两项 建议 设置false
            .setFocusable(false)-- false为返回键直接终止该程序, true即允许返回键关闭对话框 默认为true false
    --TODO 屏蔽返回键
            .setOutsideTouchable(true)--建议关闭
            .show()
end

err.onClick = function()
    Dialike("toast", Err)
            .setGravity("bottom|center")
            .setMessage("错误对话框\n这个对话框不可关闭")
            .setMessageColor(0xffd81e06)
            .setMessageSize("15sp")
            .setRadius("3dp")
            .setElevation("30dp")
    -- .setCardBackground("#ffff8080")
            .setFocusable(false)-- false为返回键直接终止该程序, true即允许返回键关闭对话框 默认为true false
            .setOutsideTouchable(false)--设置外部区域不可点击 建议关闭
    --.setImage("") --设置图片 不设置则默认。
            .show()
end







--还有很多API就不演示了 --所有API对话框都通用