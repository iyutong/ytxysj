require "import"
import "android.widget.LinearLayout"
import "android.widget.ProgressBar"
import "android.view.View"
--须把本工程libs目录下dex文件复制到你的工程才可使用
import "com.tencent.smtt.export.external.*"
import "com.tencent.smtt.export.external.extension.interfaces.*"
import "com.tencent.tbs.video.interfaces.*"
import "com.tencent.smtt.export.external.proxy.*"
import "com.tencent.smtt.export.external.extension.proxy.*"
import "com.tencent.smtt.export.external.interfaces.ConsoleMessage"
import "com.tencent.smtt.sdk.*"
import "com.lua.TbsWebView"--必导入此类
import "layout"

activity.setTitle('X5内核引用示例')
activity.setContentView(loadlayout(layout))

web.setWebChromeClient{
  onProgressChanged=function(v,progress)
    if progress==100 then
      pb.setVisibility(View.GONE)
    else
      pb.setVisibility(View.VISIBLE)
      pb.setProgress(progress)
    end
  end,
  onReceivedTitle=function(v,title)
    activity.setTitle(title)
  end,
}

web.getSettings().setBuiltInZoomControls(true)
web.getSettings().setDisplayZoomControls(false)
web.loadUrl("http://ctwhdh.xinti.cx/")