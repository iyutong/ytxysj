appname="X5内核引用示例 测试"
appver="1.0"
appcode="1"
appsdk="15"
path_pattern=""
packagename="com.newx5.encap"
theme="Theme_Holo_Light"
app_key=""
app_channel=""
developer=""
description=""
debugmode=true
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE"
}
