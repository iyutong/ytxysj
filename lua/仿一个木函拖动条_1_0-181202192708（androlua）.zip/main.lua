require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.graphics.PorterDuff"
import "android.view.*"
import "android.graphics.PorterDuffColorFilter"
import "layout"
activity.setTitle('小绵羊233+')
--activity.setTheme(android.R.style.Theme_Holo_Light)
activity.setContentView(loadlayout(layout))
--修改SeekBar滑条颜色
sb.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xFF2EC4B6,PorterDuff.Mode.SRC_ATOP))
--修改SeekBar滑块颜色
sb.Thumb.setColorFilter(PorterDuffColorFilter(0xFF2EC4B6,PorterDuff.Mode.SRC_ATOP))
--控件不可视
cv.setVisibility(View.INVISIBLE)
sb.onTouch=function(v,e) 
thex=e.getX()
 end
sb.setOnSeekBarChangeListener{
  onStartTrackingTouch=function()
import "android.view.animation.ScaleAnimation"
tv.setText(tostring(sb.getProgress()))
cv.setX(thex-cv.getWidth()/2)
cv.setVisibility(0)
cv.startAnimation(ScaleAnimation(0, 1, 0, 1, 0, thex, 1,1).setDuration(100))

--  cv.startAnimation(scale);
  end,
  onStopTrackingTouch=function()
cv.startAnimation(ScaleAnimation(1, 0, 1, 0, 0, thex, 1,1).setDuration(100))

    cv.setVisibility(View.INVISIBLE)
    --停止拖动
  end,
  onProgressChanged=function()
    --状态改变
    tv.setText(tostring(sb.getProgress()))
    cv.setX(thex-cv.getWidth()/2)
  end}
